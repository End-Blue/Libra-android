package com.libra.reader

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID
import org.json.JSONArray
import org.json.JSONObject

// ══════════════════════════════════════════════════════════════════════════════
// OPDS — modelos, catálogos curados, cliente y descargas
// ══════════════════════════════════════════════════════════════════════════════

data class OpdsCatalog(
    val id: String,
    val name: String,
    val url: String,
    val description: String = "",
    val language: String = "",
    val curated: Boolean = false
)

data class OpdsLink(
    val href: String,
    val rel: String = "",
    val type: String = "",
    val title: String = ""
)

data class OpdsEntry(
    val id: String,
    val title: String,
    val authors: List<String> = emptyList(),
    val summary: String = "",
    val published: String = "",
    val language: String = "",
    val coverUrl: String? = null,
    val links: List<OpdsLink> = emptyList(),
    val categories: List<String> = emptyList()
) {
    val authorText: String get() = authors.joinToString(", ").ifBlank { "Autor desconocido" }

    /** Mejor enlace de descarga (prioriza EPUB). */
    fun bestDownload(): OpdsLink? {
        val downloads = links.filter {
            val r = it.rel.lowercase()
            val t = it.type.lowercase()
            r.contains("acquisition") || t.contains("epub") || t.contains("pdf") ||
                t.contains("octet-stream") || r == "http://opds-spec.org/acquisition"
        }
        return downloads.firstOrNull { it.type.contains("epub", true) }
            ?: downloads.firstOrNull { it.href.contains(".epub", true) }
            ?: downloads.firstOrNull { it.type.contains("pdf", true) }
            ?: downloads.firstOrNull()
    }

    fun navigationLink(): OpdsLink? =
        links.firstOrNull { it.rel == "subsection" || it.rel == "http://opds-spec.org/sort/popular" ||
            it.rel.contains("subsection") || (it.type.contains("atom") && !it.rel.contains("acquisition")) }
}

data class OpdsFeed(
    val title: String = "",
    val entries: List<OpdsEntry> = emptyList(),
    val nextUrl: String? = null,
    val searchUrl: String? = null
)

/** Catálogos de dominio público de alta calidad, listos para usar. */
object OpdsCatalogs {
    val CURATED = listOf(
        OpdsCatalog(
            id = "standard_ebooks",
            name = "Standard Ebooks",
            url = "https://standardebooks.org/feeds/opds",
            description = "Clásicos cuidadosamente tipografiados y corregidos. EPUB de excelente calidad.",
            language = "en",
            curated = true
        ),
        OpdsCatalog(
            id = "gutenberg",
            name = "Project Gutenberg",
            url = "https://www.gutenberg.org/ebooks/search.opds/?query=the",
            description = "El mayor archivo de libros de dominio público del mundo. Usa la búsqueda para encontrar títulos.",
            language = "multi",
            curated = true
        ),
        OpdsCatalog(
            id = "internet_archive",
            name = "Internet Archive",
            url = "https://bookserver.archive.org/catalog/",
            description = "Millones de libros digitalizados. Busca por título o autor.",
            language = "multi",
            curated = true
        ),
        OpdsCatalog(
            id = "feedbooks_pd",
            name = "Feedbooks (dominio público)",
            url = "https://www.feedbooks.com/catalog/public_domain.atom",
            description = "Selección de clásicos de dominio público en varios idiomas.",
            language = "multi",
            curated = true
        ),
        OpdsCatalog(
            id = "manybooks",
            name = "ManyBooks",
            url = "https://manybooks.net/opds/index.php",
            description = "Amplio catálogo de libros libres en múltiples formatos.",
            language = "en",
            curated = true
        )
    )

    private const val PREFS = "libra_opds"
    private const val KEY_CUSTOM = "custom_catalogs"
    private const val KEY_RECENT = "recent_downloads"
    private const val KEY_LAST_CATALOG = "last_catalog_id"

    private fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(PREFS, 0)

    fun custom(ctx: Context): List<OpdsCatalog> {
        val raw = prefs(ctx).getString(KEY_CUSTOM, "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                OpdsCatalog(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    url = o.getString("url"),
                    description = o.optString("description", ""),
                    language = o.optString("language", ""),
                    curated = false
                )
            }
        }.getOrDefault(emptyList())
    }

    fun all(ctx: Context): List<OpdsCatalog> = CURATED + custom(ctx)

    fun saveCustom(ctx: Context, list: List<OpdsCatalog>) {
        val arr = JSONArray()
        list.forEach { c ->
            arr.put(JSONObject().apply {
                put("id", c.id)
                put("name", c.name)
                put("url", c.url)
                put("description", c.description)
                put("language", c.language)
            })
        }
        prefs(ctx).edit().putString(KEY_CUSTOM, arr.toString()).apply()
    }

    fun addCustom(ctx: Context, name: String, url: String, description: String = ""): OpdsCatalog {
        val cleanUrl = url.trim().let { if (it.startsWith("http")) it else "https://$it" }
        val cat = OpdsCatalog(
            id = "custom_${UUID.randomUUID().toString().take(8)}",
            name = name.trim().ifBlank { "Catálogo personalizado" },
            url = cleanUrl,
            description = description.trim(),
            curated = false
        )
        val list = custom(ctx).toMutableList()
        list.add(0, cat)
        saveCustom(ctx, list)
        return cat
    }

    fun removeCustom(ctx: Context, id: String) {
        saveCustom(ctx, custom(ctx).filter { it.id != id })
    }

    fun lastCatalogId(ctx: Context): String? =
        prefs(ctx).getString(KEY_LAST_CATALOG, null)

    fun setLastCatalogId(ctx: Context, id: String) {
        prefs(ctx).edit().putString(KEY_LAST_CATALOG, id).apply()
    }

    data class RecentDownload(
        val title: String,
        val author: String,
        val catalogName: String,
        val at: Long,
        val coverUrl: String? = null
    )

    fun recentDownloads(ctx: Context): List<RecentDownload> {
        val raw = prefs(ctx).getString(KEY_RECENT, "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                RecentDownload(
                    title = o.getString("title"),
                    author = o.optString("author", ""),
                    catalogName = o.optString("catalog", ""),
                    at = o.optLong("at", 0L),
                    coverUrl = o.optString("cover", null)
                )
            }
        }.getOrDefault(emptyList())
    }

    fun pushRecent(ctx: Context, entry: OpdsEntry, catalogName: String) {
        val list = recentDownloads(ctx).toMutableList()
        list.removeAll { it.title == entry.title && it.author == entry.authorText }
        list.add(0, RecentDownload(
            title = entry.title,
            author = entry.authorText,
            catalogName = catalogName,
            at = System.currentTimeMillis(),
            coverUrl = entry.coverUrl
        ))
        val trimmed = list.take(30)
        val arr = JSONArray()
        trimmed.forEach { r ->
            arr.put(JSONObject().apply {
                put("title", r.title)
                put("author", r.author)
                put("catalog", r.catalogName)
                put("at", r.at)
                if (r.coverUrl != null) put("cover", r.coverUrl)
            })
        }
        prefs(ctx).edit().putString(KEY_RECENT, arr.toString()).apply()
    }
}

object OpdsClient {

    private const val UA = "Libellum/0.9.10 (Android; OPDS)"
    private const val TIMEOUT = 18_000

    suspend fun fetchFeed(url: String): Result<OpdsFeed> = withContext(Dispatchers.IO) {
        runCatching {
            val text = openUrl(url)
            parseFeed(text, url)
        }
    }

    suspend fun search(baseSearchOrCatalogUrl: String, query: String): Result<OpdsFeed> = withContext(Dispatchers.IO) {
        runCatching {
            val q = query.trim()
            if (q.isEmpty()) error("Consulta vacía")
            val encoded = URLEncoder.encode(q, "UTF-8")
            val target = when {
                baseSearchOrCatalogUrl.contains("{searchTerms}") ->
                    baseSearchOrCatalogUrl.replace("{searchTerms}", encoded)
                baseSearchOrCatalogUrl.contains("search.opds") ->
                    "https://www.gutenberg.org/ebooks/search.opds/?query=$encoded"
                baseSearchOrCatalogUrl.contains("standardebooks.org") ->
                    "https://standardebooks.org/feeds/opds?query=$encoded"
                baseSearchOrCatalogUrl.contains("archive.org") ->
                    "https://bookserver.archive.org/catalog/search?q=$encoded"
                baseSearchOrCatalogUrl.endsWith("/") ->
                    "${baseSearchOrCatalogUrl}search?q=$encoded"
                else ->
                    "$baseSearchOrCatalogUrl?query=$encoded"
            }
            parseFeed(openUrl(target), target)
        }
    }

    /**
     * Descarga el mejor archivo del entry y lo deja en [destDir].
     * Devuelve el File resultante o lanza.
     */
    suspend fun downloadEntry(
        entry: OpdsEntry,
        destDir: File,
        onProgress: ((Float) -> Unit)? = null
    ): File = withContext(Dispatchers.IO) {
        val link = entry.bestDownload() ?: error("Este libro no tiene enlace de descarga")
        val href = absoluteUrl(link.href, entry.id)
        val ext = when {
            link.type.contains("epub", true) || href.contains(".epub", true) -> "epub"
            link.type.contains("pdf", true) || href.contains(".pdf", true) -> "pdf"
            link.type.contains("fb2", true) -> "fb2"
            else -> "epub"
        }
        val safeName = entry.title
            .replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .take(80)
            .ifBlank { "libro" }
        val out = File(destDir, "${safeName}_${System.currentTimeMillis()}.$ext")
        downloadFile(href, out, onProgress)
        out
    }

    private fun openUrl(urlStr: String): String {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            connectTimeout = TIMEOUT
            readTimeout = TIMEOUT
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", UA)
            setRequestProperty("Accept", "application/atom+xml, application/xml, text/xml, */*")
        }
        return try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                ?: error("HTTP $code")
            stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun downloadFile(urlStr: String, dest: File, onProgress: ((Float) -> Unit)?) {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            connectTimeout = TIMEOUT
            readTimeout = 60_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", UA)
        }
        try {
            if (conn.responseCode !in 200..299) error("HTTP ${conn.responseCode}")
            val total = conn.contentLengthLong.coerceAtLeast(0L)
            BufferedInputStream(conn.inputStream).use { input ->
                FileOutputStream(dest).use { output ->
                    val buf = ByteArray(16 * 1024)
                    var read = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n <= 0) break
                        output.write(buf, 0, n)
                        read += n
                        if (total > 0 && onProgress != null) {
                            onProgress((read.toFloat() / total).coerceIn(0f, 1f))
                        }
                    }
                }
            }
            onProgress?.invoke(1f)
        } finally {
            conn.disconnect()
        }
    }

    private fun absoluteUrl(href: String, baseHint: String): String {
        if (href.startsWith("http://") || href.startsWith("https://")) return href
        // Intento simple de resolución relativa
        return try {
            URL(URL(baseHint), href).toString()
        } catch (_: Exception) {
            href
        }
    }

    // ── Parser Atom / OPDS ────────────────────────────────────────────────────

    private fun parseFeed(xml: String, baseUrl: String): OpdsFeed {
        val factory = XmlPullParserFactory.newInstance().apply { isNamespaceAware = true }
        val parser = factory.newPullParser()
        parser.setInput(xml.reader())

        var feedTitle = ""
        var nextUrl: String? = null
        var searchUrl: String? = null
        val entries = mutableListOf<OpdsEntry>()

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                when (parser.name.lowercase()) {
                    "title" -> {
                        // Solo el título del feed (antes de entries)
                        if (entries.isEmpty() && feedTitle.isEmpty()) {
                            feedTitle = parser.nextText().trim()
                        }
                    }
                    "link" -> {
                        val rel = parser.attr("rel")
                        val href = parser.attr("href")
                        val type = parser.attr("type")
                        if (href.isNotBlank()) {
                            when {
                                rel == "next" -> nextUrl = resolve(href, baseUrl)
                                rel.contains("search") || type.contains("opensearch") ->
                                    searchUrl = resolve(href, baseUrl)
                            }
                        }
                    }
                    "entry" -> {
                        entries.add(parseEntry(parser, baseUrl))
                    }
                }
            }
            event = parser.next()
        }
        return OpdsFeed(
            title = feedTitle.ifBlank { "Catálogo" },
            entries = entries,
            nextUrl = nextUrl,
            searchUrl = searchUrl
        )
    }

    private fun parseEntry(parser: XmlPullParser, baseUrl: String): OpdsEntry {
        var id = ""
        var title = ""
        var summary = ""
        var published = ""
        var language = ""
        val authors = mutableListOf<String>()
        val links = mutableListOf<OpdsLink>()
        val categories = mutableListOf<String>()
        var cover: String? = null

        var event = parser.next()
        while (!(event == XmlPullParser.END_TAG && parser.name.equals("entry", true))) {
            if (event == XmlPullParser.START_TAG) {
                when (parser.name.lowercase()) {
                    "id" -> id = parser.nextText().trim()
                    "title" -> title = parser.nextText().trim()
                    "summary", "content" -> {
                        val t = parser.nextText().trim()
                        if (t.isNotBlank() && summary.isBlank()) summary = stripHtml(t)
                    }
                    "published", "updated", "dc:date" -> {
                        if (published.isBlank()) published = parser.nextText().trim().take(10)
                    }
                    "dc:language", "language" -> language = parser.nextText().trim()
                    "name" -> { // author/name
                        val n = parser.nextText().trim()
                        if (n.isNotBlank()) authors.add(n)
                    }
                    "author" -> {
                        // puede contener <name>
                    }
                    "category" -> {
                        val term = parser.attr("label").ifBlank { parser.attr("term") }
                        if (term.isNotBlank()) categories.add(term)
                    }
                    "link" -> {
                        val href = parser.attr("href")
                        val rel = parser.attr("rel")
                        val type = parser.attr("type")
                        val linkTitle = parser.attr("title")
                        if (href.isNotBlank()) {
                            val abs = resolve(href, baseUrl)
                            links.add(OpdsLink(abs, rel, type, linkTitle))
                            // Portada típica OPDS
                            if (rel.contains("image") || rel.contains("thumbnail") ||
                                rel == "http://opds-spec.org/image" ||
                                rel == "http://opds-spec.org/image/thumbnail" ||
                                type.startsWith("image/")
                            ) {
                                if (cover == null || rel.contains("image") && !rel.contains("thumbnail")) {
                                    cover = abs
                                }
                            }
                        }
                    }
                }
            }
            event = parser.next()
        }

        if (id.isBlank()) id = title.ifBlank { UUID.randomUUID().toString() }
        return OpdsEntry(
            id = id,
            title = title.ifBlank { "Sin título" },
            authors = authors.distinct(),
            summary = summary,
            published = published,
            language = language,
            coverUrl = cover,
            links = links,
            categories = categories.distinct()
        )
    }

    private fun XmlPullParser.attr(name: String): String {
        for (i in 0 until attributeCount) {
            if (getAttributeName(i).equals(name, true)) return getAttributeValue(i) ?: ""
        }
        // namespaces
        for (i in 0 until attributeCount) {
            if (getAttributeName(i).substringAfter(':').equals(name, true))
                return getAttributeValue(i) ?: ""
        }
        return ""
    }

    private fun resolve(href: String, base: String): String {
        if (href.startsWith("http://") || href.startsWith("https://")) return href
        return try { URL(URL(base), href).toString() } catch (_: Exception) { href }
    }

    private fun stripHtml(s: String): String =
        s.replace(Regex("<[^>]+>"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(600)
}
