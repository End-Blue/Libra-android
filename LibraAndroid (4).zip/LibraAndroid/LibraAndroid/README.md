# Libellum — Android 0.8.9

## Novedades 0.9.0 — Vitrina (expositor libre)
La pestaña **Estantería** ahora abre la **Vitrina**: un expositor donde cada libro y objeto se coloca donde quieras. Usa tus libros en 3D (`Shelf3D.kt`). La estantería clásica sigue disponible en «Vitrina ▾ → Otros → Estantería clásica» (y vuelves con el chip «✨ Vitrina»).
- **Tocar un libro** lo selecciona y abre una barra inferior: papelera (quitar de la vitrina), candado, «···» (ficha, leer, al frente/fondo, dejar como nuevo), deshacer, rehacer y ✓.
- **Cara**: Lomo · Portada · Canto (páginas). «Editar» (solo con lomo/canto) cambia color, grosor y altura del lomo.
- **Escala**: deslizador de 0,5× a 2× y atajos S / M / L.
- **Orientación**: de pie, tumbado, girar 90° y deslizador libre de −180° a 180°. Los libros inclinados se apoyan por su esquina.
- **Arrastrar libremente**: al soltar, el libro cae y se apoya en la balda o encima de un libro tumbado (torres); si el sitio está ocupado busca el hueco más cercano. Mientras arrastras se ve con línea discontinua dónde se apoyará. La vista se desplaza sola cerca de los bordes.
- **+ → De tu biblioteca**: hoja con buscador, filtros (Todos, Favoritos, Leyendo, Por leer, Terminados) y selección múltiple; luego «Toca una balda para colocar». También importar libros o buscarlos en el teléfono.
- **Decorar**: «Añadir objeto» con 26 objetos en 6 categorías (10 nuevos: monstera, helecho, bonsái, orquídea, suculentas, pampas, ramo seco, terrario, piedras, farol), tamaño, candado, papelera y deshacer. Los objetos se apoyan en baldas y libros y viajan con el libro que los lleva.
- **Menú «Vitrina ▾»**: Personalizar (taller de madera, pared, luz…), Decorar, Crear con asistente (✨), Organización (ordenar por título/autor/lectura/recientes; todos de portada, de lomo o mezcla realista), Baldas (añadir/quitar, bajas/normales/altas) y Otros.
- **Asistente**: monta la vitrina solo con los libros que elijas (todos, favoritos, leyendo, por leer, terminados), en portadas, lomos o mezcla, con pocos o muchos objetos. La primera vez se llena sola.
- Deshacer/rehacer hasta 40 pasos. Todo se guarda en el teléfono (clave `xp_board`); la base de datos no cambia.

Proyecto Android nativo con Kotlin, Jetpack Compose, Room y Media3.

## Novedades 0.8.9 — Libros en 3D en la estantería
- **Libros con volumen**: de pie se ve el lomo y la portada girada a la derecha (deformada en perspectiva) con las páginas arriba; acostados y en torre se ve el lomo al frente, la portada en la cara superior y el canto de páginas a la derecha; de frente llevan canto de páginas lateral y superior.
- **Nada de la lógica cambia**: el recuadro de cada libro mide lo mismo que antes (la profundidad se dibuja dentro del mismo ancho y solo sobresale unos dp por arriba), así que colocación, huecos, torres, gravedad, arrastre, editor y adornos funcionan igual.
- Los libros más altos se dibujan por encima de los de abajo para que la cara superior de una torre no tape al libro que va encima.
- Código nuevo en `Shelf3D.kt`; en `MainActivity.kt` solo se enganchó `ShelfBook` y se añadieron parámetros opcionales a `SpineFace`/`FrontFace`.

## Novedades 0.8.8 — Estantería minimalista
- **Barra superior de una sola fila**: «Mi estantería», buscar, Filtros y menú «···». Se acabaron las filas de botones, el buscador fijo y las 6 listas de filtros: los filtros viven en una hoja y el resto de acciones (Ordenar, Todos de frente/de pie/acostados, Mezcla, Añadir adorno, Adornos del tema) en el menú «···».
- **Editor de libro compacto y fijo abajo**: ya no tapa la estantería, así ves el cambio en vivo. Mantiene todo lo tuyo (Portada, De pie, Acostado, Torre; tamaño rápido S/M/L/XL/Automático; alto y ancho; color del lomo; Abrir; Listo).
- **Nuevo «Mover en la balda»** con flechas ◀ ▶ (8 dp por toque, respetando colisiones y gravedad). No aparece en torres.
- **Nuevo «Ajuste fino»** plegable con Altura y Grosor del lomo; el tamaño elegido queda marcado.
- La lógica de colocación (huecos, torres, gravedad, adornos) no se ha tocado.

## Novedades 0.8.7 — Torres con límite y gravedad por balda
- **Cada libro tiene su espacio**: de pie, acostado, portada o torre, ningún libro se monta encima o detrás de otro. Al soltarlo se queda en la balda donde lo sueltas, usa el hueco libre más cercano de esa balda y, si no hay hueco, vuelve a su sitio (no salta a otras baldas ni roba espacio). Lo mismo al cambiar de postura desde el editor.
- **Orden automático**: si por datos antiguos había libros solapados o sin apoyo, la estantería los reubica sola en un hueco de su balda.
- **Nuevo panel «Armar torre»** con el papel, los bordes finos y el dorado de la app: 4 huecos con las portadas elegidas (toca una para quitarla) y botones Cancelar / Hacer torre.
- **Se quita el aviso «Libro movido»** (y su «Deshacer»). Solo avisa cuando una torre ya está completa.
- **Las baldas no se mueven entre sí**: todas tienen la misma altura, así que crear o cambiar una torre arriba ya no sube/baja las de abajo.
- **Torres y libros siempre apoyados**: si una balda cambia de sitio (se añade/quita una fila, cambia un tamaño), libros, torres y adornos se mueven con su balda y no quedan en el aire. Al cambiar la postura de un libro (de pie ⇄ acostado) conserva su base apoyada.
- **Sin reacomodos**: al crear una torre o mover un libro, los demás libros se quedan donde están (no se meten delante o detrás de otros).
- **«Torre» ya no está en la barra «Todos»**: solo aparece al tocar un libro para editarlo (sección «Cómo se ve»).
- **Cada torre es individual**: al crear una torre solo cuentan los libros que elijas (máx. 4); no se suma a las torres ya hechas, se coloca en un hueco libre de **la balda del libro que editas** y no sube ni baja a otras baldas. Si no hay hueco, avisa.
- **Se quita la postura «Inclinado»**: ya no existe en la estantería. Los libros que la tenían guardada pasan a estar de pie.
- **Torres de máximo 4 libros** (`MAX_STACK_BOOKS`): al completarse la cuarta capa, la torre se cierra; el siguiente libro empieza una columna nueva al lado, sobre la misma tabla.
  - Al **soltar un libro sobre una torre completa** no se apila: se apoya en la balda junto a ella y aparece el aviso «Torre completa (máx. 4)» con Deshacer.
  - **«Hacer torre / Crear pila»** con más de 4 libros los reparte en varias torres contiguas; ya no se colocan a una altura fija.
  - La colocación automática también parte las pilas largas en columnas de 4.
- **Gravedad estricta**: las torres nuevas nacen apoyadas en el tope de la madera de la balda del primer libro elegido, y se limita su altura para que no toquen el techo de la balda.
- Cada balda sigue siendo independiente: solo se mueven los libros elegidos; el resto de torres, adornos, lomos y portadas no se tocan.

## Novedades 0.8.6
- **Pilas de libros (STACK) más robustas** (guía de geometría y aislamiento de estado):
  - Proporciones exactas: al tumbar un libro, su altura original pasa a ser la anchura horizontal y el grosor del lomo la altura de cada capa.
  - Anclaje firme a la balda (sin flotación): el libro inferior apoya el canto inferior en la madera; los de encima se apilan con interlineado 0.
  - **Aislamiento entre torres**: al modificar o crear una pila no se reinician ni reordenan las demás. Agrupación por proximidad de X cuando hay posiciones guardadas.
  - Sincronización de posición más estable: un libro con shelfX/Y explícito no salta cuando se actualiza otra torre.

## Novedades 0.8.5
- **Estantería libre mejorada** (feedback como en vídeos de referencia):
  - Al arrastrar un libro se muestran **huecos de balda con línea discontinua** y el libro arrastrado lleva contorno punteado.
  - Tras soltar: snackbar **«Libro movido»** con acción **Deshacer**.
  - **Pila en la propia estantería**: toca los libros que quieras y pulsa **Apilarlos** (torre sin interlineado).
  - Al soltar un libro encima de otro tumbado se **apila automáticamente** (pose STACK, sin hueco).
  - Grosor de pila más compacto para torres realistas.

## Novedades 0.8.4
- **Estantería realista** (como imagen de referencia): posturas Portada, De pie, Acostado, **Pila** (torre horizontal de libros tumbados) e **Inclinado**.
- Botón **Mezcla**: reparte verticales + pilas + inclinados en la misma balda.
- Botón **Pila**: selector de libros → torre centrada automática, sin solapes.
- Lector EPUB: texto multilínea vertical tipo Kindle (no una sola línea horizontal).

## Novedades 0.8.2
- **Imágenes en EPUB**: rutas reescritas en HTML y en CSS (`url(...)`), visibilidad forzada y re-medida de páginas al cargar cada imagen.
- Paginación reflowable de EPUB: columnas del ancho de pantalla, continuidad real del texto entre hojas.

## Novedades 0.8.1
- **Adornos arrastrables** en la estantería «Libre»: botón «+ Añadir» (16 adornos), tócalos para editarlos, mantén pulsado para moverlos (ya seleccionados se arrastran directamente).
- Edición del adorno: **tamaño** (×0,5 a ×3), **color** (14 colores u «Original»), **cambiar de adorno**, **duplicar** y **eliminar**.
- Al soltarlos se **apoyan solos** sobre una balda o sobre el canto superior de un libro (también libros acostados y apilados); si mueves el libro, el adorno que tiene encima se mueve con él.
- «Los del tema» devuelve los adornos del tema elegido. Posiciones, tamaños y colores se guardan en el teléfono.
- **Lector EPUB corregido**: ya no se reparte cada título en una hoja casi vacía («HOMERO», «POR»…). Se neutralizan los saltos de página forzados, alturas fijas, posiciones absolutas y márgenes enormes del propio libro, y se vuelve a medir el número de hojas cuando cargan imágenes.

## Novedades 0.8.0 — Taller de estantería
- Botón «🎨 Personalizar» en Estanterías, con vista previa en vivo y 7 pestañas: Temas, Madera, Pared, Lomos, Letra, Decoración y Luz.
- 17 maderas y acabados, 3 grosores de balda y 3 estructuras (solo balda, laterales, escuadras).
- 12 paredes (rayas, ladrillo, rombos, paneles, corcho, lino, cielo estrellado…).
- 10 paletas de lomos, 6 materiales (cuero cosido, tela, relieve, brillante, rústico…), 5 adornos de lámina y 6 colores de lámina.
- 10 tipos de letra, mayúsculas, 3 tamaños y color del título; marca de progreso en el lomo.
- 16 objetos decorativos dibujados a mano (planta, vela, globo, gato, búho…) y 6 luces (cálida, fría, atardecer, lámpara, guirnalda).
- 8 temas listos para aplicar. Color del lomo libro por libro (Ajustar lomos).
- Los ajustes se guardan en el teléfono y valen para las vistas Lomos, Portadas y Libre.

## Novedades 0.7.0
- Texto de TXT/FB2 y EPUB visible (arreglado color del texto y etiquetas autocerradas del EPUB).
- Interfaz nueva «papel»: Panel con racha, Biblioteca con filtros y detalle del libro, Favoritos, Racha, menú «Más».
- Estanterías por categoría (portadas o lomos, tamaños S/M/L, ajustar lomos) y modo libre.
- Reto de lectura, Resumen y exportar CSV.
- Widget «Mi estantería» para la pantalla de inicio.

## Funciones
- Biblioteca local (Room): importación múltiple de EPUB, PDF, TXT, FB2, CBZ y CBR, y de audiolibros MP3, M4A, M4B, AAC, OGG, OPUS, WAV y FLAC. Cada archivo se copia al almacenamiento privado de la app.
- Escáner automático: con el permiso «Acceso a todos los archivos» (documentos y libros), Libellum busca EPUB, PDF, TXT, FB2 y CBZ en todo el teléfono y la SD, con filtro por tipo. Se abre solo la primera vez.
- Portadas y metadatos automáticos (EPUB, PDF, CBZ, FB2 y audio).
- Lector: EPUB, PDF, TXT, FB2 y CBZ, con modo de scroll vertical o pasar hoja, tamaño de letra y temas. Guarda por dónde ibas. CBR se importa pero aún no se lee.
- Subrayados y notas por libro, con colores pastel y vista global en la pestaña «Notas».
- Al seleccionar texto en un EPUB aparece «Copiar · Diccionario · Subrayar»; los subrayados se ven pintados en la página.
- EPUB con hojas reales (columnas): se pasa de hoja deslizando, tocando los bordes o con las flechas; los enlaces del índice funcionan.
- Iconos propios dibujados a mano (sin librerías de iconos).
- Estantería con posturas: de frente, de pie, acostado, pila horizontal e inclinado; botón Mezcla para layout realista; se mueven manteniendo pulsado.
- Audiolibros con reproducción en segundo plano, ±15/30 s, velocidad y posición guardada.
- Favoritos, búsqueda por título o autor y separador de página.
- Biblioteca en lista, cuadrícula o estantería con movimiento libre de los libros.
- Copias de seguridad exportables (.zip) con libros, audios, portadas, progreso, favoritos, orden de la estantería y notas.

## Limitaciones conocidas
- CBR (RAR) no se lee todavía.
- En EPUB se guarda el capítulo, no la posición exacta dentro del capítulo.
- Los EPUB con DRM no se abren.
- Android no permite elegir la carpeta «Descargas» completa en el escáner; para esos archivos usa «Importar».

## Compilar
- Android Studio Ladybug o posterior, JDK 17, Android SDK 35.
- Sin Android Studio: sube `LibellumAndroid.zip` y el workflow `.github/workflows/build.yml` a GitHub; el APK sale en Actions → artefacto `app-debug`.
