@file:OptIn(ExperimentalMaterial3Api::class)

package com.libra.reader

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

@Composable
internal fun BookshelvesScreen(
    books: List<LibraryItem>,
    onBackToVitrina: (() -> Unit)? = null,
    freeShelf: @Composable (ShelfStyle) -> Unit
) {
    val ctx = LocalContext.current
    var style by remember { mutableStateOf(ShelfStyleStore.load(ctx)) }
    var studio by remember { mutableStateOf(false) }

    if (books.isEmpty()) {
        EmptyFeature("TU ESTANTERÍA ESTÁ VACÍA", "Importa libros y aquí los verás ordenados en baldas de madera.")
        return
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (onBackToVitrina != null) ModeChip("✨ Vitrina", false) { onBackToVitrina() }
            ModeChip("🎨 Personalizar", true) { studio = true }
        }
        Box(Modifier.weight(1f)) { freeShelf(style) }
    }

    if (studio) {
        ShelfStudioSheet(
            style = style,
            onChange = { st -> style = st; ShelfStyleStore.save(ctx, st) },
            onDismiss = { studio = false }
        )
    }
}

@Composable
private fun ModeChip(text: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected, onClick = onClick,
        label = { Text(text, fontSize = 12.sp) },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = Gold, selectedLabelColor = Ink, labelColor = Cream
        )
    )
}
