package com.libra.reader

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Días en los que leíste (se guardan como fechas yyyy-MM-dd en las preferencias). */
object Streak {
    private const val PREFS = "libra_prefs"
    private const val KEY = "read_days"

    fun key(cal: Calendar = Calendar.getInstance()): String =
        String.format(
            Locale.US, "%04d-%02d-%02d",
            cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH)
        )

    fun days(ctx: Context): Set<String> =
        HashSet(ctx.getSharedPreferences(PREFS, 0).getStringSet(KEY, emptySet()) ?: emptySet())

    fun markToday(ctx: Context) {
        val p = ctx.getSharedPreferences(PREFS, 0)
        val set = HashSet(p.getStringSet(KEY, emptySet()) ?: emptySet())
        if (set.add(key())) p.edit().putStringSet(KEY, set).apply()
    }

    /** Días seguidos hasta hoy (si hoy aún no lees, cuenta desde ayer). */
    fun current(days: Set<String>): Int {
        val c = Calendar.getInstance()
        if (key(c) !in days) c.add(Calendar.DAY_OF_YEAR, -1)
        var n = 0
        while (key(c) in days) {
            n++
            c.add(Calendar.DAY_OF_YEAR, -1)
        }
        return n
    }

    fun best(days: Set<String>): Int {
        if (days.isEmpty()) return 0
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val nums = days.mapNotNull { d ->
            runCatching { Math.round((fmt.parse(d)?.time ?: 0L) / 86400000.0) }.getOrNull()
        }.sorted()
        var best = 0
        var run = 0
        var prev = Long.MIN_VALUE
        for (n in nums) {
            run = if (prev != Long.MIN_VALUE && n == prev + 1) run + 1 else 1
            if (run > best) best = run
            prev = n
        }
        return best
    }

    /** Lunes a domingo de la semana actual: (inicial, fecha). */
    fun weekKeys(): List<Pair<String, String>> {
        val labels = listOf("L", "M", "X", "J", "V", "S", "D")
        val c = Calendar.getInstance()
        val back = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7
        c.add(Calendar.DAY_OF_YEAR, -back)
        return labels.map { l ->
            val k = key(c)
            c.add(Calendar.DAY_OF_YEAR, 1)
            l to k
        }
    }

    fun goal(ctx: Context): Int = ctx.getSharedPreferences(PREFS, 0).getInt("year_goal", 12)
    fun setGoal(ctx: Context, g: Int) {
        ctx.getSharedPreferences(PREFS, 0).edit().putInt("year_goal", g.coerceIn(1, 365)).apply()
    }
}
