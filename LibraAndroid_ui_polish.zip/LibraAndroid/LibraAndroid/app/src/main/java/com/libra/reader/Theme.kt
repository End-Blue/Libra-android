package com.libra.reader

import androidx.compose.ui.graphics.Color

// ── Paleta Libellum «papel»: fondo crema, texto azul tinta y acento dorado ───
internal val Ink    = Color(0xFFF5EFE3)  // fondo (papel)
internal val Panel  = Color(0xFFFFFBF2)  // tarjetas
internal val Cream  = Color(0xFF1B2A41)  // texto principal (azul tinta)
internal val Gold   = Color(0xFF9A6B1F)  // acento dorado/ocre
internal val Muted  = Color(0xFF7B8798)  // texto secundario
internal val Line   = Color(0xFFE5DAC3)  // bordes finos
internal val WoodLight = Color(0xFFB98D5C)
internal val WoodDark  = Color(0xFF86592F)
internal val ShelfBack = Color(0xFFEADFC6)

// ── Colores pastel para subrayado ───────────────────────────────────────────
internal val HighlightYellow  = Color(0xFFFFF176)
internal val HighlightGreen   = Color(0xFFB9F6CA)
internal val HighlightBlue    = Color(0xFFB3E5FC)
internal val HighlightPink    = Color(0xFFF8BBD0)
internal val HighlightLavender= Color(0xFFE1BEE7)
internal val HighlightPeach   = Color(0xFFFFCCBC)

val HIGHLIGHT_COLORS = listOf(
    0xFFFFF176L to "Amarillo",
    0xFFB9F6CAL to "Verde",
    0xFFB3E5FCL to "Azul",
    0xFFF8BBD0L to "Rosa",
    0xFFE1BEE7L to "Lavanda",
    0xFFFFCCBCL to "Melocotón"
)
