@file:OptIn(ExperimentalMaterial3Api::class)

package com.libra.reader

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlin.math.roundToInt

// ══════════════════════════════════════════════════════════════════════════════
// Adornos que se arrastran por la estantería libre: mover, agrandar, colorear,
// cambiar de tipo, duplicar y eliminar. Se apoyan solos sobre baldas y libros.
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Copia del adorno con otro tamaño y/o tipo, conservando el centro de su base:
 * así, si estaba apoyado sobre una balda o un libro, sigue apoyado al agrandarlo.
 */
internal fun PlacedDeco.resized(newScale: Float = scale, newKey: String = key): PlacedDeco {
    val old = decoOf(key)
    val nw = decoOf(newKey)
    val s = newScale.coerceIn(DECO_MIN_SCALE, DECO_MAX_SCALE)
    if (old == null || nw == null) return copy(key = newKey, scale = s)
    val cx = x + old.w * scale / 2f
    val bottom = y + old.h * scale
    return copy(
        key = newKey,
        scale = s,
        x = (cx - nw.w * s / 2f).coerceAtLeast(0f),
        y = (bottom - nw.h * s).coerceAtLeast(0f)
    )
}

/**
 * Un adorno colocado en la estantería libre.
 * Seleccionado se arrastra directamente; sin seleccionar, hay que mantenerlo pulsado
 * (así deslizar el dedo por la estantería sigue haciendo scroll).
 */
@Composable
internal fun ShelfDecoItem(
    deco: PlacedDeco,
    areaW: Int,
    areaH: Int,
    isSelected: Boolean,
    onSelect: () -> Unit,
    snap: (Float, Float, Float, Float) -> Pair<Float, Float>,
    onCommit: (Float, Float) -> Unit
) {
    val def = decoOf(deco.key) ?: return
    val density = LocalDensity.current
    val px = density.density
    val wPx = def.w * deco.scale * px
    val hPx = def.h * deco.scale * px
    val maxX = (areaW - wPx).coerceAtLeast(0f)
    val maxY = (areaH - hPx).coerceAtLeast(0f)
    var x by remember(deco.id, deco.x, deco.scale, deco.key, areaW) {
        mutableFloatStateOf((deco.x * px).coerceIn(0f, maxX))
    }
    var y by remember(deco.id, deco.y, deco.scale, deco.key, areaH) {
        mutableFloatStateOf((deco.y * px).coerceIn(0f, maxY))
    }
    var dragging by remember { mutableStateOf(false) }
    val hit = 8.dp                                  // zona táctil extra alrededor de los adornos pequeños
    val hitPx = with(density) { hit.roundToPx() }

    fun finishDrag() {
        dragging = false
        val snapped = snap(x, y, wPx, hPx)
        x = snapped.first.coerceIn(0f, maxX)
        y = snapped.second.coerceIn(0f, maxY)
        onCommit(x / px, y / px)
    }

    Box(
        Modifier
            .offset { IntOffset(x.roundToInt() - hitPx, y.roundToInt() - hitPx) }
            .zIndex(if (dragging) 25f else if (isSelected) 15f else 5f)
            .pointerInput(deco.id, isSelected, maxX, maxY) {
                if (isSelected) {
                    detectDragGestures(
                        onDragStart = { dragging = true },
                        onDragEnd = { finishDrag() },
                        onDragCancel = { dragging = false }
                    ) { change, drag ->
                        change.consume()
                        x = (x + drag.x).coerceIn(0f, maxX)
                        y = (y + drag.y).coerceIn(0f, maxY)
                    }
                } else {
                    detectDragGesturesAfterLongPress(
                        onDragStart = { dragging = true; onSelect() },
                        onDragEnd = { finishDrag() },
                        onDragCancel = { dragging = false }
                    ) { change, drag ->
                        change.consume()
                        x = (x + drag.x).coerceIn(0f, maxX)
                        y = (y + drag.y).coerceIn(0f, maxY)
                    }
                }
            }
            .clickable { onSelect() }
            .padding(hit)
    ) {
        DecoView(
            def,
            modifier = if (isSelected) Modifier.border(1.5.dp, Gold, RoundedCornerShape(4.dp)) else Modifier,
            tint = deco.color?.let { Color(it) },
            scale = deco.scale
        )
    }
}

@Composable
private fun DecoChip(text: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected, onClick = onClick,
        label = { Text(text, fontSize = 12.sp) },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = Gold, selectedLabelColor = Ink, labelColor = Cream
        )
    )
}

/** Panel para editar el adorno elegido: tamaño, color, tipo, duplicar y eliminar. */
@Composable
internal fun DecoEditorPanel(
    deco: PlacedDeco,
    onChange: (PlacedDeco) -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
    onDone: () -> Unit,
    asSheetContent: Boolean = false
) {
    val def = decoOf(deco.key) ?: return
    val body: @Composable () -> Unit = {
        Column(
            Modifier
                .fillMaxWidth()
                .then(if (asSheetContent) Modifier.padding(horizontal = 16.dp).padding(bottom = 28.dp) else Modifier.padding(14.dp)),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(56.dp), contentAlignment = Alignment.Center) {
                    DecoView(def, tint = deco.color?.let { Color(it) }, scale = 0.8f)
                }
                Column(Modifier.weight(1f).padding(start = 8.dp)) {
                    Text(def.label, color = Cream, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text(
                        "Arrástralo para moverlo. Se apoya solo sobre baldas y libros.",
                        color = Muted, fontSize = 11.sp, lineHeight = 15.sp
                    )
                }
            }

            Text("Tamaño: ×${"%.1f".format(deco.scale)}", color = Muted, fontSize = 12.sp)
            Slider(
                value = deco.scale,
                onValueChange = { onChange(deco.resized(newScale = it)) },
                valueRange = DECO_MIN_SCALE..DECO_MAX_SCALE,
                colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold)
            )

            Text("Color", color = Muted, fontSize = 12.sp)
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                DecoChip("Original", deco.color == null) { onChange(deco.copy(color = null)) }
                DECO_COLORS.forEach { (_, argb) ->
                    val on = deco.color == argb
                    Box(
                        Modifier.size(28.dp).clip(CircleShape).background(Color(argb))
                            .border(if (on) 3.dp else 1.dp, if (on) Gold else Line, CircleShape)
                            .clickable { onChange(deco.copy(color = argb)) }
                    )
                }
            }

            Text("Cambiar adorno", color = Muted, fontSize = 12.sp)
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                DECOS.forEach { d ->
                    val on = d.key == deco.key
                    Box(
                        Modifier.size(48.dp).clip(RoundedCornerShape(10.dp))
                            .border(if (on) 2.dp else 1.dp, if (on) Gold else Line, RoundedCornerShape(10.dp))
                            .clickable { if (!on) onChange(deco.resized(newKey = d.key)) },
                        contentAlignment = Alignment.Center
                    ) {
                        DecoView(d, scale = 0.65f)
                    }
                }
            }

            Spacer(Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = onDuplicate, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Cream)
                ) { Text("Duplicar", fontSize = 12.sp, maxLines = 1) }
                OutlinedButton(
                    onClick = onDelete, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFB3261E))
                ) { Text("Eliminar", fontSize = 12.sp, maxLines = 1) }
                Button(
                    onClick = onDone, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)
                ) { Text("Listo", fontSize = 12.sp, maxLines = 1) }
            }
        }
    }
    if (asSheetContent) {
        body()
    } else {
        Card(
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) { body() }
    }
}

/** Catálogo para añadir un adorno nuevo a la estantería. */
@Composable
internal fun DecoPickerDialog(onPick: (DecoDef) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Añadir adorno", color = Cream, fontSize = 16.sp) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                DECOS.chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { d ->
                            Column(
                                Modifier.weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .border(1.dp, Line, RoundedCornerShape(10.dp))
                                    .clickable { onPick(d) }
                                    .padding(vertical = 8.dp, horizontal = 2.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(Modifier.height(64.dp), contentAlignment = Alignment.BottomCenter) { DecoView(d) }
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    d.label, color = Muted, fontSize = 10.sp, maxLines = 1,
                                    overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
                                )
                            }
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar", color = Gold) } }
    )
}
