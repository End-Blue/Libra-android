@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.libra.reader

import android.Manifest
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.zIndex
import androidx.glance.appwidget.updateAll
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    // Libro que pide abrir el widget de la estantería
    private val openRequest = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        openRequest.value = intent?.getStringExtra("open_book_id")
        setContent { LibraApp(openRequest) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        openRequest.value = intent.getStringExtra("open_book_id")
    }
}

@Composable
fun LibraApp(openRequest: MutableState<String?>) {
    val context = LocalContext.current
    val db = remember { LibraryDatabase.get(context) }
    val dao = remember { db.libraryDao() }
    val highlightDao = remember { db.highlightDao() }

    val itemsFlow = remember { dao.observeAll() }
    val highlightsFlow = remember { highlightDao.observeAll() }
    val allItems by itemsFlow.collectAsState(initial = emptyList())
    val allHighlights by highlightsFlow.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    val controller by rememberMediaController()
    PlaybackPersistence(controller, dao)

    val prefs = remember { context.getSharedPreferences("libra_prefs", 0) }
    var showTutorial by remember { mutableStateOf(!prefs.getBoolean("tutorial_done", false)) }

    var selectedTab by remember { mutableStateOf("Panel") }
    var viewMode by remember { mutableStateOf("LISTA") }
    var status by remember { mutableStateOf("Libellum guarda tu biblioteca en este dispositivo.") }
    var busy by remember { mutableStateOf(false) }
    var opened by remember { mutableStateOf<LibraryItem?>(null) }
    var showScanner by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var editingHighlight by remember { mutableStateOf<Highlight?>(null) }
    var days by remember { mutableStateOf(Streak.days(context)) }
    var detailId by remember { mutableStateOf<String?>(null) }
    var showMore by remember { mutableStateOf(false) }
    var goal by remember { mutableIntStateOf(Streak.goal(context)) }

    // El widget pide abrir un libro concreto
    LaunchedEffect(openRequest.value, allItems) {
        val id = openRequest.value
        if (id != null) {
            allItems.firstOrNull { it.id == id }?.let {
                opened = it
                openRequest.value = null
            }
        }
    }
    // Se refresca el widget solo cuando cambia lo que muestra (no en cada página leída)
    val shelfSignature = remember(allItems) {
        allItems.joinToString("|") { it.id + it.isFavorite + it.statusKey() + (it.coverPath ?: "") }
    }
    LaunchedEffect(shelfSignature) { runCatching { ShelfWidget().updateAll(context) } }

    // ── Primera vez: se abre el escáner, que pide el permiso de documentos y detecta los libros solo ──
    var autoScanAsked by remember { mutableStateOf(prefs.getBoolean("auto_scan_asked", false)) }
    LaunchedEffect(showTutorial, autoScanAsked) {
        if (!showTutorial && !autoScanAsked) {
            showScanner = true
            autoScanAsked = true
            prefs.edit().putBoolean("auto_scan_asked", true).apply()
        }
    }

    // ── Lanzadores ────────────────────────────────────────────────────────────
    val bookPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            busy = true; status = "Importando…"
            status = withContext(Dispatchers.IO) {
                importUris(context.contentResolver, context.filesDir, uris, "BOOK", dao)
            }
            busy = false
        }
    }
    val audioPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            busy = true; status = "Importando audio…"
            status = withContext(Dispatchers.IO) {
                importUris(context.contentResolver, context.filesDir, uris, "AUDIO", dao)
            }
            busy = false
        }
    }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) scope.launch {
            busy = true; status = "Creando copia de seguridad…"
            status = Backup.export(context, dao, highlightDao, uri); busy = false
        }
    }
    val restoreLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) scope.launch {
            busy = true; status = "Restaurando copia de seguridad…"
            status = Backup.restore(context, dao, highlightDao, uri); busy = false
        }
    }

    val csvLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) scope.launch {
            busy = true; status = "Exportando CSV…"
            status = exportCsv(context, allItems.filter { it.mediaType == "BOOK" }, uri); busy = false
        }
    }

    // Antes de borrar se pide confirmación (un toque sin querer no debe borrar un libro)
    var pendingDelete by remember { mutableStateOf<LibraryItem?>(null) }
    val onDelete: (LibraryItem) -> Unit = { item -> pendingDelete = item }

    // ── Tutorial ──────────────────────────────────────────────────────────────
    if (showTutorial) {
        TutorialScreen(onFinish = {
            showTutorial = false
            prefs.edit().putBoolean("tutorial_done", true).apply()
        })
        return
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            background = Ink, surface = Panel, primary = Gold,
            onBackground = Cream, onSurface = Cream, onPrimary = Ink,
            surfaceVariant = Panel, onSurfaceVariant = Muted, outline = Line
        )
    ) {
        val current = opened
        if (current != null) {
            if (current.mediaType == "AUDIO") {
                AudioPlayerScreen(current, controller, onClose = { opened = null })
            } else {
                ReaderScreen(
                    item = current,
                    onClose = { opened = null },
                    onSave = { position, progress ->
                        scope.launch {
                            dao.updateProgress(current.id, position, progress)
                            val now = System.currentTimeMillis()
                            if (progress > 0) dao.markStarted(current.id, now)
                            if (progress >= 97) dao.markFinished(current.id, now)
                        }
                        Streak.markToday(context)
                        days = Streak.days(context)
                    },
                    highlightDao = highlightDao,
                    onUpdateItem = { updated -> scope.launch { dao.update(updated) } }
                )
            }
        } else {
            val toggleFav: (LibraryItem) -> Unit = { item ->
                scope.launch { dao.setFavorite(item.id, if (item.isFavorite == 1) 0 else 1) }
            }
            val books = allItems.filter { it.mediaType == "BOOK" }
            val filteredBooks = if (searchQuery.isBlank()) books
            else books.filter {
                it.title.contains(searchQuery, ignoreCase = true) ||
                    it.author.contains(searchQuery, ignoreCase = true)
            }
            // Biblioteca (lista) e Estantería intercambiadas: la pestaña principal abre la estantería
            val navItems = listOf("Panel", "Estantería", "Favoritos", "Racha", "Más")

            Scaffold(
                containerColor = Ink,
                bottomBar = {
                    NavigationBar(containerColor = Panel, contentColor = Cream) {
                        navItems.forEach { tab ->
                            val selected = if (tab == "Más") (showMore || selectedTab !in navItems) else selectedTab == tab
                            val tint = if (selected) Gold else Muted
                            NavigationBarItem(
                                selected = selected,
                                onClick = { if (tab == "Más") showMore = true else selectedTab = tab },
                                icon = {
                                    when (tab) {
                                        "Panel" -> LibIcon(LibIconKind.HOME, tint = tint, size = 24.dp, filled = selected)
                                        "Estantería" -> LibIcon(LibIconKind.SHELF, tint = tint, size = 24.dp, filled = selected)
                                        "Favoritos" -> LibIcon(LibIconKind.STAR, tint = tint, size = 24.dp, filled = selected)
                                        "Racha" -> Text("🔥", fontSize = 20.sp)
                                        else -> LibIcon(LibIconKind.LIST, tint = tint, size = 24.dp, filled = selected)
                                    }
                                },
                                label = { Text(tab, fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Gold, selectedTextColor = Gold,
                                    indicatorColor = Ink, unselectedIconColor = Muted,
                                    unselectedTextColor = Muted
                                )
                            )
                        }
                    }
                }
            ) { padding ->
                Column(
                    Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)
                ) {
                    // Nombre de la app siempre arriba a la izquierda, sin solaparse
                    Spacer(Modifier.height(10.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "LIBELLUM",
                            color = Gold,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 3.sp,
                            maxLines = 1
                        )
                        Spacer(Modifier.weight(1f))
                        if (selectedTab != "Panel") {
                            LibIconButton(LibIconKind.HELP, onClick = { showTutorial = true }, tint = Muted)
                        }
                    }
                    if (selectedTab != "Panel") {
                        Text(
                            when (selectedTab) {
                                "Estantería", "Estanterías", "Biblioteca" ->
                                    if (selectedTab == "Biblioteca") "Tu biblioteca" else "Mis estanterías"
                                "Favoritos" -> "Tus favoritos"
                                "Racha" -> "Racha de lectura"
                                "Notas" -> "Notas y citas"
                                "Audio" -> "Audiolibros"
                                "Reto" -> "Reto de lectura"
                                "Resumen" -> "Tu resumen"
                                else -> "Ajustes"
                            },
                            color = Cream, fontSize = 22.sp, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(8.dp))
                    } else {
                        Spacer(Modifier.height(6.dp))
                    }

                    // Buscador solo en la lista de libros (Biblioteca)
                    if (selectedTab == "Biblioteca") {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Buscar por título o autor…", color = Muted, fontSize = 14.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Cream, unfocusedTextColor = Cream,
                                focusedBorderColor = Gold, unfocusedBorderColor = Line,
                                focusedContainerColor = Panel, unfocusedContainerColor = Panel
                            ),
                            leadingIcon = { LibIcon(LibIconKind.SEARCH, tint = Muted, size = 20.dp) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty())
                                    LibIconButton(LibIconKind.CLOSE, onClick = { searchQuery = "" }, tint = Muted, iconSize = 18.dp)
                            },
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = {})
                        )
                        Spacer(Modifier.height(8.dp))
                    }

                    when (selectedTab) {
                        "Panel" -> DashboardScreen(
                            books = books, days = days, status = status, busy = busy,
                            onMarkToday = { Streak.markToday(context); days = Streak.days(context) },
                            onOpen = { opened = it },
                            onDetail = { detailId = it.id },
                            onImport = { bookPicker.launch(arrayOf("*/*")) },
                            onScan = { showScanner = true }
                        )
                        // Estantería en la pestaña principal (intercambiada con biblioteca)
                        "Estantería", "Estanterías" -> BookshelvesScreen(
                            books = books,
                            onDetail = { detailId = it.id },
                            onSpineSize = { id, w, h -> scope.launch { dao.setSpineSize(id, w, h) } },
                            freeShelf = { st ->
                                ShelfScreen(
                                    books = books,
                                    onOpen = { detailId = it.id },
                                    onSetPose = { id, pose -> scope.launch { dao.setShelfPose(id, pose) } },
                                    onSetAllPoses = { pose ->
                                        scope.launch {
                                            dao.setAllShelfPoses(pose)
                                            dao.resetShelfPositions()
                                        }
                                    },
                                    onMove = { id, x, y -> scope.launch { dao.updateShelfPosition(id, x, y) } },
                                    onReset = { scope.launch { dao.resetShelfPositions() } },
                                    style = st,
                                    onSpineSize = { id, w, h -> scope.launch { dao.setSpineSize(id, w, h) } }
                                )
                            }
                        )
                        "Biblioteca" -> LibraryScreen2(
                            filteredBooks,
                            onDetail = { detailId = it.id },
                            onToggleFavorite = toggleFav,
                            onImport = { bookPicker.launch(arrayOf("*/*")) },
                            onScan = { showScanner = true }
                        )
                        "Favoritos" -> FavoritesScreen(books, onDetail = { detailId = it.id })
                        "Racha" -> StreakScreen(days, onMarkToday = { Streak.markToday(context); days = Streak.days(context) })
                        "Notas" -> AllHighlightsScreen(
                            highlights = allHighlights,
                            onEdit = { editingHighlight = it },
                            onDelete = { h -> scope.launch { highlightDao.deleteById(h.id) } }
                        )
                        "Audio" -> AudioScreen(
                            allItems.filter { it.mediaType == "AUDIO" },
                            onOpen = { opened = it }, onDelete = onDelete
                        )
                        "Reto" -> ChallengeScreen(books, goal, onGoal = { g ->
                            goal = g.coerceIn(1, 365)
                            Streak.setGoal(context, goal)
                        })
                        "Resumen" -> RecapScreen(books, allHighlights.size, days)
                        else -> SettingsScreen(
                            allItems.size, busy,
                            onExport = {
                                val stamp = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
                                exportLauncher.launch("libra-copia-$stamp.zip")
                            },
                            onImport = {
                                restoreLauncher.launch(arrayOf("application/zip",
                                    "application/octet-stream", "*/*"))
                            },
                            onShowTutorial = { showTutorial = true },
                            onExportCsv = {
                                val stamp = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
                                csvLauncher.launch("libellum-libros-$stamp.csv")
                            }
                        )
                    }
                }
            }

            // ── Menú «Más» ───────────────────────────────────────────────────
            if (showMore) {
                MoreSheet(
                    onPick = { key -> selectedTab = key; showMore = false },
                    onTutorial = { showMore = false; showTutorial = true },
                    onCsv = {
                        showMore = false
                        val stamp = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
                        csvLauncher.launch("libellum-libros-$stamp.csv")
                    },
                    onDismiss = { showMore = false }
                )
            }

            // ── Detalle del libro ────────────────────────────────────────────
            val detailItem = detailId?.let { id -> allItems.firstOrNull { it.id == id } }
            if (detailItem != null) {
                BookDetailSheet(
                    item = detailItem,
                    notesCount = allHighlights.count { it.bookId == detailItem.id },
                    onDismiss = { detailId = null },
                    onRead = { detailId = null; opened = detailItem },
                    onStatus = { st ->
                        scope.launch {
                            val now = System.currentTimeMillis()
                            dao.setStatus(detailItem.id, st)
                            if (st == "READING" || st == "FINISHED") dao.markStarted(detailItem.id, now)
                            if (st == "FINISHED") dao.markFinished(detailItem.id, now)
                        }
                    },
                    onRating = { r -> scope.launch { dao.setRating(detailItem.id, r) } },
                    onGenre = { g -> scope.launch { dao.setGenre(detailItem.id, g) } },
                    onReview = { r -> scope.launch { dao.setReview(detailItem.id, r) } },
                    onFavorite = { toggleFav(detailItem) },
                    onDelete = { detailId = null; pendingDelete = detailItem }
                )
            }
        }
    }

    pendingDelete?.let { item ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            containerColor = Panel,
            title = { Text("¿Quitar de la biblioteca?", color = Cream) },
            text = {
                Text(
                    "«${item.title}» se borrará de Libellum junto con sus notas. " +
                        "El archivo original de tu teléfono no se toca.",
                    color = Muted
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        removeItem(dao, item)
                        highlightDao.deleteByBook(item.id)
                    }
                    pendingDelete = null
                }) { Text("Quitar", color = Gold) }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) { Text("Cancelar", color = Muted) }
            }
        )
    }

    if (showScanner) {
        ScannerDialog(
            context = context,
            onImport = { uris ->
                scope.launch {
                    busy = true; status = "Importando desde escáner…"
                    status = withContext(Dispatchers.IO) {
                        importUris(context.contentResolver, context.filesDir, uris, "BOOK", dao)
                    }
                    busy = false
                }
            },
            onDismiss = { showScanner = false }
        )
    }

    editingHighlight?.let { h ->
        HighlightEditDialog(
            highlight = h,
            onSave = { updated ->
                scope.launch { highlightDao.update(updated) }
                editingHighlight = null
            },
            onDismiss = { editingHighlight = null }
        )
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// PANTALLAS
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun HomeScreen(
    books: List<LibraryItem>,
    onOpen: (LibraryItem) -> Unit,
    onDelete: (LibraryItem) -> Unit,
    onToggleFavorite: (LibraryItem) -> Unit
) {
    if (books.isEmpty()) {
        EmptyFeature("TU BIBLIOTECA COMIENZA AQUÍ",
            "Importa tus archivos EPUB, PDF, TXT, FB2, CBZ o usa el escáner automático. " +
            "Libellum guardará una copia privada en tu dispositivo.")
    } else {
        val favorites = books.filter { it.isFavorite == 1 }
        val rest = books.filter { it.isFavorite == 0 }
        LazyColumn {
            if (favorites.isNotEmpty()) {
                item {
                    Text("FAVORITOS · ${favorites.size}", color = Gold, fontSize = 11.sp,
                        letterSpacing = 1.sp, modifier = Modifier.padding(bottom = 4.dp))
                }
                items(favorites, key = { it.id }) { BookRow(it, onOpen, onDelete, onToggleFavorite) }
                item { Spacer(Modifier.height(12.dp)) }
            }
            item {
                Text("LIBROS · ${rest.size}", color = Gold, fontSize = 11.sp,
                    letterSpacing = 1.sp, modifier = Modifier.padding(bottom = 4.dp))
            }
            items(rest, key = { it.id }) { BookRow(it, onOpen, onDelete, onToggleFavorite) }
        }
    }
}

@Composable
fun LibraryScreen(
    books: List<LibraryItem>,
    viewMode: String,
    onViewModeChange: (String) -> Unit,
    onOpen: (LibraryItem) -> Unit,
    onDelete: (LibraryItem) -> Unit,
    onToggleFavorite: (LibraryItem) -> Unit,
    onSetPose: (String, String) -> Unit,
    onSetAllPoses: (String) -> Unit,
    onMove: (String, Float, Float) -> Unit,
    onResetShelf: () -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("${books.size} libros", color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
        listOf(
            "LISTA" to LibIconKind.LIST,
            "CUADRICULA" to LibIconKind.GRID,
            "ESTANTERIA" to LibIconKind.SHELF
        ).forEach { (mode, kind) ->
            LibIconButton(
                kind, onClick = { onViewModeChange(mode) },
                tint = if (viewMode == mode) Gold else Muted, filled = viewMode == mode
            )
        }
    }
    if (books.isEmpty()) {
        EmptyFeature("AÚN NO HAY LIBROS", "Pulsa «Importar» o «Escanear» para añadir tu colección.")
    } else when (viewMode) {
        "ESTANTERIA" -> ShelfScreen(books, onOpen, onSetPose, onSetAllPoses, onMove, onResetShelf)
        "CUADRICULA" -> LazyColumn {
            items(books.chunked(2)) { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    row.forEach { book ->
                        Column(
                            Modifier.weight(1f).padding(vertical = 8.dp).clickable { onOpen(book) }
                        ) {
                            BookCover(book, Modifier.fillMaxWidth().height(190.dp))
                            Spacer(Modifier.height(6.dp))
                            Text(book.title, color = Cream, fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text("${book.author} · ${book.format}", color = Muted, fontSize = 10.sp,
                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
        else -> LazyColumn {
            items(books, key = { it.id }) { BookRow(it, onOpen, onDelete, onToggleFavorite) }
        }
    }
}

@Composable
fun AudioScreen(audio: List<LibraryItem>, onOpen: (LibraryItem) -> Unit, onDelete: (LibraryItem) -> Unit) {
    if (audio.isEmpty()) {
        EmptyFeature("TUS AUDIOLIBROS",
            "Importa MP3, M4A, M4B, AAC, OGG, OPUS, WAV o FLAC. " +
            "Libellum recuerda por dónde ibas y sigue sonando con la pantalla apagada.")
    } else {
        Text("${audio.size} archivos de audio importados", color = Gold, fontSize = 11.sp)
        LazyColumn {
            items(audio, key = { it.id }) { BookRow(it, onOpen, onDelete, onToggleFavorite = {}) }
        }
    }
}

@Composable
fun SettingsScreen(
    itemCount: Int, busy: Boolean,
    onExport: () -> Unit, onImport: () -> Unit, onShowTutorial: () -> Unit,
    onExportCsv: () -> Unit = {}
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            EmptyFeature("ALMACENAMIENTO LOCAL",
                "Libellum mantiene $itemCount elementos en el almacenamiento privado de la aplicación.")
        }
        item {
            Button(onClick = onExport, enabled = !busy, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)
            ) { Text("Exportar copia de seguridad") }
        }
        item {
            OutlinedButton(onClick = onImport, enabled = !busy, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
            ) { Text("Restaurar desde una copia") }
        }
        item {
            OutlinedButton(onClick = onExportCsv, enabled = !busy, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
            ) { Text("Exportar lista de libros (CSV)") }
        }
        item {
            OutlinedButton(onClick = onShowTutorial, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
            ) {
                LibIcon(LibIconKind.HELP, tint = Gold, size = 18.dp)
                Spacer(Modifier.width(8.dp))
                Text("Ver tutorial de la app")
            }
        }
        item {
            Text("La copia es un archivo .zip con tus libros, audiolibros, portadas, progreso y " +
                "orden de la estantería. Guárdalo en Drive o en la tarjeta y restáuralo en otro teléfono.",
                color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// COMPONENTES REUTILIZABLES
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun EmptyFeature(title: String, description: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text(title, color = Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Text(description, color = Cream, fontSize = 14.sp, lineHeight = 21.sp)
        }
    }
}

@Composable
fun BookRow(
    item: LibraryItem,
    onOpen: (LibraryItem) -> Unit,
    onDelete: (LibraryItem) -> Unit,
    onToggleFavorite: (LibraryItem) -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clickable { onOpen(item) }.padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BookCover(item, Modifier.size(width = 48.dp, height = 66.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(item.title, color = Cream, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text("${item.author} · ${item.format}", color = Muted, fontSize = 11.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (item.progress > 0) {
                Spacer(Modifier.height(5.dp))
                LinearProgressIndicator(
                    progress = { item.progress / 100f },
                    color = Gold, trackColor = Panel,
                    modifier = Modifier.fillMaxWidth().height(3.dp)
                )
            }
        }
        LibIconButton(
            LibIconKind.STAR, onClick = { onToggleFavorite(item) },
            tint = if (item.isFavorite == 1) Gold else Muted, filled = item.isFavorite == 1
        )
        LibIconButton(LibIconKind.TRASH, onClick = { onDelete(item) }, tint = Muted, iconSize = 20.dp)
    }
}

private fun coverColor(title: String): Color {
    val palette = listOf(
        Color(0xFF6B3540), Color(0xFF35564D),
        Color(0xFF43506D), Color(0xFF7A5C3A), Color(0xFF3B3430)
    )
    return palette[abs(title.hashCode()) % palette.size]
}

@Composable
fun BookCover(item: LibraryItem, modifier: Modifier = Modifier, textSize: TextUnit = 10.sp) {
    val cover = remember(item.coverPath) {
        item.coverPath?.let { File(it) }?.takeIf { it.exists() }
    }
    Box(modifier.clip(RoundedCornerShape(7.dp)).background(coverColor(item.title)),
        contentAlignment = Alignment.Center) {
        if (cover != null) {
            AsyncImage(model = cover, contentDescription = item.title,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Text(item.title, color = Color(0xFFF3E6C8), fontSize = textSize, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, maxLines = 6, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(5.dp))
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// ESTANTERÍA: de frente, de pie (lomo), acostado y pila horizontal
// Referencia visual: verticales + pilas tumbadas en la misma balda
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Posturas:
 * - FRONT  → portada de frente
 * - SPINE  → de pie, se ve el lomo
 * - FLAT   → un solo libro tumbado en la balda
 * - STACK  → pila horizontal (varios libros tumbados uno encima de otro = «Pirámide»)
 */
/** Máximo de libros por torre: al llegar al cuarto, la torre se cierra y el siguiente libro inicia otra columna al lado. */
internal const val MAX_STACK_BOOKS = 4

internal fun shelfPose(item: LibraryItem): String = when (item.shelfOrientation) {
    "SPINE" -> "SPINE"
    "FLAT", "ACOSTADO" -> "FLAT"
    "STACK", "LYING", "HORIZONTAL", "PIRAMIDE", "PYRAMID" -> "STACK"
    // Las posturas inclinadas ya no existen: los libros guardados así pasan a estar de pie
    "LEAN", "TILTED", "LADEADO", "INCLINADO" -> "SPINE"
    else -> "FRONT"
}

/**
 * Tamaño visual según postura.
 * - SPINE: ancho = grosor del lomo, alto = altura del libro.
 * - STACK/FLAT: libro tumbado → el alto original pasa a ser la anchura horizontal,
 *   y el grosor del lomo pasa a ser la altura de cada capa de la pila
 *   (proporciones exactas como en la guía de implementación de pilas).
 * En STACK se mantiene un factor de compactación suave para que la torre no crezca
 * demasiado, pero se respeta la proporción del lomo original.
 */
private fun poseSize(book: LibraryItem, pose: String): Pair<Dp, Dp> {
    val customW = book.spineWidthDp
    val customH = book.spineHeightDp
    if (customW > 0 && customH > 0) {
        return when (pose) {
            "SPINE" -> customW.dp to customH.dp
            // width = altura original del libro; height = grosor del lomo (compactado levemente)
            "STACK" -> customH.dp to (customW * 0.72f).toInt().coerceIn(14, 28).dp
            "FLAT" -> customH.dp to (customW * 0.78f).toInt().coerceIn(12, 30).dp
            else -> (customW * 2.4f).toInt().coerceIn(56, 100).dp to customH.dp
        }
    }
    val hScale = 0.88f + (kotlin.math.abs(book.title.hashCode()) % 28) / 100f
    val wScale = 0.85f + (kotlin.math.abs((book.title + book.author).hashCode()) % 35) / 100f
    val baseH = (114 * hScale).toInt().coerceIn(88, 150)
    val baseW = (30 * wScale).toInt().coerceIn(22, 42)
    return when (pose) {
        "SPINE" -> baseW.dp to baseH.dp
        // STACK: width = baseH (largo del libro tumbado), height = grosor del lomo
        "STACK" -> baseH.dp to (baseW * 0.70f).toInt().coerceIn(14, 24).dp
        "FLAT" -> baseH.dp to (baseW * 0.75f).toInt().coerceIn(12, 26).dp
        else -> (baseW * 2.5f).toInt().coerceIn(58, 96).dp to baseH.dp
    }
}

private class ShelfLayout(val slots: Map<String, IntOffset>, val plankTops: List<Int>, val height: Int)

/**
 * Colocación automática realista.
 * Las pilas (STACK) se tratan como unidades independientes:
 * - Si los libros tienen posiciones guardadas (shelfX/Y ≥ 0), se agrupan por proximidad
 *   en X (mismo “hueco” de torre) para que modificar una pila no reordene las demás.
 * - Si no, se agrupan por orden de lista (comportamiento anterior).
 * Cada torre se ancla a la balda (Arrangement.Bottom equivalente): el libro inferior
 * apoya su canto inferior en el tope de la madera; los de encima se apilan sin hueco.
 */
private fun layoutShelf(books: List<LibraryItem>, areaW: Int, density: Density): ShelfLayout {
    val gap = with(density) { 5.dp.roundToPx() }
    val padX = with(density) { 10.dp.roundToPx() }
    val plank = with(density) { 12.dp.roundToPx() }
    val topPad = with(density) { 18.dp.roundToPx() }
    val slots = HashMap<String, IntOffset>()
    val plankTops = ArrayList<Int>()

    data class Unit(val members: List<LibraryItem>, val w: Int, val h: Int)
    val units = ArrayList<Unit>()

    val stackBooks = books.filter { shelfPose(it) == "STACK" }
    val nonStack = books.filter { shelfPose(it) != "STACK" }

    // Agrupar STACK por proximidad de X cuando hay posiciones guardadas (aislamiento de torres)
    val used = HashSet<String>()
    val proximityPx = with(density) { 48.dp.roundToPx() }
    for (b in stackBooks) {
        if (b.id in used) continue
        val group = ArrayList<LibraryItem>()
        val bx = if (b.shelfX >= 0f) b.shelfX else -1f
        if (bx >= 0f) {
            // Torre con posiciones: agrupar por cercanía en X
            for (other in stackBooks) {
                if (other.id in used) continue
                val ox = if (other.shelfX >= 0f) other.shelfX else -1f
                if (ox >= 0f && abs(bx - ox) * density.density < proximityPx) {
                    group.add(other)
                    used.add(other.id)
                }
            }
        }
        if (group.isEmpty()) {
            // Fallback: agrupar consecutivos del listado original (máx. 6)
            val idx = books.indexOfFirst { it.id == b.id }
            if (idx >= 0) {
                var j = idx
                while (j < books.size && shelfPose(books[j]) == "STACK" && group.size < MAX_STACK_BOOKS) {
                    if (books[j].id !in used) {
                        group.add(books[j])
                        used.add(books[j].id)
                    }
                    j++
                }
            }
            if (group.isEmpty()) {
                group.add(b)
                used.add(b.id)
            }
        }
        // Ordenar de abajo (más anchos) hacia arriba para apilado estable
        val ordered = group.sortedWith(
            compareByDescending<LibraryItem> { poseSize(it, "STACK").first.value }
                .thenBy { it.shelfY }
        )
        // Torres de máximo MAX_STACK_BOOKS libros: lo que sobra forma otra columna al lado
        ordered.chunked(MAX_STACK_BOOKS).forEach { part ->
            val maxW = part.maxOf { with(density) { poseSize(it, "STACK").first.roundToPx() } }
            val sumH = part.sumOf { with(density) { poseSize(it, "STACK").second.roundToPx() } }
            units.add(Unit(part, maxW, sumH))
        }
    }

    for (b in nonStack) {
        val pose = shelfPose(b)
        val (w, h) = poseSize(b, pose)
        units.add(Unit(listOf(b), with(density) { w.roundToPx() }, with(density) { h.roundToPx() }))
    }

    // Mantener un orden determinista: primero unidades con posición guardada (por X), luego el resto
    units.sortBy { u ->
        val first = u.members.firstOrNull()
        when {
            first == null -> 9999f
            first.shelfX >= 0f -> first.shelfX
            else -> 5000f + books.indexOfFirst { it.id == first.id }.toFloat()
        }
    }

    var rowTop = topPad
    var cursor = padX
    val row = ArrayList<Unit>()

    fun flush() {
        if (row.isEmpty()) return
        val rowH = row.maxOf { it.h }
        var x = padX
        row.forEach { u ->
            if (u.members.size > 1 || shelfPose(u.members[0]) == "STACK") {
                // Pila horizontal anclada a la balda (equivalente a Arrangement.Bottom)
                var yOff = 0
                // members ya ordenados de abajo hacia arriba conceptualmente; asReversed para dibujar desde base
                u.members.asReversed().forEach { b ->
                    val bh = with(density) { poseSize(b, "STACK").second.roundToPx() }
                    val bw = with(density) { poseSize(b, "STACK").first.roundToPx() }
                    val bx = x + (u.w - bw) / 2
                    // Canto inferior del libro apoyado exactamente sobre el de abajo / la balda
                    slots[b.id] = IntOffset(bx, rowTop + rowH - yOff - bh)
                    yOff += bh
                }
            } else {
                val b = u.members[0]
                slots[b.id] = IntOffset(x, rowTop + rowH - u.h)
            }
            x += u.w + gap
        }
        plankTops.add(rowTop + rowH)
        rowTop += rowH + plank + topPad
        row.clear()
        cursor = padX
    }

    for (u in units) {
        if (cursor + u.w > areaW - padX && row.isNotEmpty()) flush()
        row.add(u)
        cursor += u.w + gap
    }
    flush()
    return ShelfLayout(slots, plankTops, (plankTops.lastOrNull() ?: topPad) + plank + topPad / 2)
}

/**
 * Asigna posturas mixtas realistas a una lista de libros (verticales + torres),
 * como en la imagen de referencia. Devuelve mapa id → pose.
 */
internal fun realisticMixPoses(books: List<LibraryItem>): Map<String, String> {
    if (books.isEmpty()) return emptyMap()
    val result = LinkedHashMap<String, String>()
    var i = 0
    while (i < books.size) {
        val roll = kotlin.math.abs((books[i].title + i).hashCode()) % 10
        when {
            // ~30%: empezar una torre de 2–4 libros tumbados
            roll < 3 && i + 1 < books.size -> {
                val n = 2 + (roll % 3) // 2..4
                val take = minOf(n, books.size - i)
                repeat(take) { result[books[i + it].id] = "STACK" }
                i += take
            }
            // resto: de pie (lomo)
            else -> {
                result[books[i].id] = "SPINE"
                i++
            }
        }
    }
    return result
}

private fun Color.shade(f: Float): Color = Color(
    (red * f).coerceIn(0f, 1f), (green * f).coerceIn(0f, 1f), (blue * f).coerceIn(0f, 1f), alpha
)

/** Gira un composable 90° ocupando el espacio girado (para el título del lomo). */
private fun Modifier.rotateVertical(): Modifier = layout { measurable, constraints ->
    val placeable = measurable.measure(Constraints(0, constraints.maxHeight, 0, constraints.maxWidth))
    layout(placeable.height, placeable.width) {
        placeable.placeWithLayer(
            (placeable.height - placeable.width) / 2,
            (placeable.width - placeable.height) / 2
        ) { rotationZ = 90f }
    }
}

private val spineColorCache = HashMap<String, Color>()

private fun averageColor(path: String): Color? {
    val options = BitmapFactory.Options().apply { inSampleSize = 16 }
    val bmp = BitmapFactory.decodeFile(path, options) ?: return null
    var r = 0L
    var g = 0L
    var b = 0L
    var n = 0
    // Se promedia la franja izquierda de la portada: es lo más parecido al color del lomo
    val xMax = maxOf(1, bmp.width / 4)
    for (x in 0 until xMax) {
        for (y in 0 until bmp.height) {
            val px = bmp.getPixel(x, y)
            r += (px shr 16) and 0xFF
            g += (px shr 8) and 0xFF
            b += px and 0xFF
            n++
        }
    }
    if (n == 0) return null
    return Color(r / n / 255f, g / n / 255f, b / n / 255f)
}

/** Color del lomo: promedio de la portada; si no hay portada, un color según el título. */
@Composable
private fun rememberSpineColor(book: LibraryItem): Color {
    val fallback = remember(book.title) { coverColor(book.title) }
    val color by produceState(spineColorCache[book.coverPath ?: ""] ?: fallback, book.coverPath) {
        val path = book.coverPath
        if (path != null) {
            val cached = spineColorCache[path]
            if (cached != null) {
                value = cached
            } else {
                val c = withContext(Dispatchers.IO) { averageColor(path) }
                if (c != null) {
                    spineColorCache[path] = c
                    value = c
                }
            }
        }
    }
    return color
}

@Composable
private fun FrontFace(book: LibraryItem) {
    Box(Modifier.fillMaxSize().clip(RoundedCornerShape(3.dp))) {
        BookCover(book, Modifier.fillMaxSize(), textSize = 9.sp)
        // pliegue del lomo en sombra, a la izquierda
        Box(
            Modifier.align(Alignment.CenterStart).fillMaxHeight().width(7.dp)
                .background(Brush.horizontalGradient(listOf(Color(0xAA000000), Color.Transparent)))
        )
        // canto de las páginas, a la derecha
        Box(Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(3.dp).background(Color(0xFFEFE6D2)))
    }
}

/** Lomo del libro: de pie (vertical) o acostado (horizontal). Se ve el canto con título y bandas. */
@Composable
private fun SpineFace(book: LibraryItem, vertical: Boolean) {
    val base = rememberSpineColor(book).let { if (it.luminance() > 0.8f) it.shade(0.8f) else it }
    val textColor = if (base.luminance() > 0.5f) Color(0xFF1B1B1B) else Color(0xFFF3E6C8)
    val brush = if (vertical) {
        Brush.horizontalGradient(listOf(base.shade(0.65f), base.shade(1.18f), base, base.shade(0.55f)))
    } else {
        Brush.verticalGradient(listOf(base.shade(1.18f), base, base.shade(0.6f)))
    }
    val band = textColor.copy(alpha = 0.55f)
    Box(
        Modifier.fillMaxSize().clip(RoundedCornerShape(3.dp)).background(brush),
        contentAlignment = Alignment.Center
    ) {
        if (vertical) {
            Box(Modifier.align(Alignment.TopCenter).padding(top = 7.dp).fillMaxWidth().height(2.dp).background(band))
            Box(Modifier.align(Alignment.TopCenter).padding(top = 11.dp).fillMaxWidth().height(1.dp).background(band))
            Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 7.dp).fillMaxWidth().height(2.dp).background(band))
            Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 11.dp).fillMaxWidth().height(1.dp).background(band))
            Text(
                book.title, color = textColor, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(vertical = 16.dp).rotateVertical()
            )
        } else {
            Box(Modifier.align(Alignment.CenterStart).padding(start = 7.dp).fillMaxHeight().width(2.dp).background(band))
            Box(Modifier.align(Alignment.CenterStart).padding(start = 11.dp).fillMaxHeight().width(1.dp).background(band))
            // extremo con las páginas a la vista
            Box(Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(8.dp).background(Color(0xFFEFE6D2)))
            Box(Modifier.align(Alignment.CenterEnd).padding(end = 3.dp).fillMaxHeight().width(1.dp).background(Color(0x33000000)))
            Text(
                book.title, color = textColor, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(start = 18.dp, end = 16.dp)
            )
        }
    }
}

@Composable
internal fun ShelfScreen(
    books: List<LibraryItem>,
    onOpen: (LibraryItem) -> Unit,
    onSetPose: (String, String) -> Unit,
    onSetAllPoses: (String) -> Unit,
    onMove: (String, Float, Float) -> Unit,
    onReset: () -> Unit,
    style: ShelfStyle = ShelfStyle(),
    onSpineSize: (String, Int, Int) -> Unit = { _, _, _ -> }
) {
    val wallDef = remember(style.wall) { wallOf(style.wall) }
    val woodDef = remember(style.wood) { woodOf(style.wood) }
    var selectedId by remember { mutableStateOf<String?>(null) }
    val selected = books.firstOrNull { it.id == selectedId }

    // Adornos colocados a mano (null = todavía no se han guardado: la primera vez se parte de los del tema)
    val ctx = LocalContext.current
    var placed by remember { mutableStateOf(ShelfStyleStore.loadPlaced(ctx)) }
    var selectedDecoId by remember { mutableStateOf<String?>(null) }
    var showDecoPicker by remember { mutableStateOf(false) }
    var pendingAdd by remember { mutableStateOf<DecoDef?>(null) }
    var reseedRequest by remember { mutableStateOf(false) }
    // Torres pedidas por el usuario: se colocan sobre la tabla de una balda (máx. MAX_STACK_BOOKS por columna)
    var pyramidRequest by remember { mutableStateOf<Set<String>?>(null) }
    // Aviso cuando se suelta un libro sobre una torre ya completa
    var towerFullNotice by remember { mutableStateOf(false) }
    // Selector de pirámide: el usuario elige qué libros apilar; el sistema los centra y apila solo
    var showPyramidPicker by remember { mutableStateOf(false) }
    var pyramidSeedId by remember { mutableStateOf<String?>(null) } // libro que abrió el selector
    var pyramidSelection by remember { mutableStateOf<Set<String>>(emptySet()) }
    // Modo apilar en la propia estantería (como vídeo de referencia): toca libros y pulsa «Apilarlos»
    var stackSelectMode by remember { mutableStateOf(false) }
    var stackSelection by remember { mutableStateOf<Set<String>>(emptySet()) }
    // Libro que se está arrastrando (para resaltar huecos con línea discontinua)
    var draggingBookId by remember { mutableStateOf<String?>(null) }
    // Undo del último movimiento: id + posición previa
    var lastMoveUndo by remember { mutableStateOf<Triple<String, Float, Float>?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val selectedDeco = placed?.firstOrNull { it.id == selectedDecoId }
    fun commitPlaced(list: List<PlacedDeco>) {
        placed = list
        ShelfStyleStore.savePlaced(ctx, list)
    }

    /**
     * Pila horizontal (torre de libros tumbados).
     * - Proporciones: ancho de cada capa = altura original del libro; alto de capa = grosor del lomo.
     * - Anclaje firme a la balda (sin flotar): el libro inferior apoya su canto inferior
     *   y los siguientes se apilan con interlineado 0.
     * - Solo se tocan los libros de esta torre; el resto de pilas permanece intacto
     *   (aislamiento de estado por stack).
     */
    fun applyPyramid(ids: Set<String>) {
        // La colocación real se hace dentro de la estantería (conoce las baldas): ver pyramidRequest
        if (ids.isNotEmpty()) pyramidRequest = ids
    }

    /** Mezcla realista: verticales + pilas en la misma estantería. */
    fun applyRealisticMix() {
        val mix = realisticMixPoses(books)
        mix.forEach { (id, pose) ->
            onSetPose(id, pose)
            onMove(id, -1f, -1f) // que el layout automático coloque con colisiones
        }
    }

    Box(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize()) {
        // Controles superiores fijos
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (stackSelectMode) "Toca los libros que quieres en esta torre"
                else "TOCA · MANTÉN PULSADO PARA MOVER",
                color = Muted, fontSize = 10.sp, letterSpacing = 1.sp,
                modifier = Modifier.weight(1f)
            )
            if (!stackSelectMode) {
                TextButton(onClick = onReset) { Text("Ordenar", color = Gold, fontSize = 11.sp) }
                Text("✓ Guardado", color = Gold.copy(alpha = 0.85f), fontSize = 11.sp)
            }
        }
        if (!stackSelectMode) {
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Todos:", color = Muted, fontSize = 11.sp)
            listOf(
                "FRONT" to "Frente",
                "SPINE" to "De pie",
                "FLAT" to "Acostados"
            ).forEach { (pose, label) ->
                TextButton(onClick = { onSetAllPoses(pose) }) {
                    Text(label, color = Gold, fontSize = 11.sp)
                }
            }
            TextButton(onClick = {
                // Modo torre en estantería (como vídeo de referencia)
                stackSelection = emptySet()
                stackSelectMode = true
                selectedId = null
                selectedDecoId = null
            }) {
                Text("Torre", color = Gold, fontSize = 11.sp)
            }
            TextButton(onClick = { applyRealisticMix() }) {
                Text("Mezcla", color = Gold, fontSize = 11.sp)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Adornos:", color = Muted, fontSize = 11.sp)
            TextButton(onClick = { showDecoPicker = true }) {
                Text("+ Añadir", color = Gold, fontSize = 11.sp)
            }
            TextButton(onClick = { reseedRequest = true }) {
                Text("Los del tema", color = Gold, fontSize = 11.sp)
            }
        }
        }
        Spacer(Modifier.height(4.dp))

        // Estantería con scroll si hace falta; el panel de edición queda fijo abajo
        LazyColumn(Modifier.weight(1f)) {
            item {
                Column {

                BoxWithConstraints(Modifier.fillMaxWidth()) {
                    val density = LocalDensity.current
                    val areaW = constraints.maxWidth
                    val poseKey = books.map { it.id to shelfPose(it) }
                    val layout = remember(poseKey, areaW) { layoutShelf(books, areaW, density) }
                    val areaH = maxOf(layout.height, with(density) { 360.dp.roundToPx() })
                    val dpx = density.density

                    // Margen de colisión entre libros (dp → px): evita que se toquen o se monten
                    val bookGapPx = 4f * dpx

                    /** Rectángulo (en px) que ocupa un libro: su sitio guardado o el automático. */
                    fun bookRect(b: LibraryItem): Rect {
                        val dims = poseSize(b, shelfPose(b))
                        val bw = dims.first.value * dpx
                        val bh = dims.second.value * dpx
                        val slot = layout.slots[b.id] ?: IntOffset.Zero
                        val l = (if (b.shelfX >= 0f) b.shelfX * dpx else slot.x.toFloat())
                            .coerceIn(0f, (areaW - bw).coerceAtLeast(0f))
                        val t = (if (b.shelfY >= 0f) b.shelfY * dpx else slot.y.toFloat())
                            .coerceIn(0f, (areaH - bh).coerceAtLeast(0f))
                        return Rect(l, t, l + bw, t + bh)
                    }

                    /**
                     * Libros que forman la misma torre que `seed` (sin contar `exceptId`):
                     * tumbados, solapados en X y apoyados canto con canto.
                     */
                    fun towerOf(seed: LibraryItem, exceptId: String): List<LibraryItem> {
                        val tol = 3f * dpx
                        val tower = arrayListOf(seed)
                        var grew = true
                        while (grew) {
                            grew = false
                            for (o in books) {
                                if (o.id == exceptId || tower.any { it.id == o.id }) continue
                                val p = shelfPose(o)
                                if (p != "STACK" && p != "FLAT") continue
                                val ro = bookRect(o)
                                val touches = tower.any { t ->
                                    val rt = bookRect(t)
                                    val overlapX = minOf(ro.right, rt.right) - maxOf(ro.left, rt.left)
                                    overlapX > 0.4f * minOf(ro.width, rt.width) &&
                                        (abs(ro.bottom - rt.top) <= tol || abs(ro.top - rt.bottom) <= tol)
                                }
                                if (touches) { tower.add(o); grew = true }
                            }
                        }
                        return tower
                    }

                    /** ¿Se solapa el rect candidato con otros libros (con margen de colisión)? */
                    fun overlapsAny(id: String, left: Float, top: Float, w: Float, h: Float): Boolean {
                        val candidate = Rect(
                            left - bookGapPx, top - bookGapPx,
                            left + w + bookGapPx, top + h + bookGapPx
                        )
                        for (b in books) {
                            if (b.id == id) continue
                            val r = bookRect(b)
                            if (candidate.overlaps(r)) return true
                        }
                        return false
                    }

                    /**
                     * Coloca el libro sin solaparse ni empujar a los demás:
                     * 1) si está en Pila (STACK), puede montarse encima de otro libro tumbado
                     * 2) si está Acostado / de pie, se apoya en la balda (sin apilar)
                     * 3) si choca, busca hueco a izquierda/derecha en esa balda
                     * 4) si no hay sitio, prueba otras baldas
                     * 5) nunca mueve los libros ya acomodados
                     */
                    fun resolveBookPlacement(id: String, xDp: Float, yDp: Float): Pair<Float, Float> {
                        val b = books.firstOrNull { it.id == id } ?: return xDp to yDp
                        val pose = shelfPose(b)
                        val dims = poseSize(b, pose)
                        val bw = dims.first.value * dpx
                        val bh = dims.second.value * dpx
                        val maxX = (areaW - bw).coerceAtLeast(0f)
                        val maxY = (areaH - bh).coerceAtLeast(0f)

                        var x = (xDp * dpx).coerceIn(0f, maxX)
                        var y = (yDp * dpx).coerceIn(0f, maxY)
                        val cx = x + bw / 2f
                        val bottom = y + bh

                        // ── Pila horizontal: soltar encima de otro → torre de libros tumbados ──
                        // Funciona si el libro ya es STACK/FLAT o si se suelta claramente encima de uno tumbado
                        run {
                            var bestStack: Rect? = null
                            var bestOther: LibraryItem? = null
                            var bestStackD = 40f * dpx
                            for (other in books) {
                                if (other.id == id) continue
                                val otherPose = shelfPose(other)
                                // Solo apilar sobre libros ya tumbados o en pila
                                if (otherPose != "STACK" && otherPose != "FLAT") continue
                                val r = bookRect(other)
                                if (cx < r.left - 8f * dpx || cx > r.right + 8f * dpx) continue
                                val d = abs(bottom - r.top)
                                val above = bottom <= r.top + 14f * dpx && y + bh * 0.5f < r.top
                                if (d <= bestStackD || above) {
                                    if (d < bestStackD || (above && bestStack == null)) {
                                        bestStackD = d
                                        bestStack = r
                                        bestOther = other
                                    }
                                }
                            }
                            // Torre completa (MAX_STACK_BOOKS): no se apila; el libro se apoya en la balda, al lado
                            val tower = bestOther?.let { towerOf(it, id) }
                            if (bestStack != null && tower != null && tower.size >= MAX_STACK_BOOKS) {
                                towerFullNotice = true
                                val towerFloor = tower.maxOf { bookRect(it).bottom }
                                y = (towerFloor - bh).coerceIn(0f, maxY)
                            } else if (bestStack != null && (pose == "STACK" || pose == "FLAT" || bestStackD < 24f * dpx)) {
                                val r = bestStack
                                // Usar grosor de STACK para el cálculo de altura
                                val stackH = poseSize(b, "STACK").second.value * dpx
                                val sx = (cx - bw / 2f).coerceIn(
                                    (r.left - bw * 0.25f).coerceAtLeast(0f),
                                    (r.right - bw * 0.75f).coerceAtMost(maxX)
                                ).coerceIn(0f, maxX)
                                // Interlineado 0: canto inferior apoyado en el superior del de abajo
                                val sy = (r.top - stackH).coerceIn(0f, maxY)
                                // Marcar ambos como STACK si aún no lo eran
                                if (pose != "STACK") onSetPose(id, "STACK")
                                bestOther?.let { o ->
                                    if (shelfPose(o) != "STACK") onSetPose(o.id, "STACK")
                                }
                                return (sx / dpx) to (sy / dpx)
                            }
                        }

                        // 1) Snap vertical a la balda más cercana (el libro se apoya, no flota)
                        var bestPlank = Float.NaN
                        var bestDist = 48f * dpx
                        layout.plankTops.forEach { top ->
                            val d = abs(top - bottom)
                            if (d <= bestDist) {
                                bestDist = d
                                bestPlank = top.toFloat()
                            }
                        }
                        if (!bestPlank.isNaN()) {
                            y = (bestPlank - bh).coerceIn(0f, maxY)
                        }

                        // 2) Si no hay colisión, listo
                        if (!overlapsAny(id, x, y, bw, bh)) {
                            return (x / dpx) to (y / dpx)
                        }

                        // 3) Buscar hueco horizontal en la misma balda (pasos de ~medio libro)
                        val step = (bw * 0.35f).coerceAtLeast(8f)
                        var foundX = Float.NaN
                        var foundDist = Float.MAX_VALUE
                        var probe = 0f
                        while (probe <= maxX) {
                            if (!overlapsAny(id, probe, y, bw, bh)) {
                                val d = abs(probe - x)
                                if (d < foundDist) {
                                    foundDist = d
                                    foundX = probe
                                }
                            }
                            probe += step
                        }
                        if (!foundX.isNaN()) {
                            val fineStart = (foundX - step).coerceAtLeast(0f)
                            val fineEnd = (foundX + step).coerceAtMost(maxX)
                            var fx = fineStart
                            while (fx <= fineEnd) {
                                if (!overlapsAny(id, fx, y, bw, bh)) {
                                    val d = abs(fx - x)
                                    if (d < foundDist) {
                                        foundDist = d
                                        foundX = fx
                                    }
                                }
                                fx += 2f
                            }
                            return (foundX / dpx) to (y / dpx)
                        }

                        // 4) Probar otras baldas (arriba y abajo)
                        val orderedPlanks = layout.plankTops
                            .map { it.toFloat() }
                            .sortedBy { abs(it - (y + bh)) }
                        for (plank in orderedPlanks) {
                            val ty = (plank - bh).coerceIn(0f, maxY)
                            probe = 0f
                            while (probe <= maxX) {
                                if (!overlapsAny(id, probe, ty, bw, bh)) {
                                    return (probe / dpx) to (ty / dpx)
                                }
                                probe += step
                            }
                        }

                        // 5) Sin hueco libre: dejar donde estaba (no empujar a nadie)
                        val original = bookRect(b)
                        return (original.left / dpx) to (original.top / dpx)
                    }

                    /** Al soltar un adorno cerca de una balda o del canto superior de un libro, se apoya en él. */
                    fun snapDeco(x: Float, y: Float, w: Float, h: Float): Pair<Float, Float> {
                        val cx = x + w / 2f
                        val bottom = y + h
                        var best = Float.NaN
                        var bestD = 36f * dpx
                        layout.plankTops.forEach { top ->
                            val d = abs(top - bottom)
                            if (d <= bestD) { bestD = d; best = top.toFloat() }
                        }
                        books.forEach { b ->
                            val r = bookRect(b)
                            if (cx >= r.left && cx <= r.right) {
                                val d = abs(r.top - bottom)
                                if (d <= bestD) { bestD = d; best = r.top }
                            }
                        }
                        return if (best.isNaN()) x to y else x to (best - h)
                    }

                    /**
                     * Mover un libro: resuelve colisiones (no solapa ni empuja a otros) y
                     * arrastra adornos que tenía encima. Devuelve la posición final en dp.
                     * Guarda la posición anterior para «Deshacer» y muestra snackbar.
                     */
                    val moveBookWithDecos: (String, Float, Float) -> Pair<Float, Float> = { id, nx, ny ->
                        val b = books.firstOrNull { it.id == id }
                        val prevX = b?.shelfX ?: -1f
                        val prevY = b?.shelfY ?: -1f
                        towerFullNotice = false
                        val (rx, ry) = resolveBookPlacement(id, nx, ny)
                        val towerWasFull = towerFullNotice
                        val cur = placed
                        if (b != null && !cur.isNullOrEmpty()) {
                            val r = bookRect(b)
                            val dx = rx * dpx - r.left
                            val dy = ry * dpx - r.top
                            val moved = cur.map { d ->
                                val def = decoOf(d.key)
                                if (def == null) {
                                    d
                                } else {
                                    val cx = d.x * dpx + def.w * d.scale * dpx / 2f
                                    val bottom = d.y * dpx + def.h * d.scale * dpx
                                    if (cx >= r.left && cx <= r.right && abs(bottom - r.top) <= 3f * dpx) {
                                        d.copy(
                                            x = ((d.x * dpx + dx) / dpx).coerceAtLeast(0f),
                                            y = ((d.y * dpx + dy) / dpx).coerceAtLeast(0f)
                                        )
                                    } else d
                                }
                            }
                            commitPlaced(moved)
                        }
                        onMove(id, rx, ry)
                        // Solo snackbar si realmente cambió de sitio
                        if (abs(rx - prevX) > 0.5f || abs(ry - prevY) > 0.5f || prevX < 0f) {
                            lastMoveUndo = Triple(id, prevX, prevY)
                            scope.launch {
                                val result = snackbarHostState.showSnackbar(
                                    message = if (towerWasFull) "Torre completa (máx. $MAX_STACK_BOOKS): el libro quedó al lado" else "Libro movido",
                                    actionLabel = "Deshacer",
                                    duration = SnackbarDuration.Short
                                )
                                if (result == SnackbarResult.ActionPerformed) {
                                    lastMoveUndo?.let { (uid, ux, uy) ->
                                        onMove(uid, ux, uy)
                                    }
                                    lastMoveUndo = null
                                }
                            }
                        }
                        rx to ry
                    }

                    // Primera vez (o «Los del tema»): se colocan los adornos del tema sobre cada balda
                    LaunchedEffect(layout, areaW, reseedRequest) {
                        if (reseedRequest) {
                            commitPlaced(seedDecos(style, layout.plankTops, areaW, density))
                            selectedDecoId = null
                            reseedRequest = false
                        } else if (placed == null) {
                            // Solo se guarda si el tema trae adornos: así una vista sin tema no «congela» una lista vacía
                            val seeded = seedDecos(style, layout.plankTops, areaW, density)
                            if (seeded.isEmpty()) placed = seeded else commitPlaced(seeded)
                        }
                    }
                    // Torres nuevas: máx. MAX_STACK_BOOKS por columna, apoyadas en la tabla de su balda
                    // (gravedad: base = tope de la madera, sin flotar ni tocar el techo de la balda)
                    LaunchedEffect(pyramidRequest) {
                        val ids = pyramidRequest ?: return@LaunchedEffect
                        pyramidRequest = null
                        val chosen = books.filter { it.id in ids }
                        val planks = layout.plankTops.sorted().map { it.toFloat() }
                        if (chosen.isEmpty() || planks.isEmpty()) return@LaunchedEffect
                        val plankPx = 12f * dpx
                        // Altura libre mínima entre baldas (para que ninguna torre toque el techo)
                        val freeH = planks.indices.minOf { i ->
                            if (i == 0) planks[0] else planks[i] - planks[i - 1] - plankPx
                        }.coerceAtLeast(40f * dpx) - 4f * dpx
                        // Más anchos abajo; columnas de máx. MAX_STACK_BOOKS y que quepan en la balda
                        val sorted = chosen.sortedByDescending { poseSize(it, "STACK").first.value }
                        val towers = ArrayList<MutableList<LibraryItem>>()
                        var curH = 0f
                        sorted.forEach { b ->
                            val h = poseSize(b, "STACK").second.value * dpx
                            val last = towers.lastOrNull()
                            if (last == null || last.size >= MAX_STACK_BOOKS || curH + h > freeH) {
                                towers.add(arrayListOf(b)); curH = h
                            } else { last.add(b); curH += h }
                        }
                        val widths = towers.map { t -> t.maxOf { poseSize(it, "STACK").first.value * dpx } }
                        val gapPx = 8f * dpx
                        val edge = 12f * dpx
                        val totalW = widths.sum() + gapPx * (towers.size - 1)
                        // Balda de destino: la del primer libro elegido
                        val ra = bookRect(chosen.first())
                        var pi = planks.indices.minByOrNull { abs(planks[it] - ra.bottom) } ?: 0
                        var x = if (totalW <= areaW - 2 * edge) (areaW - totalW) / 2f else edge
                        towers.forEachIndexed { i, tower ->
                            if (x + widths[i] > areaW - edge && x > edge + 1f && pi < planks.lastIndex) {
                                pi++; x = edge
                            }
                            var bottom = planks[pi]
                            tower.forEach { b ->
                                val (w, h) = poseSize(b, "STACK")
                                val bx = x + (widths[i] - w.value * dpx) / 2f
                                bottom -= h.value * dpx
                                onSetPose(b.id, "STACK")
                                onMove(b.id, bx / dpx, bottom / dpx)
                            }
                            x += widths[i] + gapPx
                        }
                    }
                    // Adorno nuevo elegido en el catálogo: aparece sobre la primera balda
                    LaunchedEffect(pendingAdd) {
                        val def = pendingAdd
                        if (def != null) {
                            val top = layout.plankTops.firstOrNull()?.toFloat() ?: (areaH / 2f)
                            val nd = PlacedDeco(
                                id = java.util.UUID.randomUUID().toString(),
                                key = def.key,
                                x = ((areaW - def.w * dpx) / 2f) / dpx,
                                y = (top - def.h * dpx) / dpx
                            )
                            commitPlaced(placed.orEmpty() + nd)
                            selectedDecoId = nd.id
                            selectedId = null
                            pendingAdd = null
                        }
                    }

                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(with(density) { areaH.toDp() })
                            .clip(RoundedCornerShape(14.dp))
                            .drawBehind { drawWall(wallDef); drawFrameSides(style) }
                            .drawWithContent { drawContent(); drawLight(style.light) }
                    ) {
                        layout.plankTops.forEach { top ->
                            Canvas(
                                Modifier
                                    .offset { IntOffset(0, top) }
                                    .fillMaxWidth()
                                    .height(12.dp)
                            ) { drawWoodRect(woodDef, Offset.Zero, size) }
                        }
                        // Adornos colocados a mano: se arrastran, se agrandan, se colorean y se apoyan solos
                        placed.orEmpty().forEach { d ->
                            key(d.id) {
                                ShelfDecoItem(
                                    deco = d, areaW = areaW, areaH = areaH,
                                    isSelected = selectedDecoId == d.id,
                                    onSelect = { selectedDecoId = d.id; selectedId = null },
                                    snap = { x, y, w, h -> snapDeco(x, y, w, h) },
                                    onCommit = { nx, ny ->
                                        commitPlaced(placed.orEmpty().map { if (it.id == d.id) it.copy(x = nx, y = ny) else it })
                                    }
                                )
                            }
                        }
                        // Huecos de balda con línea discontinua mientras se arrastra un libro
                        if (draggingBookId != null) {
                            val dash = PathEffect.dashPathEffect(floatArrayOf(12f, 10f), 0f)
                            Canvas(Modifier.fillMaxSize()) {
                                layout.plankTops.forEach { top ->
                                    val left = 8f * dpx
                                    val right = size.width - 8f * dpx
                                    val slotH = 28f * dpx
                                    drawRoundRect(
                                        color = Gold.copy(alpha = 0.55f),
                                        topLeft = Offset(left, top - slotH),
                                        size = androidx.compose.ui.geometry.Size(right - left, slotH),
                                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f),
                                        style = Stroke(width = 2f * dpx, pathEffect = dash)
                                    )
                                }
                            }
                        }
                        books.forEach { book ->
                            key(book.id) {
                                val inStackSel = stackSelectMode && book.id in stackSelection
                                ShelfBook(
                                    book, layout.slots[book.id] ?: IntOffset.Zero, areaW, areaH,
                                    isSelected = if (stackSelectMode) inStackSel else selectedId == book.id,
                                    stackHighlight = inStackSel,
                                    dragEnabled = !stackSelectMode,
                                    onSelect = {
                                        if (stackSelectMode) {
                                            stackSelection = if (book.id in stackSelection)
                                                stackSelection - book.id else stackSelection + book.id
                                        } else {
                                            selectedId = if (selectedId == it.id) null else it.id
                                            selectedDecoId = null
                                        }
                                    },
                                    onDragState = { dragging ->
                                        draggingBookId = if (dragging) book.id else null
                                    },
                                    onMove = moveBookWithDecos
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                }
            }
        }

        if (!stackSelectMode) {
            Text(
                "Toca un libro o adorno para editarlo · Mantén pulsado para mover",
                color = Muted, fontSize = 12.sp, lineHeight = 18.sp,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        } else {
            Spacer(Modifier.height(56.dp)) // hueco para el botón inferior
        }
    }

    // Botón «Apilarlos» fijo abajo (modo selección de pila, como en el vídeo)
    if (stackSelectMode) {
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Color(0xEE1A1510))
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TextButton(onClick = { stackSelectMode = false; stackSelection = emptySet() }) {
                Text("Cancelar", color = Gold, fontSize = 13.sp)
            }
            Button(
                onClick = {
                    if (stackSelection.isNotEmpty()) {
                        applyPyramid(stackSelection)
                    }
                    stackSelectMode = false
                    stackSelection = emptySet()
                },
                enabled = stackSelection.isNotEmpty(),
                modifier = Modifier.fillMaxWidth().height(48.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFF5F0E6),
                    contentColor = Color(0xFF1A1510),
                    disabledContainerColor = Color(0xFF3A3228),
                    disabledContentColor = Muted
                ),
                shape = RoundedCornerShape(28.dp)
            ) {
                Text(
                    if (stackSelection.isEmpty()) "Hacer torre" else "Hacer torre (${stackSelection.size})",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp
                )
            }
        }
    }

    SnackbarHost(
        hostState = snackbarHostState,
        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = if (stackSelectMode) 72.dp else 8.dp)
    )
    } // Box raíz

    // Edición de libro: ventana emergente (igual que antes)
    if (selected != null) {
        ModalBottomSheet(
            onDismissRequest = { selectedId = null },
            containerColor = Panel
        ) {
            BookShelfEditorPanel(
                book = selected,
                onSetPose = { pose ->
                    if (pose == "STACK") {
                        // Modo selección en la estantería (como vídeo de referencia)
                        stackSelection = setOf(selected.id) + books
                            .filter { shelfPose(it) == "STACK" }
                            .map { it.id }
                            .take(4)
                            .toSet()
                        stackSelectMode = true
                        selectedId = null
                    } else {
                        onSetPose(selected.id, pose)
                    }
                },
                onSpineSize = { w, h -> onSpineSize(selected.id, w, h) },
                onOpen = { onOpen(selected); selectedId = null },
                onDone = { selectedId = null },
                asSheetContent = true
            )
        }
    }

    // Selector de libros para la pirámide: el sistema los apila y centra solo
    if (showPyramidPicker) {
        AlertDialog(
            onDismissRequest = { showPyramidPicker = false },
            containerColor = Panel,
            title = {
                Text("Torre de libros", color = Cream, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Elige los libros de la torre. Quedarán tumbados uno encima de otro, centrados, como en una librería real.",
                        color = Muted, fontSize = 13.sp, lineHeight = 18.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = {
                            pyramidSelection = books.map { it.id }.toSet()
                        }) { Text("Todos", color = Gold, fontSize = 12.sp) }
                        TextButton(onClick = {
                            pyramidSelection = emptySet()
                        }) { Text("Ninguno", color = Gold, fontSize = 12.sp) }
                    }
                    androidx.compose.foundation.lazy.LazyColumn(
                        Modifier.heightIn(max = 320.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(books, key = { it.id }) { b ->
                            val checked = b.id in pyramidSelection
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (checked) Gold.copy(alpha = 0.15f) else Color.Transparent)
                                    .clickable {
                                        pyramidSelection = if (checked) pyramidSelection - b.id
                                        else pyramidSelection + b.id
                                    }
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    if (checked) "☑" else "☐",
                                    color = if (checked) Gold else Muted,
                                    fontSize = 16.sp
                                )
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        b.title, color = Cream, fontSize = 13.sp, maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(b.author, color = Muted, fontSize = 11.sp, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        applyPyramid(pyramidSelection)
                        showPyramidPicker = false
                    },
                    enabled = pyramidSelection.isNotEmpty()
                ) {
                    Text("Crear pila", color = Gold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPyramidPicker = false }) {
                    Text("Cancelar", color = Muted)
                }
            }
        )
    }

    // Edición de decoración: misma ventana emergente (sin scroll en la estantería)
    if (selectedDeco != null) {
        ModalBottomSheet(
            onDismissRequest = { selectedDecoId = null },
            containerColor = Panel
        ) {
            DecoEditorPanel(
                deco = selectedDeco,
                onChange = { nd -> commitPlaced(placed.orEmpty().map { if (it.id == nd.id) nd else it }) },
                onDuplicate = {
                    val copy = selectedDeco.copy(
                        id = java.util.UUID.randomUUID().toString(),
                        x = selectedDeco.x + 14f
                    )
                    commitPlaced(placed.orEmpty() + copy)
                    selectedDecoId = copy.id
                },
                onDelete = {
                    commitPlaced(placed.orEmpty().filter { it.id != selectedDeco.id })
                    selectedDecoId = null
                },
                onDone = { selectedDecoId = null },
                asSheetContent = true
            )
        }
    }

    if (showDecoPicker) {
        DecoPickerDialog(
            onPick = { d -> pendingAdd = d; showDecoPicker = false },
            onDismiss = { showDecoPicker = false }
        )
    }
}

/** Adornos del tema, uno junto a otro sobre el extremo derecho de cada balda (punto de partida editable). */
private fun seedDecos(style: ShelfStyle, plankTops: List<Int>, areaW: Int, density: Density): List<PlacedDeco> {
    val out = ArrayList<PlacedDeco>()
    val px = density.density
    plankTops.forEachIndexed { idx, top ->
        var dx = areaW - 10f * px
        pickDecos(style, 31, idx, 120f).forEach { d ->
            val dw = d.w * px
            val dh = d.h * px
            dx -= dw
            out.add(PlacedDeco(java.util.UUID.randomUUID().toString(), d.key, dx / px, (top - dh) / px))
            dx -= 6f * px
        }
    }
    return out
}

/** Panel de edición del libro en estantería libre (ventana emergente o Card). */
@Composable
private fun BookShelfEditorPanel(
    book: LibraryItem,
    onSetPose: (String) -> Unit,
    onSpineSize: (Int, Int) -> Unit,
    onOpen: () -> Unit,
    onDone: () -> Unit,
    asSheetContent: Boolean = false
) {
    val dims = poseSize(book, shelfPose(book))
    val baseW = if (book.spineWidthDp > 0) book.spineWidthDp else 28
    val baseH = if (book.spineHeightDp > 0) book.spineHeightDp else 114
    var sizeScale by remember(book.id, book.spineWidthDp, book.spineHeightDp) {
        mutableFloatStateOf(
            ((baseH / 114f).coerceIn(0.55f, 1.7f) + (baseW / 28f).coerceIn(0.55f, 1.7f)) / 2f
        )
    }
    val body: @Composable () -> Unit = {
        Column(
            Modifier
                .fillMaxWidth()
                .then(if (asSheetContent) Modifier.padding(horizontal = 16.dp).padding(bottom = 28.dp) else Modifier.padding(14.dp)),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                BookCover(book, Modifier.size(width = 40.dp, height = 58.dp))
                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                    Text(
                        book.title, color = Cream, fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                    Text(book.author, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        "Mantén pulsado y arrastra. «Torre» elige libros y los apila tumbados uno encima de otro. «Mezcla» reparte de pie y torres como una librería real.",
                        color = Muted, fontSize = 11.sp, lineHeight = 15.sp
                    )
                }
            }

            Text("Cómo se ve", color = Muted, fontSize = 12.sp)
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    "FRONT" to "Portada",
                    "SPINE" to "De pie",
                    "FLAT" to "Acostado",
                    "STACK" to "Torre"
                ).forEach { (pose, label) ->
                    FilterChip(
                        selected = shelfPose(book) == pose,
                        onClick = { onSetPose(pose) },
                        label = { Text(label, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Gold,
                            selectedLabelColor = Ink,
                            labelColor = Cream
                        )
                    )
                }
            }

            Text(
                "Tamaño: ×${"%.1f".format(sizeScale)}  (${dims.first.value.toInt()}×${dims.second.value.toInt()})",
                color = Muted, fontSize = 12.sp
            )
            Slider(
                value = sizeScale,
                onValueChange = { v ->
                    sizeScale = v
                    val w = (28f * v).toInt().coerceIn(16, 56)
                    val h = (114f * v).toInt().coerceIn(70, 190)
                    onSpineSize(w, h)
                },
                valueRange = 0.55f..1.7f,
                colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold)
            )

            Spacer(Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onOpen, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)
                ) { Text("Abrir", fontSize = 12.sp) }
                OutlinedButton(
                    onClick = onDone, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Cream)
                ) { Text("Listo", fontSize = 12.sp) }
            }
        }
    }
    if (asSheetContent) {
        body()
    } else {
        Card(
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) { body() }
    }
}

@Composable
private fun ShelfBook(
    book: LibraryItem,
    slot: IntOffset,
    areaW: Int,
    areaH: Int,
    isSelected: Boolean,
    stackHighlight: Boolean = false,
    dragEnabled: Boolean = true,
    onSelect: (LibraryItem) -> Unit,
    onDragState: (Boolean) -> Unit = {},
    /** Devuelve posición final en dp tras aplicar colisión / snap a balda. */
    onMove: (String, Float, Float) -> Pair<Float, Float>
) {
    val density = LocalDensity.current
    val pose = shelfPose(book)
    val dims = poseSize(book, pose)
    val bw = with(density) { dims.first.roundToPx() }
    val bh = with(density) { dims.second.roundToPx() }
    val maxX = (areaW - bw).coerceAtLeast(0)
    val maxY = (areaH - bh).coerceAtLeast(0)
    val px = density.density   // la posición guardada está en dp
    // Claves estables: si el libro tiene posición explícita, no depender del slot del layout
    // automático (evita que al actualizar otra torre se mueva esta).
    var x by remember(book.id, book.shelfX, areaW, bw) {
        mutableFloatStateOf(
            (if (book.shelfX >= 0f) book.shelfX * px else slot.x.toFloat()).coerceIn(0f, maxX.toFloat())
        )
    }
    var y by remember(book.id, book.shelfY, areaH, bh) {
        mutableFloatStateOf(
            (if (book.shelfY >= 0f) book.shelfY * px else slot.y.toFloat()).coerceIn(0f, maxY.toFloat())
        )
    }
    var dragging by remember { mutableStateOf(false) }

    // Sincronizar solo cuando cambian las coordenadas del propio libro o su pose.
    // No reaccionar a cambios de slot de otras unidades (aislamiento de pilas).
    LaunchedEffect(book.shelfX, book.shelfY, pose, areaW, areaH, bw, bh) {
        if (!dragging) {
            if (book.shelfX >= 0f) {
                x = (book.shelfX * px).coerceIn(0f, maxX.toFloat())
            } else {
                x = slot.x.toFloat().coerceIn(0f, maxX.toFloat())
            }
            if (book.shelfY >= 0f) {
                y = (book.shelfY * px).coerceIn(0f, maxY.toFloat())
            } else {
                y = slot.y.toFloat().coerceIn(0f, maxY.toFloat())
            }
        }
    }

    Box(
        Modifier
            .offset { IntOffset(x.roundToInt(), y.roundToInt()) }
            .zIndex(if (dragging) 20f else if (isSelected || stackHighlight) 10f else 0f)
            .size(dims.first, dims.second)
            .shadow(if (dragging) 12.dp else 3.dp, RoundedCornerShape(3.dp))
            .then(
                when {
                    dragging -> Modifier.border(
                        2.dp, Gold.copy(alpha = 0.9f), RoundedCornerShape(4.dp)
                    )
                    stackHighlight || isSelected -> Modifier.border(
                        2.dp, Gold, RoundedCornerShape(4.dp)
                    )
                    else -> Modifier
                }
            )
            .then(
                if (dragEnabled) {
                    Modifier.pointerInput(book.id, maxX, maxY) {
                        // Mantener pulsado y arrastrar: el scroll de la estantería sigue funcionando
                        detectDragGesturesAfterLongPress(
                            onDragStart = {
                                dragging = true
                                onDragState(true)
                            },
                            onDragEnd = {
                                dragging = false
                                onDragState(false)
                                // Al soltar: colisión + snap a balda; no solapa ni empuja a otros
                                val (rx, ry) = onMove(book.id, x / px, y / px)
                                x = (rx * px).coerceIn(0f, maxX.toFloat())
                                y = (ry * px).coerceIn(0f, maxY.toFloat())
                            },
                            onDragCancel = {
                                dragging = false
                                onDragState(false)
                            }
                        ) { change, drag ->
                            change.consume()
                            x = (x + drag.x).coerceIn(0f, maxX.toFloat())
                            y = (y + drag.y).coerceIn(0f, maxY.toFloat())
                        }
                    }
                } else Modifier
            )
            .clickable { onSelect(book) }
    ) {
        when (pose) {
            "SPINE" -> SpineFace(book, vertical = true)
            "STACK", "FLAT" -> SpineFace(book, vertical = false) // pila horizontal / acostado
            else -> FrontFace(book)
        }
        // Contorno discontinuo extra mientras se arrastra (como en el vídeo de referencia)
        if (dragging) {
            Canvas(Modifier.fillMaxSize()) {
                val dash = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)
                drawRoundRect(
                    color = Color(0xFFFFE08A),
                    topLeft = Offset.Zero,
                    size = size,
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(4.dp.toPx(), 4.dp.toPx()),
                    style = Stroke(width = 2.5.dp.toPx(), pathEffect = dash)
                )
            }
        }
    }
}
