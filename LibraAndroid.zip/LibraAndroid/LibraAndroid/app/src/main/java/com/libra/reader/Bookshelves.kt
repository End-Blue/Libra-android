@file:OptIn(ExperimentalMaterial3Api::class)

package com.libra.reader

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

/** Color del lomo: el elegido a mano para ese libro o, si no, uno de la paleta del estilo. */
private fun spineColor(b: LibraryItem, style: ShelfStyle, overrides: Map<String, Long>): Color {
    overrides[b.id]?.let { return Color(it) }
    val colors = paletteOf(style.palette).colors
    return colors[abs(b.title.hashCode()) % colors.size]
}

/** Tamaño (ancho, alto) en dp del lomo: automático según el título, o el que fijó el lector. */
private fun spineDims(b: LibraryItem, size: String): Pair<Int, Int> {
    if (b.spineWidthDp > 0 && b.spineHeightDp > 0) return b.spineWidthDp to b.spineHeightDp
    val base = when (size) { "S" -> 92; "L" -> 138; else -> 114 }
    val h = base * (90 + abs(b.title.hashCode()) % 22) / 100
    val w = (22 + abs((b.title + b.author).hashCode()) % 13) * base / 114
    return w to h
}

private fun coverDims(size: String): Pair<Int, Int> {
    val w = when (size) { "S" -> 54; "L" -> 90; else -> 70 }
    return w to (w * 3 / 2)
}

@Composable
internal fun BookshelvesScreen(
    books: List<LibraryItem>,
    onDetail: (LibraryItem) -> Unit,
    onSpineSize: (String, Int, Int) -> Unit,
    freeShelf: @Composable (ShelfStyle) -> Unit
) {
    val ctx = LocalContext.current
    var spines by remember { mutableStateOf(true) }
    var groupBy by remember { mutableStateOf("Género") }
    var size by remember { mutableStateOf("M") }
    var adjust by remember { mutableStateOf(false) }
    var free by remember { mutableStateOf(true) }  // Libre por defecto
    var resizing by remember { mutableStateOf<LibraryItem?>(null) }
    var style by remember { mutableStateOf(ShelfStyleStore.load(ctx)) }
    var overrides by remember { mutableStateOf(ShelfStyleStore.loadBookColors(ctx)) }
    var studio by remember { mutableStateOf(false) }

    if (books.isEmpty()) {
        EmptyFeature("TU ESTANTERÍA ESTÁ VACÍA", "Importa libros y aquí los verás ordenados en baldas de madera.")
        return
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ModeChip("Libre", free) { free = true }
            ModeChip("Portadas", !free && !spines) { free = false; spines = false }
            ModeChip("Lomos", !free && spines) { free = false; spines = true }
            ModeChip("🎨 Personalizar", true) { studio = true }
        }
        if (free) {
            Box(Modifier.weight(1f)) { freeShelf(style) }
        } else {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Agrupar:", color = Muted, fontSize = 12.sp)
                listOf("Género", "Autor", "Estado", "Formato").forEach { g ->
                    ModeChip(g, groupBy == g) { groupBy = g }
                }
            }
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Tamaño:", color = Muted, fontSize = 12.sp)
                listOf("S", "M", "L").forEach { s -> ModeChip(s, size == s) { size = s } }
                if (spines) ModeChip(if (adjust) "Listo" else "Ajustar lomos", adjust) { adjust = !adjust }
            }
            if (adjust) {
                Text("Toca un lomo para cambiar su alto, ancho y color.", color = Muted, fontSize = 11.sp)
            }

            val groups = remember(books, groupBy) {
                val map = books.groupBy { b ->
                    when (groupBy) {
                        "Autor" -> b.author
                        "Estado" -> statusLabel(b.statusKey())
                        "Formato" -> b.format
                        else -> b.genreLabel()
                    }
                }
                val order = listOf("Por leer", "Leyendo", "Terminado")
                if (groupBy == "Estado") map.toList().sortedBy { order.indexOf(it.first) }
                else map.toList().sortedBy { it.first.lowercase() }
            }

            LazyColumn(
                Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)
            ) {
                item { ShelfStats(books) }
                items(groups, key = { it.first }) { (label, list) ->
                    ShelfGroup(
                        label = label, list = list, spines = spines, size = size,
                        style = style, overrides = overrides,
                        onTap = { b -> if (spines && adjust) resizing = b else onDetail(b) }
                    )
                }
            }
        }
    }

    resizing?.let { b ->
        SpineDialog(
            book = b, size = size, style = style, colorOverride = overrides[b.id],
            onDone = { w, h, col ->
                onSpineSize(b.id, w, h)
                val m = HashMap(overrides)
                if (col == null) m.remove(b.id) else m[b.id] = col
                overrides = m
                ShelfStyleStore.saveBookColors(ctx, m)
                resizing = null
            },
            onDismiss = { resizing = null }
        )
    }

    if (studio) {
        ShelfStudioSheet(
            style = style,
            onChange = { st -> style = st; ShelfStyleStore.save(ctx, st) },
            onDismiss = { studio = false }
        )
    }
}

@Composable
private fun ModeChip(text: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected, onClick = onClick,
        label = { Text(text, fontSize = 12.sp) },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = Gold, selectedLabelColor = Ink, labelColor = Cream
        )
    )
}

@Composable
private fun ShelfStats(books: List<LibraryItem>) {
    PaperCard(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
            listOf(
                "Libros" to books.size,
                "Terminados" to books.count { it.statusKey() == "FINISHED" },
                "Leyendo" to books.count { it.statusKey() == "READING" },
                "Por leer" to books.count { it.statusKey() == "TBR" }
            ).forEach { (l, n) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$n", color = Cream, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(l, color = Muted, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun ShelfGroup(
    label: String,
    list: List<LibraryItem>,
    spines: Boolean,
    size: String,
    style: ShelfStyle,
    overrides: Map<String, Long>,
    onTap: (LibraryItem) -> Unit
) {
    val wallDef = remember(style.wall) { wallOf(style.wall) }
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp)) {
            Text(label.uppercase(), color = Cream, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp, modifier = Modifier.weight(1f))
            Text("${list.size}", color = Muted, fontSize = 12.sp)
        }
        BoxWithConstraints(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .drawBehind { drawWall(wallDef); drawFrameSides(style) }
                .drawWithContent { drawContent(); drawLight(style.light) }
        ) {
            val gap = 4
            val padX = if (style.frame == "SIDES") 14 else 10
            val inner = maxWidth.value - 2f * padX
            // Se reserva sitio en cada balda para los objetos decorativos
            val reserve = if (style.decos.isNotEmpty() && style.decoDensity > 0) 46f * minOf(style.decoDensity, 2) else 0f
            val usable = inner - reserve
            val dims = list.associate { b ->
                b.id to (if (spines) spineDims(b, size) else coverDims(size))
            }
            val rows = ArrayList<MutableList<LibraryItem>>()
            val rowWidths = ArrayList<Float>()
            rows.add(ArrayList())
            rowWidths.add(0f)
            list.forEach { b ->
                val wDp = (dims[b.id]?.first ?: 60) + gap
                if (rowWidths.last() + wDp > usable && rows.last().isNotEmpty()) {
                    rows.add(ArrayList())
                    rowWidths.add(0f)
                }
                rows.last().add(b)
                rowWidths[rowWidths.lastIndex] = rowWidths.last() + wDp
            }
            Column(Modifier.fillMaxWidth()) {
                rows.forEachIndexed { idx, row ->
                    val rowH = row.maxOf { dims[it.id]?.second ?: 90 }
                    Row(
                        Modifier.fillMaxWidth().padding(start = padX.dp, end = padX.dp, top = 10.dp).height(rowH.dp),
                        horizontalArrangement = Arrangement.spacedBy(gap.dp),
                        verticalAlignment = Alignment.Bottom
                    ) {
                        row.forEach { b ->
                            val (w, h) = dims[b.id] ?: (60 to 90)
                            if (spines) {
                                StyledSpine(
                                    b.title, spineColor(b, style, overrides), b.progress, w, h, style,
                                    Modifier.clickable { onTap(b) }
                                )
                            } else {
                                BookCover(b, Modifier.size(w.dp, h.dp).clickable { onTap(b) }, textSize = 8.sp)
                            }
                        }
                        Spacer(Modifier.weight(1f))
                        pickDecos(style, label.hashCode(), idx, inner - rowWidths[idx]).forEach { d ->
                            DecoView(d)
                        }
                    }
                    WoodPlank(style)
                }
            }
        }
    }
}

@Composable
private fun SpineDialog(
    book: LibraryItem,
    size: String,
    style: ShelfStyle,
    colorOverride: Long?,
    onDone: (Int, Int, Long?) -> Unit,
    onDismiss: () -> Unit
) {
    val (w0, h0) = spineDims(book, size)
    var w by remember(book.id) { mutableStateOf(w0.toFloat()) }
    var h by remember(book.id) { mutableStateOf(h0.toFloat()) }
    var chosen by remember(book.id) { mutableStateOf(colorOverride) }
    val swatches = paletteOf(style.palette).colors
    val previewColor = chosen?.let { Color(it) } ?: spineColor(book, style, emptyMap())
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text(book.title, color = Cream, maxLines = 2, fontSize = 16.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.BottomCenter) {
                    StyledSpine(book.title, previewColor, book.progress, w.toInt(), h.toInt(), style)
                }
                Text("Alto: ${h.toInt()}", color = Muted, fontSize = 12.sp)
                Slider(
                    value = h, onValueChange = { h = it }, valueRange = 70f..190f,
                    colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold)
                )
                Text("Ancho: ${w.toInt()}", color = Muted, fontSize = 12.sp)
                Slider(
                    value = w, onValueChange = { w = it }, valueRange = 16f..60f,
                    colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold)
                )
                Text("Color de este lomo", color = Muted, fontSize = 12.sp)
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ModeChip("Auto", chosen == null) { chosen = null }
                    swatches.forEach { c ->
                        val argb = c.toArgb().toLong() and 0xFFFFFFFFL
                        val on = chosen == argb
                        Box(
                            Modifier.size(28.dp).clip(CircleShape).background(c)
                                .border(if (on) 3.dp else 1.dp, if (on) Gold else Line, CircleShape)
                                .clickable { chosen = argb }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onDone(w.toInt(), h.toInt(), chosen) }) { Text("Listo", color = Gold) }
        },
        dismissButton = {
            TextButton(onClick = { onDone(0, 0, null) }) { Text("Automático", color = Muted) }
        }
    )
}
