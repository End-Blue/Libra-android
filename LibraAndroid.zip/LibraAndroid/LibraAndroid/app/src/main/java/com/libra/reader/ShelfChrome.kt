package com.libra.reader

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Barra superior minimalista de la estantería (inspirada en Mistbook):
 * una sola fila con título, búsqueda, filtros y un menú «···» que guarda el resto de acciones
 * (ordenar, poner todos de una forma, mezcla, adornos). Así la estantería ocupa casi toda la pantalla.
 */
@Composable
internal fun ShelfTopBar(
    stackSelectMode: Boolean,
    query: String,
    onQuery: (String) -> Unit,
    filtersActive: Boolean,
    onOpenFilters: () -> Unit,
    onOrder: () -> Unit,
    onAllPoses: (String) -> Unit,
    onMix: () -> Unit,
    onAddDeco: () -> Unit,
    onThemeDecos: () -> Unit
) {
    var searching by remember { mutableStateOf(query.isNotEmpty()) }
    var menu by remember { mutableStateOf(false) }

    if (stackSelectMode) {
        Text(
            "Toca los libros que quieres en esta torre",
            color = Muted, fontSize = 12.sp,
            modifier = Modifier.padding(vertical = 12.dp)
        )
    } else {
        Row(
            Modifier.fillMaxWidth().heightIn(min = 48.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (searching) {
                OutlinedTextField(
                    value = query,
                    onValueChange = onQuery,
                    placeholder = { Text("Título, autor o género…", color = Muted, fontSize = 13.sp) },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Cream, unfocusedTextColor = Cream,
                        focusedBorderColor = Gold, unfocusedBorderColor = Line,
                        focusedContainerColor = Panel, unfocusedContainerColor = Panel
                    ),
                    trailingIcon = {
                        LibIconButton(
                            LibIconKind.CLOSE,
                            onClick = { onQuery(""); searching = false },
                            tint = Muted, iconSize = 18.dp
                        )
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = {})
                )
            } else {
                Text(
                    "MI ESTANTERÍA",
                    color = Muted, fontSize = 11.sp, letterSpacing = 1.sp,
                    modifier = Modifier.weight(1f).padding(start = 4.dp)
                )
                LibIconButton(
                    LibIconKind.SEARCH,
                    onClick = { searching = true },
                    tint = if (query.isNotEmpty()) Gold else Muted,
                    iconSize = 20.dp
                )
            }
            TextButton(onClick = onOpenFilters) {
                Text(
                    if (filtersActive) "Filtros •" else "Filtros",
                    color = if (filtersActive) Gold else Muted,
                    fontSize = 12.sp
                )
            }
            Box {
                TextButton(onClick = { menu = true }) {
                    Text("···", color = Muted, fontSize = 20.sp)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    ShelfMenuRow("Ordenar automáticamente") { menu = false; onOrder() }
                    HorizontalDivider(color = Line)
                    ShelfMenuRow("Todos de frente") { menu = false; onAllPoses("FRONT") }
                    ShelfMenuRow("Todos de pie") { menu = false; onAllPoses("SPINE") }
                    ShelfMenuRow("Todos acostados") { menu = false; onAllPoses("FLAT") }
                    ShelfMenuRow("Mezcla realista") { menu = false; onMix() }
                    HorizontalDivider(color = Line)
                    ShelfMenuRow("Añadir adorno") { menu = false; onAddDeco() }
                    ShelfMenuRow("Adornos del tema") { menu = false; onThemeDecos() }
                }
            }
        }
    }
}

@Composable
private fun ShelfMenuRow(text: String, onClick: () -> Unit) {
    DropdownMenuItem(text = { Text(text, fontSize = 14.sp) }, onClick = onClick)
}

/** Los filtros de la estantería, escondidos en una hoja para no ocupar espacio. */
@Composable
internal fun ShelfFilterSheet(
    genres: List<String>,
    authors: List<String>,
    formats: List<String>,
    colors: List<String>,
    fGenre: String,
    fAuthor: String,
    fStatus: String,
    fFormat: String,
    fSize: String,
    fColor: String,
    onGenre: (String) -> Unit,
    onAuthor: (String) -> Unit,
    onStatus: (String) -> Unit,
    onFormat: (String) -> Unit,
    onSize: (String) -> Unit,
    onColor: (String) -> Unit,
    onClear: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Panel) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Filtrar estantería", color = Cream, fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)
                )
                TextButton(onClick = onClear) { Text("Limpiar", color = Gold, fontSize = 12.sp) }
            }
            Text("Los libros que no coinciden se atenúan, sin cambiar de sitio.", color = Muted, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterMenu("Género", fGenre, genres, onGenre)
                FilterMenu("Autor", fAuthor, authors, onAuthor)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterMenu("Estado", fStatus, listOf("Por leer", "Leyendo", "Terminado"), onStatus)
                FilterMenu("Formato", fFormat, formats, onFormat)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterMenu("Tamaño", fSize, listOf("Chicos", "Medianos", "Grandes"), onSize)
                FilterMenu("Color", fColor, colors, onColor)
            }
            Button(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)
            ) { Text("Listo", fontSize = 13.sp) }
        }
    }
}
