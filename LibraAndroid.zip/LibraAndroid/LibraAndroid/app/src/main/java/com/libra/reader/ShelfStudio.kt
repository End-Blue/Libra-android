@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.libra.reader

import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val STUDIO_TABS = listOf("Temas", "Madera", "Pared", "Letra", "Decoración", "Luz")

@Composable
internal fun ShelfStudioSheet(
    style: ShelfStyle,
    onChange: (ShelfStyle) -> Unit,
    onDismiss: () -> Unit
) {
    var tab by remember { mutableStateOf("Temas") }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Panel
    ) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 12.dp).navigationBarsPadding()
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Taller de estantería", color = Cream, fontSize = 16.sp,
                    fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { onChange(ShelfStyle()) }) { Text("Restablecer", color = Muted, fontSize = 12.sp) }
                TextButton(onClick = onDismiss) { Text("Listo", color = Gold) }
            }
            ShelfPreview(style)
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                STUDIO_TABS.forEach { t -> OptChip(t, tab == t, { tab = t }) }
            }
            Spacer(Modifier.height(8.dp))
            Column(
                Modifier.fillMaxWidth().heightIn(max = 320.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                when (tab) {
                    "Temas" -> ThemesTab(onChange)
                    "Madera" -> WoodTab(style, onChange)
                    "Pared" -> WallTab(style, onChange)
                    "Lomos" -> SpinesTab(style, onChange)
                    "Letra" -> FontTab(style, onChange)
                    "Decoración" -> DecoTab(style, onChange)
                    else -> LightTab(style, onChange)
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

// ── Pestañas ─────────────────────────────────────────────────────────────────

@Composable
private fun ThemesTab(onChange: (ShelfStyle) -> Unit) {
    SectionLabel("Toca un tema para aplicarlo; después puedes afinar cada detalle.")
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        SHELF_PRESETS.forEach { (name, st) ->
            Column(Modifier.width(150.dp).clip(RoundedCornerShape(12.dp)).clickable { onChange(st) }) {
                ShelfPreview(st, compact = true)
                Text(
                    name, color = Cream, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun WoodTab(style: ShelfStyle, onChange: (ShelfStyle) -> Unit) {
    SectionLabel("Tipo de madera o acabado")
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        WOODS.forEach { wd ->
            Swatch(wd.label, style.wood == wd.key, { onChange(style.copy(wood = wd.key)) }) {
                Canvas(Modifier.fillMaxSize()) { drawWoodRect(wd, Offset.Zero, size) }
            }
        }
    }
    SectionLabel("Grosor de la balda")
    ChipRow {
        listOf("Fina", "Media", "Gruesa").forEachIndexed { i, l ->
            OptChip(l, style.thickness == i, { onChange(style.copy(thickness = i)) })
        }
    }
    SectionLabel("Estructura")
    ChipRow {
        FRAMES.forEach { f -> OptChip(f.label, style.frame == f.key, { onChange(style.copy(frame = f.key)) }) }
    }
}

@Composable
private fun WallTab(style: ShelfStyle, onChange: (ShelfStyle) -> Unit) {
    SectionLabel("Pared del fondo")
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        WALLS.forEach { wl ->
            Swatch(wl.label, style.wall == wl.key, { onChange(style.copy(wall = wl.key)) }) {
                Canvas(Modifier.fillMaxSize()) { drawWall(wl) }
            }
        }
    }
}

@Composable
private fun SpinesTab(style: ShelfStyle, onChange: (ShelfStyle) -> Unit) {
    SectionLabel("Paleta de colores de los lomos")
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        PALETTES.forEach { pl ->
            Swatch(pl.label, style.palette == pl.key, { onChange(style.copy(palette = pl.key)) }) {
                Row(Modifier.fillMaxSize()) {
                    pl.colors.take(6).forEach { c -> Box(Modifier.weight(1f).fillMaxHeight().background(c)) }
                }
            }
        }
    }
    SectionLabel("Material de la cubierta")
    ChipRow {
        MATERIALS.forEach { m -> OptChip(m.label, style.material == m.key, { onChange(style.copy(material = m.key)) }) }
    }
    SectionLabel("Adorno de lámina")
    ChipRow {
        FOILS.forEach { f -> OptChip(f.label, style.foil == f.key, { onChange(style.copy(foil = f.key)) }) }
    }
    SectionLabel("Color del adorno")
    ChipRow {
        FOIL_COLORS.forEach { fc ->
            OptChip(fc.label, style.foilColor == fc.key, { onChange(style.copy(foilColor = fc.key)) }, dot = fc.color)
        }
    }
    ToggleRow("Marca de progreso en el lomo", style.showProgress) { onChange(style.copy(showProgress = it)) }
}

@Composable
private fun FontTab(style: ShelfStyle, onChange: (ShelfStyle) -> Unit) {
    SectionLabel("Tipo de letra del título")
    ChipRow {
        FONTS.forEach { f ->
            val family = remember(f.key) { FontFamily(Typeface.create(f.family, f.style)) }
            OptChip(f.label, style.font == f.key, { onChange(style.copy(font = f.key)) }, family = family)
        }
    }
    SectionLabel("Tamaño")
    ChipRow {
        listOf("Pequeño", "Normal", "Grande").forEachIndexed { i, l ->
            OptChip(l, style.titleSize == i, { onChange(style.copy(titleSize = i)) })
        }
    }
    SectionLabel("Color del título")
    ChipRow {
        TITLE_COLORS.forEach { c -> OptChip(c.label, style.titleColor == c.key, { onChange(style.copy(titleColor = c.key)) }) }
    }
    ToggleRow("TODO EN MAYÚSCULAS", style.caps) { onChange(style.copy(caps = it)) }
}

@Composable
private fun DecoTab(style: ShelfStyle, onChange: (ShelfStyle) -> Unit) {
    SectionLabel("Cantidad de adornos por balda")
    ChipRow {
        listOf("Ninguno", "Pocos", "Algunos", "Muchos").forEachIndexed { i, l ->
            OptChip(l, style.decoDensity == i, { onChange(style.copy(decoDensity = i)) })
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        TextButton(onClick = {
            onChange(style.copy(decos = DECOS.map { it.key }.toSet(), decoDensity = maxOf(1, style.decoDensity)))
        }) { Text("Elegir todos", color = Gold, fontSize = 12.sp) }
        TextButton(onClick = { onChange(style.copy(decos = emptySet())) }) {
            Text("Quitar todos", color = Muted, fontSize = 12.sp)
        }
    }
    SectionLabel("Toca los objetos que quieras en tus baldas")
    val wallColor = wallOf(style.wall).base
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        DECOS.forEach { d ->
            val on = d.key in style.decos
            Swatch(d.label, on, {
                val next = if (on) style.decos - d.key else style.decos + d.key
                onChange(
                    style.copy(
                        decos = next,
                        decoDensity = if (style.decoDensity == 0 && next.isNotEmpty()) 1 else style.decoDensity
                    )
                )
            }, height = 68.dp) {
                Box(Modifier.fillMaxSize().background(wallColor), contentAlignment = Alignment.BottomCenter) {
                    DecoView(d, Modifier.padding(bottom = 4.dp))
                }
            }
        }
    }
}

@Composable
private fun LightTab(style: ShelfStyle, onChange: (ShelfStyle) -> Unit) {
    SectionLabel("Iluminación de la estantería")
    ChipRow {
        LIGHTS.forEach { l -> OptChip(l.label, style.light == l.key, { onChange(style.copy(light = l.key)) }) }
    }
}

// ── Vista previa en vivo ─────────────────────────────────────────────────────

@Composable
internal fun ShelfPreview(style: ShelfStyle, compact: Boolean = false) {
    val wall = wallOf(style.wall)
    val pal = paletteOf(style.palette).colors
    val titles = listOf("Don Quijote", "Odisea", "Hamlet", "Dune", "Emma", "Ficciones")
    val count = if (compact) 3 else titles.size
    val rowH = if (compact) 70 else 112
    val widths = List(count) { i -> if (compact) 18 + (i * 3) % 7 else 26 + (i * 5) % 10 }
    val heights = List(count) { i -> if (compact) 52 + (i * 7) % 14 else 84 + (i * 11) % 24 }

    BoxWithConstraints(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .drawBehind { drawWall(wall); drawFrameSides(style) }
            .drawWithContent { drawContent(); drawLight(style.light) }
    ) {
        val used = widths.sum() + 4 * count + 24
        val remaining = maxWidth.value - used
        Column(Modifier.fillMaxWidth()) {
            Row(
                Modifier.fillMaxWidth().height(rowH.dp).padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                for (i in 0 until count) {
                    StyledSpine(titles[i], pal[i % pal.size], if (i == 1) 60 else 0, widths[i], heights[i], style)
                }
                Spacer(Modifier.weight(1f))
                pickDecos(style, 7, 0, remaining).forEach { DecoView(it) }
            }
            WoodPlank(style)
        }
    }
}

// ── Piezas pequeñas ──────────────────────────────────────────────────────────

@Composable
private fun SectionLabel(text: String) {
    Text(text, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
}

@Composable
private fun ChipRow(content: @Composable () -> Unit) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) { content() }
}

@Composable
private fun OptChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    family: FontFamily? = null,
    dot: Color? = null
) {
    val icon: (@Composable () -> Unit)? =
        if (dot != null) ({ Box(Modifier.size(10.dp).clip(CircleShape).background(dot)) }) else null
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label, fontSize = 12.sp, fontFamily = family) },
        leadingIcon = icon,
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = Gold, selectedLabelColor = Ink, labelColor = Cream
        )
    )
}

@Composable
private fun Swatch(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    height: Dp = 44.dp,
    content: @Composable BoxScope.() -> Unit
) {
    Column(
        Modifier.width(72.dp).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.fillMaxWidth().height(height)
                .clip(RoundedCornerShape(8.dp))
                .border(if (selected) 2.dp else 1.dp, if (selected) Gold else Line, RoundedCornerShape(8.dp)),
            content = content
        )
        Text(
            label, color = if (selected) Gold else Muted, fontSize = 10.sp, lineHeight = 12.sp,
            maxLines = 2, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 2.dp)
        )
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Cream, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked, onCheckedChange = onChecked,
            colors = SwitchDefaults.colors(checkedTrackColor = Gold, checkedThumbColor = Ink)
        )
    }
}
