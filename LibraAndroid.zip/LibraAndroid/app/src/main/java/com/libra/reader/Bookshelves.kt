@file:OptIn(ExperimentalMaterial3Api::class)

package com.libra.reader

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

private val SPINE_PALETTE = listOf(
    0xFF2F4B6B, 0xFF7A2E3A, 0xFF35563F, 0xFFB5832F, 0xFF4A3B6B,
    0xFF1F3C3F, 0xFF8A4B2B, 0xFF5B6B3A, 0xFFC9B79C, 0xFF2B2B33,
    0xFF9C3D2E, 0xFF3E6A7A
).map { Color(it) }

private fun spineColor(b: LibraryItem): Color = SPINE_PALETTE[abs(b.title.hashCode()) % SPINE_PALETTE.size]

/** Tamaño (ancho, alto) en dp del lomo: automático según el título, o el que fijó el lector. */
private fun spineDims(b: LibraryItem, size: String): Pair<Int, Int> {
    if (b.spineWidthDp > 0 && b.spineHeightDp > 0) return b.spineWidthDp to b.spineHeightDp
    val base = when (size) { "S" -> 92; "L" -> 138; else -> 114 }
    val h = base * (90 + abs(b.title.hashCode()) % 22) / 100
    val w = (22 + abs((b.title + b.author).hashCode()) % 13) * base / 114
    return w to h
}

private fun coverDims(size: String): Pair<Int, Int> {
    val w = when (size) { "S" -> 54; "L" -> 90; else -> 70 }
    return w to (w * 3 / 2)
}

@Composable
fun BookshelvesScreen(
    books: List<LibraryItem>,
    onDetail: (LibraryItem) -> Unit,
    onSpineSize: (String, Int, Int) -> Unit,
    freeShelf: @Composable () -> Unit
) {
    var spines by remember { mutableStateOf(true) }
    var groupBy by remember { mutableStateOf("Género") }
    var size by remember { mutableStateOf("M") }
    var adjust by remember { mutableStateOf(false) }
    var free by remember { mutableStateOf(false) }
    var resizing by remember { mutableStateOf<LibraryItem?>(null) }

    if (books.isEmpty()) {
        EmptyFeature("TU ESTANTERÍA ESTÁ VACÍA", "Importa libros y aquí los verás ordenados en baldas de madera.")
        return
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ModeChip("Portadas", !free && !spines) { free = false; spines = false }
            ModeChip("Lomos", !free && spines) { free = false; spines = true }
            ModeChip("Libre", free) { free = true }
        }
        if (free) {
            Box(Modifier.weight(1f)) { freeShelf() }
        } else {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Agrupar:", color = Muted, fontSize = 12.sp)
                listOf("Género", "Autor", "Estado", "Formato").forEach { g ->
                    ModeChip(g, groupBy == g) { groupBy = g }
                }
            }
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Tamaño:", color = Muted, fontSize = 12.sp)
                listOf("S", "M", "L").forEach { s -> ModeChip(s, size == s) { size = s } }
                if (spines) ModeChip(if (adjust) "Listo" else "Ajustar lomos", adjust) { adjust = !adjust }
            }
            if (adjust) {
                Text("Toca un lomo para cambiar su alto y ancho.", color = Muted, fontSize = 11.sp)
            }

            val groups = remember(books, groupBy) {
                val map = books.groupBy { b ->
                    when (groupBy) {
                        "Autor" -> b.author
                        "Estado" -> statusLabel(b.statusKey())
                        "Formato" -> b.format
                        else -> b.genreLabel()
                    }
                }
                val order = listOf("Por leer", "Leyendo", "Terminado")
                if (groupBy == "Estado") map.toList().sortedBy { order.indexOf(it.first) }
                else map.toList().sortedBy { it.first.lowercase() }
            }

            LazyColumn(
                Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)
            ) {
                item { ShelfStats(books) }
                items(groups, key = { it.first }) { (label, list) ->
                    ShelfGroup(
                        label = label, list = list, spines = spines, size = size,
                        onTap = { b -> if (spines && adjust) resizing = b else onDetail(b) }
                    )
                }
            }
        }
    }

    resizing?.let { b ->
        SpineDialog(
            book = b, size = size,
            onDone = { w, h -> onSpineSize(b.id, w, h); resizing = null },
            onDismiss = { resizing = null }
        )
    }
}

@Composable
private fun ModeChip(text: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected, onClick = onClick,
        label = { Text(text, fontSize = 12.sp) },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = Gold, selectedLabelColor = Ink, labelColor = Cream
        )
    )
}

@Composable
private fun ShelfStats(books: List<LibraryItem>) {
    PaperCard(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
            listOf(
                "Libros" to books.size,
                "Terminados" to books.count { it.statusKey() == "FINISHED" },
                "Leyendo" to books.count { it.statusKey() == "READING" },
                "Por leer" to books.count { it.statusKey() == "TBR" }
            ).forEach { (l, n) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$n", color = Cream, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(l, color = Muted, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun ShelfGroup(
    label: String,
    list: List<LibraryItem>,
    spines: Boolean,
    size: String,
    onTap: (LibraryItem) -> Unit
) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp)) {
            Text(label.uppercase(), color = Cream, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp, modifier = Modifier.weight(1f))
            Text("${list.size}", color = Muted, fontSize = 12.sp)
        }
        BoxWithConstraints(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(ShelfBack)
        ) {
            val gap = 4
            val usable = maxWidth.value - 20f
            val dims = list.associate { b ->
                b.id to (if (spines) spineDims(b, size) else coverDims(size))
            }
            val rows = ArrayList<MutableList<LibraryItem>>()
            rows.add(ArrayList())
            var cur = 0f
            list.forEach { b ->
                val w = (dims[b.id]?.first ?: 60) + gap
                if (cur + w > usable && rows.last().isNotEmpty()) {
                    rows.add(ArrayList())
                    cur = 0f
                }
                rows.last().add(b)
                cur += w
            }
            Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp)) {
                rows.forEach { row ->
                    val rowH = row.maxOf { dims[it.id]?.second ?: 90 }
                    Row(
                        Modifier.fillMaxWidth().padding(top = 10.dp).height(rowH.dp),
                        horizontalArrangement = Arrangement.spacedBy(gap.dp),
                        verticalAlignment = Alignment.Bottom
                    ) {
                        row.forEach { b ->
                            val (w, h) = dims[b.id] ?: (60 to 90)
                            if (spines) {
                                SpineView(b, w, h, Modifier.clickable { onTap(b) })
                            } else {
                                BookCover(b, Modifier.size(w.dp, h.dp).clickable { onTap(b) }, textSize = 8.sp)
                            }
                        }
                    }
                    Box(
                        Modifier.fillMaxWidth().height(9.dp)
                            .background(Brush.verticalGradient(listOf(WoodLight, WoodDark)))
                    )
                }
            }
        }
    }
}

@Composable
private fun SpineView(b: LibraryItem, w: Int, h: Int, modifier: Modifier = Modifier) {
    val color = remember(b.id, b.title) { spineColor(b) }
    val dark = color.luminance() < 0.5f
    val textArgb = if (dark) 0xFFF3E6C8.toInt() else 0xFF1B2A41.toInt()
    Canvas(modifier.size(w.dp, h.dp)) {
        drawRoundRect(color, cornerRadius = CornerRadius(3.dp.toPx()))
        drawRect(Color.Black.copy(alpha = 0.14f), Offset.Zero, Size(size.width * 0.14f, size.height))
        val band = if (dark) Color(0xFFD4AF37) else Color(0xFF86592F)
        drawRect(band.copy(alpha = 0.85f), Offset(0f, size.height * 0.06f), Size(size.width, 2.dp.toPx()))
        drawRect(band.copy(alpha = 0.85f), Offset(0f, size.height * 0.94f), Size(size.width, 2.dp.toPx()))
        drawIntoCanvas { canvas ->
            val paint = android.graphics.Paint().apply {
                isAntiAlias = true
                this.color = textArgb
                textSize = minOf(12.sp.toPx(), size.width * 0.5f)
                isFakeBoldText = true
            }
            val maxLen = size.height * 0.80f
            val n = paint.breakText(b.title, true, maxLen, null)
            val text = if (n < b.title.length && n > 1) b.title.substring(0, n - 1) + "…" else b.title.take(maxOf(n, 0))
            val nc = canvas.nativeCanvas
            nc.save()
            nc.translate(size.width / 2f - paint.textSize * 0.35f, size.height * 0.1f)
            nc.rotate(90f)
            nc.drawText(text, 0f, 0f, paint)
            nc.restore()
        }
    }
}

@Composable
private fun SpineDialog(
    book: LibraryItem,
    size: String,
    onDone: (Int, Int) -> Unit,
    onDismiss: () -> Unit
) {
    val (w0, h0) = spineDims(book, size)
    var w by remember(book.id) { mutableStateOf(w0.toFloat()) }
    var h by remember(book.id) { mutableStateOf(h0.toFloat()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text(book.title, color = Cream, maxLines = 2, fontSize = 16.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.BottomCenter) {
                    SpineView(book.copy(spineWidthDp = w.toInt(), spineHeightDp = h.toInt()), w.toInt(), h.toInt())
                }
                Text("Alto: ${h.toInt()}", color = Muted, fontSize = 12.sp)
                Slider(
                    value = h, onValueChange = { h = it }, valueRange = 70f..190f,
                    colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold)
                )
                Text("Ancho: ${w.toInt()}", color = Muted, fontSize = 12.sp)
                Slider(
                    value = w, onValueChange = { w = it }, valueRange = 16f..60f,
                    colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onDone(w.toInt(), h.toInt()) }) { Text("Listo", color = Gold) }
        },
        dismissButton = {
            TextButton(onClick = { onDone(0, 0) }) { Text("Automático", color = Muted) }
        }
    )
}
