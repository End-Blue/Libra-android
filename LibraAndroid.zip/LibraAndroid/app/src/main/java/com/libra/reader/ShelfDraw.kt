package com.libra.reader

import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ══════════════════════════════════════════════════════════════════════════════
// Dibujo de la estantería personalizada (todo con Canvas, sin imágenes)
// ══════════════════════════════════════════════════════════════════════════════

internal fun plankDp(thickness: Int): Int = when (thickness) { 0 -> 7; 2 -> 15; else -> 11 }

// ── Pared ────────────────────────────────────────────────────────────────────
internal fun DrawScope.drawWall(wall: WallDef) {
    val w = size.width
    val h = size.height
    if (wall.pattern == 9) {
        drawRect(Brush.verticalGradient(listOf(wall.base, wall.accent)), Offset.Zero, size)
        return
    }
    drawRect(wall.base, Offset.Zero, size)
    when (wall.pattern) {
        1 -> {
            val step = 18.dp.toPx()
            var x = 0f
            var i = 0
            while (x < w) {
                if (i % 2 == 0) drawRect(wall.accent.copy(alpha = 0.55f), Offset(x, 0f), Size(step, h))
                x += step
                i++
            }
        }
        2 -> {
            val bh = 14.dp.toPx()
            val bw = 36.dp.toPx()
            val sw = 1.5.dp.toPx()
            var y = 0f
            var r = 0
            while (y < h) {
                drawLine(wall.accent, Offset(0f, y), Offset(w, y), sw)
                var x = if (r % 2 == 0) 0f else -bw / 2f
                while (x < w) {
                    drawLine(wall.accent, Offset(x, y), Offset(x, y + bh), sw)
                    x += bw
                }
                y += bh
                r++
            }
        }
        3 -> {
            val s = 26.dp.toPx()
            val r = 3.5.dp.toPx()
            var gy = 0
            while (gy * s / 2f < h + s) {
                var gx = 0
                while (gx * s < w + s) {
                    val cx = gx * s + (if (gy % 2 == 0) 0f else s / 2f)
                    val cy = gy * s / 2f
                    val p = Path().apply {
                        moveTo(cx, cy - r); lineTo(cx + r, cy); lineTo(cx, cy + r); lineTo(cx - r, cy); close()
                    }
                    drawPath(p, wall.accent)
                    gx++
                }
                gy++
            }
        }
        4 -> {
            val step = 24.dp.toPx()
            var x = 0f
            var i = 0
            while (x < w) {
                if (i % 2 == 1) drawRect(Color.Black.copy(alpha = 0.06f), Offset(x, 0f), Size(step, h))
                drawLine(wall.accent, Offset(x, 0f), Offset(x, h), 1.dp.toPx())
                x += step
                i++
            }
        }
        5 -> {
            for (i in 0 until 160) {
                val fx = ((i * 7919) % 1000) / 1000f
                val fy = ((i * 104729) % 1000) / 1000f
                val rad = (0.8f + (i % 4) * 0.5f).dp.toPx()
                drawCircle(wall.accent.copy(alpha = 0.7f), rad, Offset(fx * w, fy * h))
            }
        }
        6 -> {
            val step = 6.dp.toPx()
            var y = 0f
            while (y < h) { drawLine(wall.accent.copy(alpha = 0.3f), Offset(0f, y), Offset(w, y), 0.6.dp.toPx()); y += step }
            var x = 0f
            while (x < w) { drawLine(wall.accent.copy(alpha = 0.3f), Offset(x, 0f), Offset(x, h), 0.6.dp.toPx()); x += step }
        }
        7 -> {
            drawRect(Brush.verticalGradient(listOf(wall.base, Color(0xFF1F2745))), Offset.Zero, size)
            for (i in 0 until 90) {
                val fx = ((i * 7919) % 997) / 997f
                val fy = ((i * 6007) % 991) / 991f
                val bright = i % 7 == 0
                drawCircle(
                    (if (bright) Color(0xFFFFF1B8) else wall.accent).copy(alpha = if (bright) 0.95f else 0.7f),
                    (if (bright) 1.6f else 0.9f).dp.toPx(), Offset(fx * w, fy * h)
                )
            }
        }
        8 -> {
            val s = 22.dp.toPx()
            var gy = 0
            while (gy * s < h + s) {
                var gx = 0
                while (gx * s < w + s) {
                    val cx = gx * s + (if (gy % 2 == 0) 0f else s / 2f)
                    drawCircle(wall.accent, 3.dp.toPx(), Offset(cx, gy * s))
                    gx++
                }
                gy++
            }
        }
    }
}

/** Laterales de madera de la estantería («Con laterales») */
internal fun DrawScope.drawFrameSides(style: ShelfStyle) {
    if (style.frame != "SIDES") return
    val wd = woodOf(style.wood)
    val sideW = 9.dp.toPx()
    drawRect(
        Brush.horizontalGradient(listOf(wd.light, wd.dark), startX = 0f, endX = sideW),
        Offset.Zero, Size(sideW, size.height)
    )
    drawRect(
        Brush.horizontalGradient(listOf(wd.dark, wd.light), startX = size.width - sideW, endX = size.width),
        Offset(size.width - sideW, 0f), Size(sideW, size.height)
    )
}

// ── Madera ───────────────────────────────────────────────────────────────────
internal fun DrawScope.drawWoodRect(wd: WoodDef, topLeft: Offset, sz: Size) {
    drawRect(
        Brush.verticalGradient(listOf(wd.light, wd.dark), startY = topLeft.y, endY = topLeft.y + sz.height),
        topLeft, sz
    )
    val x0 = topLeft.x
    val x1 = topLeft.x + sz.width
    when (wd.kind) {
        0 -> {
            val n = maxOf(2, (sz.height / 3.dp.toPx()).toInt())
            for (i in 1..n) {
                val y = topLeft.y + sz.height * i / (n + 1f)
                drawLine(wd.grain, Offset(x0, y), Offset(x1, y), 0.8.dp.toPx())
            }
        }
        1, 3 -> {
            val n = maxOf(2, (sz.height / 3.5f.dp.toPx()).toInt())
            val step = 36.dp.toPx()
            for (i in 1..n) {
                val y = topLeft.y + sz.height * i / (n + 1f)
                val amp = (1.2f + (i % 3) * 0.8f).dp.toPx()
                val path = Path()
                path.moveTo(x0, y)
                var x = x0
                var up = i % 2 == 0
                while (x < x1) {
                    path.quadraticBezierTo(x + step / 2f, if (up) y - amp else y + amp, x + step, y)
                    x += step
                    up = !up
                }
                drawPath(path, wd.grain, style = Stroke(width = 0.8.dp.toPx()))
            }
            if (wd.kind == 3) {
                var kx = x0 + 40.dp.toPx()
                var k = 0
                while (kx < x1) {
                    val ky = topLeft.y + sz.height * (0.35f + (k % 3) * 0.15f)
                    drawOval(wd.grain, Offset(kx, ky), Size(9.dp.toPx(), minOf(5.dp.toPx(), sz.height * 0.5f)))
                    kx += 110.dp.toPx()
                    k++
                }
            }
        }
        4 -> {
            var x = x0 + 90.dp.toPx()
            while (x < x1) {
                drawLine(wd.grain, Offset(x, topLeft.y), Offset(x, topLeft.y + sz.height), 1.dp.toPx())
                x += 90.dp.toPx() + 17.dp.toPx()
            }
            val n = maxOf(1, (sz.height / 4.dp.toPx()).toInt())
            for (i in 1..n) {
                val y = topLeft.y + sz.height * i / (n + 1f)
                drawLine(wd.grain.copy(alpha = 0.18f), Offset(x0, y), Offset(x1, y), 0.7.dp.toPx())
            }
        }
        5 -> {
            var x = x0 + 60.dp.toPx()
            while (x < x1) {
                drawRect(wd.grain, Offset(x, topLeft.y), Size(2.dp.toPx(), sz.height))
                x += 70.dp.toPx()
            }
        }
        else -> Unit
    }
    drawRect(Color.White.copy(alpha = 0.22f), topLeft, Size(sz.width, 1.5.dp.toPx()))
    drawRect(
        Color.Black.copy(alpha = 0.28f),
        Offset(topLeft.x, topLeft.y + sz.height - 1.5.dp.toPx()), Size(sz.width, 1.5.dp.toPx())
    )
}

/** Balda de madera (con escuadras opcionales debajo). */
@Composable
internal fun WoodPlank(style: ShelfStyle, modifier: Modifier = Modifier) {
    val wd = woodOf(style.wood)
    val th = plankDp(style.thickness)
    Canvas(modifier.fillMaxWidth().height(th.dp)) { drawWoodRect(wd, Offset.Zero, size) }
    if (style.frame == "BRACKETS") {
        Canvas(Modifier.fillMaxWidth().height(14.dp)) {
            val bw = 14.dp.toPx()
            listOf(size.width * 0.12f, size.width * 0.88f - bw).forEach { x ->
                val p = Path().apply {
                    moveTo(x, 0f); lineTo(x + bw, 0f); lineTo(x, size.height); close()
                }
                drawPath(p, wd.dark)
                drawPath(p, wd.light.copy(alpha = 0.35f), style = Stroke(width = 1.dp.toPx()))
            }
        }
    }
}

// ── Luz ambiente ─────────────────────────────────────────────────────────────
internal fun DrawScope.drawLight(kind: String) {
    val w = size.width
    val h = size.height
    when (kind) {
        "WARM" -> drawRect(
            Brush.radialGradient(listOf(Color(0x55FFC773), Color.Transparent), center = Offset(w / 2f, 0f), radius = w * 0.95f),
            Offset.Zero, size
        )
        "COOL" -> drawRect(
            Brush.radialGradient(listOf(Color(0x449FC4FF), Color.Transparent), center = Offset(w / 2f, 0f), radius = w * 0.95f),
            Offset.Zero, size
        )
        "SUNSET" -> drawRect(
            Brush.horizontalGradient(listOf(Color(0x55FF8A3D), Color.Transparent, Color(0x33B04A7A))),
            Offset.Zero, size
        )
        "LAMP" -> {
            drawRect(
                Brush.radialGradient(listOf(Color(0x66FFD27A), Color.Transparent), center = Offset(w * 0.82f, 0f), radius = w * 0.85f),
                Offset.Zero, size
            )
            drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color(0x40000000))), Offset.Zero, size)
        }
        "FAIRY" -> {
            val y0 = 5.dp.toPx()
            val yc = 26.dp.toPx()
            val path = Path().apply { moveTo(0f, y0); quadraticBezierTo(w / 2f, yc, w, y0) }
            drawPath(path, Color(0x88331F14), style = Stroke(width = 1.2.dp.toPx()))
            val n = maxOf(6, (w / 30.dp.toPx()).toInt())
            val colors = listOf(Color(0xFFFFD27A), Color(0xFFFFB3A7), Color(0xFFFFF1B8), Color(0xFFB8E6FF))
            for (i in 0..n) {
                val t = i / n.toFloat()
                val x = w * t
                val y = y0 + 2f * (1f - t) * t * (yc - y0) + 3.dp.toPx()
                val c = colors[i % colors.size]
                drawCircle(c.copy(alpha = 0.28f), 8.dp.toPx(), Offset(x, y))
                drawCircle(c, 2.6.dp.toPx(), Offset(x, y))
            }
        }
        else -> Unit
    }
}

// ── Lomo con estilo ──────────────────────────────────────────────────────────
private val TITLE_SCALE = listOf(0.85f, 1f, 1.15f)

private fun foilColorOf(key: String, dark: Boolean): Color =
    FOIL_COLORS.firstOrNull { it.key == key }?.color ?: (if (dark) Color(0xFFD4AF37) else Color(0xFF86592F))

private fun titleColorOf(key: String, dark: Boolean, foil: Color): Color = when (key) {
    "cream" -> Color(0xFFF3E6C8)
    "gold" -> if (dark) Color(0xFFD4AF37) else Color(0xFF86592F)
    "ink" -> Color(0xFF1B2A41)
    "white" -> Color(0xFFFFFFFF)
    else -> if (dark) Color(0xFFF3E6C8) else Color(0xFF1B2A41)
}

private fun DrawScope.drawDiamond(cx: Float, cy: Float, r: Float, c: Color) {
    val p = Path().apply { moveTo(cx, cy - r); lineTo(cx + r, cy); lineTo(cx, cy + r); lineTo(cx - r, cy); close() }
    drawPath(p, c)
}

private fun DrawScope.drawFoil(kind: String, c: Color) {
    val w = size.width
    val h = size.height
    val t = 2.dp.toPx()
    when (kind) {
        "single" -> drawRect(c.copy(alpha = 0.85f), Offset(0f, h * 0.06f), Size(w, t))
        "double" -> {
            drawRect(c.copy(alpha = 0.85f), Offset(0f, h * 0.06f), Size(w, t))
            drawRect(c.copy(alpha = 0.85f), Offset(0f, h * 0.94f), Size(w, t))
        }
        "ornate" -> {
            val th = 1.3.dp.toPx()
            drawRect(c.copy(alpha = 0.85f), Offset(0f, h * 0.05f), Size(w, th))
            drawRect(c.copy(alpha = 0.85f), Offset(0f, h * 0.085f), Size(w, th))
            drawRect(c.copy(alpha = 0.85f), Offset(0f, h * 0.915f), Size(w, th))
            drawRect(c.copy(alpha = 0.85f), Offset(0f, h * 0.95f), Size(w, th))
            drawDiamond(w / 2f, h * 0.125f, 2.6.dp.toPx(), c)
            drawDiamond(w / 2f, h * 0.875f, 2.6.dp.toPx(), c)
        }
        "frame" -> drawRect(
            c.copy(alpha = 0.85f), Offset(3.dp.toPx(), 3.dp.toPx()),
            Size(w - 6.dp.toPx(), h - 6.dp.toPx()), style = Stroke(width = 1.2.dp.toPx())
        )
        else -> Unit
    }
}

/** (inicio del texto, largo disponible) como fracción del alto del lomo */
private fun textRegion(foil: String): Pair<Float, Float> = when (foil) {
    "none" -> 0.06f to 0.88f
    "single" -> 0.12f to 0.82f
    "ornate" -> 0.17f to 0.66f
    "frame" -> 0.14f to 0.72f
    else -> 0.10f to 0.80f
}

@Composable
internal fun StyledSpine(
    title: String, color: Color, progress: Int, w: Int, h: Int,
    style: ShelfStyle, modifier: Modifier = Modifier
) {
    val dark = color.luminance() < 0.5f
    val foil = foilColorOf(style.foilColor, dark)
    val titleArgb = titleColorOf(style.titleColor, dark, foil).toArgb()
    val font = fontOf(style.font)
    val tf = remember(font.key) { Typeface.create(font.family, font.style) }
    val shown = if (style.caps) title.uppercase() else title
    val scale = TITLE_SCALE[style.titleSize.coerceIn(0, 2)]

    Canvas(modifier.size(w.dp, h.dp)) {
        val sw = size.width
        val sh = size.height
        drawRoundRect(color, cornerRadius = CornerRadius(3.dp.toPx()))

        // Material de la cubierta
        when (style.material) {
            "leather" -> {
                for (i in 0 until 36) {
                    val fx = ((i * 37) % 97) / 97f
                    val fy = ((i * 53) % 89) / 89f
                    drawCircle(Color.Black.copy(alpha = 0.10f), 0.8.dp.toPx(), Offset(fx * sw, fy * sh))
                }
                drawRoundRect(
                    foil.copy(alpha = 0.5f), Offset(2.dp.toPx(), 2.dp.toPx()),
                    Size(sw - 4.dp.toPx(), sh - 4.dp.toPx()), CornerRadius(2.dp.toPx()),
                    style = Stroke(
                        width = 0.8.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(4.dp.toPx(), 3.dp.toPx()))
                    )
                )
            }
            "cloth" -> {
                val step = 3.dp.toPx()
                var y = 0f
                while (y < sh) { drawLine(Color.Black.copy(alpha = 0.07f), Offset(0f, y), Offset(sw, y), 0.6.dp.toPx()); y += step }
                var x = 0f
                while (x < sw) { drawLine(Color.White.copy(alpha = 0.07f), Offset(x, 0f), Offset(x, sh), 0.6.dp.toPx()); x += step }
            }
            "emboss" -> {
                drawRect(
                    Color.Black.copy(alpha = 0.25f), Offset(3.dp.toPx(), 3.dp.toPx()),
                    Size(sw - 6.dp.toPx(), sh - 6.dp.toPx()), style = Stroke(width = 1.dp.toPx())
                )
                drawRect(
                    Color.White.copy(alpha = 0.2f), Offset(4.dp.toPx(), 4.dp.toPx()),
                    Size(sw - 6.dp.toPx(), sh - 6.dp.toPx()), style = Stroke(width = 0.8.dp.toPx())
                )
            }
            "gloss" -> drawRoundRect(
                brush = Brush.horizontalGradient(
                    listOf(Color.White.copy(alpha = 0.30f), Color.Transparent, Color.Black.copy(alpha = 0.18f))
                ),
                cornerRadius = CornerRadius(3.dp.toPx())
            )
            "rustic" -> {
                var y = 5.dp.toPx()
                while (y < sh) { drawRect(Color.Black.copy(alpha = 0.10f), Offset(0f, y), Size(sw, 1.5.dp.toPx())); y += 7.dp.toPx() }
                for (i in 0 until 6) {
                    val fx = ((i * 41) % 89) / 89f
                    drawLine(Color.White.copy(alpha = 0.08f), Offset(fx * sw, 0f), Offset(fx * sw, sh), 0.7.dp.toPx())
                }
            }
            else -> Unit
        }

        // Sombra del lomo (como antes) y adornos de lámina
        drawRect(Color.Black.copy(alpha = 0.14f), Offset.Zero, Size(sw * 0.14f, sh))
        drawFoil(style.foil, foil)

        // Título en vertical
        val (top, lenFrac) = textRegion(style.foil)
        drawIntoCanvas { canvas ->
            val paint = android.graphics.Paint().apply {
                isAntiAlias = true
                this.color = titleArgb
                this.typeface = tf
                textSize = minOf(12.sp.toPx() * scale, sw * 0.5f)
            }
            val maxLen = sh * lenFrac
            val n = paint.breakText(shown, true, maxLen, null)
            val text = if (n < shown.length && n > 1) shown.substring(0, n - 1) + "…" else shown.take(maxOf(n, 0))
            val nc = canvas.nativeCanvas
            nc.save()
            nc.translate(sw / 2f - paint.textSize * 0.35f, sh * top)
            nc.rotate(90f)
            nc.drawText(text, 0f, 0f, paint)
            nc.restore()
        }

        // Marca de progreso de lectura
        if (style.showProgress && progress in 1..100) {
            val ph = sh * progress / 100f
            drawRect(foil.copy(alpha = 0.9f), Offset(sw - 3.dp.toPx(), sh - ph), Size(2.dp.toPx(), ph))
        }
    }
}

// ── Decoraciones físicas ─────────────────────────────────────────────────────
@Composable
internal fun DecoView(def: DecoDef, modifier: Modifier = Modifier) {
    Canvas(modifier.size(def.w.dp, def.h.dp)) { drawDeco(def.key) }
}

private fun DrawScope.drawDeco(key: String) {
    val w = size.width
    val h = size.height
    fun o(x: Float, y: Float) = Offset(x * w, y * h)
    fun s(sw: Float, sh: Float) = Size(sw * w, sh * h)
    when (key) {
        "plant" -> {
            val leafA = Color(0xFF3F7D4A)
            val leafB = Color(0xFF5BA063)
            drawLine(leafA, o(0.5f, 0.62f), o(0.5f, 0.2f), 1.5.dp.toPx())
            drawOval(leafB, o(0.38f, 0.04f), s(0.24f, 0.34f))
            drawOval(leafA, o(0.08f, 0.26f), s(0.36f, 0.18f))
            drawOval(leafB, o(0.56f, 0.2f), s(0.36f, 0.18f))
            drawOval(leafA, o(0.14f, 0.44f), s(0.3f, 0.16f))
            drawOval(leafB, o(0.56f, 0.42f), s(0.3f, 0.16f))
            val pot = Path().apply {
                moveTo(0.22f * w, 0.6f * h); lineTo(0.78f * w, 0.6f * h)
                lineTo(0.68f * w, h); lineTo(0.32f * w, h); close()
            }
            drawPath(pot, Color(0xFFC0673F))
            drawRect(Color(0xFFA8532F), o(0.18f, 0.56f), s(0.64f, 0.08f))
        }
        "cactus" -> {
            val g = Color(0xFF4C8C5A)
            drawRoundRect(g, o(0.36f, 0.1f), s(0.28f, 0.68f), CornerRadius(0.14f * w))
            drawRoundRect(g, o(0.1f, 0.36f), s(0.3f, 0.12f), CornerRadius(0.06f * w))
            drawRoundRect(g, o(0.1f, 0.24f), s(0.12f, 0.24f), CornerRadius(0.06f * w))
            drawRoundRect(g, o(0.6f, 0.44f), s(0.3f, 0.12f), CornerRadius(0.06f * w))
            drawRoundRect(g, o(0.78f, 0.32f), s(0.12f, 0.24f), CornerRadius(0.06f * w))
            drawCircle(Color(0xFFE88AA8), 0.07f * w, o(0.5f, 0.1f))
            drawRoundRect(Color(0xFFD9A066), o(0.24f, 0.76f), s(0.52f, 0.24f), CornerRadius(2.dp.toPx()))
            drawRect(Color(0xFFBF8447), o(0.2f, 0.74f), s(0.6f, 0.06f))
        }
        "flowers" -> {
            val stem = Color(0xFF4E8A4F)
            listOf(0.3f, 0.5f, 0.7f).forEach { x -> drawLine(stem, o(0.5f, 0.6f), o(x, 0.2f), 1.3.dp.toPx()) }
            drawCircle(Color(0xFFE88AA8), 0.13f * w, o(0.3f, 0.2f))
            drawCircle(Color(0xFFF5D26B), 0.13f * w, o(0.5f, 0.12f))
            drawCircle(Color(0xFFF7F3EA), 0.13f * w, o(0.7f, 0.2f))
            drawCircle(Color(0xFFE0A93A), 0.05f * w, o(0.5f, 0.12f))
            val vase = Path().apply {
                moveTo(0.32f * w, 0.55f * h)
                lineTo(0.68f * w, 0.55f * h)
                quadraticBezierTo(0.9f * w, 0.78f * h, 0.7f * w, h)
                lineTo(0.3f * w, h)
                quadraticBezierTo(0.1f * w, 0.78f * h, 0.32f * w, 0.55f * h)
                close()
            }
            drawPath(vase, Color(0xFF6FA8B8))
            drawRect(Color.White.copy(alpha = 0.25f), o(0.34f, 0.62f), s(0.08f, 0.26f))
        }
        "candle" -> {
            drawCircle(Color(0x44FFC773), 0.9f * w, o(0.5f, 0.22f))
            drawOval(Color(0xFFC9A24A), o(0.06f, 0.86f), s(0.88f, 0.14f))
            drawRoundRect(Color(0xFFF3E9D2), o(0.3f, 0.36f), s(0.4f, 0.54f), CornerRadius(2.dp.toPx()))
            drawLine(Color(0xFF4A3A2A), o(0.5f, 0.36f), o(0.5f, 0.3f), 1.dp.toPx())
            val flame = Path().apply {
                moveTo(0.5f * w, 0.04f * h)
                quadraticBezierTo(0.72f * w, 0.2f * h, 0.5f * w, 0.32f * h)
                quadraticBezierTo(0.28f * w, 0.2f * h, 0.5f * w, 0.04f * h)
                close()
            }
            drawPath(flame, Color(0xFFF5A623))
            drawOval(Color(0xFFFFE08A), o(0.43f, 0.16f), s(0.14f, 0.14f))
        }
        "lamp" -> {
            drawCircle(Color(0x33FFD27A), 0.8f * w, o(0.5f, 0.4f))
            drawRoundRect(Color(0xFF5B4630), o(0.34f, 0.92f), s(0.32f, 0.08f), CornerRadius(2.dp.toPx()))
            drawRect(Color(0xFF5B4630), o(0.47f, 0.38f), s(0.06f, 0.56f))
            val shade = Path().apply {
                moveTo(0.22f * w, 0.08f * h); lineTo(0.78f * w, 0.08f * h)
                lineTo(0.95f * w, 0.4f * h); lineTo(0.05f * w, 0.4f * h); close()
            }
            drawPath(shade, Color(0xFF2E5E4E))
            drawRect(Color(0xFFFFE8A3).copy(alpha = 0.5f), o(0.1f, 0.38f), s(0.8f, 0.04f))
        }
        "coffee" -> {
            drawOval(Color(0xFFE8E2D4), o(0.04f, 0.84f), s(0.84f, 0.16f))
            drawRoundRect(Color(0xFFF7F3EA), o(0.12f, 0.34f), s(0.6f, 0.56f), CornerRadius(0.18f * w))
            drawOval(Color(0xFF5A3A24), o(0.14f, 0.34f), s(0.56f, 0.12f))
            drawCircle(Color(0xFFF7F3EA), 0.14f * w, o(0.78f, 0.6f), style = Stroke(width = 2.dp.toPx()))
            listOf(0.3f, 0.5f).forEach { x ->
                val steam = Path().apply {
                    moveTo(x * w, 0.28f * h)
                    quadraticBezierTo((x + 0.08f) * w, 0.16f * h, x * w, 0.06f * h)
                }
                drawPath(steam, Color(0x88A8A39A), style = Stroke(width = 1.2.dp.toPx(), cap = StrokeCap.Round))
            }
        }
        "globe" -> {
            drawRoundRect(Color(0xFF6B4423), o(0.28f, 0.9f), s(0.44f, 0.1f), CornerRadius(2.dp.toPx()))
            drawRect(Color(0xFF6B4423), o(0.46f, 0.74f), s(0.08f, 0.18f))
            drawCircle(Color(0xFF3E7CB1), 0.38f * w, o(0.5f, 0.4f))
            drawOval(Color(0xFF6BA36B), o(0.26f, 0.2f), s(0.22f, 0.2f))
            drawOval(Color(0xFF6BA36B), o(0.5f, 0.38f), s(0.2f, 0.26f))
            drawOval(Color.White.copy(alpha = 0.55f), o(0.34f, 0.1f), s(0.14f, 0.08f))
            drawOval(Color.White.copy(alpha = 0.35f), o(0.14f, 0.02f), s(0.72f, 0.76f), style = Stroke(width = 0.8.dp.toPx()))
        }
        "clock" -> {
            drawRoundRect(Color(0xFF6B4423), o(0.06f, 0.06f), s(0.88f, 0.84f), CornerRadius(0.2f * w))
            drawCircle(Color(0xFFF3E9D2), 0.34f * w, o(0.5f, 0.48f))
            for (i in 0 until 12) {
                val a = Math.toRadians(i * 30.0)
                val r1 = 0.28f * w
                val r2 = 0.32f * w
                drawLine(
                    Color(0xFF4A3A2A),
                    Offset(0.5f * w + (r1 * Math.sin(a)).toFloat(), 0.48f * h - (r1 * Math.cos(a)).toFloat()),
                    Offset(0.5f * w + (r2 * Math.sin(a)).toFloat(), 0.48f * h - (r2 * Math.cos(a)).toFloat()),
                    0.8.dp.toPx()
                )
            }
            drawLine(Color(0xFF2B2B33), o(0.5f, 0.48f), o(0.5f, 0.28f), 1.3.dp.toPx(), StrokeCap.Round)
            drawLine(Color(0xFF2B2B33), o(0.5f, 0.48f), o(0.66f, 0.54f), 1.3.dp.toPx(), StrokeCap.Round)
            drawRect(Color(0xFF4A2F18), o(0.2f, 0.9f), s(0.12f, 0.1f))
            drawRect(Color(0xFF4A2F18), o(0.68f, 0.9f), s(0.12f, 0.1f))
        }
        "hourglass" -> {
            val glass = Color(0x66BFD9E6)
            val sand = Color(0xFFE0B85A)
            val top = Path().apply { moveTo(0.18f * w, 0.1f * h); lineTo(0.82f * w, 0.1f * h); lineTo(0.5f * w, 0.5f * h); close() }
            val bot = Path().apply { moveTo(0.5f * w, 0.5f * h); lineTo(0.82f * w, 0.9f * h); lineTo(0.18f * w, 0.9f * h); close() }
            drawPath(top, glass); drawPath(bot, glass)
            val sTop = Path().apply { moveTo(0.34f * w, 0.26f * h); lineTo(0.66f * w, 0.26f * h); lineTo(0.5f * w, 0.5f * h); close() }
            val sBot = Path().apply { moveTo(0.5f * w, 0.68f * h); lineTo(0.76f * w, 0.9f * h); lineTo(0.24f * w, 0.9f * h); close() }
            drawPath(sTop, sand); drawPath(sBot, sand)
            drawRoundRect(Color(0xFF6B4423), o(0.1f, 0.02f), s(0.8f, 0.09f), CornerRadius(2.dp.toPx()))
            drawRoundRect(Color(0xFF6B4423), o(0.1f, 0.89f), s(0.8f, 0.09f), CornerRadius(2.dp.toPx()))
        }
        "inkwell" -> {
            drawRoundRect(Color(0xFF2A2F3A), o(0.1f, 0.58f), s(0.62f, 0.42f), CornerRadius(3.dp.toPx()))
            drawRect(Color(0xFF1B1F27), o(0.26f, 0.5f), s(0.3f, 0.1f))
            drawRect(Color.White.copy(alpha = 0.18f), o(0.16f, 0.64f), s(0.08f, 0.26f))
            val quill = Path().apply {
                moveTo(0.4f * w, 0.52f * h)
                quadraticBezierTo(0.95f * w, 0.3f * h, 0.86f * w, 0.02f * h)
                quadraticBezierTo(0.5f * w, 0.14f * h, 0.4f * w, 0.52f * h)
                close()
            }
            drawPath(quill, Color(0xFFF3E9D2))
            drawLine(Color(0xFF8A7A5A), o(0.4f, 0.52f), o(0.84f, 0.06f), 1.dp.toPx())
        }
        "stack" -> {
            drawRoundRect(Color(0xFF7A2E3A), o(0.02f, 0.66f), s(0.96f, 0.34f), CornerRadius(2.dp.toPx()))
            drawRoundRect(Color(0xFF2F4B6B), o(0.1f, 0.34f), s(0.8f, 0.32f), CornerRadius(2.dp.toPx()))
            drawRoundRect(Color(0xFFB5832F), o(0.18f, 0.04f), s(0.64f, 0.3f), CornerRadius(2.dp.toPx()))
            listOf(0.66f to 0.34f, 0.34f to 0.32f, 0.04f to 0.3f).forEach { (y, hh) ->
                drawLine(Color(0xFFF3E9D2), o(0.2f, y + hh * 0.5f), o(0.8f, y + hh * 0.5f), 1.dp.toPx())
            }
        }
        "glasses" -> {
            val c = Color(0xFF2B2B33)
            val r = 0.42f * h
            drawCircle(c, r, o(0.27f, 0.5f), style = Stroke(width = 1.4.dp.toPx()))
            drawCircle(c, r, o(0.73f, 0.5f), style = Stroke(width = 1.4.dp.toPx()))
            drawLine(c, o(0.27f + 0.42f * h / w, 0.45f), o(0.73f - 0.42f * h / w, 0.45f), 1.4.dp.toPx())
            drawLine(c, o(0.0f, 0.4f), o(0.27f - 0.42f * h / w, 0.45f), 1.2.dp.toPx())
            drawLine(c, o(1.0f, 0.4f), o(0.73f + 0.42f * h / w, 0.45f), 1.2.dp.toPx())
        }
        "cat" -> {
            val c = Color(0xFF2B2B33)
            val tail = Path().apply {
                moveTo(0.76f * w, 0.92f * h)
                quadraticBezierTo(1.05f * w, 0.8f * h, 0.9f * w, 0.52f * h)
            }
            drawPath(tail, c, style = Stroke(width = 0.07f * w, cap = StrokeCap.Round))
            drawOval(c, o(0.18f, 0.44f), s(0.62f, 0.56f))
            drawCircle(c, 0.2f * w, o(0.48f, 0.3f))
            val ear1 = Path().apply { moveTo(0.3f * w, 0.2f * h); lineTo(0.3f * w, 0.02f * h); lineTo(0.44f * w, 0.14f * h); close() }
            val ear2 = Path().apply { moveTo(0.66f * w, 0.2f * h); lineTo(0.66f * w, 0.02f * h); lineTo(0.52f * w, 0.14f * h); close() }
            drawPath(ear1, c); drawPath(ear2, c)
            drawCircle(Color(0xFFF5D26B), 0.035f * w, o(0.4f, 0.3f))
            drawCircle(Color(0xFFF5D26B), 0.035f * w, o(0.56f, 0.3f))
        }
        "owl" -> {
            drawOval(Color(0xFF8A6240), o(0.14f, 0.26f), s(0.72f, 0.72f))
            drawOval(Color(0xFFD9B98C), o(0.3f, 0.54f), s(0.4f, 0.4f))
            val e1 = Path().apply { moveTo(0.2f * w, 0.34f * h); lineTo(0.2f * w, 0.08f * h); lineTo(0.38f * w, 0.26f * h); close() }
            val e2 = Path().apply { moveTo(0.8f * w, 0.34f * h); lineTo(0.8f * w, 0.08f * h); lineTo(0.62f * w, 0.26f * h); close() }
            drawPath(e1, Color(0xFF6B4A2E)); drawPath(e2, Color(0xFF6B4A2E))
            drawCircle(Color(0xFFF7F3EA), 0.13f * w, o(0.36f, 0.38f))
            drawCircle(Color(0xFFF7F3EA), 0.13f * w, o(0.64f, 0.38f))
            drawCircle(Color(0xFF2B2B33), 0.06f * w, o(0.36f, 0.38f))
            drawCircle(Color(0xFF2B2B33), 0.06f * w, o(0.64f, 0.38f))
            val beak = Path().apply { moveTo(0.44f * w, 0.46f * h); lineTo(0.56f * w, 0.46f * h); lineTo(0.5f * w, 0.56f * h); close() }
            drawPath(beak, Color(0xFFE8903A))
        }
        "trophy" -> {
            val g = Color(0xFFE8B63D)
            drawCircle(g, 0.14f * w, o(0.12f, 0.24f), style = Stroke(width = 0.06f * w))
            drawCircle(g, 0.14f * w, o(0.88f, 0.24f), style = Stroke(width = 0.06f * w))
            val cup = Path().apply {
                moveTo(0.2f * w, 0.04f * h); lineTo(0.8f * w, 0.04f * h)
                quadraticBezierTo(0.8f * w, 0.5f * h, 0.56f * w, 0.56f * h)
                lineTo(0.44f * w, 0.56f * h)
                quadraticBezierTo(0.2f * w, 0.5f * h, 0.2f * w, 0.04f * h)
                close()
            }
            drawPath(cup, g)
            drawRect(g, o(0.44f, 0.56f), s(0.12f, 0.26f))
            drawRoundRect(Color(0xFF6B4423), o(0.24f, 0.82f), s(0.52f, 0.18f), CornerRadius(2.dp.toPx()))
            drawRect(Color.White.copy(alpha = 0.35f), o(0.28f, 0.1f), s(0.08f, 0.3f))
        }
        "frame" -> {
            drawRoundRect(Color(0xFF7A5232), o(0.04f, 0.04f), s(0.92f, 0.78f), CornerRadius(2.dp.toPx()))
            drawRect(Color(0xFFF3E9D2), o(0.14f, 0.14f), s(0.72f, 0.58f))
            drawRect(Color(0xFFBFD9E6), o(0.14f, 0.14f), s(0.72f, 0.34f))
            val hill = Path().apply { moveTo(0.14f * w, 0.72f * h); lineTo(0.42f * w, 0.36f * h); lineTo(0.64f * w, 0.72f * h); close() }
            drawPath(hill, Color(0xFF5B8A5B))
            drawCircle(Color(0xFFF5D26B), 0.07f * w, o(0.7f, 0.26f))
            drawLine(Color(0xFF7A5232), o(0.5f, 0.82f), o(0.62f, 1f), 1.5.dp.toPx())
        }
        else -> Unit
    }
}
