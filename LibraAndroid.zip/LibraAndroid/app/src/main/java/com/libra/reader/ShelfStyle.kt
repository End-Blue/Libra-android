package com.libra.reader

import android.content.Context
import androidx.compose.ui.graphics.Color

// ══════════════════════════════════════════════════════════════════════════════
// Taller de estantería: todo lo que el lector puede personalizar.
// Los ajustes se guardan en SharedPreferences («libra_prefs»), sin tocar la base de datos.
// ══════════════════════════════════════════════════════════════════════════════

/** Tipo de madera / acabado de la balda. kind: 0 veta recta, 1 veta ondulada, 2 lacado liso, 3 nudos, 4 tablones, 5 bambú */
internal data class WoodDef(
    val key: String, val label: String,
    val light: Color, val dark: Color, val grain: Color, val kind: Int
)

internal val WOODS = listOf(
    WoodDef("oak", "Roble dorado", Color(0xFFB98D5C), Color(0xFF86592F), Color(0x33502A0A), 0),
    WoodDef("lightoak", "Roble claro", Color(0xFFDDB985), Color(0xFFBB9159), Color(0x33704A22), 0),
    WoodDef("walnut", "Nogal", Color(0xFF8B5E3C), Color(0xFF5E3A22), Color(0x44301A0A), 1),
    WoodDef("cherry", "Cerezo", Color(0xFFB4663F), Color(0xFF86432A), Color(0x44501F0E), 1),
    WoodDef("mahogany", "Caoba", Color(0xFF8E3B2B), Color(0xFF5F2219), Color(0x44300C08), 1),
    WoodDef("teak", "Teca", Color(0xFFB0793F), Color(0xFF85561F), Color(0x44421F08), 1),
    WoodDef("ebony", "Ébano", Color(0xFF3A3029), Color(0xFF1F1813), Color(0x33000000), 0),
    WoodDef("pine", "Pino con nudos", Color(0xFFE6C98F), Color(0xFFC9A263), Color(0x33856024), 3),
    WoodDef("birch", "Abedul", Color(0xFFF0DDB8), Color(0xFFD3B987), Color(0x22906A3A), 0),
    WoodDef("bamboo", "Bambú", Color(0xFFD8C27A), Color(0xFFB09B52), Color(0x44594D1C), 5),
    WoodDef("driftwood", "Madera gris", Color(0xFFB9B2A5), Color(0xFF8F887B), Color(0x44504A40), 4),
    WoodDef("white", "Blanco lacado", Color(0xFFF4F1EA), Color(0xFFD8D3C7), Color(0x00000000), 2),
    WoodDef("black", "Negro mate", Color(0xFF2B2B2E), Color(0xFF17171A), Color(0x00000000), 2),
    WoodDef("navy", "Azul noche", Color(0xFF2F4B6B), Color(0xFF1C3048), Color(0x00000000), 2),
    WoodDef("forest", "Verde bosque", Color(0xFF3E6B4A), Color(0xFF264A33), Color(0x00000000), 2),
    WoodDef("burgundy", "Borgoña", Color(0xFF7A2E3A), Color(0xFF4F1822), Color(0x00000000), 2),
    WoodDef("rose", "Rosa empolvado", Color(0xFFD9A7A0), Color(0xFFB7807A), Color(0x00000000), 2)
)

internal fun woodOf(key: String): WoodDef = WOODS.firstOrNull { it.key == key } ?: WOODS[0]

/** Pared del fondo. pattern: 0 liso, 1 rayas, 2 ladrillo, 3 rombos, 4 paneles, 5 corcho, 6 lino, 7 estrellas, 8 lunares, 9 degradado */
internal data class WallDef(val key: String, val label: String, val base: Color, val accent: Color, val pattern: Int)

internal val WALLS = listOf(
    WallDef("paper", "Papel crema", Color(0xFFEADFC6), Color(0xFFDCCDAA), 0),
    WallDef("stripes", "Rayas clásicas", Color(0xFFE8DFC9), Color(0xFFD4C4A0), 1),
    WallDef("brick", "Ladrillo", Color(0xFFA9573E), Color(0xFF7F3C2A), 2),
    WallDef("damask", "Rombos azules", Color(0xFF2F4B6B), Color(0xFF3F6188), 3),
    WallDef("panels", "Paneles de roble", Color(0xFFA67C52), Color(0xFF8A6340), 4),
    WallDef("cork", "Corcho", Color(0xFFC69C6D), Color(0xFFA27A4B), 5),
    WallDef("linen", "Lino gris", Color(0xFFD9D6CF), Color(0xFFBFBAB0), 6),
    WallDef("night", "Cielo nocturno", Color(0xFF141B2E), Color(0xFF3A4770), 7),
    WallDef("dots", "Lunares", Color(0xFFF3E6D8), Color(0xFFE4B7A6), 8),
    WallDef("pine", "Verde botella", Color(0xFF264A33), Color(0xFF1B3524), 9),
    WallDef("velvet", "Terciopelo burdeos", Color(0xFF5A1F2B), Color(0xFF3E1019), 9),
    WallDef("nordic", "Blanco nórdico", Color(0xFFF6F4EF), Color(0xFFE6E2D8), 0)
)

internal fun wallOf(key: String): WallDef = WALLS.firstOrNull { it.key == key } ?: WALLS[0]

/** Paletas de colores para los lomos */
internal data class PaletteDef(val key: String, val label: String, val colors: List<Color>)

internal val PALETTES = listOf(
    PaletteDef("classic", "Clásica", listOf(
        0xFF2F4B6B, 0xFF7A2E3A, 0xFF35563F, 0xFFB5832F, 0xFF4A3B6B, 0xFF1F3C3F,
        0xFF8A4B2B, 0xFF5B6B3A, 0xFFC9B79C, 0xFF2B2B33, 0xFF9C3D2E, 0xFF3E6A7A).map { Color(it) }),
    PaletteDef("pastel", "Pastel", listOf(
        0xFFF4B8C1, 0xFFB8D8F0, 0xFFC9E4C5, 0xFFFBE3A1, 0xFFD9C3F0, 0xFFFAD0B6,
        0xFFB5E3DC, 0xFFE8C5D8, 0xFFCFE0A8, 0xFFF3D9E5).map { Color(it) }),
    PaletteDef("night", "Nocturna", listOf(
        0xFF14213D, 0xFF1F2A4F, 0xFF2B2D5B, 0xFF3A2B54, 0xFF1D3B4F, 0xFF0F2B33,
        0xFF40264F, 0xFF22303F, 0xFF2D3A66).map { Color(it) }),
    PaletteDef("forest", "Bosque", listOf(
        0xFF2F5233, 0xFF4A6B3A, 0xFF6B7F45, 0xFF5B3F2A, 0xFF7A5A36, 0xFF23402E,
        0xFF8C6B3F, 0xFF3C5A44, 0xFFA9A06B).map { Color(it) }),
    PaletteDef("earth", "Tierra", listOf(
        0xFFB5532F, 0xFFC98B4A, 0xFFD9B77A, 0xFF8A4B2B, 0xFFA66A3F, 0xFF6B3F2A,
        0xFFE0C79A, 0xFF9C6B4A, 0xFF7B5B3A).map { Color(it) }),
    PaletteDef("sea", "Mar", listOf(
        0xFF1F4E6B, 0xFF2F7A8C, 0xFF58A5A8, 0xFF8CC7C4, 0xFF264A78, 0xFF3D6FA3,
        0xFFB5DDD8, 0xFF1B3A4B, 0xFF4F8FA0).map { Color(it) }),
    PaletteDef("sunset", "Atardecer", listOf(
        0xFF9C2F3A, 0xFFD2572F, 0xFFE8903A, 0xFFF2B65A, 0xFF7A2E5A, 0xFFB5426B,
        0xFF5A2A5E, 0xFFD97A4A, 0xFF8A3A3A).map { Color(it) }),
    PaletteDef("mono", "Blanco y negro", listOf(
        0xFF1C1C20, 0xFF3A3A40, 0xFF6B6B72, 0xFFA8A8AE, 0xFFE9E6DE, 0xFFF7F4EC,
        0xFF2B2B33, 0xFFC9C6BE).map { Color(it) }),
    PaletteDef("rainbow", "Arcoíris", listOf(
        0xFFD94B4B, 0xFFE8873A, 0xFFEDC24A, 0xFF6FB05A, 0xFF3FA3A0, 0xFF4A86D9,
        0xFF7A5AD1, 0xFFC25AA8).map { Color(it) }),
    PaletteDef("gold", "Dorado y crema", listOf(
        0xFFB5832F, 0xFFD9B85A, 0xFFF0E2B6, 0xFF8C5E22, 0xFFE8D3A0, 0xFF6B4A1F,
        0xFFCFA64A, 0xFFF6EDD2).map { Color(it) })
)

internal fun paletteOf(key: String): PaletteDef = PALETTES.firstOrNull { it.key == key } ?: PALETTES[0]

internal data class OptionDef(val key: String, val label: String)

/** Materiales de la cubierta del libro */
internal val MATERIALS = listOf(
    OptionDef("paper", "Papel liso"), OptionDef("leather", "Cuero cosido"), OptionDef("cloth", "Tela"),
    OptionDef("emboss", "Relieve"), OptionDef("gloss", "Brillante"), OptionDef("rustic", "Rústico")
)

/** Adornos de lámina dorada en el lomo */
internal val FOILS = listOf(
    OptionDef("none", "Sin adorno"), OptionDef("single", "Una cinta"), OptionDef("double", "Dos cintas"),
    OptionDef("ornate", "Ornamental"), OptionDef("frame", "Marco")
)

internal data class FoilColorDef(val key: String, val label: String, val color: Color?)

internal val FOIL_COLORS = listOf(
    FoilColorDef("auto", "Automático", null),
    FoilColorDef("gold", "Oro", Color(0xFFD4AF37)),
    FoilColorDef("silver", "Plata", Color(0xFFC9CED6)),
    FoilColorDef("copper", "Cobre", Color(0xFFB8693D)),
    FoilColorDef("cream", "Crema", Color(0xFFF3E6C8)),
    FoilColorDef("ink", "Tinta", Color(0xFF1B2A41))
)

internal val TITLE_COLORS = listOf(
    OptionDef("auto", "Automático"), OptionDef("cream", "Crema"), OptionDef("gold", "Dorado"),
    OptionDef("ink", "Tinta"), OptionDef("white", "Blanco")
)

/** Tipos de letra del lomo (fuentes del sistema; no hace falta añadir archivos) */
internal data class FontDef(val key: String, val label: String, val family: String, val style: Int)

internal val FONTS = listOf(
    FontDef("serifbold", "Clásica negrita", "serif", 1),
    FontDef("serif", "Clásica", "serif", 0),
    FontDef("italic", "Cursiva elegante", "serif", 2),
    FontDef("modern", "Moderna", "sans-serif-medium", 0),
    FontDef("light", "Fina", "sans-serif-light", 0),
    FontDef("black", "Gruesa", "sans-serif-black", 0),
    FontDef("condensed", "Condensada", "sans-serif-condensed", 0),
    FontDef("mono", "Máquina de escribir", "monospace", 0),
    FontDef("script", "Manuscrita", "cursive", 0),
    FontDef("casual", "Informal", "casual", 0)
)

internal fun fontOf(key: String): FontDef = FONTS.firstOrNull { it.key == key } ?: FONTS[0]

internal val LIGHTS = listOf(
    OptionDef("NONE", "Sin luz"), OptionDef("WARM", "Cálida"), OptionDef("COOL", "Fría"),
    OptionDef("SUNSET", "Atardecer"), OptionDef("LAMP", "Lámpara"), OptionDef("FAIRY", "Guirnalda")
)

internal val FRAMES = listOf(
    OptionDef("NONE", "Solo balda"), OptionDef("SIDES", "Con laterales"), OptionDef("BRACKETS", "Con escuadras")
)

/** Decoraciones físicas que se colocan sobre las baldas */
internal data class DecoDef(val key: String, val label: String, val w: Int, val h: Int)

internal val DECOS = listOf(
    DecoDef("plant", "Planta", 36, 52), DecoDef("cactus", "Cactus", 30, 46),
    DecoDef("flowers", "Florero", 32, 50), DecoDef("candle", "Vela", 24, 44),
    DecoDef("lamp", "Lámpara", 38, 60), DecoDef("coffee", "Taza de café", 36, 32),
    DecoDef("globe", "Globo terráqueo", 42, 56), DecoDef("clock", "Reloj", 34, 40),
    DecoDef("hourglass", "Reloj de arena", 26, 42), DecoDef("inkwell", "Tintero y pluma", 32, 44),
    DecoDef("stack", "Pila de libros", 50, 30), DecoDef("glasses", "Gafas", 40, 18),
    DecoDef("cat", "Gato", 40, 48), DecoDef("owl", "Búho", 34, 46),
    DecoDef("trophy", "Trofeo", 30, 46), DecoDef("frame", "Foto enmarcada", 38, 46)
)

internal fun decoOf(key: String): DecoDef? = DECOS.firstOrNull { it.key == key }

internal data class ShelfStyle(
    val wood: String = "oak",
    val thickness: Int = 1,              // 0 fina, 1 media, 2 gruesa
    val frame: String = "NONE",
    val wall: String = "paper",
    val palette: String = "classic",
    val material: String = "paper",
    val foil: String = "double",
    val foilColor: String = "auto",
    val font: String = "serifbold",
    val caps: Boolean = false,
    val titleSize: Int = 1,              // 0 pequeño, 1 normal, 2 grande
    val titleColor: String = "auto",
    val showProgress: Boolean = false,
    val decos: Set<String> = emptySet(),
    val decoDensity: Int = 1,            // máximo de adornos por balda (0 = ninguno)
    val light: String = "NONE"
)

/** Temas listos para aplicar con un toque; luego se puede afinar cada detalle. */
internal val SHELF_PRESETS: List<Pair<String, ShelfStyle>> = listOf(
    "Biblioteca clásica" to ShelfStyle(
        wood = "walnut", thickness = 2, frame = "SIDES", wall = "stripes", palette = "classic",
        material = "leather", foil = "ornate", foilColor = "gold", font = "italic",
        decos = setOf("globe", "inkwell", "stack"), decoDensity = 1, light = "WARM"
    ),
    "Estudio nocturno" to ShelfStyle(
        wood = "ebony", thickness = 1, wall = "night", palette = "night", material = "gloss",
        foil = "single", foilColor = "gold", font = "modern", titleColor = "gold",
        decos = setOf("lamp", "candle", "glasses", "owl"), decoDensity = 2, light = "LAMP"
    ),
    "Cabaña" to ShelfStyle(
        wood = "pine", thickness = 2, frame = "SIDES", wall = "panels", palette = "earth",
        material = "rustic", foil = "none", font = "casual", titleColor = "cream",
        decos = setOf("plant", "coffee", "cat", "candle"), decoDensity = 2, light = "WARM"
    ),
    "Nórdico minimal" to ShelfStyle(
        wood = "white", thickness = 0, frame = "BRACKETS", wall = "nordic", palette = "mono",
        material = "paper", foil = "none", font = "light", caps = true, titleSize = 0,
        decos = setOf("plant", "candle"), decoDensity = 1, light = "NONE"
    ),
    "Café-librería" to ShelfStyle(
        wood = "lightoak", thickness = 1, wall = "brick", palette = "sunset",
        material = "cloth", foil = "single", foilColor = "cream", font = "mono",
        decos = setOf("coffee", "clock", "globe", "plant"), decoDensity = 2, light = "FAIRY"
    ),
    "Jardín" to ShelfStyle(
        wood = "bamboo", thickness = 1, wall = "dots", palette = "pastel",
        material = "cloth", foil = "none", font = "modern", titleColor = "ink",
        decos = setOf("flowers", "plant", "cactus", "owl"), decoDensity = 2, light = "SUNSET"
    ),
    "Gabinete antiguo" to ShelfStyle(
        wood = "mahogany", thickness = 2, frame = "SIDES", wall = "velvet", palette = "gold",
        material = "emboss", foil = "frame", foilColor = "gold", font = "serifbold",
        decos = setOf("globe", "hourglass", "inkwell", "trophy", "stack"), decoDensity = 2, light = "LAMP"
    ),
    "Océano" to ShelfStyle(
        wood = "navy", thickness = 1, wall = "linen", palette = "sea",
        material = "gloss", foil = "double", foilColor = "silver", font = "condensed", caps = true,
        decos = setOf("globe", "frame", "hourglass"), decoDensity = 1, light = "COOL"
    )
)

/** Elige qué adornos caben en una balda con `remainingDp` de espacio libre. */
internal fun pickDecos(style: ShelfStyle, seed: Int, rowIndex: Int, remainingDp: Float): List<DecoDef> {
    if (style.decos.isEmpty() || style.decoDensity <= 0) return emptyList()
    val pool = DECOS.filter { it.key in style.decos }
    if (pool.isEmpty()) return emptyList()
    val out = ArrayList<DecoDef>()
    var left = remainingDp
    val want = style.decoDensity.coerceIn(1, 3)
    val start = (seed and 0x7fffffff) % 97 + rowIndex * 2
    var tries = 0
    while (out.size < want && tries < pool.size * 2) {
        val d = pool[(start + tries * 3) % pool.size]
        if (d.w + 6 <= left && out.none { it.key == d.key }) {
            out.add(d)
            left -= d.w + 6
        }
        tries++
    }
    return out
}

internal object ShelfStyleStore {
    private const val PREFS = "libra_prefs"

    fun load(ctx: Context): ShelfStyle {
        val p = ctx.getSharedPreferences(PREFS, 0)
        val d = ShelfStyle()
        fun s(k: String, def: String): String = p.getString(k, def) ?: def
        return ShelfStyle(
            wood = s("ss_wood", d.wood),
            thickness = p.getInt("ss_thick", d.thickness),
            frame = s("ss_frame", d.frame),
            wall = s("ss_wall", d.wall),
            palette = s("ss_palette", d.palette),
            material = s("ss_material", d.material),
            foil = s("ss_foil", d.foil),
            foilColor = s("ss_foilc", d.foilColor),
            font = s("ss_font", d.font),
            caps = p.getBoolean("ss_caps", d.caps),
            titleSize = p.getInt("ss_tsize", d.titleSize),
            titleColor = s("ss_tcolor", d.titleColor),
            showProgress = p.getBoolean("ss_progress", d.showProgress),
            decos = s("ss_decos", "").split(",").filter { it.isNotBlank() }.toSet(),
            decoDensity = p.getInt("ss_density", d.decoDensity),
            light = s("ss_light", d.light)
        )
    }

    fun save(ctx: Context, st: ShelfStyle) {
        ctx.getSharedPreferences(PREFS, 0).edit()
            .putString("ss_wood", st.wood)
            .putInt("ss_thick", st.thickness)
            .putString("ss_frame", st.frame)
            .putString("ss_wall", st.wall)
            .putString("ss_palette", st.palette)
            .putString("ss_material", st.material)
            .putString("ss_foil", st.foil)
            .putString("ss_foilc", st.foilColor)
            .putString("ss_font", st.font)
            .putBoolean("ss_caps", st.caps)
            .putInt("ss_tsize", st.titleSize)
            .putString("ss_tcolor", st.titleColor)
            .putBoolean("ss_progress", st.showProgress)
            .putString("ss_decos", st.decos.joinToString(","))
            .putInt("ss_density", st.decoDensity)
            .putString("ss_light", st.light)
            .apply()
    }

    /** Color de lomo elegido a mano para un libro (id → ARGB). Sin entrada = automático. */
    fun loadBookColors(ctx: Context): Map<String, Long> {
        val set = ctx.getSharedPreferences(PREFS, 0).getStringSet("ss_book_colors", emptySet()) ?: emptySet()
        val out = HashMap<String, Long>()
        set.forEach { e ->
            val i = e.lastIndexOf('|')
            if (i > 0) e.substring(i + 1).toLongOrNull()?.let { out[e.substring(0, i)] = it }
        }
        return out
    }

    fun saveBookColors(ctx: Context, m: Map<String, Long>) {
        ctx.getSharedPreferences(PREFS, 0).edit()
            .putStringSet("ss_book_colors", m.map { "${it.key}|${it.value}" }.toSet())
            .apply()
    }
}
