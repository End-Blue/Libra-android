package com.libra.reader

import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ══════════════════════════════════════════════════════════════════════════════
// NOTAS Y CITAS — pantalla
//   Cabecera editorial · tarjeta «Nueva nota o cita» · filtros · lista de tarjetas con menú ⋮
// ══════════════════════════════════════════════════════════════════════════════

private val NoteCream = Color(0xFFFDF1DC)
private val NoteError = Color(0xFFB3472B)

@Composable
internal fun NotesScreen(vm: NotesViewModel = viewModel()) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    NotesContent(state, vm)
}

@Composable
private fun NotesContent(state: NotesUiState, vm: NotesViewModel) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val notes = state.notes

    // imePadding: con el teclado abierto la lista se reduce y el campo + «Guardar» nunca quedan tapados
    LazyColumn(
        Modifier.fillMaxSize().imePadding(),
        contentPadding = PaddingValues(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item(key = "notes_hero") {
            HeroHeader(
                art = R.drawable.hero_notes,
                title = "Notas y Citas",
                sub = "Guarda tus reflexiones, citas y pensamientos favoritos de tus libros.",
                quote = "", titleSize = 34, subSize = 15, subItalic = true, subWidth = 0.66f
            )
        }
        item(key = "notes_new") { NewNoteCard(state, vm, Modifier.padding(horizontal = 18.dp)) }
        item(key = "notes_filters") { NotesFilterBar(state, vm) }
        if (notes.isEmpty()) {
            item(key = "notes_empty") { NotesEmptyState(state, Modifier.padding(horizontal = 18.dp)) }
        } else {
            items(notes, key = { it.id }) { note ->
                NoteCard(
                    note = note,
                    book = state.bookOf(note.bookId),
                    menuOpen = state.activeMenuNoteId == note.id,
                    vm = vm,
                    onCopy = {
                        clipboard.setText(AnnotatedString(note.text))
                        Toast.makeText(ctx, "Texto copiado", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.padding(horizontal = 18.dp)
                )
            }
        }
    }

    // ── Diálogos ─────────────────────────────────────────────────────────────
    state.editingNote?.let { n -> EditNoteDialog(n, onSave = vm::saveEdit, onDismiss = vm::cancelEdit) }

    state.pendingDeleteId?.let {
        AlertDialog(
            onDismissRequest = vm::dismissDelete,
            containerColor = LbCardTop,
            title = { Text("¿Eliminar esta nota?", color = LbTitle, fontFamily = LibellumSerif, fontWeight = FontWeight.Bold) },
            text = { Text("Se borrará de forma definitiva y no se puede deshacer.", color = LbText, fontFamily = LibellumSerif) },
            confirmButton = { TextButton(onClick = vm::confirmDelete) { Text("Eliminar", color = NoteError, fontWeight = FontWeight.Bold) } },
            dismissButton = { TextButton(onClick = vm::dismissDelete) { Text("Cancelar", color = LbBrown) } }
        )
    }

    when (val picker = state.bookPicker) {
        BookPicker.Filter -> BookPickerDialog(
            title = "Filtrar por libro",
            options = state.booksWithNotes,
            selectedId = state.selectedBookFilter,
            noneLabel = "Todos los libros",
            emptyHint = "Aún no hay notas asociadas a ningún libro.",
            onPick = vm::selectBookFilter,
            onDismiss = { vm.openBookPicker(null) }
        )
        is BookPicker.Change -> BookPickerDialog(
            title = "Libro asociado",
            options = state.availableBooks.map { it.id to it.title },
            selectedId = state.allNotes.firstOrNull { it.id == picker.noteId }?.bookId?.ifBlank { null },
            noneLabel = "Sin libro asociado",
            emptyHint = "Tu biblioteca aún no tiene libros.",
            onPick = { vm.changeBook(picker.noteId, it) },
            onDismiss = { vm.openBookPicker(null) }
        )
        null -> Unit
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// Tarjeta «NUEVA NOTA O CITA»
// ══════════════════════════════════════════════════════════════════════════════

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun NewNoteCard(state: NotesUiState, vm: NotesViewModel, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(26.dp)
    val scope = rememberCoroutineScope()
    val bring = remember { BringIntoViewRequester() }
    var bookMenu by remember { mutableStateOf(false) }

    // El texto se edita en un TextFieldValue local (sin saltos de cursor) y se refleja en el estado;
    // cuando el estado se limpia tras guardar, el campo se vacía.
    var field by remember { mutableStateOf(TextFieldValue(state.draftText)) }
    LaunchedEffect(state.draftText) { if (state.draftText != field.text) field = TextFieldValue(state.draftText) }

    val draftBook = state.selectedBookForDraft?.let { state.bookOf(it) }

    Box(
        modifier.fillMaxWidth()
            .bringIntoViewRequester(bring)
            .shadow(4.dp, shape, ambientColor = Color(0x22805020), spotColor = Color(0x33805020))
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFFFFF6E6), Color(0xFFF8E9CF))))
            .border(1.dp, LbCardEdge, shape)
    ) {
        LeafSprig(Modifier.align(Alignment.TopEnd).offset(x = 4.dp, y = 0.dp).size(72.dp, 54.dp))
        LeafSprig(Modifier.align(Alignment.BottomStart).offset(x = (-2).dp, y = 2.dp).size(54.dp, 46.dp), flip = true)

        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Box(
                    Modifier.size(56.dp).clip(CircleShape).background(Color(0x33C99A4B)),
                    contentAlignment = Alignment.Center
                ) { NoteIcon(NoteGlyph.FEATHER, tint = LbBrown, size = 30.dp) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "NUEVA NOTA O CITA", color = LbBrownLight, fontSize = 14.sp, fontFamily = LibellumSerif,
                        fontStyle = FontStyle.Italic, fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp,
                        maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 4.dp, end = 60.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    QuoteTextField(
                        value = field,
                        onChange = { field = it; vm.onDraftChange(it.text) },
                        placeholder = "Escribe aquí tu nota o cita...",
                        error = state.draftError,
                        minLines = 3,
                        onFocus = { scope.launch { delay(350); bring.bringIntoView() } }
                    ) {
                        // marcador: marca la nota como favorita antes de guardar
                        Box(
                            Modifier.align(Alignment.TopEnd).padding(top = 6.dp, end = 6.dp).size(36.dp)
                                .clip(CircleShape)
                                .semantics { contentDescription = "Marcar como favorita" }
                                .clickable(role = Role.Button, onClick = vm::toggleDraftFavorite),
                            contentAlignment = Alignment.Center
                        ) { NoteIcon(NoteGlyph.BOOKMARK, tint = LbBrownLight, size = 22.dp, filled = state.draftMarkedFavorite) }
                    }
                    if (state.draftError) {
                        Text(
                            "Escribe algo antes de guardar.", color = NoteError, fontSize = 12.sp,
                            fontFamily = LibellumSerif, fontStyle = FontStyle.Italic,
                            modifier = Modifier.padding(start = 6.dp, top = 4.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                            .clickable { bookMenu = true }.padding(vertical = 8.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        LbIcon(LbIconKind.BOOK_OPEN, tint = LbBrown, size = 26.dp)
                        Spacer(Modifier.width(8.dp))
                        Box(Modifier.weight(1f)) {
                            LbFitText(
                                draftBook?.title ?: "Selecciona un libro (opcional)",
                                color = LbText, maxSize = 14.sp, minSize = 10.sp
                            )
                        }
                        Spacer(Modifier.width(4.dp))
                        LbIcon(LbIconKind.CHEVRON_DOWN, tint = LbBrownLight, size = 20.dp)
                    }
                    DropdownMenu(
                        expanded = bookMenu, onDismissRequest = { bookMenu = false },
                        containerColor = Color(0xFFFFF8EA)
                    ) {
                        DropdownMenuItem(
                            text = { Text("Sin libro asociado", fontFamily = LibellumSerif, color = LbText) },
                            onClick = { vm.selectDraftBook(null); bookMenu = false }
                        )
                        state.availableBooks.forEach { b ->
                            DropdownMenuItem(
                                text = {
                                    Text(b.title, fontFamily = LibellumSerif, color = LbTitle, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                },
                                onClick = { vm.selectDraftBook(b.id); bookMenu = false }
                            )
                        }
                    }
                }
                Spacer(Modifier.width(10.dp))
                Row(
                    Modifier.height(48.dp)
                        .shadow(3.dp, RoundedCornerShape(50), ambientColor = Color(0x33805020), spotColor = Color(0x44805020))
                        .clip(RoundedCornerShape(50))
                        .background(Brush.horizontalGradient(listOf(Color(0xFFB57A1E), LbBrown)))
                        .clickable(enabled = !state.isSaving, role = Role.Button, onClick = vm::saveDraft)
                        .padding(horizontal = 18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    if (state.isSaving) {
                        CircularProgressIndicator(Modifier.size(22.dp), color = NoteCream, strokeWidth = 2.dp)
                    } else {
                        NoteIcon(NoteGlyph.SAVE, tint = NoteCream, size = 24.dp)
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Guardar", color = NoteCream, fontSize = 17.sp, fontFamily = LibellumSerif,
                        fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false
                    )
                }
            }
        }
    }
}

/** Campo multilínea de estilo pergamino. [overlay] permite superponer controles (p. ej. el marcador). */
@Composable
private fun QuoteTextField(
    value: TextFieldValue,
    onChange: (TextFieldValue) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    error: Boolean = false,
    minLines: Int = 3,
    onFocus: () -> Unit = {},
    overlay: @Composable BoxScope.() -> Unit = {}
) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier.fillMaxWidth().heightIn(min = 96.dp).clip(shape)
            .background(Color(0xFFFFFAF0))
            .border(1.dp, if (error) NoteError else LbCardEdge, shape)
    ) {
        BasicTextField(
            value = value, onValueChange = onChange,
            modifier = Modifier.fillMaxWidth()
                .padding(start = 14.dp, top = 12.dp, end = 46.dp, bottom = 12.dp)
                .onFocusChanged { if (it.isFocused) onFocus() },
            textStyle = TextStyle(color = LbTitle, fontSize = 16.sp, fontFamily = LibellumSerif, lineHeight = 22.sp),
            cursorBrush = SolidColor(LbBrown),
            minLines = minLines, maxLines = 10,
            decorationBox = { inner ->
                Box {
                    if (value.text.isEmpty()) {
                        Text(
                            placeholder, color = LbMuted.copy(alpha = 0.85f), fontSize = 16.sp,
                            fontFamily = LibellumSerif, fontStyle = FontStyle.Italic, lineHeight = 22.sp
                        )
                    }
                    inner()
                }
            }
        )
        overlay()
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// Filtros
// ══════════════════════════════════════════════════════════════════════════════

@Composable
private fun NotesFilterBar(state: NotesUiState, vm: NotesViewModel) {
    val f = state.selectedFilter
    LazyRow(
        contentPadding = PaddingValues(horizontal = 18.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            FilterPill("Todas", f == NotesFilter.ALL, { c -> NoteIcon(NoteGlyph.STAR, tint = c, size = 20.dp, filled = true) }) {
                vm.selectFilter(NotesFilter.ALL)
            }
        }
        item {
            FilterPill(
                state.selectedBookFilterTitle ?: "Por libro", f == NotesFilter.BY_BOOK,
                { c -> LbIcon(LbIconKind.BOOK_OPEN, tint = c, size = 22.dp) }
            ) { vm.openBookPicker(BookPicker.Filter) }
        }
        item {
            FilterPill("Favoritas", f == NotesFilter.FAVORITES, { c -> NoteIcon(NoteGlyph.STAR, tint = c, size = 20.dp) }) {
                vm.selectFilter(NotesFilter.FAVORITES)
            }
        }
        item {
            val old = f == NotesFilter.RECENT && state.recentAscending
            FilterPill(if (old) "Antiguas" else "Recientes", f == NotesFilter.RECENT, { c -> LbIcon(LbIconKind.CLOCK, tint = c, size = 20.dp) }) {
                vm.selectFilter(NotesFilter.RECENT)
            }
        }
    }
}

@Composable
private fun FilterPill(
    label: String,
    selected: Boolean,
    icon: @Composable (Color) -> Unit,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(50)
    val fg = if (selected) NoteCream else LbBrown
    Row(
        Modifier.height(44.dp)
            .then(if (selected) Modifier.shadow(3.dp, shape, ambientColor = Color(0x33805020), spotColor = Color(0x44805020)) else Modifier)
            .clip(shape)
            .background(if (selected) Brush.horizontalGradient(listOf(Color(0xFFB57A1E), LbBrown)) else SolidColor(Color(0xFFFBEFD9)))
            .border(1.dp, if (selected) LbBrown else LbCardEdge, shape)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        icon(fg)
        Spacer(Modifier.width(7.dp))
        Text(
            label, color = if (selected) NoteCream else LbTitle, fontSize = 15.sp, fontFamily = LibellumSerif,
            maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 150.dp)
        )
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// Tarjeta de nota + menú ⋮
// ══════════════════════════════════════════════════════════════════════════════

@Composable
private fun NoteCard(
    note: QuoteNote,
    book: LibraryItem?,
    menuOpen: Boolean,
    vm: NotesViewModel,
    onCopy: () -> Unit,
    modifier: Modifier = Modifier
) {
    val date = remember(note.createdAt) { SimpleDateFormat("dd/MM/yyyy", Locale("es")).format(Date(note.createdAt)) }
    val bookTitle = book?.title ?: note.bookTitle
    val fav = note.isFavorite == 1

    LbCard(modifier.fillMaxWidth(), padding = 12.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Portada (o placeholder editorial si no hay libro)
            val coverMod = Modifier.size(width = 60.dp, height = 86.dp).clip(RoundedCornerShape(10.dp))
            if (book != null) {
                BookCover(book, coverMod)
            } else {
                Box(
                    coverMod.background(Brush.verticalGradient(listOf(Color(0xFFF4DFB8), Color(0xFFE9C98F))))
                        .border(1.dp, LbCardEdge, RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) { NoteIcon(NoteGlyph.FEATHER, tint = LbBrown.copy(alpha = 0.8f), size = 28.dp) }
            }
            Spacer(Modifier.width(12.dp))

            Column(Modifier.weight(1f)) {
                Text(
                    "“${note.text.trim().trim('“', '”', '"')}”", color = LbTitle, fontSize = 17.sp,
                    fontFamily = LibellumSerif, fontStyle = FontStyle.Italic, lineHeight = 23.sp,
                    maxLines = 5, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (bookTitle.isNotBlank()) {
                        LbIcon(LbIconKind.BOOK_OPEN, tint = LbBrown, size = 18.dp)
                        Spacer(Modifier.width(5.dp))
                        Text(
                            bookTitle, color = LbText, fontSize = 13.sp, fontFamily = LibellumSerif,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false)
                        )
                        Box(Modifier.padding(horizontal = 8.dp).width(1.dp).height(16.dp).background(LbLine))
                    }
                    LbIcon(LbIconKind.CALENDAR, tint = LbBrown, size = 18.dp)
                    Spacer(Modifier.width(5.dp))
                    Text(date, color = LbText, fontSize = 13.sp, fontFamily = LibellumSerif, maxLines = 1, softWrap = false)
                }
            }

            Spacer(Modifier.width(6.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier.size(40.dp).clip(CircleShape)
                        .semantics { contentDescription = if (fav) "Quitar de favoritas" else "Marcar como favorita" }
                        .clickable(role = Role.Button) { vm.toggleFavorite(note) },
                    contentAlignment = Alignment.Center
                ) { NoteIcon(NoteGlyph.BOOKMARK, tint = LbBrown, size = 24.dp, filled = fav) }
                Box {
                    Box(
                        Modifier.size(40.dp).clip(CircleShape)
                            .semantics { contentDescription = "Más opciones" }
                            .clickable(role = Role.Button) { vm.openMenu(note.id) },
                        contentAlignment = Alignment.Center
                    ) { LbIcon(LbIconKind.DOTS_V, tint = LbTitle, size = 22.dp) }
                    DropdownMenu(
                        expanded = menuOpen, onDismissRequest = { vm.openMenu(null) },
                        containerColor = Color(0xFFFFF8EA)
                    ) {
                        NoteMenuItem("Editar nota/cita", { NoteIcon(NoteGlyph.EDIT, size = 20.dp) }) { vm.startEdit(note) }
                        NoteMenuItem("Cambiar libro asociado", { LbIcon(LbIconKind.BOOK_OPEN, size = 20.dp) }) {
                            vm.openBookPicker(BookPicker.Change(note.id))
                        }
                        NoteMenuItem(
                            if (fav) "Quitar de favoritas" else "Marcar como favorita",
                            { NoteIcon(NoteGlyph.BOOKMARK, size = 20.dp, filled = fav) }
                        ) { vm.toggleFavorite(note) }
                        NoteMenuItem("Copiar texto", { NoteIcon(NoteGlyph.COPY, size = 20.dp) }) { vm.openMenu(null); onCopy() }
                        NoteMenuItem("Eliminar", { NoteIcon(NoteGlyph.TRASH, tint = NoteError, size = 20.dp) }, danger = true) {
                            vm.requestDelete(note.id)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NoteMenuItem(label: String, icon: @Composable () -> Unit, danger: Boolean = false, onClick: () -> Unit) {
    DropdownMenuItem(
        text = {
            Text(label, color = if (danger) NoteError else LbTitle, fontFamily = LibellumSerif, fontSize = 15.sp, maxLines = 1, softWrap = false)
        },
        leadingIcon = icon,
        onClick = onClick
    )
}

// ══════════════════════════════════════════════════════════════════════════════
// Estado vacío y diálogos
// ══════════════════════════════════════════════════════════════════════════════

@Composable
private fun NotesEmptyState(state: NotesUiState, modifier: Modifier = Modifier) {
    val (title, msg) = when {
        state.allNotes.isEmpty() ->
            "Aún no tienes notas" to "Escribe tu primera nota o cita arriba y guárdala para volver a ella cuando quieras."
        state.selectedFilter == NotesFilter.FAVORITES ->
            "Sin favoritas todavía" to "Toca el marcador de una nota para guardarla aquí."
        state.selectedFilter == NotesFilter.BY_BOOK && state.selectedBookFilter != null ->
            "Sin notas de este libro" to "Elige otro libro o quita el filtro desde «Por libro»."
        else -> "Nada por aquí" to "No hay notas que coincidan con este filtro."
    }
    LbCard(modifier.fillMaxWidth(), padding = 22.dp) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            NoteIcon(NoteGlyph.FEATHER, tint = LbBrownLight, size = 40.dp)
            Spacer(Modifier.height(10.dp))
            Text(
                title, color = LbTitle, fontSize = 19.sp, fontFamily = LibellumSerif, fontWeight = FontWeight.Bold,
                fontStyle = FontStyle.Italic, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(4.dp))
            Text(msg, color = LbMuted, fontSize = 14.sp, fontFamily = LibellumSerif, textAlign = TextAlign.Center, lineHeight = 20.sp)
        }
    }
}

@Composable
private fun EditNoteDialog(note: QuoteNote, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var tf by remember(note.id) { mutableStateOf(TextFieldValue(note.text, selection = androidx.compose.ui.text.TextRange(note.text.length))) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = LbCardTop,
        title = { Text("Editar nota o cita", color = LbTitle, fontFamily = LibellumSerif, fontWeight = FontWeight.Bold) },
        text = { QuoteTextField(tf, { tf = it }, "Escribe aquí tu nota o cita...", minLines = 3) },
        confirmButton = {
            TextButton(onClick = { onSave(tf.text) }, enabled = tf.text.isNotBlank()) {
                Text("Guardar", color = LbBrown, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar", color = LbBrownLight) } }
    )
}

@Composable
private fun BookPickerDialog(
    title: String,
    options: List<Pair<String, String>>,
    selectedId: String?,
    noneLabel: String,
    emptyHint: String,
    onPick: (String?) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = LbCardTop,
        title = { Text(title, color = LbTitle, fontFamily = LibellumSerif, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(Modifier.heightIn(max = 360.dp)) {
                item {
                    PickerRow(noneLabel, selectedId == null, italic = true) { onPick(null) }
                }
                if (options.isEmpty()) {
                    item { Text(emptyHint, color = LbMuted, fontSize = 13.sp, fontFamily = LibellumSerif, modifier = Modifier.padding(vertical = 10.dp)) }
                }
                items(options, key = { it.first }) { (id, name) -> PickerRow(name, id == selectedId) { onPick(id) } }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar", color = LbBrown) } }
    )
}

@Composable
private fun PickerRow(label: String, selected: Boolean, italic: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
            .background(if (selected) Color(0x26C99A4B) else Color.Transparent)
            .clickable(onClick = onClick).padding(vertical = 12.dp, horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label, color = LbTitle, fontSize = 15.sp, fontFamily = LibellumSerif,
            fontStyle = if (italic) FontStyle.Italic else FontStyle.Normal,
            maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
        )
        if (selected) { Spacer(Modifier.width(8.dp)); LbIcon(LbIconKind.CHECK, tint = LbBrown, size = 20.dp) }
    }
}
