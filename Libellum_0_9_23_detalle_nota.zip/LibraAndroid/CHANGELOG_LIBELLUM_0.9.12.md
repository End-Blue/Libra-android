# Libellum 0.9.12 — OPDS corregido

- Red: redirecciones (http→https) seguidas a mano; los errores HTTP (401/403/404/5xx) ahora se muestran en vez de aparecer como catálogo vacío.
- Parser: contenido XHTML/anidado ya no rompe el feed; detecta respuestas HTML/JSON y avisa.
- Carpetas: los errores al abrir una carpeta se ven en pantalla; «Cargar más» añade resultados en lugar de reemplazarlos.
- Gutenberg: los libros de los resultados abren directamente su ficha con descarga (antes parecían carpetas); el autor se lee correctamente.
- Búsqueda: usa el enlace de búsqueda que declara cada catálogo (OpenSearch) en lugar de URLs adivinadas.
- Descarga: el formato (EPUB/PDF) se decide por el contenido del archivo; rechaza páginas web y archivos vacíos.
- Catálogos curados: Project Gutenberg (raíz), Gutenberg en español, Standard Ebooks (novedades). Se retiraron enlaces que ya no responden.
