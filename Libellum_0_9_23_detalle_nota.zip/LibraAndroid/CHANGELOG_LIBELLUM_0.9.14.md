# Libellum 0.9.14

## Novedades 0.9.14 — Lector nativo con paso de hoja tipo cilindro
**Se eliminó** el motor anterior: `PageCurl.kt` completo, el `WebView` con columnas CSS y su JavaScript (`EPUB_JS`, CSS, servidor de recursos), `TextFileReader`/`ParagraphList`/`SelectableText` y el visor de imágenes antiguo. EPUB, TXT y FB2 se leen ahora con un único motor nativo.

**Motor nuevo** (`BookText.kt`, `PageLayout.kt`, `PageCurlView.kt`, `NativeReader.kt`, `Dictionary.kt`):
- **Paso de hoja tipo cilindro**: la hoja se enrolla siguiendo el dedo. Se ven las letras de la página nueva debajo, en la cara delantera y en el dorso (en espejo y algo aclarado), con sombras sobre la página de abajo. Las dos páginas se dibujan antes de empezar a girar, así que nunca hay pantalla en blanco. Funciona con arrastre, tocando los bordes y con los botones ◀ ▶; compatible con zurdos.
- **Paginación por páginas completas**: `StaticLayout` con justificado, sangría, interlineado, márgenes y tipografía. Sin líneas viudas/huérfanas y con el título unido a su primer párrafo. Las imágenes nunca se parten ni se deforman.
- **Imágenes**: al tocar una, se abre en pantalla completa con pellizco, doble toque, arrastre y botón ✕; al cerrar vuelves al mismo punto.
- **Posición exacta**: capítulo + carácter + fragmento de texto de respaldo. Cambiar tipografía, tamaño o márgenes vuelve a paginar sin perder el sitio. El avance (%) se calcula por caracteres. Marcadores y subrayados usan el mismo anclaje.
- **Selección**: pulsación larga elige la palabra; arrastra o usa las gotas para ampliar. Barra: Subrayar, Definir, Copiar, Frase. Tocar un subrayado permite editar su nota o quitarlo.
- **Diccionario**: memoria → caché en disco → diccionario offline opcional → internet (Español, Wikcionario ES, inglés traducido). Todo en segundo plano; lo encontrado queda guardado. Distingue «sin conexión» de «no encontrada».
  - *Offline*: coloca un archivo `dict/es.tsv` en `assets` (o en la carpeta de datos de la app), ordenado por bytes, con líneas `palabra<TAB>categoría<TAB>definición` (varias líneas = varias acepciones). Se busca por bisección sin cargarlo en memoria. Sin ese archivo, la caché cubre las palabras ya consultadas.
- Se conservan: tamaño de texto, interlineado, márgenes, tipografía, color de fondo/tema, justificado, sangría, capítulos, notas, subrayar y barra de progreso.
- La última posición se guarda en `pg2_<id>` (capítulo|carácter) y `pg2s_<id>` (fragmento). Las posiciones guardadas con el lector anterior se abren en el capítulo correcto, pero no en la página exacta.

