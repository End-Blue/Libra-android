# Libellum 0.9.11

## Explorar OPDS — catálogos abiertos con diseño «papel dorado»

Nueva sección **Explorar** (menú Más → Explorar OPDS) para descubrir y descargar libros de dominio público directamente a tu biblioteca.

### Qué incluye
- **Catálogos recomendados**: Standard Ebooks, Project Gutenberg, Internet Archive, Feedbooks (dominio público) y ManyBooks.
- **Catálogos propios**: añade cualquier feed OPDS/Atom por URL; se guardan en el teléfono.
- **Búsqueda** por título o autor dentro del catálogo.
- **Navegación por carpetas** del catálogo (pilas de feed) con historial atrás.
- **Ficha del libro**: portada, autor, resumen, categorías y descarga prioritaria de EPUB.
- **Descarga con progreso** e importación automática a la biblioteca local.
- **Descargas recientes** en la pantalla de inicio de Explorar.
- Interfaz alineada con Panel, Favoritos y Audiolibros (`LbCard`, `LbSectionHeader`, tipografía serif, colores papel dorado).

### Archivos nuevos
- `OpdsClient.kt` — modelos, catálogos, parser Atom/OPDS, descarga.
- `OpdsUi.kt` — pantallas y componentes visuales.

### Integración
- Entrada en el menú «Más».
- Pestaña `Explorar` con el mismo fondo `LbBg` que el resto del diseño papel dorado.
- Permiso de red (ya existente) y cleartext permitido para catálogos HTTP antiguos.
