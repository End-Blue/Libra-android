package com.libra.reader

import android.graphics.Bitmap
import android.graphics.Canvas as NativeCanvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.platform.LocalDensity
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

// ══════════════════════════════════════════════════════════════════════════════
// PASO DE PÁGINA TIPO CILINDRO
//
//  La hoja se enrolla alrededor de un cilindro vertical de radio R cuyo eje (x = a) se
//  desplaza a medida que el dedo arrastra el borde libre de la hoja (x = f):
//    · x ≤ a              → hoja plana, sin tocar
//    · a < x < a + πR     → la hoja se curva: X' = a + R·sin(θ), con θ = (x − a)/R
//                           (θ < 90°: cara delantera; θ > 90°: dorso, se ve en espejo)
//    · x ≥ a + πR         → dorso plano, apoyado sobre la parte plana
//  Debajo siempre se ve la página nueva, ya dibujada: nunca hay una pantalla en blanco.
//  Las letras se ven en la cara delantera, en el dorso (reflejadas y algo aclaradas) y
//  en la página inferior.
// ══════════════════════════════════════════════════════════════════════════════

internal class CurlPainter {
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val p = Paint()
    private val srcR = Rect()
    private val dstR = RectF()
    private val pi = Math.PI.toFloat()

    private fun xFree(a: Float, w: Float, r: Float): Float {
        val len = w - a
        return when {
            len <= 0f -> w
            len <= pi * r -> a + r * sin(len / r)
            else -> 2f * a + pi * r - w
        }
    }

    /** Eje del cilindro para que el borde libre de la hoja quede en x = [f]. */
    private fun axisFor(f: Float, w: Float, r: Float): Float {
        var lo = f - w - 4f * r - 10f
        var hi = w
        repeat(36) {
            val mid = (lo + hi) / 2f
            if (xFree(mid, w, r) < f) lo = mid else hi = mid
        }
        return (lo + hi) / 2f
    }

    private fun gradient(c: NativeCanvas, l: Float, r: Float, h: Float, c0: Int, c1: Int) {
        if (r <= l) return
        p.shader = LinearGradient(l, 0f, r, 0f, c0, c1, Shader.TileMode.CLAMP)
        c.drawRect(l, 0f, r, h, p)
        p.shader = null
    }

    private fun strip(c: NativeCanvas, bmp: Bitmap, s0: Float, s1: Float, dl: Float, dr: Float, h: Float, mirror: Boolean) {
        val left = floor(max(s0, 0f)).toInt()
        val right = ceil(min(s1, bmp.width.toFloat())).toInt()
        if (right <= left || dr <= dl) return
        srcR.set(left, 0, right, bmp.height)
        dstR.set(dl, 0f, dr, h)
        if (mirror) {
            c.save()
            c.scale(-1f, 1f, (dl + dr) / 2f, 0f)
            c.drawBitmap(bmp, srcR, dstR, bmpPaint)
            c.restore()
        } else {
            c.drawBitmap(bmp, srcR, dstR, bmpPaint)
        }
    }

    private fun alpha(v: Float): Int = (v.coerceIn(0f, 1f) * 255f).toInt()

    /**
     * Dibuja un fotograma. [sheet] es la hoja que se pliega y [under] lo que queda debajo.
     * [f] es la posición del borde libre: [w] = hoja plana; ≤ −w·1,15 = hoja ya fuera por la izquierda.
     */
    fun draw(c: NativeCanvas, w: Float, h: Float, sheet: Bitmap, under: Bitmap, f: Float, paper: Int, density: Float) {
        val r = (w * 0.085f).coerceIn(24f * density, 46f * density)
        c.drawBitmap(under, 0f, 0f, null)
        if (f >= w - 0.5f) {
            c.drawBitmap(sheet, 0f, 0f, null)
            return
        }
        val a = axisFor(f, w, r)
        if (a + r <= 0f) return
        val len = w - a
        val thetaMax = min(pi, len / r)
        val xr = if (thetaMax >= pi / 2f) a + r else a + r * sin(thetaMax)

        // 1) Sombra que proyecta el cilindro sobre la página de debajo
        gradient(c, xr, xr + 1.9f * r, h, 0x59000000, 0x00000000)

        // 2) Parte plana (sin tocar) con un poco de volumen cerca del pliegue
        if (a > 0f) {
            c.save()
            c.clipRect(0f, 0f, a, h)
            c.drawBitmap(sheet, 0f, 0f, null)
            c.restore()
            gradient(c, max(a - 0.9f * r, 0f), a, h, 0x00000000, 0x26000000)
        }

        // 3) Cara delantera curva (letras visibles, sombreado según la inclinación)
        val thetaF = min(pi / 2f, thetaMax)
        if (thetaF > 0f) {
            val n = max(3, ceil(thetaF / 0.05f).toInt())
            val d = thetaF / n
            for (i in 0 until n) {
                val t0 = i * d
                val t1 = (i + 1) * d
                val s0 = a + r * t0
                val s1 = a + r * t1
                if (s1 <= 0f) continue
                val x0 = a + r * sin(t0)
                val x1 = a + r * sin(t1) + 0.8f
                strip(c, sheet, s0, s1, x0, x1, h, false)
                val tm = (t0 + t1) / 2f
                val dark = 0.55f * sin(tm).pow(1.6f)
                val glint = 0.14f * exp(-(((tm - 0.8f) / 0.3f) * ((tm - 0.8f) / 0.3f)))
                p.color = alpha(dark) shl 24
                c.drawRect(x0, 0f, x1, h, p)
                p.color = (alpha(glint) shl 24) or 0x00FFFFFF
                c.drawRect(x0, 0f, x1, h, p)
            }
        }

        // 4) Dorso curvo: la misma página en espejo, algo aclarada para que se lea como el reverso del papel
        val paperTint = (alpha(0.42f) shl 24) or (paper and 0x00FFFFFF)
        if (thetaMax > pi / 2f) {
            val t0s = pi / 2f
            val nb = max(3, ceil((thetaMax - t0s) / 0.05f).toInt())
            val d = (thetaMax - t0s) / nb
            for (i in 0 until nb) {
                val t0 = t0s + i * d
                val t1 = t0 + d
                val s0 = a + r * t0
                val s1 = a + r * t1
                val xa = a + r * sin(t0)
                val xb = a + r * sin(t1) - 0.8f
                strip(c, sheet, s0, s1, xb, xa, h, true)
                p.color = paperTint
                c.drawRect(xb, 0f, xa, h, p)
                val tm = (t0 + t1) / 2f
                val u = (tm - pi / 2f) / (pi / 2f)
                val dark = 0.42f * (1f - u).coerceIn(0f, 1f).pow(1.4f)
                p.color = alpha(dark) shl 24
                c.drawRect(xb, 0f, xa, h, p)
            }
        }

        // 5) Dorso plano apoyado sobre la parte plana
        if (len > pi * r) {
            val sFlat = a + pi * r
            strip(c, sheet, sFlat, w, f, a, h, true)
            p.color = paperTint
            c.drawRect(f, 0f, a, h, p)
            gradient(c, max(f - 1.4f * r, 0f), f, h, 0x00000000, 0x47000000)
        }
        p.shader = null
    }
}

/** Para pasar de página desde fuera (toques en los bordes, botones ◀ ▶). */
internal class PagerController {
    internal var turnFn: ((Boolean) -> Unit)? = null
    fun turn(forward: Boolean) { turnFn?.invoke(forward) }
}

private class CurlState {
    var dir by mutableIntStateOf(0)          // 0 reposo · 1 siguiente · −1 anterior
    var edge by mutableFloatStateOf(0f)
    var sheet: Bitmap? = null
    var under: Bitmap? = null
    var animating by mutableStateOf(false)
}

/**
 * Contenedor de la página: dibuja la página actual y gestiona
 * toque (menú / zonas), presión larga (selección) y arrastre horizontal (giro de hoja).
 */
@Composable
internal fun BookPager(
    current: Bitmap?,
    canNext: Boolean,
    canPrev: Boolean,
    nextBitmap: () -> Bitmap?,
    prevBitmap: () -> Bitmap?,
    paperColor: Int,
    controller: PagerController,
    onTurnStart: () -> Unit,
    onTurnEnd: () -> Unit,
    onCommit: (Boolean) -> Unit,
    onTap: (Offset) -> Unit,
    onLongPress: (Offset) -> Unit,
    onLongDrag: (Offset) -> Unit,
    onLongRelease: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val st = remember { CurlState() }
    val painter = remember { CurlPainter() }
    val anim = remember { Animatable(0f) }
    val density = LocalDensity.current.density

    val curBmp by rememberUpdatedState(current)
    val nextOk by rememberUpdatedState(canNext)
    val prevOk by rememberUpdatedState(canPrev)
    val nextProv by rememberUpdatedState(nextBitmap)
    val prevProv by rememberUpdatedState(prevBitmap)
    val tapCb by rememberUpdatedState(onTap)
    val longCb by rememberUpdatedState(onLongPress)
    val longDragCb by rememberUpdatedState(onLongDrag)
    val longEndCb by rememberUpdatedState(onLongRelease)
    val commitCb by rememberUpdatedState(onCommit)
    val startCb by rememberUpdatedState(onTurnStart)
    val endCb by rememberUpdatedState(onTurnEnd)
    var width by remember { mutableFloatStateOf(0f) }

    fun hidden(): Float = -width * 1.15f

    fun begin(forward: Boolean): Boolean {
        if (st.dir != 0 || st.animating || width <= 0f) return false
        if (forward && !nextOk) return false
        if (!forward && !prevOk) return false
        val cur = curBmp ?: return false
        val other = (if (forward) nextProv() else prevProv()) ?: return false
        st.sheet = if (forward) cur else other
        st.under = if (forward) other else cur
        st.edge = if (forward) width else hidden()
        st.dir = if (forward) 1 else -1
        startCb()
        return true
    }

    fun finish(complete: Boolean) {
        val forward = st.dir == 1
        val target = when {
            forward && complete -> hidden()
            forward -> width
            complete -> width
            else -> hidden()
        }
        val dist = abs(target - st.edge) / (width * 2.15f).coerceAtLeast(1f)
        val ms = (160f + 300f * dist).toInt().coerceIn(160, 460)
        st.animating = true
        scope.launch {
            anim.snapTo(st.edge)
            anim.animateTo(target, tween(ms, easing = FastOutSlowInEasing)) { st.edge = value }
            if (complete) commitCb(forward)
            withFrameNanos { }
            st.dir = 0
            st.sheet = null
            st.under = null
            st.animating = false
            endCb()
        }
    }

    SideEffect {
        controller.turnFn = { forward -> if (begin(forward)) finish(true) }
    }

    Canvas(
        modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                val longMs = viewConfiguration.longPressTimeoutMillis
                val slop = viewConfiguration.touchSlop
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    width = size.width.toFloat()
                    var lastPos = down.position
                    val phase = withTimeoutOrNull(longMs) {
                        var out = -1
                        while (out < 0) {
                            val ev = awaitPointerEvent()
                            val ch = ev.changes.firstOrNull { it.id == down.id }
                            if (ch != null) lastPos = ch.position
                            out = when {
                                ch == null -> 3
                                !ch.pressed -> 1
                                (ch.position - down.position).getDistance() > slop -> 2
                                else -> -1
                            }
                        }
                        out
                    }
                    when (phase) {
                        1 -> tapCb(down.position)
                        null -> {
                            longCb(down.position)
                            while (true) {
                                val ev = awaitPointerEvent()
                                val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                                if (!ch.pressed) break
                                longDragCb(ch.position)
                                ch.consume()
                            }
                            longEndCb()
                        }
                        2 -> {
                            val dx0 = lastPos.x - down.position.x
                            val dy0 = lastPos.y - down.position.y
                            if (abs(dx0) >= abs(dy0) * 0.8f) {
                                val forward = dx0 < 0f
                                if (begin(forward)) {
                                    val startX = down.position.x
                                    val tracker = VelocityTracker()
                                    var x = lastPos.x
                                    fun move(px: Float) {
                                        val w = width
                                        st.edge = if (forward) (w - (startX - px) * 1.25f).coerceIn(hidden(), w)
                                        else (hidden() + (px - startX) * 2.2f).coerceIn(hidden(), w)
                                    }
                                    move(x)
                                    var end = false
                                    while (!end) {
                                        val ev = awaitPointerEvent()
                                        val ch = ev.changes.firstOrNull { it.id == down.id }
                                        if (ch == null) {
                                            finish(false)
                                            end = true
                                        } else {
                                            tracker.addPosition(ch.uptimeMillis, ch.position)
                                            x = ch.position.x
                                            if (!ch.pressed) {
                                                val vx = tracker.calculateVelocity().x
                                                val span = width - hidden()
                                                val progress = if (forward) (width - st.edge) / span else (st.edge - hidden()) / span
                                                val fling = if (forward) vx < -900f else vx > 900f
                                                val back = if (forward) vx > 900f else vx < -900f
                                                finish((progress > 0.30f || fling) && !back)
                                                end = true
                                            } else {
                                                move(x)
                                                ch.consume()
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else -> Unit
                    }
                }
            }
    ) {
        drawIntoCanvas { cv ->
            val nc = cv.nativeCanvas
            val sheet = st.sheet
            val under = st.under
            if (st.dir == 0 || sheet == null || under == null) {
                curBmp?.let { nc.drawBitmap(it, 0f, 0f, null) }
            } else {
                painter.draw(nc, size.width, size.height, sheet, under, st.edge, paperColor, density)
            }
        }
    }
}
