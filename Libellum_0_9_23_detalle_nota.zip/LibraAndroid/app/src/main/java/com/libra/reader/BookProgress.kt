package com.libra.reader

/**
 * ÚNICA fuente de verdad para mostrar el progreso de un libro.
 *
 * El dato sigue viviendo en `LibraryItem.progress` (Room), pero todas las pantallas lo leen
 * a través de estas funciones para que el número, la barra y el estado coincidan siempre:
 *  - se limita a 0..100,
 *  - un libro marcado como TERMINADO (a mano o por llegar al 97 %) se muestra al 100 %.
 */
internal fun LibraryItem.progressPct(): Int =
    if (statusKey() == "FINISHED") 100 else progress.coerceIn(0, 100)

internal fun LibraryItem.progressFraction(): Float = progressPct() / 100f

/** «42%» o, con sufijo, «42% leído». */
internal fun LibraryItem.progressText(suffix: String = ""): String = "${progressPct()}%$suffix"
