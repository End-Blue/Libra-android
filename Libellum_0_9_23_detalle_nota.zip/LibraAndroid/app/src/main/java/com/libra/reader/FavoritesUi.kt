package com.libra.reader

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

// ══════════════════════════════════════════════════════════════════════════════
// FAVORITOS — diseño «papel dorado»
// ══════════════════════════════════════════════════════════════════════════════

/** Recuerda cuándo marcaste cada favorito (para «Último añadido»). */
internal object FavStamps {
    private const val PREFS = "libra_prefs"
    private const val SET = "fav_ids"

    fun sync(ctx: Context, favIds: Set<String>) {
        val p = ctx.getSharedPreferences(PREFS, 0)
        val known = p.getStringSet(SET, null)
        val ed = p.edit()
        if (known != null) {
            val now = System.currentTimeMillis()
            favIds.filter { it !in known }.forEach { ed.putLong("fav_at_$it", now) }
        }
        ed.putStringSet(SET, HashSet(favIds))
        ed.apply()
    }

    fun at(ctx: Context, id: String): Long = ctx.getSharedPreferences(PREFS, 0).getLong("fav_at_$id", 0L)
}

private val FAV_SORTS = listOf(
    "RECENT" to "Recientes", "TITLE" to "Título", "AUTHOR" to "Autor",
    "RATING" to "Valoración", "PROGRESS" to "Progreso"
)

@Composable
fun FavoritesScreen(
    books: List<LibraryItem>,
    onDetail: (LibraryItem) -> Unit,
    onAllBooks: () -> Unit = {}
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    var filter by rememberPrefString("ui_fav_filter", "ALL")
    var sort by rememberPrefString("ui_fav_sort", "RECENT")
    var sortMenu by remember { mutableStateOf(false) }

    val favs = remember(books) { books.filter { it.isFavorite == 1 } }
    fun stampOf(b: LibraryItem): Long = FavStamps.at(ctx, b.id).takeIf { it > 0L } ?: b.addedAt
    val lastFav = favs.maxByOrNull { stampOf(it) }
    val topAuthor = favs.map { it.author.trim() }.filter { it.isNotBlank() }
        .groupingBy { it }.eachCount().maxByOrNull { it.value }?.key

    val filtered = favs.filter {
        when (filter) {
            "READING" -> it.statusKey() == "READING"
            "FINISHED" -> it.statusKey() == "FINISHED"
            "TOP" -> it.rating >= 4
            else -> true
        }
    }
    val sorted = when (if (filter == "TOP" && sort == "RECENT") "RATING" else sort) {
        "TITLE" -> filtered.sortedBy { it.title.lowercase() }
        "AUTHOR" -> filtered.sortedBy { it.author.lowercase() }
        "RATING" -> filtered.sortedByDescending { it.rating }
        "PROGRESS" -> filtered.sortedByDescending { it.progressPct() }
        else -> filtered.sortedByDescending { stampOf(it) }
    }
    val recs = remember(books) { recommendFor(books) }

    LazyColumn(
        state = listState,
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 18.dp)
    ) {
        item {
            HeroHeader(
                art = R.drawable.hero_favs,
                title = "Mis Favoritos",
                sub = "Tus historias más queridas,\nreunidas en un solo lugar.",
                quote = "Los buenos libros\nsiempre se quedan contigo.",
                titleSize = 36,
                subSize = 17
            )
        }

        // ── Colección ──
        item {
            LbCard(
                Modifier.padding(horizontal = 18.dp).fillMaxWidth(), padding = 14.dp,
                onClick = { scope.launch { listState.animateScrollToItem(3) } }
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(66.dp).clip(CircleShape).background(Color(0xFFF3DFBD)),
                        contentAlignment = Alignment.Center
                    ) {
                        LibIcon(
                            LibIconKind.STAR, tint = Color(0xFFC8912F), accent = Color(0xFFD9A441),
                            size = 42.dp, filled = true
                        )
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Tu colección de favoritos", color = LbText, fontSize = 15.sp, fontFamily = LibellumSerif)
                        Text(
                            "${favs.size} ${if (favs.size == 1) "libro" else "libros"}",
                            color = LbTitle, fontSize = 30.sp, fontWeight = FontWeight.Bold,
                            fontFamily = LibellumSerif, fontStyle = FontStyle.Italic, maxLines = 1
                        )
                    }
                    Box(
                        Modifier.size(42.dp).clip(CircleShape).background(Color(0xFFF2DDB8)),
                        contentAlignment = Alignment.Center
                    ) { LbIcon(LbIconKind.CHEVRON_RIGHT, tint = LbBrown, size = 22.dp) }
                }
                Spacer(Modifier.height(10.dp))
                Box(Modifier.fillMaxWidth().height(1.dp).background(LbCardEdge))
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                        LbIcon(LbIconKind.BOOK_OPEN, size = 28.dp)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text("Último añadido", color = LbMuted, fontSize = 11.sp, fontFamily = LibellumSerif)
                            Text(
                                lastFav?.title ?: "—", color = LbTitle, fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold, fontFamily = LibellumSerif,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    Box(Modifier.width(1.dp).height(34.dp).background(LbCardEdge))
                    Row(Modifier.weight(1f).padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        LbIcon(LbIconKind.PERSON, size = 28.dp)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text("Autor favorito", color = LbMuted, fontSize = 11.sp, fontFamily = LibellumSerif)
                            Text(
                                topAuthor ?: "—", color = LbTitle, fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold, fontFamily = LibellumSerif,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // ── Filtros ──
        item {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                LbChip("Todos", filter == "ALL", { filter = "ALL" }) { fg ->
                    LibIcon(LibIconKind.STAR, tint = fg, accent = fg, size = 18.dp, filled = true)
                }
                LbChip("Leyendo", filter == "READING", { filter = "READING" }) { fg ->
                    LbIcon(LbIconKind.BOOK_OPEN, tint = fg, size = 20.dp)
                }
                LbChip("Terminados", filter == "FINISHED", { filter = "FINISHED" }) { fg ->
                    LbIcon(LbIconKind.CHECK, tint = fg, size = 18.dp)
                }
                LbChip("Más valorados", filter == "TOP", { filter = "TOP" }) { fg ->
                    LbIcon(LbIconKind.HEART, tint = fg, size = 18.dp)
                }
            }
        }

        // ── Tus libros favoritos ──
        item {
            LbSectionHeader(
                "Tus libros favoritos",
                icon = { LibIcon(LibIconKind.LIBRARY, tint = LbBrown, accent = LbBrown, size = 26.dp) },
                modifier = Modifier.padding(horizontal = 18.dp),
                trailing = {
                    Box {
                        Row(
                            Modifier.clip(RoundedCornerShape(8.dp)).clickable { sortMenu = true }.padding(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Ordenar", color = LbText, fontSize = 14.sp, fontFamily = LibellumSerif,
                                fontStyle = FontStyle.Italic, maxLines = 1, softWrap = false
                            )
                            Spacer(Modifier.width(4.dp))
                            LbIcon(LbIconKind.CHEVRON_DOWN, tint = LbBrownLight, size = 16.dp)
                        }
                        DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                            FAV_SORTS.forEach { (key, label) ->
                                DropdownMenuItem(
                                    text = { Text((if (sort == key) "✓  " else "     ") + label) },
                                    onClick = { sort = key; sortMenu = false }
                                )
                            }
                        }
                    }
                }
            )
        }

        if (sorted.isEmpty()) {
            item {
                LbCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), padding = 18.dp) {
                    Text(
                        if (favs.isEmpty()) "Aún no tienes favoritos" else "Ningún favorito coincide con el filtro",
                        color = LbTitle, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                        fontFamily = LibellumSerif, fontStyle = FontStyle.Italic
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (favs.isEmpty()) "Toca un libro de tu biblioteca y márcalo con ☆ Favorito: aparecerá aquí."
                        else "Prueba con otro filtro o pulsa «Todos».",
                        color = LbText, fontSize = 13.sp, lineHeight = 19.sp
                    )
                }
            }
        } else {
            items(sorted.chunked(3), key = { it.first().id }) { row ->
                Row(
                    Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    row.forEach { b -> FavCard(b, Modifier.weight(1f), onDetail) }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }

        // ── Recomendados ──
        if (recs.isNotEmpty()) {
            item {
                LbSectionHeader(
                    "Recomendados para ti",
                    icon = { LbIcon(LbIconKind.SPARKLE, size = 26.dp) },
                    trailing = { LbLink("Ver todos", onAllBooks) },
                    modifier = Modifier.padding(horizontal = 18.dp)
                )
            }
            item {
                BoxWithConstraints(Modifier.fillMaxWidth()) {
                    val w = (maxWidth - 36.dp - 30.dp) / 4
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 18.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(recs, key = { it.id }) { b ->
                            BookCover(
                                b,
                                Modifier.size(width = w, height = w * 1.4f)
                                    .shadow(4.dp, RoundedCornerShape(10.dp))
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { onDetail(b) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FavCard(b: LibraryItem, modifier: Modifier, onDetail: (LibraryItem) -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier
            .shadow(3.dp, shape, ambientColor = Color(0x22805020), spotColor = Color(0x33805020))
            .clip(shape)
            .background(Brush.verticalGradient(listOf(LbCardTop, LbCardBottom)))
            .border(1.dp, LbCardEdge, shape)
            .clickable { onDetail(b) }
            .padding(7.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(0.70f)) {
            BookCover(b, Modifier.fillMaxSize().clip(RoundedCornerShape(9.dp)))
            Box(
                Modifier.align(Alignment.TopEnd).padding(5.dp).size(22.dp).clip(CircleShape)
                    .background(Brush.verticalGradient(listOf(Color(0xFFE2AE4A), Color(0xFFB9801F)))),
                contentAlignment = Alignment.Center
            ) {
                LibIcon(LibIconKind.STAR, tint = Color.White, accent = Color.White, size = 14.dp, filled = true)
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            b.author, color = LbText, fontSize = 12.sp, fontFamily = LibellumSerif,
            maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(3.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(1.dp)) {
            for (i in 1..5) {
                LibIcon(
                    LibIconKind.STAR,
                    tint = if (i <= b.rating) Color(0xFFC8912F) else LbLine,
                    accent = Color(0xFFD9A441), size = 13.dp, filled = i <= b.rating
                )
            }
        }
        Spacer(Modifier.height(5.dp))
        LbProgress(b.progressFraction(), Modifier.fillMaxWidth(), height = 5.dp)
        Text(
            b.progressText(" leído"), color = LbMuted, fontSize = 11.sp, fontFamily = LibellumSerif,
            modifier = Modifier.padding(top = 2.dp), maxLines = 1, softWrap = false
        )
    }
}

/** Libros sin leer que se parecen a tus favoritos (mismo autor o género). */
private fun recommendFor(books: List<LibraryItem>): List<LibraryItem> {
    val favs = books.filter { it.isFavorite == 1 }
    val genres = favs.map { it.genre.lowercase() }.filter { it.isNotBlank() }.toSet()
    val authors = favs.map { it.author.lowercase() }.filter { it.isNotBlank() }.toSet()
    return books
        .filter { it.isFavorite != 1 && it.statusKey() != "FINISHED" }
        .sortedWith(
            compareByDescending<LibraryItem> {
                (if (it.author.lowercase() in authors) 3 else 0) + (if (it.genre.lowercase() in genres) 2 else 0)
            }.thenByDescending { it.addedAt }
        )
        .take(8)
}
