package com.libra.reader

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ══════════════════════════════════════════════════════════════════════════════
// Controles reutilizables del kit «papel dorado»
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Texto de UNA línea que nunca se parte ni se corta: si no cabe a [maxSize], baja de tamaño
 * (de 1 en 1 sp) hasta [minSize]; solo si ni así cabe, termina en «…».
 */
@Composable
internal fun LbFitText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = LbTitle,
    maxSize: TextUnit = 14.sp,
    minSize: TextUnit = 9.sp,
    fontWeight: FontWeight? = null,
    fontStyle: FontStyle? = null,
    textAlign: TextAlign = TextAlign.Unspecified
) {
    var size by remember(text, maxSize) { mutableStateOf(maxSize) }
    Text(
        text,
        modifier = modifier,
        color = color,
        fontSize = size,
        fontWeight = fontWeight,
        fontStyle = fontStyle,
        fontFamily = LibellumSerif,
        textAlign = textAlign,
        maxLines = 1,
        softWrap = false,
        overflow = TextOverflow.Ellipsis,
        onTextLayout = { r ->
            if ((r.hasVisualOverflow || r.didOverflowWidth) && size.value > minSize.value) {
                size = (size.value - 1f).coerceAtLeast(minSize.value).sp
            }
        }
    )
}

/**
 * Selector de periodo: botón con icono + etiqueta del periodo activo. Al tocarlo se despliegan
 * las opciones EN LÍNEA (empujan el contenido hacia abajo), así nunca tapan los días ni las barras
 * del gráfico, a diferencia de un DropdownMenu, que siempre se dibuja encima.
 *
 * [options] = lista de clave → etiqueta. Colócalo como primer elemento de la tarjeta del gráfico.
 */
@Composable
internal fun LbPeriodSelector(
    options: List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var open by remember { mutableStateOf(false) }
    val label = options.firstOrNull { it.first == selected }?.second ?: options.first().second
    val chip = RoundedCornerShape(50)

    Column(modifier.fillMaxWidth().animateContentSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Row(
                Modifier
                    .clip(chip)
                    .background(Color(0xFFF2DDB8))
                    .border(1.dp, LbLine, chip)
                    .clickable(role = Role.Button) { open = !open }
                    .padding(horizontal = 12.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LbIcon(LbIconKind.CALENDAR, tint = LbBrown, size = 16.dp)
                Spacer(Modifier.width(6.dp))
                Text(
                    label, color = LbTitle, fontSize = 13.sp, fontFamily = LibellumSerif,
                    fontStyle = FontStyle.Italic, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, softWrap = false
                )
                Spacer(Modifier.width(4.dp))
                LbIcon(
                    LbIconKind.CHEVRON_DOWN, tint = LbBrownLight, size = 16.dp,
                    modifier = Modifier.graphicsLayer { rotationZ = if (open) 180f else 0f }
                )
            }
        }
        if (open) {
            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                options.forEach { (key, text) ->
                    val on = key == selected
                    Box(
                        Modifier
                            .weight(1f)
                            .clip(chip)
                            .background(if (on) LbBrown else Color(0xFFF8EEDB))
                            .border(1.dp, if (on) LbBrown else LbCardEdge, chip)
                            .clickable { onSelect(key); open = false }
                            .padding(horizontal = 6.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        LbFitText(
                            text, color = if (on) Color(0xFFFDF1DC) else LbText,
                            maxSize = 13.sp, minSize = 10.sp, textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}
