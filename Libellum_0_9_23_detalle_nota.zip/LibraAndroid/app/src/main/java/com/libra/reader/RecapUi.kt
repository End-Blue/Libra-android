package com.libra.reader

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar
import java.util.Locale

// ══════════════════════════════════════════════════════════════════════════════
// TU RESUMEN — diseño «papel dorado»
// ══════════════════════════════════════════════════════════════════════════════

private val GENRE_COLORS = listOf(
    Color(0xFF834906), Color(0xFFC6924B), Color(0xFFA37A3C), Color(0xFFD9C29A)
)

private fun dateKeyOf(c: Calendar): String =
    String.format(Locale.US, "%04d-%02d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))

@Composable
fun RecapScreen(
    books: List<LibraryItem>,
    notesCount: Int,
    days: Set<String>,
    onOpenLibrary: (String) -> Unit = {}
) {
    val ctx = LocalContext.current
    val msByDay = remember(days) { ReadStats.all(ctx) }
    var period by remember { mutableStateOf("MONTH") }
    var selectedDay by remember(period) { mutableIntStateOf(-1) }

    // Periodo elegido: de [start] a hoy
    val start = remember(period) {
        val c = Calendar.getInstance()
        when (period) {
            "WEEK" -> c.add(Calendar.DAY_OF_YEAR, -((c.get(Calendar.DAY_OF_WEEK) + 5) % 7))
            "YEAR" -> c.set(c.get(Calendar.YEAR), Calendar.JANUARY, 1)
            else -> c.set(Calendar.DAY_OF_MONTH, 1)
        }
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        dateKeyOf(c) to c.timeInMillis
    }
    // Días naturales desde el inicio del periodo hasta hoy (ambos a medianoche; redondeo para absorber el cambio de hora).
    val elapsedDays = remember(start) {
        val todayStart = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        Math.round((todayStart - start.second) / 86_400_000.0).toInt() + 1
    }
    val inPeriod = remember(period, msByDay, days) {
        val keys = (msByDay.keys + days).filter { it >= start.first && it <= dateKeyOf(Calendar.getInstance()) }
        keys.toSet()
    }
    val perWeekday = remember(inPeriod) {
        val v = LongArray(7)
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US)
        inPeriod.forEach { k ->
            val d = runCatching { fmt.parse(k) }.getOrNull() ?: return@forEach
            val c = Calendar.getInstance().apply { time = d }
            v[(c.get(Calendar.DAY_OF_WEEK) + 5) % 7] += msByDay[k] ?: 0L
        }
        v.toList()
    }
    val periodTotal = perWeekday.sum()
    // Un día cuenta como «leído» si está marcado O tiene tiempo registrado: así «Días leídos» y «Tiempo total» nunca se contradicen.
    val periodDaysRead = inPeriod.count { it in days || (msByDay[it] ?: 0L) > 0L }
    val avgDaily = periodTotal / elapsedDays.coerceAtLeast(1)

    val rated = books.filter { it.rating > 0 }
    val avg = if (rated.isEmpty()) "—" else String.format(Locale.US, "%.1f", rated.map { it.rating }.average())
    val reading = books.count { it.statusKey() == "READING" }
    val finished = books.count { it.statusKey() == "FINISHED" }
    val tbr = books.count { it.statusKey() == "TBR" }

    // «Leídos» = empezados o terminados. Género favorito, autor más leído y el gráfico de géneros
    // parten de este mismo conjunto, así que siempre cuentan la misma historia que Leyendo/Terminados.
    val readBooks = books.filter { it.statusKey() != "TBR" || it.progress > 0 }
    val topAuthor = (readBooks.ifEmpty { books })
        .filter { it.author.isNotBlank() && it.author != "Autor no identificado" }
        .groupBy { it.author }
        .maxWithOrNull(
            compareBy<Map.Entry<String, List<LibraryItem>>>({ it.value.size })
                .thenBy { e -> e.value.count { it.statusKey() == "FINISHED" } }
        )?.key ?: "—"

    // Géneros más leídos (libros empezados; si no hay, todos)
    val genreBase = readBooks.filter { it.genre.isNotBlank() }
        .ifEmpty { books.filter { it.genre.isNotBlank() } }
    val genreCounts = genreBase.groupingBy { it.genre }.eachCount().entries.sortedByDescending { it.value }
    val top3 = genreCounts.take(3)
    val otherCount = genreCounts.drop(3).sumOf { it.value }
    val genreRows = buildList<Pair<String, Int>> {
        top3.forEach { add(it.key to it.value) }
        if (otherCount > 0) add("Otros" to otherCount)
    }
    val genreTotal = genreRows.sumOf { it.second }.coerceAtLeast(1)
    val topGenre = genreCounts.firstOrNull()?.key ?: "—"

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 18.dp)
    ) {
        item {
            HeroHeader(
                art = R.drawable.hero_recap,
                title = "Tu resumen",
                sub = "Así evoluciona tu historia\ncomo lector.",
                quote = "Cada libro deja una huella\nen quien eres.",
                titleSize = 34,
                subSize = 16
            )
        }

        // ── Tu biblioteca ──
        item {
            LbCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), padding = 0.dp, onClick = { onOpenLibrary("") }) {
                Box(Modifier.fillMaxWidth().height(172.dp)) {
                    Image(
                        painter = painterResource(R.drawable.card_recap),
                        contentDescription = null,
                        contentScale = ContentScale.FillHeight,
                        alignment = Alignment.BottomEnd,
                        modifier = Modifier.align(Alignment.BottomEnd).fillMaxHeight(0.84f)
                    )
                    Column(Modifier.padding(start = 16.dp, top = 14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            LbIcon(LbIconKind.BOOK_OPEN, size = 44.dp)
                            Spacer(Modifier.width(12.dp))
                            Text(
                                "Tu biblioteca", color = LbTitle, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                                fontFamily = LibellumSerif, maxLines = 1
                            )
                        }
                        Text(
                            "${books.size}", color = LbTitle, fontSize = 54.sp, fontWeight = FontWeight.Bold,
                            fontFamily = LibellumSerif, fontStyle = FontStyle.Italic, lineHeight = 58.sp,
                            modifier = Modifier.padding(start = 14.dp, top = 2.dp)
                        )
                        Text(
                            if (books.size == 1) "libro" else "libros", color = LbTitle, fontSize = 20.sp,
                            fontFamily = LibellumSerif, fontStyle = FontStyle.Italic,
                            modifier = Modifier.padding(start = 14.dp)
                        )
                    }
                    Row(
                        Modifier.align(Alignment.BottomEnd).padding(10.dp)
                            .clip(RoundedCornerShape(50)).background(Color(0xE6FBF1DE))
                            .clickable { onOpenLibrary("") }
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Ver biblioteca", color = LbTitle, fontSize = 14.sp, fontFamily = LibellumSerif, fontStyle = FontStyle.Italic)
                        Spacer(Modifier.width(4.dp))
                        LbIcon(LbIconKind.CHEVRON_RIGHT, tint = LbBrown, size = 16.dp)
                    }
                }
            }
        }

        // ── Estado de tus libros ──
        item {
            LbSectionHeader(
                "Estado de tus libros",
                icon = { LibIcon(LibIconKind.NOTES, tint = LbBrown, accent = LbBrown, size = 26.dp) },
                modifier = Modifier.padding(horizontal = 18.dp)
            )
        }
        item {
            Column(Modifier.padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    LbTile(Modifier.weight(1f), { LbIcon(LbIconKind.BOOK_OPEN, size = 32.dp) }, "$reading", "Leyendo", onClick = { onOpenLibrary("READING") })
                    LbTile(Modifier.weight(1f), { LbIcon(LbIconKind.CHECK_CIRCLE, size = 32.dp) }, "$finished", "Terminados", onClick = { onOpenLibrary("FINISHED") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    LbTile(Modifier.weight(1f), { LbIcon(LbIconKind.HOURGLASS, size = 32.dp) }, "$tbr", "Por leer", onClick = { onOpenLibrary("TBR") })
                    LbTile(
                        Modifier.weight(1f),
                        { LibIcon(LibIconKind.SHELF, tint = LbBrown, accent = LbBrown, size = 32.dp) },
                        "${books.size}", "En tu biblioteca", onClick = { onOpenLibrary("") }
                    )
                }
            }
        }

        // ── Tu actividad de lectura ──
        item {
            LbSectionHeader(
                "Tu actividad de lectura",
                icon = { LbIcon(LbIconKind.CHART, size = 26.dp) },
                modifier = Modifier.padding(horizontal = 18.dp)
            )
        }
        item {
            LbCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), padding = 8.dp) {
                LbPeriodSelector(
                    options = listOf("WEEK" to "Esta semana", "MONTH" to "Este mes", "YEAR" to "Este año"),
                    selected = period,
                    onSelect = { period = it },
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
                WeekBarsChart(
                    labels = listOf("L", "M", "X", "J", "V", "S", "D"),
                    values = perWeekday,
                    selected = selectedDay,
                    onSelect = { selectedDay = if (selectedDay == it) -1 else it },
                    valueText = { formatReadingTime(it) }
                )
                Box(Modifier.fillMaxWidth().padding(horizontal = 6.dp).height(1.dp).background(LbCardEdge))
                Row(
                    Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    MiniStat(Modifier.weight(1f), LbIconKind.CALENDAR, "$periodDaysRead", "Días leídos")
                    MiniStat(Modifier.weight(1f), LbIconKind.CLOCK, formatReadingTime(periodTotal), "Tiempo total")
                    MiniStat(Modifier.weight(1f), LbIconKind.CHART, formatReadingTime(avgDaily), "Promedio diario")
                }
            }
        }

        // ── Estadísticas literarias ──
        item {
            LbSectionHeader(
                "Tus estadísticas literarias",
                icon = { LbIcon(LbIconKind.SPARKLE, size = 26.dp) },
                modifier = Modifier.padding(horizontal = 18.dp)
            )
        }
        item {
            Column(Modifier.padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    LbTile(
                        Modifier.weight(1f),
                        { LibIcon(LibIconKind.STAR, tint = Color(0xFFC8912F), accent = Color(0xFFD9A441), size = 32.dp, filled = true) },
                        avg, "Valoración media"
                    )
                    LbTile(Modifier.weight(1f), { LbIcon(LbIconKind.DOC, size = 32.dp) }, "$notesCount", "Notas y subrayados")
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    LbTile(Modifier.weight(1f), { LbIcon(LbIconKind.TAG, size = 32.dp) }, topGenre, "Género favorito", valueSize = 15)
                    LbTile(Modifier.weight(1f), { LbIcon(LbIconKind.PERSON, size = 32.dp) }, topAuthor, "Autor más leído", valueSize = 15)
                }
            }
        }

        // ── Libros más leídos por género ──
        item {
            LbSectionHeader(
                "Libros más leídos por género",
                icon = { LbIcon(LbIconKind.BOOK_OPEN, size = 26.dp) },
                modifier = Modifier.padding(horizontal = 18.dp)
            )
        }
        item {
            LbCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), padding = 14.dp) {
                if (genreRows.isEmpty()) {
                    Text(
                        "Asigna un género en la ficha de tus libros para ver aquí cuáles lees más.",
                        color = LbMuted, fontSize = 13.sp, lineHeight = 19.sp
                    )
                } else {
                    Row(Modifier.fillMaxWidth().height(22.dp).clip(RoundedCornerShape(50))) {
                        genreRows.forEachIndexed { i, (_, n) ->
                            Box(
                                Modifier.weight(n.toFloat()).fillMaxHeight()
                                    .background(GENRE_COLORS[i.coerceAtMost(GENRE_COLORS.lastIndex)])
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    genreRows.forEachIndexed { i, (name, n) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(11.dp).clip(CircleShape)
                                    .background(GENRE_COLORS[i.coerceAtMost(GENRE_COLORS.lastIndex)])
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(name, color = LbText, fontSize = 13.sp, fontFamily = LibellumSerif, modifier = Modifier.weight(1f), maxLines = 1)
                            Text("${Math.round(n * 100f / genreTotal)}%", color = LbText, fontSize = 13.sp, fontFamily = LibellumSerif)
                        }
                    }
                }
            }
        }

        item { LbQuoteFooter("Leer es coleccionar\nmejores versiones de ti.") }
    }
}

@Composable
private fun MiniStat(modifier: Modifier, icon: LbIconKind, value: String, label: String) {
    Row(modifier.padding(horizontal = 2.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        LbIcon(icon, size = 26.dp)
        Spacer(Modifier.width(6.dp))
        Column(Modifier.weight(1f, fill = false)) {
            LbFitText(value, color = LbTitle, maxSize = 15.sp, minSize = 11.sp, fontWeight = FontWeight.Bold)
            LbFitText(label, color = LbMuted, maxSize = 10.sp, minSize = 8.sp)
        }
    }
}
