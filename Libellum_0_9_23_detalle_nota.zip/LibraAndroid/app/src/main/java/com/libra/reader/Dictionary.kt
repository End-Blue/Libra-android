package com.libra.reader

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.net.UnknownHostException
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder

data class DictMeaning(
    val partOfSpeech: String,
    val definitions: List<String>,
    val synonyms: List<String>
)

data class DictResult(
    val word: String,
    val phonetic: String,
    val meanings: List<DictMeaning>,
    val lang: String,
    val translatedFrom: String = ""
)

/** Falta de conexión (distinta de «palabra no encontrada»). */
class DictOfflineError : Exception("Sin conexión")

private fun openUrl(urlStr: String): String {
    val conn = URL(urlStr).openConnection()
    conn.connectTimeout = 6000
    conn.readTimeout = 7000
    conn.setRequestProperty("User-Agent", "Libellum/1.0")
    return conn.getInputStream().bufferedReader(Charsets.UTF_8).use { it.readText() }
}

private fun translateToSpanish(text: String): String {
    if (text.isBlank()) return text
    return try {
        val enc = URLEncoder.encode(text, "UTF-8")
        val json = openUrl("https://api.mymemory.translated.net/get?q=$enc&langpair=en|es")
        val obj = JSONObject(json)
        obj.optJSONObject("responseData")?.optString("translatedText")?.takeIf { it.isNotBlank() } ?: text
    } catch (_: Exception) {
        text
    }
}

private fun parseDictionaryApi(json: String, lang: String): DictResult {
    val arr = JSONArray(json)
    val entry = arr.getJSONObject(0)
    val word = entry.optString("word", "")
    val phonetic = entry.optString("phonetic", "")
    val meaningsArr = entry.getJSONArray("meanings")
    val meanings = (0 until meaningsArr.length()).map { i ->
        val m = meaningsArr.getJSONObject(i)
        val pos = m.optString("partOfSpeech", "")
        val defs = m.getJSONArray("definitions")
        val defList = (0 until minOf(defs.length(), 3)).map { j ->
            defs.getJSONObject(j).optString("definition", "")
        }
        val syns = m.optJSONArray("synonyms")
        val synList = if (syns != null)
            (0 until minOf(syns.length(), 4)).map { j -> syns.getString(j) }
        else emptyList()
        DictMeaning(pos, defList, synList)
    }
    return DictResult(word, phonetic, meanings, lang)
}

/** Wikcionario en español: definiciones en español para muchas palabras que la otra API no tiene. */
private fun parseWiktionaryEs(word: String, json: String): DictResult {
    val root = JSONObject(json)
    val arr = root.optJSONArray("es") ?: error("sin entradas")
    val meanings = ArrayList<DictMeaning>()
    for (i in 0 until arr.length()) {
        val e = arr.getJSONObject(i)
        val pos = e.optString("partOfSpeech", "")
        val defs = e.optJSONArray("definitions") ?: continue
        val list = ArrayList<String>()
        for (j in 0 until minOf(defs.length(), 4)) {
            val raw = defs.getJSONObject(j).optString("definition", "")
            val clean = android.text.Html.fromHtml(raw, android.text.Html.FROM_HTML_MODE_LEGACY).toString().trim()
            if (clean.isNotBlank()) list.add(clean)
        }
        if (list.isNotEmpty()) meanings.add(DictMeaning(pos, list, emptyList()))
    }
    if (meanings.isEmpty()) error("sin definiciones")
    return DictResult(word, "", meanings, "es")
}

private fun toSpanish(result: DictResult): DictResult {
    if (result.lang == "es") return result
    val mapped = result.meanings.map { m ->
        DictMeaning(
            partOfSpeech = when (m.partOfSpeech.lowercase()) {
                "noun" -> "sustantivo"
                "verb" -> "verbo"
                "adjective" -> "adjetivo"
                "adverb" -> "adverbio"
                "pronoun" -> "pronombre"
                "preposition" -> "preposición"
                "conjunction" -> "conjunción"
                "interjection" -> "interjección"
                else -> m.partOfSpeech
            },
            definitions = m.definitions.map { translateToSpanish(it) },
            synonyms = m.synonyms.map { translateToSpanish(it) }
        )
    }
    return result.copy(meanings = mapped, lang = "es", translatedFrom = result.lang)
}

// ── Serialización para la caché ──────────────────────────────────────────────

private fun DictResult.toJson(): JSONObject = JSONObject().apply {
    put("w", word); put("p", phonetic); put("l", lang); put("t", translatedFrom)
    put("m", JSONArray().also { arr ->
        meanings.forEach { m ->
            arr.put(JSONObject().apply {
                put("pos", m.partOfSpeech)
                put("d", JSONArray(m.definitions))
                put("s", JSONArray(m.synonyms))
            })
        }
    })
}

private fun dictFromJson(o: JSONObject): DictResult {
    val ma = o.optJSONArray("m") ?: JSONArray()
    val ms = (0 until ma.length()).map { i ->
        val m = ma.getJSONObject(i)
        val d = m.optJSONArray("d") ?: JSONArray()
        val sy = m.optJSONArray("s") ?: JSONArray()
        DictMeaning(m.optString("pos"), (0 until d.length()).map { d.getString(it) }, (0 until sy.length()).map { sy.getString(it) })
    }
    return DictResult(o.optString("w"), o.optString("p"), ms, o.optString("l", "es"), o.optString("t"))
}

/**
 * Diccionario offline opcional: un archivo de texto ORDENADO (orden de bytes) con líneas
 *     palabra<TAB>categoría<TAB>definición
 * (varias líneas con la misma palabra = varias acepciones). Se busca por bisección en el
 * propio archivo, así que no ocupa memoria. Ubicación: `assets/dict/es.tsv` o `files/dict/es.tsv`.
 */
private class OfflineDictionary(private val file: File) {
    /** Lee una línea (UTF-8) desde la posición actual y deja el puntero justo después del salto de línea. */
    private fun readLine(raf: RandomAccessFile): String? {
        val start = raf.filePointer
        if (start >= raf.length()) return null
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(256)
        var consumed = 0L
        var found = false
        while (!found) {
            val n = raf.read(buf)
            if (n <= 0) break
            var nl = -1
            for (i in 0 until n) if (buf[i] == 10.toByte()) { nl = i; break }
            if (nl >= 0) { out.write(buf, 0, nl); consumed += nl + 1; found = true }
            else { out.write(buf, 0, n); consumed += n }
        }
        raf.seek(start + consumed)
        return out.toString("UTF-8")
    }

    /** Inicio de la línea que contiene el byte [pos]. */
    private fun lineStart(raf: RandomAccessFile, pos: Long): Long {
        var p = pos
        while (p > 0) {
            raf.seek(p - 1)
            if (raf.read() == 10) return p
            p--
        }
        return 0L
    }

    fun find(key: String): List<Pair<String, String>>? {
        if (!file.exists()) return null
        RandomAccessFile(file, "r").use { raf ->
            var lo = 0L
            var hi = raf.length()
            while (lo < hi) {
                val mid = (lo + hi) / 2
                val ls = lineStart(raf, mid)
                raf.seek(ls)
                val line = readLine(raf) ?: break
                val k = line.substringBefore('\t')
                if (k < key) lo = raf.filePointer else hi = ls
            }
            raf.seek(lo)
            val found = ArrayList<Pair<String, String>>()
            while (true) {
                val line = readLine(raf) ?: break
                val parts = line.split('\t')
                if (parts[0] != key) break
                found.add((parts.getOrNull(1) ?: "") to (parts.getOrNull(2) ?: ""))
            }
            return found.ifEmpty { null }
        }
    }
}

/**
 * Motor de diccionario: responde en milisegundos y nunca bloquea la interfaz.
 *   1) memoria (palabras recientes)  2) caché persistente en disco  3) diccionario offline
 *   4) internet: español → Wikcionario ES → inglés traducido al español
 * Todo lo que se encuentra en internet se guarda para la próxima vez.
 */
object DictionaryEngine {
    private val mem = object : LinkedHashMap<String, DictResult>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, DictResult>?): Boolean = size > 400
    }
    private val lock = Mutex()
    private var loaded = false
    private var disk = HashMap<String, String>()
    private var cacheFile: File? = null
    private var offline: OfflineDictionary? = null

    private fun key(word: String): String =
        word.trim().lowercase().split(Regex("\\s+")).firstOrNull().orEmpty().trim { !it.isLetter() }

    /** Carga la caché y prepara el diccionario offline (llamar una vez al abrir el lector, en segundo plano). */
    suspend fun warm(ctx: Context) = withContext(Dispatchers.IO) {
        lock.withLock {
            if (loaded) return@withLock
            val dir = File(ctx.filesDir, "dict").apply { mkdirs() }
            cacheFile = File(dir, "cache.jsonl")
            val f = cacheFile!!
            var lines = 0
            if (f.exists()) {
                runCatching {
                    f.forEachLine { line ->
                        lines++
                        val k = line.substringBefore('\t', "")
                        if (k.isNotEmpty()) disk[k] = line.substringAfter('\t')
                    }
                }
                if (lines > disk.size * 2 + 200) {   // compactar
                    runCatching { f.writeText(disk.entries.joinToString("") { "${it.key}\t${it.value}\n" }) }
                }
            }
            val off = File(dir, "es.tsv")
            if (!off.exists()) {
                runCatching { ctx.assets.open("dict/es.tsv").use { i -> off.outputStream().use { o -> i.copyTo(o) } } }
            }
            if (off.exists() && off.length() > 0) offline = OfflineDictionary(off)
            loaded = true
        }
    }

    /** Respuesta inmediata si ya está en memoria o en la caché (sin red). */
    fun peek(word: String): DictResult? {
        val k = key(word)
        if (k.isEmpty()) return null
        synchronized(mem) { mem[k]?.let { return it } }
        val raw = synchronized(disk) { disk[k] } ?: return null
        return runCatching { dictFromJson(JSONObject(raw)) }.getOrNull()?.also { synchronized(mem) { mem[k] = it } }
    }

    private fun candidates(w: String): List<String> {
        val out = LinkedHashSet<String>()
        out.add(w)
        if (w.endsWith("es") && w.length > 4) out.add(w.dropLast(2))
        if (w.endsWith("s") && w.length > 3) out.add(w.dropLast(1))
        if (w.endsWith("as") && w.length > 4) out.add(w.dropLast(2) + "o")
        if (w.endsWith("a") && w.length > 3) out.add(w.dropLast(1) + "o")
        for ((suf, rep) in listOf(
            "ando" to "ar", "iendo" to "er", "iendo" to "ir", "ado" to "ar", "ido" to "er", "ido" to "ir",
            "aba" to "ar", "aban" to "ar", "ó" to "ar", "aron" to "ar", "ía" to "er", "ía" to "ir", "ían" to "er"
        )) {
            if (w.endsWith(suf) && w.length > suf.length + 1) out.add(w.dropLast(suf.length) + rep)
        }
        return out.toList()
    }

    private fun fromOffline(w: String): DictResult? {
        val off = offline ?: return null
        for (cand in candidates(w)) {
            val rows = runCatching { off.find(cand) }.getOrNull() ?: continue
            val meanings = rows.groupBy { it.first }.map { (pos, list) -> DictMeaning(pos, list.map { it.second }.take(4), emptyList()) }
            return DictResult(cand, "", meanings, "es")
        }
        return null
    }

    private suspend fun store(k: String, r: DictResult) {
        synchronized(mem) { mem[k] = r }
        val json = r.toJson().toString().replace("\n", " ")
        synchronized(disk) { disk[k] = json }
        lock.withLock {
            runCatching { cacheFile?.appendText("$k\t$json\n") }
        }
    }

    suspend fun lookup(ctx: Context, word: String): Result<DictResult> = withContext(Dispatchers.IO) {
        val k = key(word)
        if (k.isEmpty()) return@withContext Result.failure(Exception("Palabra vacía"))
        if (!loaded) warm(ctx)
        peek(k)?.let { return@withContext Result.success(it) }
        fromOffline(k)?.let { store(k, it); return@withContext Result.success(it) }

        var network = false
        var anyAnswer = false
        fun <T> attempt(block: () -> T): T? = try {
            val v = block(); network = true; anyAnswer = true; v
        } catch (e: java.io.FileNotFoundException) {
            network = true; null                       // la API contestó «no existe»
        } catch (e: UnknownHostException) {
            null
        } catch (e: IOException) {
            if (e.message?.contains("HTTP response code: 404") == true) network = true
            null
        } catch (_: Exception) {
            network = true                              // el servidor respondió, pero con algo que no se entiende
            null
        }

        val enc = URLEncoder.encode(k, "UTF-8")
        attempt { parseDictionaryApi(openUrl("https://api.dictionaryapi.dev/api/v2/entries/es/$enc"), "es") }
            ?.let { store(k, it); return@withContext Result.success(it) }
        attempt { parseWiktionaryEs(k, openUrl("https://es.wiktionary.org/api/rest_v1/page/definition/$enc")) }
            ?.let { store(k, it); return@withContext Result.success(it) }
        attempt { toSpanish(parseDictionaryApi(openUrl("https://api.dictionaryapi.dev/api/v2/entries/en/$enc"), "en")) }
            ?.let { store(k, it); return@withContext Result.success(it) }
        attempt {
            val trJson = openUrl("https://api.mymemory.translated.net/get?q=$enc&langpair=es|en")
            val translated = JSONObject(trJson).optJSONObject("responseData")?.optString("translatedText")
                ?.trim()?.lowercase()?.split(" ")?.firstOrNull() ?: error("sin traducción")
            val encEn = URLEncoder.encode(translated, "UTF-8")
            toSpanish(
                parseDictionaryApi(openUrl("https://api.dictionaryapi.dev/api/v2/entries/en/$encEn"), "en")
                    .copy(word = "$k → $translated")
            )
        }?.let { store(k, it); return@withContext Result.success(it) }

        if (!network && !anyAnswer) Result.failure(DictOfflineError())
        else Result.failure(Exception("No se encontró definición para «$k»"))
    }
}

/** Compatibilidad: otros archivos llaman a esta función (por ejemplo, el cuadro de subrayado). */
suspend fun fetchDefinition(word: String): Result<DictResult> {
    val ctx = DictionaryContext.app ?: return Result.failure(Exception("Diccionario no iniciado"))
    return DictionaryEngine.lookup(ctx, word)
}

/** Contexto de aplicación para el motor (se rellena al abrir el lector o el cuadro del diccionario). */
object DictionaryContext {
    @Volatile var app: Context? = null
}

@Composable
fun DictionaryDialog(word: String, onDismiss: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current.applicationContext
    DictionaryContext.app = ctx
    // Respuesta instantánea si la palabra ya está en memoria o en la caché; si no, se busca en segundo plano
    var state by remember(word) { mutableStateOf<Result<DictResult>?>(DictionaryEngine.peek(word)?.let { Result.success(it) }) }
    var attempt by remember(word) { mutableIntStateOf(0) }

    LaunchedEffect(word, attempt) {
        if (state?.isSuccess != true) {
            state = null
            state = DictionaryEngine.lookup(ctx, word)
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Panel,
            modifier = Modifier.fillMaxWidth().heightIn(max = 480.dp)
        ) {
            Column(Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LibIcon(LibIconKind.DICTIONARY, tint = Gold, size = 20.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("DICCIONARIO", color = Gold, fontSize = 13.sp, letterSpacing = 1.sp,
                        fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    LibIconButton(LibIconKind.CLOSE, onClick = onDismiss, tint = Muted, iconSize = 18.dp)
                }
                Spacer(Modifier.height(4.dp))
                when {
                    state == null -> Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Gold, modifier = Modifier.size(32.dp))
                    }
                    state!!.isFailure -> Column {
                        val offline = state!!.exceptionOrNull() is DictOfflineError
                        Text(
                            if (offline) "Sin conexión a internet.\n\n«$word» no está en el diccionario del teléfono ni en tu caché. Conéctate y vuelve a intentarlo: la definición quedará guardada para consultarla sin conexión."
                            else "No se encontró definición para «$word».\n\nPrueba con otra palabra o revisa la ortografía.",
                            color = Cream, fontSize = 14.sp, lineHeight = 20.sp
                        )
                        if (offline) {
                            TextButton(onClick = { attempt++ }) { Text("Reintentar", color = Gold) }
                        }
                    }
                    else -> {
                        val r = state!!.getOrNull()!!
                        Column(Modifier.verticalScroll(rememberScrollState())) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(r.word, color = Cream, fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                Box(Modifier.background(Gold.copy(alpha = .2f), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)) {
                                    Text(if (r.translatedFrom.isNotBlank()) "ES (trad.)" else "ES",
                                        color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            if (r.phonetic.isNotBlank())
                                Text(r.phonetic, color = Gold, fontSize = 14.sp, fontStyle = FontStyle.Italic)
                            Spacer(Modifier.height(12.dp))
                            r.meanings.forEach { m ->
                                if (m.partOfSpeech.isNotBlank())
                                    Text(m.partOfSpeech, color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                m.definitions.forEachIndexed { i, def ->
                                    Text("${i + 1}. $def", color = Cream, fontSize = 14.sp, lineHeight = 20.sp,
                                        modifier = Modifier.padding(start = 8.dp, top = 4.dp))
                                }
                                if (m.synonyms.isNotEmpty())
                                    Text("Sinónimos: ${m.synonyms.joinToString(", ")}",
                                        color = Muted, fontSize = 12.sp,
                                        modifier = Modifier.padding(start = 8.dp, top = 4.dp))
                                Spacer(Modifier.height(10.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
