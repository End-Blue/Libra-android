package com.libra.reader

import android.util.Xml
import android.webkit.MimeTypeMap
import org.xmlpull.v1.XmlPullParser
import java.io.Closeable
import java.io.File
import java.io.StringReader
import java.net.URLDecoder
import java.util.zip.ZipFile

/** Entrada del índice tal como aparece en nav.xhtml / toc.ncx (ruta del ZIP + ancla), en orden del documento. */
class TocRef(val title: String, val path: String, val fragment: String?, val level: Int)

/** Lector mínimo de paquetes EPUB: metadatos, portada y orden de capítulos (spine). */
class EpubPackage(file: File) : Closeable {
    private class Item(val path: String, val mediaType: String, val properties: String)

    private val zip = ZipFile(file)
    private val mimeByPath = HashMap<String, String>()
    private var coverItem: Item? = null

    /** Rutas dentro del ZIP de los capítulos, en orden de lectura. */
    val spine = ArrayList<String>()
    var title: String? = null
        private set
    var author: String? = null
        private set

    /** Títulos reales de capítulo según el índice del libro (nav.xhtml o toc.ncx), por ruta de archivo. */
    val tocTitles = HashMap<String, String>()

    /** TODAS las entradas del índice (varias pueden apuntar al mismo archivo con anclas distintas). */
    val tocRefs = ArrayList<TocRef>()
    private val titleHasFragment = HashSet<String>()
    private var navPath: String? = null
    private var ncxPath: String? = null

    init {
        try {
            parse()
        } catch (e: Exception) {
            runCatching { zip.close() }
            throw e
        }
    }

    private fun parse() {
        val container = readText("META-INF/container.xml")
            ?: throw IllegalStateException("EPUB sin container.xml")
        var opfPath: String? = null
        run {
            val p = newParser(container)
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT && opfPath == null) {
                if (ev == XmlPullParser.START_TAG && p.name.substringAfterLast(':') == "rootfile") {
                    opfPath = p.getAttributeValue(null, "full-path")
                }
                ev = p.next()
            }
        }
        val opf = opfPath ?: throw IllegalStateException("EPUB sin archivo OPF")
        val opfText = readText(opf) ?: throw IllegalStateException("No se pudo leer el OPF")
        val base = opf.substringBeforeLast('/', "")

        val rawItems = LinkedHashMap<String, Item>()
        val spineIds = ArrayList<String>()
        var coverId: String? = null
        var tocId: String? = null
        var inMetadata = false

        val p = newParser(opfText)
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name.substringAfterLast(':')) {
                    "metadata" -> inMetadata = true
                    "title" -> if (inMetadata && title == null) {
                        title = p.nextText().trim().ifEmpty { null }
                    }
                    "creator" -> if (inMetadata && author == null) {
                        author = p.nextText().trim().ifEmpty { null }
                    }
                    "meta" -> if (p.getAttributeValue(null, "name") == "cover") {
                        coverId = p.getAttributeValue(null, "content")
                    }
                    "item" -> {
                        val id = p.getAttributeValue(null, "id")
                        val href = p.getAttributeValue(null, "href")
                        if (id != null && href != null) {
                            rawItems[id] = Item(
                                resolve(base, href),
                                p.getAttributeValue(null, "media-type") ?: "",
                                p.getAttributeValue(null, "properties") ?: ""
                            )
                        }
                    }
                    "spine" -> tocId = p.getAttributeValue(null, "toc")
                    "itemref" -> p.getAttributeValue(null, "idref")?.let { spineIds.add(it) }
                }
            } else if (ev == XmlPullParser.END_TAG && p.name.substringAfterLast(':') == "metadata") {
                inMetadata = false
            }
            ev = p.next()
        }

        rawItems.values.forEach { if (it.mediaType.isNotBlank()) mimeByPath[it.path] = it.mediaType }
        navPath = rawItems.values.firstOrNull { it.properties.split(' ').contains("nav") }?.path
        ncxPath = (tocId?.let { rawItems[it] }
            ?: rawItems.values.firstOrNull { it.mediaType == "application/x-dtbncx+xml" })?.path
        runCatching { loadToc() }
        spineIds.forEach { id ->
            val found = rawItems[id]
            if (found == null) readerLog("spine: el idref «$id» no existe en el manifiesto; se omite")
            else spine.add(found.path)
        }
        coverItem = rawItems.values.firstOrNull { it.properties.split(' ').contains("cover-image") }
            ?: coverId?.let { rawItems[it] }
            ?: rawItems.entries.firstOrNull {
                it.key.contains("cover", ignoreCase = true) && it.value.mediaType.startsWith("image/")
            }?.value
    }

    // ── Índice del libro: nombres reales de los capítulos ────────────────────────
    private fun cleanTitle(raw: String): String =
        android.text.Html.fromHtml(raw, android.text.Html.FROM_HTML_MODE_LEGACY).toString()
            .replace('\u00A0', ' ').replace(Regex("\\s+"), " ").trim()

    private fun loadToc() {
        // EPUB 3: nav.xhtml
        navPath?.let { np ->
            runCatching { parseNav(np) }
        }
        // EPUB 2 (o si el nav no dio nada): toc.ncx
        if (tocTitles.isEmpty()) ncxPath?.let { runCatching { parseNcx(it) } }
        if (tocTitles.isEmpty()) navPath?.let { runCatching { parseNavLoose(it) } }
    }

    private fun addToc(base: String, src: String?, label: String?, level: Int = 0) {
        if (src.isNullOrBlank() || label.isNullOrBlank()) return
        val path = resolve(base, src)
        val frag = src.substringAfter('#', "").ifEmpty { null }
        val t = cleanTitle(label)
        if (t.isEmpty()) return
        tocRefs.add(TocRef(t, path, frag, level))
        // Título del archivo completo: gana la entrada que apunta al archivo sin ancla; si no, la primera.
        if (!tocTitles.containsKey(path)) {
            tocTitles[path] = t
            if (frag != null) titleHasFragment.add(path)
        } else if (frag == null && path in titleHasFragment) {
            tocTitles[path] = t
            titleHasFragment.remove(path)
        }
    }

    /** Posición en el spine de un archivo (exacta; si no, sin distinguir mayúsculas; si no, por nombre). -1 si no está. */
    fun spineIndexOf(path: String): Int {
        var idx = spine.indexOf(path)
        if (idx < 0) idx = spine.indexOfFirst { it.equals(path, ignoreCase = true) }
        if (idx < 0) {
            val name = path.substringAfterLast('/')
            idx = spine.indexOfFirst { it.substringAfterLast('/').equals(name, ignoreCase = true) }
        }
        return idx
    }

    private fun parseNcx(path: String) {
        val text = readText(path) ?: return
        val base = path.substringBeforeLast('/', "")
        val p = newParser(text)
        var label: String? = null
        var inLabel = false
        var inNavMap = false      // solo navMap: pageList (números de página) no es índice
        var depth = 0
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name.substringAfterLast(':')) {
                    "navMap" -> inNavMap = true
                    "navPoint" -> { depth++; label = null }
                    "navLabel" -> inLabel = true
                    "text" -> if (inLabel) label = p.nextText()
                    "content" -> {
                        if (inNavMap) addToc(base, p.getAttributeValue(null, "src"), label, (depth - 1).coerceAtLeast(0))
                        label = null
                    }
                }
            } else if (ev == XmlPullParser.END_TAG) {
                when (p.name.substringAfterLast(':')) {
                    "navLabel" -> inLabel = false
                    "navPoint" -> depth--
                    "navMap" -> inNavMap = false
                }
            }
            ev = p.next()
        }
    }

    private fun parseNav(path: String) {
        val text = readText(path) ?: return
        val base = path.substringBeforeLast('/', "")
        val p = newParser(text)
        var inToc = false
        var depthNav = 0
        var olDepth = 0
        var href: String? = null
        val sb = StringBuilder()
        var aDepth = 0
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> {
                    val n = p.name.substringAfterLast(':')
                    if (n == "nav") {
                        val t = p.getAttributeValue(null, "epub:type") ?: p.getAttributeValue(null, "type") ?: ""
                        if (!inToc && t.split(' ').contains("toc")) { inToc = true; depthNav = 0; olDepth = 0 }
                        if (inToc) depthNav++
                    } else if (inToc && n == "a") {
                        href = p.getAttributeValue(null, "href"); sb.setLength(0); aDepth = 1
                    } else if (aDepth > 0) aDepth++
                    else if (inToc && n == "ol") olDepth++
                }
                XmlPullParser.TEXT -> if (aDepth > 0) sb.append(p.text)
                XmlPullParser.END_TAG -> {
                    val n = p.name.substringAfterLast(':')
                    if (aDepth > 0) {
                        aDepth--
                        if (aDepth == 0) { addToc(base, href, sb.toString(), (olDepth - 1).coerceAtLeast(0)); href = null }
                    } else if (inToc && n == "ol") {
                        olDepth--
                    } else if (inToc && n == "nav") {
                        depthNav--
                        if (depthNav <= 0) inToc = false
                    }
                }
            }
            ev = p.next()
        }
    }

    /** Respaldo si el nav.xhtml no es XML válido: se leen los enlaces con expresiones regulares. */
    private fun parseNavLoose(path: String) {
        val text = readText(path) ?: return
        val base = path.substringBeforeLast('/', "")
        val re = Regex("<a\\b[^>]*href\\s*=\\s*[\"']([^\"']+)[\"'][^>]*>([\\s\\S]*?)</a>", RegexOption.IGNORE_CASE)
        re.findAll(text).forEach { addToc(base, it.groupValues[1], it.groupValues[2]) }
    }

    /** Título del capítulo i del spine según el índice del libro, o null si el índice no lo menciona. */
    fun tocTitleFor(index: Int): String? = spine.getOrNull(index)?.let { tocTitles[it] }

    /** Respaldo: primer encabezado (h1–h3) o <title> del propio capítulo. */
    fun headingOf(path: String): String? {
        val html = readText(path) ?: return null
        val head = if (html.length > 60_000) html.substring(0, 60_000) else html
        val h = Regex("<h[1-3]\\b[^>]*>([\\s\\S]*?)</h[1-3]>", RegexOption.IGNORE_CASE).find(head)?.groupValues?.get(1)
        val t = h?.let { cleanTitle(it) }?.takeIf { it.length in 1..90 }
        if (t != null) return t
        val ti = Regex("<title\\b[^>]*>([\\s\\S]*?)</title>", RegexOption.IGNORE_CASE).find(head)?.groupValues?.get(1)
        return ti?.let { cleanTitle(it) }?.takeIf { it.length in 1..90 }
    }

    /** Busca una entrada del ZIP tolerando decodificación URL, mayúsculas y variantes de ruta. */
    fun readBytes(path: String): ByteArray? {
        val candidates = pathCandidates(path)
        for (c in candidates) {
            val entry = zip.getEntry(c) ?: continue
            return zip.getInputStream(entry).use { it.readBytes() }
        }
        // Último recurso: coincidencia por nombre de archivo (algunos EPUB tienen rutas inconsistentes)
        val fileName = path.substringAfterLast('/').lowercase()
        if (fileName.isNotBlank()) {
            val en = zip.entries()
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                if (!e.isDirectory && e.name.substringAfterLast('/').equals(fileName, ignoreCase = true)) {
                    return zip.getInputStream(e).use { it.readBytes() }
                }
            }
        }
        return null
    }

    private fun pathCandidates(path: String): List<String> {
        val decoded = try {
            URLDecoder.decode(path.replace("+", "%2B"), "UTF-8")
        } catch (_: Exception) {
            path
        }
        val normalized = decoded.trimStart('/').replace('\\', '/')
        val list = linkedSetOf<String>()
        list.add(normalized)
        list.add(decoded)
        list.add(path)
        // Variantes sin prefijo común
        if (normalized.startsWith("OEBPS/", ignoreCase = true)) {
            list.add(normalized.removePrefix("OEBPS/").removePrefix("oebps/"))
        }
        if (normalized.startsWith("OPS/", ignoreCase = true)) {
            list.add(normalized.removePrefix("OPS/").removePrefix("ops/"))
        }
        return list.toList()
    }

    fun readText(path: String): String? =
        readBytes(path)?.toString(Charsets.UTF_8)?.removePrefix("\uFEFF")

    fun coverBytes(): ByteArray? = coverItem?.let { readBytes(it.path) }

    fun mimeOf(path: String): String {
        val decoded = try {
            URLDecoder.decode(path.replace("+", "%2B"), "UTF-8")
        } catch (_: Exception) {
            path
        }
        mimeByPath[decoded]?.let { return it }
        mimeByPath[path]?.let { return it }
        // Buscar por coincidencia parcial de path
        mimeByPath.entries.firstOrNull {
            it.key.equals(decoded, ignoreCase = true) || it.key.endsWith("/$decoded")
        }?.value?.let { return it }

        val ext = decoded.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            ?: when (ext) {
                "xhtml", "html", "htm" -> "text/html"
                "css" -> "text/css"
                "jpg", "jpeg" -> "image/jpeg"
                "png" -> "image/png"
                "gif" -> "image/gif"
                "webp" -> "image/webp"
                "svg" -> "image/svg+xml"
                "ttf", "otf" -> "font/ttf"
                "woff" -> "font/woff"
                "woff2" -> "font/woff2"
                else -> "application/octet-stream"
            }
    }

    /** Resuelve una ruta relativa respecto a un capítulo del spine (para reescribir src de imágenes). */
    fun resolveRelative(chapterPath: String, relativeHref: String): String {
        val base = chapterPath.substringBeforeLast('/', "")
        return resolve(base, relativeHref)
    }

    override fun close() {
        runCatching { zip.close() }
    }

    private fun newParser(text: String): XmlPullParser =
        Xml.newPullParser().apply { setInput(StringReader(text)) }

    private fun resolve(base: String, href: String): String {
        val cleaned = href.substringBefore('#').substringBefore('?').replace("+", "%2B")
        val decoded = try {
            URLDecoder.decode(cleaned, "UTF-8")
        } catch (_: Exception) {
            cleaned
        }
        val parts = ArrayList<String>()
        val full = if (base.isEmpty()) decoded else "$base/$decoded"
        for (seg in full.split('/')) {
            when (seg) {
                "", "." -> {}
                ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.lastIndex)
                else -> parts.add(seg)
            }
        }
        return parts.joinToString("/")
    }
}
