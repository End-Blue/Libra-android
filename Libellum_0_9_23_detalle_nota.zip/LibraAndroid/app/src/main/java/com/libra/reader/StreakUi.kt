package com.libra.reader

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

// ══════════════════════════════════════════════════════════════════════════════
// RACHA DE LECTURA — diseño «papel dorado»
// ══════════════════════════════════════════════════════════════════════════════

/** Minutos leídos por día (los guarda el lector en «libra_reading_stats»). */
internal object ReadStats {
    fun all(ctx: Context): Map<String, Long> =
        ctx.getSharedPreferences("libra_reading_stats", 0).all.entries
            .filter { it.key.startsWith("day_") }
            .mapNotNull { e -> (e.value as? Long)?.let { e.key.removePrefix("day_") to it } }
            .toMap()
}

/** Un día con al menos este tiempo cuenta como «objetivo cumplido». */
private const val DAILY_GOAL_MS = 15 * 60_000L

private class Achievement(val name: String, val tone: MedalTone, val value: Int, val goal: Int, val needs: Int = -1)

@Composable
fun StreakScreen(days: Set<String>, onMarkToday: () -> Unit) {
    val ctx = LocalContext.current
    val current = remember(days) { Streak.current(days) }
    val best = remember(days) { Streak.best(days) }
    val readToday = Streak.key() in days
    val msByDay = remember(days) { ReadStats.all(ctx) }
    val totalMs = msByDay.values.sum()
    val todayMs = msByDay[Streak.key()] ?: 0L
    var monthOffset by remember { mutableIntStateOf(0) }
    var achDialog by remember { mutableStateOf(false) }

    val achievements = listOf(
        Achievement("Primer día", MedalTone.BRONZE, days.size, 1),
        Achievement("Primera semana", MedalTone.SILVER, best, 7, needs = 0),
        Achievement("Primer mes", MedalTone.GOLD, best, 30, needs = 1)
    )
    val extra = listOf(
        Achievement("10 días leídos", MedalTone.BRONZE, days.size, 10),
        Achievement("Racha de 14 días", MedalTone.SILVER, best, 14),
        Achievement("100 días leídos", MedalTone.GOLD, days.size, 100),
        Achievement("10 horas de lectura", MedalTone.SILVER, (totalMs / 3_600_000L).toInt(), 10)
    )

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 18.dp)
    ) {
        item {
            HeroHeader(
                art = R.drawable.hero_streak,
                title = "Tu racha de lectura",
                sub = "Cada página leída\nfortalece tu hábito.",
                quote = "La constancia de hoy\nconstruye los lectores\ndel mañana.",
                titleSize = 28,
                subSize = 16
            )
        }

        // ── Tarjeta principal ──
        item {
            LbCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), padding = 0.dp) {
                Box(Modifier.fillMaxWidth()) {
                    Laurel(Modifier.align(Alignment.CenterStart).padding(start = 4.dp, top = 40.dp), flip = false, scale = 1.35f)
                    Laurel(Modifier.align(Alignment.CenterEnd).padding(end = 4.dp, top = 40.dp), flip = true, scale = 1.35f)
                    Laurel(Modifier.align(Alignment.TopStart).padding(top = 4.dp), flip = false, scale = 0.55f)
                    Laurel(Modifier.align(Alignment.TopEnd).padding(top = 4.dp), flip = true, scale = 0.55f)
                    Column(
                        Modifier.fillMaxWidth().padding(vertical = 18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Medallón con la llama
                        Box(Modifier.size(84.dp), contentAlignment = Alignment.Center) {
                            Canvas(Modifier.fillMaxSize()) {
                                val r = this.size.minDimension / 2f
                                drawCircle(
                                    Brush.verticalGradient(listOf(Color(0xFFE8BC5E), Color(0xFFA9701E))), r
                                )
                                drawCircle(Color(0xFFFBEFD8), r * 0.82f)
                                drawCircle(Color(0x55A9701E), r * 0.82f, style = Stroke(r * 0.04f))
                            }
                            LbIcon(LbIconKind.FLAME, size = 50.dp, filled = true)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "$current", color = LbTitle, fontSize = 66.sp, fontWeight = FontWeight.Bold,
                            fontFamily = LibellumSerif, fontStyle = FontStyle.Italic, lineHeight = 70.sp
                        )
                        Text(
                            if (current == 1) "día consecutivo" else "días consecutivos",
                            color = LbTitle, fontSize = 20.sp, fontFamily = LibellumSerif
                        )
                        Spacer(Modifier.height(12.dp))
                        Box(
                            Modifier
                                .shadow(3.dp, RoundedCornerShape(50), ambientColor = Color(0x33805020), spotColor = Color(0x55805020))
                                .clip(RoundedCornerShape(50))
                                .background(Brush.verticalGradient(listOf(Color(0xFF9A5A0C), LbBrown)))
                                .then(if (readToday) Modifier else Modifier.clickable(onClick = onMarkToday))
                                .padding(horizontal = 30.dp, vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                if (readToday) "¡Hoy ya leíste!" else "Marcar hoy como leído",
                                color = Color(0xFFFDF1DC), fontSize = 17.sp, fontFamily = LibellumSerif,
                                fontStyle = FontStyle.Italic, fontWeight = FontWeight.SemiBold
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "Un pequeño paso, grandes historias\npor venir.",
                            color = LbMuted, fontSize = 14.sp, fontFamily = LibellumSerif,
                            fontStyle = FontStyle.Italic, textAlign = TextAlign.Center, lineHeight = 19.sp
                        )
                        if (!readToday) {
                            Text(
                                "Abrir un libro y avanzar también cuenta.",
                                color = LbMuted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        // ── Tus estadísticas ──
        item {
            LbSectionHeader(
                "Tus estadísticas",
                icon = { LbIcon(LbIconKind.CHART, size = 26.dp) },
                modifier = Modifier.padding(horizontal = 18.dp)
            )
        }
        item {
            Column(Modifier.padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    LbTile(Modifier.weight(1f), { LbIcon(LbIconKind.FLAME, size = 32.dp, filled = true) }, "$best", "Mejor racha")
                    LbTile(Modifier.weight(1f), { LbIcon(LbIconKind.BOOK_OPEN, size = 32.dp) }, "${days.size}", "Días leídos")
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    LbTile(Modifier.weight(1f), { LbIcon(LbIconKind.CLOCK, size = 32.dp) }, formatReadingTime(totalMs), "Tiempo total")
                    LbTile(Modifier.weight(1f), { LbIcon(LbIconKind.CHART, size = 32.dp) }, formatReadingTime(todayMs), "Leídos hoy")
                }
            }
        }

        // ── Calendario ──
        item {
            LbSectionHeader(
                "Calendario de lectura",
                icon = { LbIcon(LbIconKind.CALENDAR, size = 26.dp) },
                modifier = Modifier.padding(horizontal = 18.dp)
            )
        }
        item {
            val cal = Calendar.getInstance().apply { add(Calendar.MONTH, monthOffset) }
            val year = cal.get(Calendar.YEAR)
            val month = cal.get(Calendar.MONTH)
            val first = Calendar.getInstance().apply { set(year, month, 1) }
            val offset = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7
            val dim = first.getActualMaximum(Calendar.DAY_OF_MONTH)
            val rows = (offset + dim + 6) / 7
            val monthName = SimpleDateFormat("MMMM yyyy", Locale("es")).format(first.time)
                .replaceFirstChar { it.uppercase() }
            val todayKey = Streak.key()
            LbCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), padding = 12.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(36.dp).clip(CircleShape).clickable { monthOffset -= 1 }, contentAlignment = Alignment.Center) {
                        LbIcon(LbIconKind.CHEVRON_LEFT, tint = LbBrown, size = 22.dp)
                    }
                    Text(
                        monthName, color = LbTitle, fontSize = 18.sp, fontFamily = LibellumSerif,
                        textAlign = TextAlign.Center, modifier = Modifier.weight(1f)
                    )
                    Box(
                        Modifier.size(36.dp).clip(CircleShape)
                            .then(if (monthOffset < 0) Modifier.clickable { monthOffset += 1 } else Modifier),
                        contentAlignment = Alignment.Center
                    ) {
                        LbIcon(LbIconKind.CHEVRON_RIGHT, tint = if (monthOffset < 0) LbBrown else LbLine, size = 22.dp)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth()) {
                    listOf("L", "M", "X", "J", "V", "S", "D").forEach {
                        Text(
                            it, color = LbMuted, fontSize = 13.sp, fontFamily = LibellumSerif,
                            textAlign = TextAlign.Center, modifier = Modifier.weight(1f)
                        )
                    }
                }
                for (r in 0 until rows) {
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                        for (c in 0 until 7) {
                            val day = r * 7 + c - offset + 1
                            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                                if (day in 1..dim) {
                                    val key = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day)
                                    val done = key in days
                                    val goalMet = (msByDay[key] ?: 0L) >= DAILY_GOAL_MS
                                    val isToday = key == todayKey
                                    Box(
                                        Modifier.size(34.dp).clip(CircleShape)
                                            .background(if (done) LbBrown else Color.Transparent)
                                            .border(
                                                if (isToday && !done) 2.dp else 0.dp,
                                                if (isToday && !done) LbBrown else Color.Transparent, CircleShape
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            "$day", fontSize = 14.sp, fontFamily = LibellumSerif,
                                            color = if (done) Color(0xFFFDF1DC) else LbText
                                        )
                                    }
                                    if (goalMet) {
                                        LbIcon(
                                            LbIconKind.FLAME, size = 13.dp, filled = true,
                                            modifier = Modifier.align(Alignment.TopEnd).offset(x = (-1).dp, y = (-2).dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(16.dp).clip(CircleShape).border(1.3.dp, LbLine, CircleShape))
                        Spacer(Modifier.width(6.dp))
                        Text("Sin lectura", color = LbMuted, fontSize = 11.sp, fontFamily = LibellumSerif)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(16.dp).clip(CircleShape).background(LbBrown))
                        Spacer(Modifier.width(6.dp))
                        Text("Leíste", color = LbMuted, fontSize = 11.sp, fontFamily = LibellumSerif)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LbIcon(LbIconKind.FLAME, size = 16.dp, filled = true)
                        Spacer(Modifier.width(4.dp))
                        Text("Objetivo cumplido (15 min)", color = LbMuted, fontSize = 11.sp, fontFamily = LibellumSerif)
                    }
                }
            }
        }

        // ── Logros ──
        item {
            LbSectionHeader(
                "Logros de lectura",
                icon = { LbIcon(LbIconKind.BADGE, size = 26.dp) },
                trailing = { LbLink("Ver todos") { achDialog = true } },
                modifier = Modifier.padding(horizontal = 18.dp)
            )
        }
        item {
            Row(
                Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                achievements.forEachIndexed { i, a ->
                    val done = a.value >= a.goal
                    val unlocked = a.needs < 0 || achievements[a.needs].value >= achievements[a.needs].goal
                    AchievementCard(a, done, unlocked, Modifier.weight(1f))
                }
            }
        }

        item { LbQuoteFooter("Los hábitos de hoy\nescriben las grandes historias de mañana.") }
    }

    if (achDialog) {
        AlertDialog(
            onDismissRequest = { achDialog = false },
            containerColor = LbBg,
            title = { Text("Logros de lectura", color = LbTitle, fontFamily = LibellumSerif, fontStyle = FontStyle.Italic) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    (achievements + extra).forEach { a ->
                        val done = a.value >= a.goal
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(22.dp).clip(CircleShape)
                                    .background(if (done) LbBrown else Color.Transparent)
                                    .border(1.3.dp, if (done) LbBrown else LbLine, CircleShape),
                                contentAlignment = Alignment.Center
                            ) { if (done) LbIcon(LbIconKind.CHECK, tint = Color(0xFFFDF1DC), size = 12.dp) }
                            Spacer(Modifier.width(10.dp))
                            Text(a.name, color = LbText, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            Text(
                                if (done) "¡Logrado!" else "${minOf(a.value, a.goal)}/${a.goal}",
                                color = if (done) LbBrown else LbMuted, fontSize = 12.sp
                            )
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { achDialog = false }) { Text("Cerrar", color = LbBrown) } }
        )
    }
}

@Composable
private fun AchievementCard(a: Achievement, done: Boolean, unlocked: Boolean, modifier: Modifier) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier
            .shadow(2.dp, shape, ambientColor = Color(0x22805020), spotColor = Color(0x22805020))
            .clip(shape)
            .background(Brush.verticalGradient(listOf(LbCardTop, LbCardBottom)))
            .border(1.dp, LbCardEdge, shape)
            .padding(horizontal = 6.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LbMedal(a.tone, locked = !unlocked && !done, diameter = 54.dp)
        Spacer(Modifier.height(6.dp))
        Text(
            a.name, color = LbTitle, fontSize = 14.sp, fontWeight = FontWeight.Bold,
            fontFamily = LibellumSerif, textAlign = TextAlign.Center, lineHeight = 16.sp, minLines = 2, maxLines = 2
        )
        Spacer(Modifier.height(4.dp))
        when {
            done -> Text("Completado", color = LbText, fontSize = 12.sp, fontFamily = LibellumSerif)
            unlocked -> Text("En progreso", color = LbMuted, fontSize = 12.sp, fontFamily = LibellumSerif, fontStyle = FontStyle.Italic)
            else -> Box(
                Modifier.clip(RoundedCornerShape(50)).background(Color(0xFFE6D8BF)).padding(horizontal = 10.dp, vertical = 3.dp)
            ) { Text("Bloqueado", color = LbMuted, fontSize = 11.sp, fontFamily = LibellumSerif) }
        }
    }
}
