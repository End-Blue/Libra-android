package com.libra.reader

import android.app.Application
import androidx.compose.runtime.Immutable
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

// ══════════════════════════════════════════════════════════════════════════════
// NOTAS Y CITAS — estado y lógica
//   Room (quote_notes + highlights + library_items) → NotesViewModel → NotesUiState → NotesScreen
//   Las notas manuales y los subrayados del lector se unifican en una sola lista de NoteEntry.
// ══════════════════════════════════════════════════════════════════════════════

internal enum class NotesFilter { ALL, BY_BOOK, FAVORITES, RECENT }

internal enum class NoteKind { MANUAL, HIGHLIGHT }

/** Elemento unificado de «Notas y Citas»: una nota/cita manual o un subrayado hecho leyendo. */
@Immutable
internal data class NoteEntry(
    val key: String,                 // «n:<id>» o «h:<id>» (único en la lista)
    val kind: NoteKind,
    val id: String,
    val text: String,                // cita / texto subrayado
    val comment: String,             // nota del lector sobre el subrayado (vacía en notas manuales)
    val bookId: String,
    val bookTitle: String,
    val isFavorite: Boolean,
    val createdAt: Long,
    val chapterIndex: Int,           // orden de lectura dentro del libro (las notas manuales van al final)
    val chapterTitle: String,
    val colorArgb: Long,
    val quote: QuoteNote? = null,
    val highlight: Highlight? = null
)

/** Para qué se abrió el selector de libros: filtrar la lista o cambiar el libro de una nota manual. */
internal sealed interface BookPicker {
    data object Filter : BookPicker
    data class Change(val noteId: String) : BookPicker
}

/** Opción del filtro «Por libro»: libro + cuántos elementos tiene. */
internal data class BookOption(val id: String, val title: String, val count: Int)

@Immutable
internal data class NotesUiState(
    val allEntries: List<NoteEntry> = emptyList(),
    val availableBooks: List<LibraryItem> = emptyList(),
    val selectedFilter: NotesFilter = NotesFilter.ALL,
    val selectedBookFilter: String? = null,
    val recentAscending: Boolean = false,          // «Recientes» ↓ más nuevas primero · «Antiguas» ↑
    // vista «un libro»: carrusel o lista + búsqueda y filtros propios del libro
    val bookCarousel: Boolean = true,
    val bookSearch: String = "",
    val bookOnlyFavs: Boolean = false,
    val bookChapter: String? = null,
    // borrador
    val draftText: String = "",
    val selectedBookForDraft: String? = null,
    val draftMarkedFavorite: Boolean = false,
    val draftError: Boolean = false,
    val isSaving: Boolean = false,
    // menús y diálogos
    val activeMenuKey: String? = null,
    val editingNote: QuoteNote? = null,
    val editingHighlight: Highlight? = null,
    val pendingDeleteKey: String? = null,
    val detailKey: String? = null,                  // nota/subrayado abierto en el modal de detalle
    val bookPicker: BookPicker? = null
) {
    /** ¿Se está viendo un libro concreto (filtro «Por libro» con libro elegido)? */
    val inBookMode: Boolean get() = selectedFilter == NotesFilter.BY_BOOK && selectedBookFilter != null

    /** Lista visible según el filtro activo (misma lógica para notas manuales y subrayados). */
    val entries: List<NoteEntry>
        get() = when (selectedFilter) {
            NotesFilter.FAVORITES -> allEntries.filter { it.isFavorite }
            NotesFilter.BY_BOOK ->
                if (selectedBookFilter == null) allEntries
                else allEntries.filter { it.bookId == selectedBookFilter }
            else -> allEntries
        }.let { base ->
            when {
                inBookMode -> base.sortedWith(compareBy({ it.chapterIndex }, { it.createdAt }))  // orden de lectura
                selectedFilter == NotesFilter.RECENT && recentAscending -> base.sortedBy { it.createdAt }
                else -> base.sortedByDescending { it.createdAt }
            }
        }

    /** Elementos del libro tras aplicar búsqueda, «solo favoritos» y capítulo. */
    val bookEntries: List<NoteEntry>
        get() {
            val q = bookSearch.trim()
            return entries.filter { e ->
                (!bookOnlyFavs || e.isFavorite) &&
                    (bookChapter == null || e.chapterTitle == bookChapter) &&
                    (q.isEmpty() || e.text.contains(q, true) || e.comment.contains(q, true) || e.chapterTitle.contains(q, true))
            }
        }

    /** Capítulos/secciones del libro (solo subrayados), en orden de lectura. */
    val bookChapters: List<String>
        get() = entries.filter { it.kind == NoteKind.HIGHLIGHT && it.chapterTitle.isNotBlank() }
            .sortedBy { it.chapterIndex }.map { it.chapterTitle }.distinct()

    fun bookOf(id: String): LibraryItem? = if (id.isBlank()) null else availableBooks.firstOrNull { it.id == id }

    /** Libros con al menos un elemento (opciones del filtro «Por libro»). */
    val booksWithNotes: List<BookOption>
        get() = allEntries.filter { it.bookId.isNotBlank() }
            .groupBy { it.bookId }
            .map { (id, list) -> BookOption(id, bookOf(id)?.title ?: list.first().bookTitle, list.size) }
            .sortedBy { it.title.lowercase() }

    val selectedBookFilterTitle: String?
        get() = selectedBookFilter?.let { id -> bookOf(id)?.title ?: allEntries.firstOrNull { it.bookId == id }?.bookTitle }

    fun entryByKey(key: String): NoteEntry? = allEntries.firstOrNull { it.key == key }
}

internal class NotesViewModel(app: Application) : AndroidViewModel(app) {
    private val db = LibraryDatabase.get(app)
    private val noteDao = db.quoteNoteDao()
    private val highlightDao = db.highlightDao()

    private val _ui = MutableStateFlow(NotesUiState())
    val uiState: StateFlow<NotesUiState> = _ui.asStateFlow()

    init {
        // Notas, subrayados y biblioteca se observan: cualquier cambio (aquí, en el lector o en otras pantallas) llega al instante.
        viewModelScope.launch {
            combine(noteDao.observeAll(), highlightDao.observeAll(), db.libraryDao().observeAll()) { notes, highlights, items ->
                val books = items.filter { it.mediaType == "BOOK" }.sortedBy { it.title.lowercase() }
                val merged = notes.map { it.toEntry() } + highlights.map { it.toEntry() }
                merged.sortedByDescending { it.createdAt } to books
            }.collect { (entries, books) ->
                _ui.update { it.copy(allEntries = entries, availableBooks = books) }
            }
        }
    }

    // ── Borrador (tarjeta «Nueva nota o cita») ────────────────────────────────
    fun onDraftChange(text: String) = _ui.update { it.copy(draftText = text, draftError = false) }
    fun toggleDraftFavorite() = _ui.update { it.copy(draftMarkedFavorite = !it.draftMarkedFavorite) }
    fun selectDraftBook(id: String?) = _ui.update { it.copy(selectedBookForDraft = id) }

    fun saveDraft() {
        val s = _ui.value
        if (s.isSaving) return
        val text = s.draftText.trim()
        if (text.isEmpty()) {                       // nunca se guardan notas vacías
            _ui.update { it.copy(draftError = true) }
            return
        }
        _ui.update { it.copy(isSaving = true, draftError = false) }
        val book = s.selectedBookForDraft?.let { s.bookOf(it) }
        viewModelScope.launch {
            try {
                noteDao.upsert(
                    QuoteNote(
                        id = UUID.randomUUID().toString(), text = text,
                        bookId = book?.id.orEmpty(), bookTitle = book?.title.orEmpty(),
                        isFavorite = if (s.draftMarkedFavorite) 1 else 0
                    )
                )
                _ui.update { it.copy(draftText = "", draftMarkedFavorite = false, isSaving = false) }
            } catch (e: Exception) {
                readerLog("notas: no se pudo guardar la nota: ${e.message}")
                _ui.update { it.copy(isSaving = false) }
            }
        }
    }

    // ── Filtros ───────────────────────────────────────────────────────────────
    fun selectFilter(f: NotesFilter) = _ui.update {
        when {
            f == NotesFilter.RECENT && it.selectedFilter == NotesFilter.RECENT ->
                it.copy(recentAscending = !it.recentAscending)           // segundo toque: invierte el orden
            f == NotesFilter.RECENT -> it.copy(selectedFilter = f, recentAscending = false)
            else -> it.copy(selectedFilter = f)
        }
    }

    fun selectBookFilter(id: String?) = _ui.update {
        if (id == null) it.copy(
            selectedBookFilter = null, selectedFilter = NotesFilter.ALL, bookPicker = null,
            bookSearch = "", bookOnlyFavs = false, bookChapter = null
        )
        else it.copy(
            selectedBookFilter = id, selectedFilter = NotesFilter.BY_BOOK, bookPicker = null,
            bookSearch = "", bookOnlyFavs = false, bookChapter = null
        )
    }

    // ── Vista de un libro: carrusel / lista, búsqueda, favoritos, capítulo ───
    fun setBookCarousel(on: Boolean) = _ui.update { it.copy(bookCarousel = on) }
    fun setBookSearch(q: String) = _ui.update { it.copy(bookSearch = q) }
    fun toggleBookOnlyFavs() = _ui.update { it.copy(bookOnlyFavs = !it.bookOnlyFavs) }
    fun selectBookChapter(c: String?) = _ui.update { it.copy(bookChapter = if (it.bookChapter == c) null else c) }

    // ── Detalle (modal con el texto completo) ────────────────────────────────
    fun openDetail(key: String) = _ui.update { it.copy(detailKey = key, activeMenuKey = null) }
    fun closeDetail() = _ui.update { it.copy(detailKey = null) }

    // ── Menú, favorito, edición, libro y borrado ─────────────────────────────
    fun openMenu(key: String?) = _ui.update { it.copy(activeMenuKey = key) }
    fun openBookPicker(p: BookPicker?) = _ui.update { it.copy(bookPicker = p, activeMenuKey = null) }

    fun toggleFavorite(e: NoteEntry) {
        _ui.update { it.copy(activeMenuKey = null) }
        val fav = if (e.isFavorite) 0 else 1
        viewModelScope.launch {
            if (e.kind == NoteKind.MANUAL) noteDao.setFavorite(e.id, fav) else highlightDao.setFavorite(e.id, fav)
        }
    }

    fun startEdit(e: NoteEntry) = _ui.update {
        it.copy(activeMenuKey = null, editingNote = e.quote, editingHighlight = e.highlight)
    }
    fun cancelEdit() = _ui.update { it.copy(editingNote = null, editingHighlight = null) }

    fun saveEdit(text: String) {
        val note = _ui.value.editingNote ?: return
        val t = text.trim()
        if (t.isEmpty()) return
        _ui.update { it.copy(editingNote = null) }
        viewModelScope.launch { noteDao.updateText(note.id, t) }
    }

    fun saveHighlight(updated: Highlight) {
        _ui.update { it.copy(editingHighlight = null) }
        viewModelScope.launch { highlightDao.update(updated) }
    }

    fun changeBook(noteId: String, bookId: String?) {
        val book = bookId?.let { _ui.value.bookOf(it) }
        _ui.update { it.copy(bookPicker = null) }
        viewModelScope.launch { noteDao.setBook(noteId, book?.id.orEmpty(), book?.title.orEmpty()) }
    }

    fun requestDelete(key: String) = _ui.update { it.copy(pendingDeleteKey = key, activeMenuKey = null) }
    fun dismissDelete() = _ui.update { it.copy(pendingDeleteKey = null) }
    fun confirmDelete() {
        val e = _ui.value.pendingDeleteKey?.let { _ui.value.entryByKey(it) }
        _ui.update { it.copy(pendingDeleteKey = null, detailKey = if (it.detailKey == e?.key) null else it.detailKey) }
        if (e == null) return
        viewModelScope.launch {
            if (e.kind == NoteKind.MANUAL) noteDao.deleteById(e.id) else highlightDao.deleteById(e.id)
        }
    }
}

private fun QuoteNote.toEntry() = NoteEntry(
    key = "n:$id", kind = NoteKind.MANUAL, id = id, text = text, comment = "",
    bookId = bookId, bookTitle = bookTitle, isFavorite = isFavorite == 1, createdAt = createdAt,
    chapterIndex = Int.MAX_VALUE, chapterTitle = "", colorArgb = 0, quote = this
)

private fun Highlight.toEntry() = NoteEntry(
    key = "h:$id", kind = NoteKind.HIGHLIGHT, id = id, text = selectedText, comment = note,
    bookId = bookId, bookTitle = bookTitle, isFavorite = isFavorite == 1, createdAt = createdAt,
    chapterIndex = chapterIndex, chapterTitle = chapterTitle, colorArgb = colorArgb, highlight = this
)
