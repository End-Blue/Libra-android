@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.libra.reader

import android.app.Activity
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.webkit.WebView
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipFile

// ══════════════════════════════════════════════════════════════════════════════
// PANTALLA PRINCIPAL DEL LECTOR
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun ReaderScreen(
    item: LibraryItem,
    onClose: () -> Unit,
    onSave: (Long, Int) -> Unit,
    highlightDao: HighlightDao,
    onUpdateItem: (LibraryItem) -> Unit,  // para guardar readingMode, bookmarkStyle
    startHighlight: Highlight? = null     // abrir el libro directamente en la hoja de este subrayado
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val activity = context as? Activity
    val sp = remember { context.getSharedPreferences("libra_reading_prefs", 0) }

    var showMenu by remember { mutableStateOf(false) }
    var showHighlights by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    BackHandler(onBack = onClose)
    BackHandler(enabled = showSettings || showHighlights) { showSettings = false; showHighlights = false }
    var showContents by remember { mutableStateOf(false) }
    // Chrome del lector: oculto al leer; un toque lo muestra/oculta
    var showChrome by remember { mutableStateOf(false) }
    // Progreso actualizado por el lector (capítulo / página)
    var liveProgress by remember { mutableIntStateOf(item.progress.coerceIn(0, 100)) }
    var liveChapterLabel by remember { mutableStateOf("") }
    // Posición viva (EPUB: índice de capítulo) y petición de salto desde marcadores / resaltados
    var livePos by remember { mutableLongStateOf(item.lastPosition) }
    var jumpChapter by remember { mutableStateOf<Int?>(startHighlight?.chapterIndex) }
    var jumpOffset by remember { mutableIntStateOf(-1) }
    var jumpText by remember { mutableStateOf<String?>(startHighlight?.selectedText) }
    var jumpTextK by remember { mutableIntStateOf(startHighlight?.let { sp.getInt("hlk_${it.id}", 0) } ?: 0) }
    var bookmarkRequest by remember { mutableIntStateOf(0) }
    var chapterNames by remember { mutableStateOf<List<String>>(emptyList()) }
    var pageBookmarked by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current
    // Última página exacta: capítulo + posición del primer carácter visible + un fragmento de texto de respaldo
    val savedAnchor = remember(item.id) {
        val parts = sp.getString("pg2_${item.id}", null)?.split("|")
        if (parts != null && parts.getOrNull(0)?.toLongOrNull() == item.lastPosition)
            (parts.getOrNull(1)?.toIntOrNull() ?: -1) to (sp.getString("pg2s_${item.id}", "") ?: "")
        else -1 to ""
    }
    // EPUB, TXT y FB2 se leen con el mismo motor nativo
    val isEpub = item.format.lowercase() in setOf("epub", "txt", "fb2")
    // Marcadores del libro (SharedPreferences; la base de datos no cambia)
    val bookmarks = remember(item.id) {
        mutableStateListOf<ReaderBookmark>().apply { addAll(loadReaderBookmarks(sp, item.id)) }
    }
    var readingPrefs by remember {
        mutableStateOf(
            ReadingPrefs(
                themeMode = sp.getInt("themeMode", 2),
                fontSizeSp = sp.getInt("fontSizeSp", 18),
                lineHeight = sp.getFloat("lineHeight", 1.65f),
                marginDp = sp.getInt("marginDp", 28),
                brightness = sp.getFloat("brightness", 1f),
                fontFamily = sp.getString("fontFamily", "serif") ?: "serif",
                pageTurnStyle = sp.getString("pageTurnStyle", "slide") ?: "slide",
                orientation = sp.getString("orientation", "auto") ?: "auto",
                showNavButtons = sp.getBoolean("showNavButtons", false),
                leftHanded = sp.getBoolean("leftHanded", false),
                justify = sp.getBoolean("justify", true),
                indent = sp.getBoolean("indent", true)
            )
        )
    }

    // Persistir y aplicar orientación
    LaunchedEffect(readingPrefs) {
        sp.edit()
            .putInt("themeMode", readingPrefs.themeMode)
            .putInt("fontSizeSp", readingPrefs.fontSizeSp)
            .putFloat("lineHeight", readingPrefs.lineHeight)
            .putInt("marginDp", readingPrefs.marginDp)
            .putFloat("brightness", readingPrefs.brightness)
            .putString("fontFamily", readingPrefs.fontFamily)
            .putString("pageTurnStyle", readingPrefs.pageTurnStyle)
            .putString("orientation", readingPrefs.orientation)
            .putBoolean("showNavButtons", readingPrefs.showNavButtons)
            .putBoolean("leftHanded", readingPrefs.leftHanded)
            .putBoolean("justify", readingPrefs.justify)
            .putBoolean("indent", readingPrefs.indent)
            .apply()
        when (readingPrefs.orientation) {
            "portrait" -> activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            "landscape" -> activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            else -> activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    val highlights by highlightDao.observeByBook(item.id).collectAsState(initial = emptyList())
    var editingHighlight by remember { mutableStateOf<Highlight?>(null) }

    // Al abrir: muestra opciones un momento y luego solo el texto
    LaunchedEffect(item.id) {
        showChrome = true
        kotlinx.coroutines.delay(2200)
        if (!showSettings && !showContents && !showHighlights) showChrome = false
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Ink)
            .systemBarsPadding()
    ) {
        // ── Solo el texto del libro ───────────────────────────────────────────
        Box(Modifier.fillMaxSize()) {
            val progressCb: (Long, Int) -> Unit = { pos, pct ->
                livePos = pos
                liveProgress = pct.coerceIn(0, 100)
                onSave(pos, pct)
            }
            val immersivePrefs = readingPrefs.copy(showNavButtons = showChrome && readingPrefs.showNavButtons)
            when (item.format.lowercase()) {
                "epub", "txt", "fb2" -> NativeBookReader(
                    item = item,
                    onSave = progressCb,
                    highlightDao = highlightDao,
                    prefs = immersivePrefs,
                    showContents = showContents,
                    onContentsDismiss = { showContents = false },
                    onChapterLabel = { liveChapterLabel = it },
                    onToggleChrome = { showChrome = !showChrome },
                    jumpChapter = jumpChapter,
                    onJumpConsumed = { jumpChapter = null; jumpOffset = -1; jumpText = null },
                    jumpOffset = jumpOffset,
                    jumpText = jumpText,
                    jumpTextK = jumpTextK,
                    initialOffset = savedAnchor.first,
                    initialSnippet = savedAnchor.second,
                    onOffsetSave = { spine, off, snippet ->
                        sp.edit()
                            .putString("pg2_${item.id}", "$spine|$off")
                            .putString("pg2s_${item.id}", snippet)
                            .apply()
                    },
                    bookmarkOffsets = bookmarks.filter { it.off >= 0 }.map { it.pos.toInt() to it.off },
                    bookmarkRequest = bookmarkRequest,
                    onBookmarkToggle = { spine, off, pct, label, existing ->
                        if (existing >= 0) {
                            bookmarks.removeAll { it.pos == spine.toLong() && it.off == existing }
                        } else if (off >= 0) {
                            bookmarks.add(0, newReaderBookmark(spine.toLong(), off, pct, label))
                        }
                        saveReaderBookmarks(sp, item.id, bookmarks)
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    },
                    ribbonEnabled = item.bookmarkStyle != "NONE",
                    onChapterNames = { chapterNames = it },
                    onPageBookmarked = { pageBookmarked = it }
                )
                "pdf"  -> PdfReader(item, progressCb, item.readingMode, highlightDao, onUpdateItem)
                "cbz"  -> CbzReader(item, progressCb, item.readingMode)
                else   -> Message(
                    "Los archivos CBR (RAR) todavía no se pueden leer dentro de Libellum. " +
                    "Conviértelo a CBZ y vuelve a importarlo."
                )
            }
        }

        // Franja superior táctil cuando las opciones están ocultas (no interfiere con el texto)
        if (!showChrome) {
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .height(36.dp)
                    .clickable { showChrome = true }
            )
        }

        // ── Opciones: aparecen al tocar la franja superior o el centro del EPUB ─
        if (showChrome) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(Ink.copy(alpha = 0.94f))
                        .clickable { showChrome = false }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LibIconButton(LibIconKind.CLOSE, onClick = onClose, tint = Cream)
                    Text(
                        item.title, color = Cream, fontSize = 13.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f).padding(horizontal = 4.dp)
                    )
                    LibIconButton(LibIconKind.LIST, onClick = { showContents = true }, tint = Cream)
                    // Aquí flota el botón de anotaciones (arriba a la derecha)
                    Spacer(Modifier.width(48.dp))
                }
                Column(
                    Modifier
                        .fillMaxWidth()
                        .background(Ink.copy(alpha = 0.94f))
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    GoldProgressBar(liveProgress / 100f, height = 5.dp)
                    if (liveChapterLabel.isNotBlank()) {
                        Text(liveChapterLabel, color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 2.dp))
                    }
                }
                // Zona central: tocar para ocultar opciones y volver al texto
                Spacer(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .clickable(
                            interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                            indication = null
                        ) { showChrome = false }
                )
            }
        }

        // ── Paneles flotantes: ajustes (abajo derecha) y anotaciones (arriba derecha) ──
        ReaderFloatingPanels(
            item = item,
            prefs = readingPrefs,
            onPrefsChange = { readingPrefs = it },
            onUpdateItem = onUpdateItem,
            highlights = highlights,
            onEditHighlight = { editingHighlight = it },
            onDeleteHighlight = { h -> scope.launch { highlightDao.deleteById(h.id) } },
            bookmarks = bookmarks,
            pageBookmarked = pageBookmarked,
            onToggleBookmark = { bookmarkRequest++ },
            onDeleteBookmark = { b ->
                bookmarks.remove(b)
                saveReaderBookmarks(sp, item.id, bookmarks)
            },
            onJumpHighlight = { h ->
                jumpText = h.selectedText
                jumpTextK = sp.getInt("hlk_${h.id}", 0)
                jumpOffset = -1
                jumpChapter = h.chapterIndex
                showSettings = false; showHighlights = false
            },
            onJumpBookmark = { b ->
                jumpText = null
                jumpChapter = b.pos.toInt(); jumpOffset = b.off
                showSettings = false; showHighlights = false
            },
            chapters = chapterNames,
            currentChapter = livePos.toInt(),
            onGoChapter = { idx ->
                jumpText = null; jumpChapter = idx; jumpOffset = -1
                showSettings = false; showHighlights = false
            },
            onJumpChapter = { idx ->
                jumpText = null; jumpChapter = idx; jumpOffset = -1
                showSettings = false; showHighlights = false
            },
            canJump = isEpub,
            panel = when {
                showSettings -> ReaderPanel.SETTINGS
                showHighlights -> ReaderPanel.NOTES
                else -> ReaderPanel.NONE
            },
            onPanelChange = { p ->
                showSettings = p == ReaderPanel.SETTINGS
                showHighlights = p == ReaderPanel.NOTES
            },
            buttonsVisible = showChrome
        )

        // ── Separador de página: tarjeta con la portada ───────────────────────
        if (item.bookmarkStyle == "COVER") {
            BookmarkDivider(item)
        }
    }

    // Contenido / avance para formatos sin TOC propio (PDF, TXT, CBZ…)
    if (showContents && item.format.lowercase() != "epub") {
        ModalBottomSheet(
            onDismissRequest = { showContents = false },
            containerColor = Panel
        ) {
            Column(
                Modifier
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 24.dp)
            ) {
                Text("AVANCE", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(Modifier.height(10.dp))
                GoldProgressBar(liveProgress / 100f, height = 10.dp)
                Text(
                    "${liveProgress}% leído",
                    color = Cream, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp)
                )
                if (liveChapterLabel.isNotBlank()) {
                    Text(liveChapterLabel, color = Muted, fontSize = 12.sp)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "En EPUB verás aquí la lista de capítulos. En este formato el avance se guarda por posición de lectura.",
                    color = Muted, fontSize = 12.sp, lineHeight = 18.sp
                )
            }
        }
    }

    // ── Diálogo de edición de nota ────────────────────────────────────────────
    editingHighlight?.let { h ->
        HighlightEditDialog(
            highlight = h,
            onSave = { updated ->
                scope.launch { highlightDao.update(updated) }
                editingHighlight = null
            },
            onDismiss = { editingHighlight = null }
        )
    }
}

// (El panel de ajustes y el de anotaciones viven ahora en ReaderPanels.kt)

/** Imagen del libro a pantalla completa: pellizca para acercar, doble toque para ampliar/restablecer. */
/** Barra de lectura en dorado vivo: degradado ámbar → oro claro, extremos redondeados y animada. */
@Composable
fun GoldProgressBar(progress: Float, modifier: Modifier = Modifier, height: androidx.compose.ui.unit.Dp = 8.dp) {
    val shape = RoundedCornerShape(50)
    val p by androidx.compose.animation.core.animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = androidx.compose.animation.core.tween(350),
        label = "readProgress"
    )
    Box(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(shape)
            .background(GoldTrack)
    ) {
        if (p > 0f) {
            Box(
                Modifier
                    .fillMaxWidth(p.coerceAtLeast(0.02f))
                    .fillMaxHeight()
                    .clip(shape)
                    .background(
                        androidx.compose.ui.graphics.Brush.horizontalGradient(
                            listOf(GoldDeep, GoldBright, GoldLight)
                        )
                    )
            )
        }
    }
}

@Composable
fun BookmarkDivider(item: LibraryItem) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(48.dp)
            .background(Panel)
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BookCover(item, Modifier.size(width = 25.dp, height = 36.dp))
        Spacer(Modifier.width(10.dp))
        Text("Continuarás aquí", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.weight(1f))
        LibIcon(LibIconKind.BOOKMARK, tint = Gold, size = 20.dp, filled = true)
    }
}

/** Marcapáginas de tela: rectángulo rojo con muesca en V y un hilo dorado en el centro. */
@Composable
fun BookmarkRibbon(modifier: Modifier = Modifier) {
    Canvas(modifier.size(width = 26.dp, height = 78.dp)) {
        val w = size.width
        val h = size.height
        val path = Path().apply {
            moveTo(0f, 0f)
            lineTo(w, 0f)
            lineTo(w, h)
            lineTo(w / 2f, h - w * 0.6f)
            lineTo(0f, h)
            close()
        }
        drawPath(path, Color(0xFFB3322F))
        drawRect(Color(0x33FFFFFF), topLeft = Offset(w * 0.12f, 0f), size = Size(w * 0.14f, h - w * 0.7f))
        drawRect(Gold, topLeft = Offset(w * 0.46f, 0f), size = Size(w * 0.08f, h - w * 0.65f))
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// HELPERS COMUNES
// ══════════════════════════════════════════════════════════════════════════════

@Composable
private fun Message(text: String) {
    Box(Modifier.fillMaxSize().padding(28.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Cream, fontSize = 15.sp, lineHeight = 22.sp, textAlign = TextAlign.Center)
    }
}

/**
 * Detecta el deslizamiento horizontal acumulando el recorrido completo del dedo
 * (comparar solo el delta de cada evento casi nunca llega al umbral).
 */
@Composable
private fun Modifier.pageSwipe(onNext: () -> Unit, onPrev: () -> Unit): Modifier {
    val next by rememberUpdatedState(onNext)
    val prev by rememberUpdatedState(onPrev)
    return pointerInput(Unit) {
        var total = 0f
        detectHorizontalDragGestures(
            onDragStart = { total = 0f },
            onDragEnd = { if (total < -80f) next() else if (total > 80f) prev() },
            onDragCancel = { total = 0f }
        ) { _, amount -> total += amount }
    }
}

/** Cambio de página de los lectores no-EPUB: directo, sin animaciones (la hoja de libro es del lector EPUB). */
@Composable
private fun <T> PagedContent(
    state: T,
    goingForward: Boolean,
    pageTurnStyle: String = "slide",
    modifier: Modifier = Modifier,
    content: @Composable (T) -> Unit
) {
    Box(modifier) { content(state) }
}

// ══════════════════════════════════════════════════════════════════════════════
// EPUB — páginas reales: el capítulo se reparte en columnas del ancho de la pantalla
// y cada «hoja» es una columna (un solo WebView por capítulo, sin recargar).
// ══════════════════════════════════════════════════════════════════════════════

/** Preferencias de lectura en memoria (se aplican a EPUB/TXT) */
data class ReadingPrefs(
    val themeMode: Int = 2,       // 0 oscuro, 1 sepia, 2 blanco, 3 negro
    val fontSizeSp: Int = 18,
    val lineHeight: Float = 1.65f, // interlineado generoso como página de libro
    val marginDp: Int = 28,        // márgenes laterales amplios (captura de referencia)
    val brightness: Float = 1f,   // 0.3 .. 1.0
    val fontFamily: String = "serif",  // serif | sans | classic
    // Nuevas opciones inspiradas en el lector de referencia
    val pageTurnStyle: String = "slide", // slide | fade | curl | none | scroll
    val orientation: String = "auto",    // auto | portrait | landscape
    val showNavButtons: Boolean = false, // por defecto solo el número de página, como en la captura
    val leftHanded: Boolean = false,     // voltear con mano izquierda
    val justify: Boolean = true,         // texto justificado (si no, alineado a la izquierda)
    val indent: Boolean = true           // sangría en la primera línea de cada párrafo
)

/** Lee un TXT: UTF-8 si es válido; si no, Windows-1252/Latin-1 (típico de archivos viejos en español). */
internal fun readTextSmart(file: File): String {
    val bytes = file.readBytes()
    return try {
        Charsets.UTF_8.newDecoder()
            .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
            .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
            .decode(java.nio.ByteBuffer.wrap(bytes)).toString().removePrefix("\uFEFF")
    } catch (_: Exception) {
        String(bytes, charset("windows-1252"))
    }
}

internal fun themeBgColor(mode: Int): Int = when (mode) {
    0 -> 0xFF0B1426.toInt()
    1 -> 0xFFF4ECD8.toInt()
    3 -> 0xFF000000.toInt()
    else -> 0xFFFFFFFF.toInt()
}

private class PdfHolder(file: File) {
    private val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(pfd)
    private val mutex = Mutex()
    val pageCount: Int = renderer.pageCount

    suspend fun render(index: Int, width: Int): Bitmap = mutex.withLock {
        withContext(Dispatchers.IO) {
            val page = renderer.openPage(index)
            try {
                val height = (width.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(android.graphics.Color.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                bmp
            } finally { page.close() }
        }
    }

    fun close() {
        runCatching { renderer.close() }
        runCatching { pfd.close() }
    }
}

@Composable
private fun PdfReader(
    item: LibraryItem,
    onSave: (Long, Int) -> Unit,
    readingMode: String,
    highlightDao: HighlightDao,
    onUpdateItem: (LibraryItem) -> Unit
) {
    val holder = remember(item.id) { runCatching { PdfHolder(File(item.localPath)) }.getOrNull() }
    DisposableEffect(holder) { onDispose { holder?.close() } }
    if (holder == null || holder.pageCount == 0) {
        Message("No se pudo abrir este PDF.")
        return
    }

    var index by remember(item.id) {
        mutableIntStateOf(item.lastPosition.toInt().coerceIn(0, holder.pageCount - 1))
    }
    var goingForward by remember { mutableStateOf(true) }
    LaunchedEffect(index) { onSave(index.toLong(), (index + 1) * 100 / holder.pageCount) }

    Column(Modifier.fillMaxSize()) {
        BoxWithConstraints(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .pageSwipe(
                    onNext = { if (index < holder.pageCount - 1) { goingForward = true; index++ } },
                    onPrev = { if (index > 0) { goingForward = false; index-- } }
                )
        ) {
            val widthPx = constraints.maxWidth.coerceAtLeast(1)
            PagedContent(state = index, goingForward = goingForward, modifier = Modifier.fillMaxSize()) { pg ->
                val bitmap by produceState<Bitmap?>(null, pg, widthPx) {
                    value = try { holder.render(pg, widthPx) } catch (_: Exception) { null }
                }
                bitmap?.let {
                    Image(
                        bitmap = it.asImageBitmap(),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                } ?: Box(Modifier.fillMaxSize().background(Panel))
            }
        }
        Row(
            Modifier.fillMaxWidth().background(Panel).padding(4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            LibIconButton(LibIconKind.CHEVRON_LEFT, onClick = { if (index > 0) { goingForward = false; index-- } }, tint = Gold)
            Text("${index + 1} / ${holder.pageCount}", color = Muted, fontSize = 12.sp)
            LibIconButton(LibIconKind.CHEVRON_RIGHT, onClick = { if (index < holder.pageCount - 1) { goingForward = true; index++ } }, tint = Gold)
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// TXT / FB2
// ══════════════════════════════════════════════════════════════════════════════

@Composable
private fun CbzReader(
    item: LibraryItem,
    onSave: (Long, Int) -> Unit,
    readingMode: String
) {
    val zip = remember(item.id) { runCatching { ZipFile(File(item.localPath)) }.getOrNull() }
    DisposableEffect(zip) { onDispose { runCatching { zip?.close() } } }
    if (zip == null) { Message("No se pudo abrir este CBZ."); return }

    val pages = remember(zip) {
        zip.entries().toList()
            .filter { !it.isDirectory && it.name.substringAfterLast('.').lowercase() in IMAGE_EXTENSIONS }
            .sortedBy { naturalKey(it.name) }
            .map { it.name }
    }
    if (pages.isEmpty()) { Message("Este CBZ no contiene imágenes."); return }

    var index by remember(item.id) {
        mutableIntStateOf(item.lastPosition.toInt().coerceIn(0, pages.lastIndex))
    }
    var goingForward by remember { mutableStateOf(true) }
    LaunchedEffect(index) { onSave(index.toLong(), (index + 1) * 100 / pages.size) }

    Column(Modifier.fillMaxSize()) {
        BoxWithConstraints(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .pageSwipe(
                    onNext = { if (index < pages.lastIndex) { goingForward = true; index++ } },
                    onPrev = { if (index > 0) { goingForward = false; index-- } }
                )
        ) {
            val widthPx = constraints.maxWidth.coerceAtLeast(1)
            PagedContent(state = index, goingForward = goingForward, modifier = Modifier.fillMaxSize()) { pg ->
                val bitmap by produceState<Bitmap?>(null, pages[pg], widthPx) {
                    value = withContext(Dispatchers.IO) {
                        try {
                            val entry = zip.getEntry(pages[pg])
                            val bytes = zip.getInputStream(entry).use { it.readBytes() }
                            decodeSampled(bytes, widthPx)
                        } catch (_: Exception) { null }
                    }
                }
                bitmap?.let {
                    Image(
                        bitmap = it.asImageBitmap(),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                } ?: Box(Modifier.fillMaxSize().background(Panel))
            }
        }
        Row(
            Modifier.fillMaxWidth().background(Panel).padding(4.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            LibIconButton(LibIconKind.CHEVRON_LEFT, onClick = { if (index > 0) { goingForward = false; index-- } }, tint = Gold)
            Text("${index + 1} / ${pages.size}", color = Muted, fontSize = 12.sp)
            LibIconButton(LibIconKind.CHEVRON_RIGHT, onClick = { if (index < pages.lastIndex) { goingForward = true; index++ } }, tint = Gold)
        }
    }
}

