package com.libra.reader

import android.util.Log
import kotlin.math.max

// ══════════════════════════════════════════════════════════════════════════════
// ÍNDICE Y PROGRESO DEL LIBRO
//   · TocEntry  = entrada del índice tal como la declara el libro (capítulo del spine + ancla)
//   · TocTarget = la misma entrada ya resuelta a una posición exacta (capítulo, carácter)
//   · ProgressModel = peso de cada capítulo para calcular el % de avance
// Todo lo que falla (ancla, capítulo o imagen inexistente) se registra y se omite: nunca salta en silencio.
// ══════════════════════════════════════════════════════════════════════════════

internal const val READER_TAG = "LibellumReader"

internal fun readerLog(msg: String) {
    runCatching { Log.w(READER_TAG, msg) }
}

/** Entrada del índice según el libro: índice de capítulo en el spine, ancla opcional y nivel de anidación. */
internal class TocEntry(val title: String, val chapter: Int, val anchor: String?, val level: Int)

/** Entrada resuelta: posición exacta (capítulo + desplazamiento de carácter dentro del capítulo). */
internal class TocTarget(val title: String, val chapter: Int, val offset: Int, val level: Int)

internal object TocResolver {

    /**
     * Convierte las entradas del índice en destinos exactos y las ordena en el orden REAL de lectura
     * (capítulo del spine, después posición dentro del capítulo), sin importar cómo las ordene el nav/ncx.
     */
    fun resolve(entries: List<TocEntry>, chapterCount: Int, docOf: (Int) -> ChapterDoc?): List<TocTarget> {
        val raw = ArrayList<TocTarget>()
        for (e in entries) {
            if (e.chapter !in 0 until chapterCount) {
                readerLog("índice: «${e.title}» apunta al capítulo ${e.chapter}, fuera del libro; se omite")
                continue
            }
            var offset = 0
            if (!e.anchor.isNullOrEmpty()) {
                val doc = docOf(e.chapter)
                val o = doc?.anchors?.get(e.anchor)
                if (o == null) {
                    readerLog("índice: ancla «${e.anchor}» de «${e.title}» no existe en el capítulo ${e.chapter}; se abre al inicio")
                } else {
                    offset = o.coerceIn(0, max((doc?.plain?.length ?: 1) - 1, 0))
                }
            }
            raw.add(TocTarget(e.title, e.chapter, offset, e.level))
        }
        val sorted = raw.withIndex()
            .sortedWith(compareBy({ it.value.chapter }, { it.value.offset }, { it.index }))
            .map { it.value }
        val out = ArrayList<TocTarget>()
        for (t in sorted) {
            val p = out.lastOrNull()
            if (p != null && p.chapter == t.chapter && p.offset == t.offset && p.title == t.title) continue
            out.add(t)
        }
        return out
    }

    /** Índice de respaldo (libros sin nav/ncx útil): un destino por capítulo del spine que tenga contenido. */
    fun fromSpine(chapterCount: Int, docOf: (Int) -> ChapterDoc?, titleOf: (Int) -> String): List<TocTarget> {
        val out = ArrayList<TocTarget>()
        var n = 0
        for (i in 0 until chapterCount) {
            val doc = docOf(i) ?: continue
            if (doc.blocks.isEmpty()) continue            // portadillas en blanco, separadores vacíos…
            n++
            val head = doc.blocks.firstOrNull { it is TextBlock && it.kind != BlockKind.PARAGRAPH } as? TextBlock
            val title = titleOf(i).ifBlank { head?.text?.toString()?.replace('\n', ' ')?.take(80).orEmpty() }
                .ifBlank { "Sección $n" }
            out.add(TocTarget(title, i, 0, 0))
        }
        return out
    }

    /** Índice de la última entrada alcanzada en (chapter, offset), o -1 si aún no se llega a la primera. */
    fun activeIndex(targets: List<TocTarget>, chapter: Int, offset: Int): Int {
        var idx = -1
        for (i in targets.indices) {
            val t = targets[i]
            if (t.chapter < chapter || (t.chapter == chapter && t.offset <= offset)) idx = i else break
        }
        return idx
    }
}

/**
 * Peso de cada capítulo para el % de avance: texto + un peso fijo por imagen (una ilustración ocupa
 * una página aunque no tenga texto) y un mínimo, para que capítulos cortos, poemas o láminas no
 * hagan «saltar» la barra ni queden con peso casi cero.
 */
internal object ProgressModel {
    const val IMAGE_WEIGHT = 900.0
    const val MIN_WEIGHT = 250.0
    const val DEFAULT_WEIGHT = 1500.0

    fun weightOf(doc: ChapterDoc): Double {
        val images = doc.blocks.count { it is ImageBlock }
        return max(doc.plain.length.toDouble() + images * IMAGE_WEIGHT, MIN_WEIGHT)
    }
}
