package com.libra.reader

import android.content.SharedPreferences

/**
 * ÚNICO criterio para saber qué libro se está leyendo «ahora».
 *
 * Orden: el libro con actividad más reciente primero. La actividad es la mayor de:
 *   · lastOpenedAt  → se actualiza al abrir el lector, en cada guardado de página y al cerrarlo (Room),
 *   · book_last_at_ → fin de la última sesión cronometrada (SharedPreferences «libra_reading_stats»),
 *   · startedAt     → respaldo para libros antiguos sin ninguna de las dos.
 * Así «Leyendo ahora» (Panel), «Continuar leyendo» (Biblioteca) y el carrusel salen de la misma lista.
 */
internal object ReadingNow {

    fun lastActivity(book: LibraryItem, stats: SharedPreferences): Long =
        maxOf(book.lastOpenedAt, stats.getLong("book_last_at_${book.id}", 0L), book.startedAt)

    /** Libros en curso, el más reciente primero (empates: el empezado antes del mismo instante no importa, se mantiene el orden de la biblioteca). */
    fun ordered(books: List<LibraryItem>, stats: SharedPreferences): List<LibraryItem> =
        books.filter { it.statusKey() == "READING" }
            .sortedByDescending { lastActivity(it, stats) }

    fun current(books: List<LibraryItem>, stats: SharedPreferences): LibraryItem? =
        ordered(books, stats).firstOrNull()
}
