package com.libra.reader

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import kotlinx.coroutines.delay
import java.util.Locale

// ══════════════════════════════════════════════════════════════════════════════
// AUDIOLIBROS — diseño «papel dorado»
// ══════════════════════════════════════════════════════════════════════════════

/** Tiempo escuchado por día y última vez que sonó cada audiolibro. */
internal object AudioStats {
    private const val PREFS = "libra_audio_stats"

    private fun p(ctx: Context) = ctx.getSharedPreferences(PREFS, 0)

    fun add(ctx: Context, ms: Long, bookId: String?) {
        val prefs = p(ctx)
        val key = "day_${Streak.key()}"
        val ed = prefs.edit().putLong(key, prefs.getLong(key, 0L) + ms)
        if (bookId != null) ed.putLong("last_$bookId", System.currentTimeMillis())
        ed.apply()
    }

    fun dayMs(ctx: Context, dateKey: String): Long = p(ctx).getLong("day_$dateKey", 0L)

    fun lastAt(ctx: Context, id: String): Long = p(ctx).getLong("last_$id", 0L)

    fun totalMs(ctx: Context): Long =
        p(ctx).all.entries.filter { it.key.startsWith("day_") }.sumOf { (it.value as? Long) ?: 0L }

    fun listenDays(ctx: Context): Set<String> =
        p(ctx).all.entries
            .filter { it.key.startsWith("day_") && ((it.value as? Long) ?: 0L) > 0L }
            .map { it.key.removePrefix("day_") }
            .toSet()
}

private class AudioLive {
    var playing by mutableStateOf(false)
    var mediaId by mutableStateOf<String?>(null)
    var pos by mutableLongStateOf(0L)
    var dur by mutableLongStateOf(0L)
    var speed by mutableFloatStateOf(1f)
}

@Composable
private fun rememberAudioLive(c: MediaController?): AudioLive {
    val live = remember { AudioLive() }
    DisposableEffect(c) {
        if (c == null) return@DisposableEffect onDispose { }
        fun sync() {
            live.playing = c.isPlaying
            live.mediaId = c.currentMediaItem?.mediaId
            live.speed = c.playbackParameters.speed
            live.dur = c.duration.coerceAtLeast(0L)
            live.pos = c.currentPosition
        }
        sync()
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { sync() }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { sync() }
            override fun onPlaybackStateChanged(playbackState: Int) { sync() }
            override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) { sync() }
        }
        c.addListener(listener)
        onDispose { c.removeListener(listener) }
    }
    LaunchedEffect(c) {
        while (true) {
            if (c != null) {
                live.pos = c.currentPosition
                val d = c.duration
                if (d > 0L) live.dur = d
            }
            delay(500)
        }
    }
    return live
}

private data class AudioCat(val name: String, val icon: LbIconKind, val keys: List<String>)

private val AUDIO_CATS = listOf(
    AudioCat("Fantasía", LbIconKind.CAT_FANTASY, listOf("fantas")),
    AudioCat("Drama", LbIconKind.CAT_DRAMA, listOf("drama")),
    AudioCat("Desarrollo personal", LbIconKind.CAT_LEAF, listOf("desarrollo", "autoayuda", "superaci", "personal")),
    AudioCat("Historia", LbIconKind.CAT_HISTORY, listOf("histor")),
    AudioCat("Aventura", LbIconKind.CAT_ADVENTURE, listOf("aventur")),
    AudioCat("Suspenso", LbIconKind.CAT_SUSPENSE, listOf("suspens", "thriller", "misterio", "terror")),
    AudioCat("Romance", LbIconKind.CAT_ROMANCE, listOf("romanc", "romántic", "romantic")),
    AudioCat("Ciencia Ficción", LbIconKind.CAT_SCIFI, listOf("ciencia", "sci"))
)

private fun matchesCat(genre: String, cat: String): Boolean {
    val keys = AUDIO_CATS.firstOrNull { it.name == cat }?.keys ?: return false
    val g = genre.lowercase()
    return keys.any { g.contains(it) }
}

private val SPEED_STEPS = listOf(0.75f, 1f, 1.25f, 1.5f, 2f)

@Composable
fun AudioScreen(
    audio: List<LibraryItem>,
    controller: MediaController?,
    onOpen: (LibraryItem) -> Unit,
    onDetail: (LibraryItem) -> Unit,
    onDelete: (LibraryItem) -> Unit,
    onToggleFavorite: (LibraryItem) -> Unit,
    onImport: () -> Unit
) {
    val ctx = LocalContext.current
    val live = rememberAudioLive(controller)
    var category by rememberPrefString("ui_audio_cat", "")
    var showAll by remember { mutableStateOf(false) }
    var detailsDialog by remember { mutableStateOf(false) }
    var achievementsDialog by remember { mutableStateOf(false) }

    // Se refresca cada pocos segundos mientras escuchas
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) { delay(5000); tick++ }
    }
    val week = remember { Streak.weekKeys(0) }
    val weekValues = remember(tick) { week.map { AudioStats.dayMs(ctx, it.second) } }
    val totalMs = remember(tick) { AudioStats.totalMs(ctx) }
    val streakDays = remember(tick) { Streak.current(AudioStats.listenDays(ctx)) }
    val finished = audio.count { it.statusKey() == "FINISHED" }
    val todayIdx = week.indexOfFirst { it.second == Streak.key() }.coerceAtLeast(0)
    var selectedDay by remember { mutableIntStateOf(todayIdx) }

    val nowItem: LibraryItem? = audio.firstOrNull { it.id == live.mediaId }
        ?: audio.maxByOrNull { AudioStats.lastAt(ctx, it.id) }?.takeIf { AudioStats.lastAt(ctx, it.id) > 0L }
        ?: audio.firstOrNull { it.statusKey() == "READING" }
        ?: audio.firstOrNull()

    val inProgress = audio.filter { it.statusKey() == "READING" }
        .sortedByDescending { AudioStats.lastAt(ctx, it.id) }
    val base = if (category.isNotEmpty()) audio.filter { matchesCat(it.genre, category) }
    else inProgress.ifEmpty { audio.filter { it.statusKey() != "FINISHED" } }
    val shown = if (showAll || category.isNotEmpty()) base else base.take(3)

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 18.dp)
    ) {
        item {
            HeroHeader(
                art = R.drawable.hero_audio,
                title = "Audiolibros",
                sub = "Escucha historias donde\nquieras que estés.",
                quote = "Un gran libro también\nsuena increíble.",
                titleSize = 36,
                subSize = 17
            )
        }

        // ── En reproducción ──
        item {
            if (nowItem == null) {
                LbCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), padding = 16.dp) {
                    Text(
                        "Tus audiolibros comienzan aquí", color = LbTitle, fontSize = 18.sp,
                        fontWeight = FontWeight.Bold, fontFamily = LibellumSerif, fontStyle = FontStyle.Italic
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Importa MP3, M4A, M4B, AAC, OGG, OPUS, WAV o FLAC. Libellum recuerda por dónde ibas y sigue sonando con la pantalla apagada.",
                        color = LbText, fontSize = 13.sp, lineHeight = 19.sp
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = onImport, modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = LbBrown, contentColor = Color(0xFFFDF1DC))
                    ) { Text("Importar audiolibros", fontSize = 14.sp) }
                }
            } else {
                NowPlayingCard(
                    item = nowItem, audio = audio, live = live, controller = controller,
                    onOpen = onOpen, onDetail = onDetail, onDelete = onDelete,
                    onToggleFavorite = onToggleFavorite,
                    modifier = Modifier.padding(horizontal = 18.dp)
                )
            }
        }

        // ── Tiempo escuchado esta semana ──
        item {
            LbCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), padding = 12.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LibIcon(LibIconKind.AUDIO, tint = LbBrown, accent = LbBrown, size = 38.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            "Tiempo escuchado esta semana", color = LbText, fontSize = 13.sp,
                            fontFamily = LibellumSerif, maxLines = 1
                        )
                        Text(
                            formatReadingTime(weekValues.sum()), color = LbTitle, fontSize = 26.sp,
                            fontWeight = FontWeight.Bold, fontFamily = LibellumSerif,
                            fontStyle = FontStyle.Italic, maxLines = 1
                        )
                    }
                    LbLink("Ver detalles") { detailsDialog = true }
                }
                WeekBarsChart(
                    labels = week.map { it.first },
                    values = weekValues,
                    selected = -1,
                    onSelect = { selectedDay = it; detailsDialog = true },
                    valueText = { formatReadingTime(it) }
                )
            }
        }

        // ── Continúa escuchando / categoría ──
        item {
            LbSectionHeader(
                if (category.isEmpty()) "Continúa escuchando" else category,
                icon = { LbIcon(LbIconKind.CLOCK, size = 26.dp) },
                modifier = Modifier.padding(horizontal = 18.dp),
                trailing = {
                    if (category.isNotEmpty()) LbLink("Quitar filtro") { category = "" }
                    else if (base.size > 3) LbLink(if (showAll) "Ver menos" else "Ver todos") { showAll = !showAll }
                }
            )
        }
        item {
            LbCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), padding = 0.dp) {
                if (shown.isEmpty()) {
                    Text(
                        if (audio.isEmpty()) "Cuando importes audiolibros aparecerán aquí."
                        else if (category.isNotEmpty()) "No hay audiolibros de este género. Asigna el género en la ficha del audiolibro (⋮ → Editar ficha)."
                        else "No tienes audiolibros en curso.",
                        color = LbMuted, fontSize = 13.sp, lineHeight = 19.sp,
                        modifier = Modifier.padding(16.dp)
                    )
                } else {
                    shown.forEachIndexed { i, b ->
                        if (i > 0) Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp).height(1.dp).background(LbCardEdge))
                        ContinueRow(b, live, controller, onOpen, onDetail, onDelete)
                    }
                }
            }
        }

        // ── Explora por categorías ──
        item {
            LbSectionHeader(
                "Explora por categorías",
                icon = { LbIcon(LbIconKind.SPARKLE, size = 26.dp) },
                modifier = Modifier.padding(horizontal = 18.dp)
            )
        }
        item {
            Column(
                Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AUDIO_CATS.chunked(4).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { cat ->
                            val sel = category == cat.name
                            val fg = if (sel) Color(0xFFFDF1DC) else LbBrown
                            Column(
                                Modifier.weight(1f).height(78.dp)
                                    .shadow(2.dp, RoundedCornerShape(14.dp), ambientColor = Color(0x22805020), spotColor = Color(0x22805020))
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (sel) LbBrown else Color(0xFFFBF0DC))
                                    .border(1.dp, if (sel) LbBrown else LbCardEdge, RoundedCornerShape(14.dp))
                                    .clickable { category = if (sel) "" else cat.name; showAll = false }
                                    .padding(horizontal = 4.dp, vertical = 8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                LbIcon(cat.icon, tint = fg, size = 28.dp, filled = cat.icon == LbIconKind.CAT_ROMANCE)
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    cat.name, color = if (sel) Color(0xFFFDF1DC) else LbText, fontSize = 11.sp,
                                    fontFamily = LibellumSerif, textAlign = TextAlign.Center,
                                    maxLines = 2, lineHeight = 13.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // ── Tus logros de escucha ──
        item {
            LbSectionHeader(
                "Tus logros de escucha",
                icon = { LbIcon(LbIconKind.BADGE, size = 26.dp) },
                trailing = { LbLink("Ver todos") { achievementsDialog = true } },
                modifier = Modifier.padding(horizontal = 18.dp)
            )
        }
        item {
            LbCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), padding = 12.dp) {
                val hours = totalMs / 3_600_000.0
                val (hv, hl) = when {
                    hours >= 10 -> hours.toInt().toString() to "horas escuchadas"
                    hours >= 1 -> String.format(Locale("es"), "%.1f", hours) to "horas escuchadas"
                    else -> (totalMs / 60_000L).toString() to "min escuchados"
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    StatCell(Modifier.weight(1f), { LibIcon(LibIconKind.AUDIO, tint = LbBrown, accent = LbBrown, size = 32.dp) }, hv, hl)
                    Box(Modifier.width(1.dp).height(76.dp).background(LbCardEdge))
                    StatCell(Modifier.weight(1f), { LbIcon(LbIconKind.TROPHY, size = 32.dp) }, finished.toString(), "libros finalizados")
                    Box(Modifier.width(1.dp).height(76.dp).background(LbCardEdge))
                    StatCell(Modifier.weight(1f), { LbIcon(LbIconKind.FLAME, size = 32.dp) }, streakDays.toString(), "días consecutivos")
                }
            }
        }
    }

    // ── Detalles de la semana ──
    if (detailsDialog) {
        val total = weekValues.sum()
        val best = weekValues.indices.maxByOrNull { weekValues[it] } ?: 0
        AlertDialog(
            onDismissRequest = { detailsDialog = false },
            containerColor = LbBg,
            title = { Text("Esta semana", color = LbTitle, fontFamily = LibellumSerif, fontStyle = FontStyle.Italic) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    val names = listOf("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo")
                    weekValues.forEachIndexed { i, v ->
                        Row(Modifier.fillMaxWidth()) {
                            Text(
                                names[i], color = LbText, fontSize = 14.sp, modifier = Modifier.weight(1f),
                                fontWeight = if (i == selectedDay) FontWeight.Bold else FontWeight.Normal
                            )
                            Text(
                                formatReadingTime(v), color = LbTitle, fontSize = 14.sp,
                                fontWeight = if (i == selectedDay) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(LbCardEdge))
                    Text("Total: ${formatReadingTime(total)}", color = LbTitle, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("Media diaria: ${formatReadingTime(total / 7)}", color = LbText, fontSize = 13.sp)
                    if (total > 0L) Text("Tu mejor día: ${names[best]}", color = LbText, fontSize = 13.sp)
                }
            },
            confirmButton = { TextButton(onClick = { detailsDialog = false }) { Text("Cerrar", color = LbBrown) } }
        )
    }

    // ── Logros ──
    if (achievementsDialog) {
        val hours = totalMs / 3_600_000.0
        val milestones = listOf(
            Triple("Primera hora escuchada", hours >= 1, "${minOf(hours, 1.0).let { (it * 100).toInt() }}%"),
            Triple("10 horas escuchadas", hours >= 10, "${minOf(hours / 10.0, 1.0).let { (it * 100).toInt() }}%"),
            Triple("50 horas escuchadas", hours >= 50, "${minOf(hours / 50.0, 1.0).let { (it * 100).toInt() }}%"),
            Triple("100 horas escuchadas", hours >= 100, "${minOf(hours / 100.0, 1.0).let { (it * 100).toInt() }}%"),
            Triple("Primer audiolibro terminado", finished >= 1, "$finished/1"),
            Triple("5 audiolibros terminados", finished >= 5, "${minOf(finished, 5)}/5"),
            Triple("3 días seguidos escuchando", streakDays >= 3, "${minOf(streakDays, 3)}/3"),
            Triple("7 días seguidos escuchando", streakDays >= 7, "${minOf(streakDays, 7)}/7"),
            Triple("30 días seguidos escuchando", streakDays >= 30, "${minOf(streakDays, 30)}/30")
        )
        AlertDialog(
            onDismissRequest = { achievementsDialog = false },
            containerColor = LbBg,
            title = { Text("Tus logros de escucha", color = LbTitle, fontFamily = LibellumSerif, fontStyle = FontStyle.Italic) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    milestones.forEach { (name, done, prog) ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(22.dp).clip(CircleShape)
                                    .background(if (done) LbBrown else Color.Transparent)
                                    .border(1.3.dp, if (done) LbBrown else LbLine, CircleShape),
                                contentAlignment = Alignment.Center
                            ) { if (done) LbIcon(LbIconKind.CHECK, tint = Color(0xFFFDF1DC), size = 12.dp) }
                            Spacer(Modifier.width(10.dp))
                            Text(name, color = LbText, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            Text(if (done) "¡Logrado!" else prog, color = if (done) LbBrown else LbMuted, fontSize = 12.sp)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { achievementsDialog = false }) { Text("Cerrar", color = LbBrown) } }
        )
    }
}

@Composable
private fun StatCell(modifier: Modifier, icon: @Composable () -> Unit, value: String, label: String) {
    Column(modifier.padding(horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        icon()
        Spacer(Modifier.height(4.dp))
        LbFitText(value, color = LbTitle, maxSize = 22.sp, minSize = 15.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        LbFitText(label, color = LbMuted, maxSize = 11.sp, minSize = 8.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun NowPlayingCard(
    item: LibraryItem,
    audio: List<LibraryItem>,
    live: AudioLive,
    controller: MediaController?,
    onOpen: (LibraryItem) -> Unit,
    onDetail: (LibraryItem) -> Unit,
    onDelete: (LibraryItem) -> Unit,
    onToggleFavorite: (LibraryItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val isCurrent = live.mediaId == item.id
    val pos = if (isCurrent) live.pos else item.lastPosition
    val dur = if (isCurrent && live.dur > 0L) live.dur else item.durationMs
    val playing = isCurrent && live.playing
    var dragFrac by remember(item.id) { mutableStateOf<Float?>(null) }
    var menu by remember { mutableStateOf(false) }
    val frac = dragFrac ?: if (dur > 0L) (pos.toFloat() / dur.toFloat()).coerceIn(0f, 1f) else 0f
    val shownPos = if (dragFrac != null && dur > 0L) (dragFrac!! * dur).toLong() else pos

    fun ensureLoaded(c: MediaController) = startAudio(c, item, play = false)

    Box(modifier.fillMaxWidth()) {
        LbCard(Modifier.fillMaxWidth(), padding = 14.dp) {
            Row {
                BookCover(
                    item,
                    Modifier.size(width = 96.dp, height = 138.dp)
                        .shadow(5.dp, RoundedCornerShape(6.dp)).clip(RoundedCornerShape(6.dp))
                )
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LibIcon(LibIconKind.AUDIO, tint = LbBrown, accent = LbBrown, size = 20.dp)
                        Spacer(Modifier.width(6.dp))
                        Text(
                            if (playing) "En reproducción" else if (isCurrent) "En pausa" else "Último que escuchaste",
                            color = LbBrownLight, fontSize = 13.sp, fontFamily = LibellumSerif,
                            fontStyle = FontStyle.Italic, maxLines = 1
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        item.title, color = LbTitle, fontSize = 23.sp, fontWeight = FontWeight.Bold,
                        fontFamily = LibellumSerif, fontStyle = FontStyle.Italic, lineHeight = 26.sp,
                        maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(end = 26.dp)
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            item.author, color = LbText, fontSize = 14.sp, fontFamily = LibellumSerif,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                        )
                        Box {
                            Box(
                                Modifier.size(32.dp).clip(CircleShape).clickable { menu = true },
                                contentAlignment = Alignment.Center
                            ) { LbIcon(LbIconKind.DOTS_H, tint = LbText, size = 20.dp) }
                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                DropdownMenuItem(text = { Text("Abrir reproductor") }, onClick = { menu = false; onOpen(item) })
                                DropdownMenuItem(text = { Text("Editar ficha") }, onClick = { menu = false; onDetail(item) })
                                DropdownMenuItem(text = { Text("Eliminar") }, onClick = { menu = false; onDelete(item) })
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            Slider(
                value = frac,
                onValueChange = { dragFrac = it },
                onValueChangeFinished = {
                    val f = dragFrac
                    val c = controller
                    if (f != null && c != null && dur > 0L) {
                        ensureLoaded(c)
                        c.seekTo((f * dur).toLong())
                    }
                    dragFrac = null
                },
                colors = SliderDefaults.colors(
                    thumbColor = LbBrown, activeTrackColor = LbBrown, inactiveTrackColor = LbTrack
                )
            )
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
                Text(formatAudioTime(shownPos), color = LbText, fontSize = 12.sp, modifier = Modifier.weight(1f))
                Text("-" + formatAudioTime((dur - shownPos).coerceAtLeast(0L)), color = LbText, fontSize = 12.sp)
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                // Al azar: pone a sonar otro audiolibro
                Box(
                    Modifier.size(40.dp).clip(CircleShape).clickable {
                        val c = controller
                        val other = audio.filter { it.id != item.id && it.statusKey() != "FINISHED" }.randomOrNull()
                        if (c != null && other != null) startAudio(c, other)
                    },
                    contentAlignment = Alignment.Center
                ) { LbIcon(LbIconKind.SHUFFLE, tint = LbBrown, size = 24.dp) }
                SeekCircle(LibIconKind.REPLAY) {
                    val c = controller
                    if (c != null) {
                        ensureLoaded(c)
                        c.seekTo((c.currentPosition - 15_000L).coerceAtLeast(0L))
                    }
                }
                Box(
                    Modifier.size(66.dp)
                        .shadow(4.dp, CircleShape, ambientColor = Color(0x33805020), spotColor = Color(0x55805020))
                        .clip(CircleShape).background(LbBrown)
                        .alpha(if (controller == null) 0.5f else 1f)
                        .clickable {
                            val c = controller
                            if (c != null) {
                                if (isCurrent) { if (c.isPlaying) c.pause() else c.play() }
                                else startAudio(c, item)
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    LibIcon(
                        if (playing) LibIconKind.PAUSE else LibIconKind.PLAY,
                        tint = Color(0xFFFDF1DC), size = 30.dp
                    )
                }
                SeekCircle(LibIconKind.FORWARD) {
                    val c = controller
                    if (c != null) {
                        ensureLoaded(c)
                        val d = c.duration
                        val t = c.currentPosition + 15_000L
                        c.seekTo(if (d > 0L) minOf(t, d) else t)
                    }
                }
                val speed = if (isCurrent) live.speed else 1f
                Text(
                    String.format(Locale.US, "%.1fx", speed), color = LbBrown, fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold, fontFamily = LibellumSerif,
                    modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable {
                        val c = controller
                        if (c != null) {
                            ensureLoaded(c)
                            val cur = c.playbackParameters.speed
                            val i = SPEED_STEPS.indexOfFirst { it == cur }
                            c.setPlaybackSpeed(SPEED_STEPS[(if (i < 0) 1 else i + 1) % SPEED_STEPS.size])
                        }
                    }.padding(horizontal = 6.dp, vertical = 8.dp)
                )
            }
        }
        RibbonMark(
            Modifier.align(Alignment.TopEnd).padding(end = 28.dp),
            on = item.isFavorite == 1,
            onClick = { onToggleFavorite(item) }
        )
    }
}

/** Botón de ±15 s con el número en el centro. */
@Composable
private fun SeekCircle(kind: LibIconKind, onClick: () -> Unit) {
    Box(Modifier.size(44.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        LibIcon(kind, tint = LbBrown, accent = LbBrown, size = 34.dp)
        Text("15", color = LbBrown, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ContinueRow(
    b: LibraryItem,
    live: AudioLive,
    controller: MediaController?,
    onOpen: (LibraryItem) -> Unit,
    onDetail: (LibraryItem) -> Unit,
    onDelete: (LibraryItem) -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    val isCurrent = live.mediaId == b.id
    val playing = isCurrent && live.playing
    Row(
        Modifier.fillMaxWidth().clickable { onOpen(b) }.padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BookCover(b, Modifier.size(width = 52.dp, height = 66.dp).clip(RoundedCornerShape(6.dp)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                b.title, color = LbTitle, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                fontFamily = LibellumSerif, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(b.author, color = LbMuted, fontSize = 12.sp, fontFamily = LibellumSerif, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                LbProgress(b.progressFraction(), Modifier.weight(1f), height = 5.dp)
                Spacer(Modifier.width(6.dp))
                Text(b.progressText(" escuchado"), color = LbMuted, fontSize = 10.sp, maxLines = 1, softWrap = false)
            }
        }
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier.size(42.dp).clip(CircleShape).background(LbBrown)
                .alpha(if (controller == null) 0.5f else 1f)
                .clickable {
                    val c = controller
                    if (c != null) {
                        if (isCurrent) { if (c.isPlaying) c.pause() else c.play() }
                        else startAudio(c, b)
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            LibIcon(if (playing) LibIconKind.PAUSE else LibIconKind.PLAY, tint = Color(0xFFFDF1DC), size = 22.dp)
        }
        Box {
            Box(Modifier.size(32.dp).clip(CircleShape).clickable { menu = true }, contentAlignment = Alignment.Center) {
                LbIcon(LbIconKind.DOTS_V, tint = LbText, size = 20.dp)
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Abrir reproductor") }, onClick = { menu = false; onOpen(b) })
                DropdownMenuItem(text = { Text("Editar ficha") }, onClick = { menu = false; onDetail(b) })
                DropdownMenuItem(text = { Text("Eliminar") }, onClick = { menu = false; onDelete(b) })
            }
        }
    }
}
