package com.libra.reader

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

// Iconos de «Notas y Citas» dibujados a mano (trazo fino sobre rejilla 24×24, como los demás Lb*).

internal enum class NoteGlyph { FEATHER, BOOKMARK, SAVE, STAR, EDIT, COPY, TRASH, SEARCH, CAROUSEL, LIST, JUMP, CLOSE, SHARE }

@Composable
internal fun NoteIcon(
    kind: NoteGlyph,
    modifier: Modifier = Modifier,
    tint: Color = LbBrown,
    size: Dp = 24.dp,
    filled: Boolean = false
) {
    Canvas(modifier.size(size)) {
        val u = this.size.minDimension / 24f
        val st = Stroke(width = 1.7f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun p(x: Float, y: Float) = Offset(x * u, y * u)
        when (kind) {
            NoteGlyph.BOOKMARK -> {
                val path = Path().apply {
                    moveTo(6.5f * u, 3f * u); lineTo(17.5f * u, 3f * u); lineTo(17.5f * u, 21f * u)
                    lineTo(12f * u, 16.8f * u); lineTo(6.5f * u, 21f * u); close()
                }
                if (filled) drawPath(path, tint)
                drawPath(path, tint, style = st)
            }
            NoteGlyph.STAR -> {
                val path = Path()
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) 9.5f else 4.3f
                    val a = Math.toRadians((-90.0 + i * 36.0))
                    val x = (12f + r * cos(a).toFloat()) * u
                    val y = (12.8f + r * sin(a).toFloat()) * u
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
                if (filled) drawPath(path, tint)
                drawPath(path, tint, style = st)
            }
            NoteGlyph.SAVE -> {
                drawRoundRect(tint, p(4f, 4f), Size(16f * u, 16f * u), CornerRadius(2.5f * u), style = st)
                drawRect(tint, p(8f, 4f), Size(7f * u, 5f * u), style = st)
                drawRoundRect(tint, p(7f, 13f), Size(10f * u, 7f * u), CornerRadius(1f * u), style = st)
            }
            NoteGlyph.FEATHER -> {
                val path = Path().apply {
                    moveTo(5f * u, 18.5f * u)
                    cubicTo(5.5f * u, 10.5f * u, 11f * u, 5f * u, 20f * u, 3.8f * u)
                    cubicTo(19.5f * u, 11f * u, 14.5f * u, 16.5f * u, 8f * u, 17.6f * u)
                }
                drawPath(path, tint, style = st)
                drawLine(tint, p(5f, 18.5f), p(14.5f, 9.5f), strokeWidth = 1.7f * u, cap = StrokeCap.Round)
                drawLine(tint, p(3.5f, 21.5f), p(12f, 21.5f), strokeWidth = 1.7f * u, cap = StrokeCap.Round)
            }
            NoteGlyph.EDIT -> {
                val path = Path().apply {
                    moveTo(4f * u, 20f * u); lineTo(5f * u, 15.5f * u); lineTo(15.5f * u, 5f * u)
                    lineTo(19f * u, 8.5f * u); lineTo(8.5f * u, 19f * u); close()
                }
                drawPath(path, tint, style = st)
                drawLine(tint, p(13.5f, 7f), p(17f, 10.5f), strokeWidth = 1.7f * u, cap = StrokeCap.Round)
            }
            NoteGlyph.COPY -> {
                drawRoundRect(tint, p(9f, 9f), Size(11f * u, 11f * u), CornerRadius(2f * u), style = st)
                val back = Path().apply {
                    moveTo(15f * u, 5f * u); lineTo(6f * u, 5f * u)
                    quadraticBezierTo(4f * u, 5f * u, 4f * u, 7f * u); lineTo(4f * u, 16f * u)
                }
                drawPath(back, tint, style = st)
            }
            NoteGlyph.SEARCH -> {
                drawCircle(tint, radius = 6f * u, center = p(10.5f, 10.5f), style = st)
                drawLine(tint, p(15f, 15f), p(20f, 20f), strokeWidth = 1.7f * u, cap = StrokeCap.Round)
            }
            NoteGlyph.CAROUSEL -> {
                drawRoundRect(tint, p(7f, 5f), Size(10f * u, 14f * u), CornerRadius(2f * u), style = st)
                drawLine(tint, p(3.5f, 8f), p(3.5f, 16f), strokeWidth = 1.7f * u, cap = StrokeCap.Round)
                drawLine(tint, p(20.5f, 8f), p(20.5f, 16f), strokeWidth = 1.7f * u, cap = StrokeCap.Round)
            }
            NoteGlyph.LIST -> {
                for (y in listOf(7f, 12f, 17f)) {
                    drawLine(tint, p(9f, y), p(20f, y), strokeWidth = 1.7f * u, cap = StrokeCap.Round)
                    drawCircle(tint, radius = 1.2f * u, center = p(4.5f, y))
                }
            }
            NoteGlyph.JUMP -> {   // «ir al texto»: flecha hacia una línea
                drawLine(tint, p(5f, 12f), p(17f, 12f), strokeWidth = 1.7f * u, cap = StrokeCap.Round)
                val head = Path().apply { moveTo(12f * u, 6.5f * u); lineTo(17.5f * u, 12f * u); lineTo(12f * u, 17.5f * u) }
                drawPath(head, tint, style = st)
                drawLine(tint, p(20.5f, 5f), p(20.5f, 19f), strokeWidth = 1.7f * u, cap = StrokeCap.Round)
            }
            NoteGlyph.CLOSE -> {
                drawLine(tint, p(6f, 6f), p(18f, 18f), strokeWidth = 1.9f * u, cap = StrokeCap.Round)
                drawLine(tint, p(18f, 6f), p(6f, 18f), strokeWidth = 1.9f * u, cap = StrokeCap.Round)
            }
            NoteGlyph.SHARE -> {
                drawCircle(tint, radius = 2.7f * u, center = p(18f, 5.5f), style = st)
                drawCircle(tint, radius = 2.7f * u, center = p(6f, 12f), style = st)
                drawCircle(tint, radius = 2.7f * u, center = p(18f, 18.5f), style = st)
                drawLine(tint, p(8.3f, 10.8f), p(15.7f, 6.7f), strokeWidth = 1.7f * u, cap = StrokeCap.Round)
                drawLine(tint, p(8.3f, 13.2f), p(15.7f, 17.3f), strokeWidth = 1.7f * u, cap = StrokeCap.Round)
            }
            NoteGlyph.TRASH -> {
                drawLine(tint, p(4f, 7f), p(20f, 7f), strokeWidth = 1.7f * u, cap = StrokeCap.Round)
                val lid = Path().apply { moveTo(9f * u, 7f * u); lineTo(9f * u, 4.5f * u); lineTo(15f * u, 4.5f * u); lineTo(15f * u, 7f * u) }
                drawPath(lid, tint, style = st)
                val body = Path().apply { moveTo(6f * u, 7f * u); lineTo(7f * u, 20f * u); lineTo(17f * u, 20f * u); lineTo(18f * u, 7f * u) }
                drawPath(body, tint, style = st)
                drawLine(tint, p(10f, 11f), p(10f, 16f), strokeWidth = 1.5f * u, cap = StrokeCap.Round)
                drawLine(tint, p(14f, 11f), p(14f, 16f), strokeWidth = 1.5f * u, cap = StrokeCap.Round)
            }
        }
    }
}

/** Ramita botánica discreta para las esquinas de la tarjeta (se puede voltear con [flip]). */
@Composable
internal fun LeafSprig(
    modifier: Modifier = Modifier,
    flip: Boolean = false,
    color: Color = Color(0xFFC9964A)
) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        withTransform({ if (flip) scale(-1f, 1f, Offset(w / 2f, h / 2f)) }) {
            val cx = w * 0.35f
            val cy = h * 0.55f
            val stem = Path().apply {
                moveTo(0f, h); quadraticBezierTo(cx, cy, w * 0.96f, h * 0.04f)
            }
            drawPath(stem, color.copy(alpha = 0.8f), style = Stroke(width = 1.2.dp.toPx(), cap = StrokeCap.Round))
            val n = 5
            for (i in 1..n) {
                val t = i / (n + 1f)
                val x = 2f * (1f - t) * t * cx + t * t * w * 0.96f
                val y = (1f - t) * (1f - t) * h + 2f * (1f - t) * t * cy + t * t * h * 0.04f
                leaf(Offset(x, y), -92f, w * 0.27f, color)
                leaf(Offset(x, y), -8f, w * 0.27f, color)
            }
        }
    }
}

private fun DrawScope.leaf(at: Offset, angle: Float, len: Float, color: Color) {
    rotate(angle, at) {
        val wid = len * 0.34f
        val path = Path().apply {
            moveTo(at.x, at.y)
            quadraticBezierTo(at.x + len * 0.5f, at.y - wid, at.x + len, at.y)
            quadraticBezierTo(at.x + len * 0.5f, at.y + wid, at.x, at.y)
            close()
        }
        drawPath(path, color.copy(alpha = 0.55f))
    }
}
