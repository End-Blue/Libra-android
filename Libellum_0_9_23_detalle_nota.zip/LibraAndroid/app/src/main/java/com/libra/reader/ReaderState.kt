package com.libra.reader

import android.graphics.Bitmap
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.max

// ══════════════════════════════════════════════════════════════════════════════
// ESTADO ÚNICO DEL LECTOR
//   ReaderStateHolder = dueño de la posición (capítulo, hoja, desplazamiento) y de las páginas
//   que se están mostrando. ReaderUiState = «foto» inmutable derivada de él (y del motor)
//   que usan la cabecera, el panel de contenido, el guardado y el % de avance.
// ══════════════════════════════════════════════════════════════════════════════

@Immutable
internal data class ReaderUiState(
    val chapter: Int,        // capítulo del spine (orden real de lectura)
    val chapterCount: Int,
    val page: Int,           // hoja dentro del capítulo (0-based)
    val pageCount: Int,
    val offset: Int,         // carácter exacto al inicio de la hoja
    val progress: Float,     // 0..1 de TODO el libro
    val tocIndex: Int,       // entrada activa del índice (-1 = antes de la primera)
    val tocTitle: String,
    val tocNumber: Int,      // 1-based, 0 si no hay entrada activa
    val tocCount: Int
) {
    val progressPct: Int get() = (progress * 100f).toInt().coerceIn(0, 100)
}

@Stable
internal class ReaderStateHolder(startChapter: Int, startOffset: Int) {
    var chapter by mutableIntStateOf(startChapter)
    var anchor by mutableIntStateOf(startOffset)
    var pageNo by mutableIntStateOf(0)
    var pages by mutableStateOf<ChapterPages?>(null)

    /** Clave de composición (tamaño, tipografía…) con la que se calcularon [pages]. */
    var pagesKey by mutableStateOf<String?>(null)
    var bitmap by mutableStateOf<Bitmap?>(null)

    val page: PageSpec? get() = pages?.pages?.getOrNull(pageNo)

    /** Las páginas mostradas pertenecen a la composición actual (si no, hay una repaginación en curso). */
    fun isFresh(cfgKey: String): Boolean = pages != null && pagesKey == cfgKey

    /** Último carácter «visible» de la hoja: sirve para saber qué entrada del índice está activa. */
    fun probeOffset(): Int {
        val p = page ?: return anchor
        return max(p.start, p.end - 1)
    }

    fun snapshot(eng: ReaderEngine, toc: List<TocTarget>, chapterCount: Int): ReaderUiState {
        val pg = page
        val off = pg?.start ?: anchor
        val idx = TocResolver.activeIndex(toc, chapter, probeOffset())
        val t = toc.getOrNull(idx)
        return ReaderUiState(
            chapter = chapter, chapterCount = chapterCount,
            page = pageNo, pageCount = pages?.pages?.size ?: 1,
            offset = off, progress = eng.fraction(chapter, off),
            tocIndex = idx, tocTitle = t?.title.orEmpty(),
            tocNumber = if (idx >= 0) idx + 1 else 0, tocCount = toc.size
        )
    }
}
