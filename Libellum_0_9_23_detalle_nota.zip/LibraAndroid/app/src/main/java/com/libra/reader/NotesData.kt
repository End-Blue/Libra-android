package com.libra.reader

import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * Nota o cita escrita a mano en «Notas y Citas» (independiente de los subrayados del lector).
 * Puede o no estar asociada a un libro; guarda el título por si el libro se borra después.
 */
@Entity(tableName = "quote_notes")
data class QuoteNote(
    @PrimaryKey val id: String,
    val text: String,
    @ColumnInfo(defaultValue = "''") val bookId: String = "",
    @ColumnInfo(defaultValue = "''") val bookTitle: String = "",
    @ColumnInfo(defaultValue = "0") val isFavorite: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface QuoteNoteDao {
    @Query("SELECT * FROM quote_notes ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<QuoteNote>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(note: QuoteNote)

    @Query("UPDATE quote_notes SET text = :text WHERE id = :id")
    suspend fun updateText(id: String, text: String)

    @Query("UPDATE quote_notes SET isFavorite = :fav WHERE id = :id")
    suspend fun setFavorite(id: String, fav: Int)

    @Query("UPDATE quote_notes SET bookId = :bookId, bookTitle = :bookTitle WHERE id = :id")
    suspend fun setBook(id: String, bookId: String, bookTitle: String)

    @Query("DELETE FROM quote_notes WHERE id = :id")
    suspend fun deleteById(id: String)
}
