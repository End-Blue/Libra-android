package com.libra.reader

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar
import kotlin.math.ceil

// ══════════════════════════════════════════════════════════════════════════════
// RETO DE LECTURA — diseño «papel dorado»
// ══════════════════════════════════════════════════════════════════════════════

private val MONTHS_ES = listOf("Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic")

@Composable
fun ChallengeScreen(books: List<LibraryItem>, goal: Int, onGoal: (Int) -> Unit) {
    val now = Calendar.getInstance()
    val year = now.get(Calendar.YEAR)
    val month = now.get(Calendar.MONTH)

    // Libros terminados este año (si no tienen fecha, cuentan igualmente)
    val finishedThisYear = books.filter { b ->
        b.statusKey() == "FINISHED" && (b.finishedAt == 0L ||
            Calendar.getInstance().apply { timeInMillis = b.finishedAt }.get(Calendar.YEAR) == year)
    }
    val done = finishedThisYear.size
    val frac = (done.toFloat() / goal.coerceAtLeast(1)).coerceIn(0f, 1f)
    val pct = Math.round(frac * 100f)
    val perMonth = IntArray(12)
    finishedThisYear.forEach { b ->
        if (b.finishedAt > 0L) {
            perMonth[Calendar.getInstance().apply { timeInMillis = b.finishedAt }.get(Calendar.MONTH)]++
        }
    }
    val monthlyTarget = ceil(goal / 12.0).toInt().coerceAtLeast(1)
    var milestonesDialog by remember { mutableStateOf(false) }

    val remaining = (goal - done).coerceAtLeast(0)
    val monthsLeft = (12 - month).coerceAtLeast(1)
    val daysLeft = (now.getActualMaximum(Calendar.DAY_OF_YEAR) - now.get(Calendar.DAY_OF_YEAR) + 1).coerceAtLeast(1)
    val booksPerMonth = ceil(remaining / monthsLeft.toDouble()).toInt().coerceAtLeast(1)
    val pagesPerDay = ceil(remaining * 320.0 / daysLeft).toInt().coerceAtLeast(1)
    val milestones = listOf(25, 50, 75, 100).map { p -> p to ceil(goal * p / 100.0).toInt().coerceAtLeast(1) }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 6.dp)
    ) {
        item {
            HeroHeader(
                art = R.drawable.hero_challenge,
                title = "Reto de lectura $year",
                sub = "Cada libro te acerca\na una mejor versión de ti.",
                quote = "Un año. Muchas historias.\nUn gran tú.",
                titleSize = 28,
                subSize = 16
            )
        }

        // ── Anillo de progreso ──
        item {
            LbCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), padding = 0.dp) {
                Box(Modifier.fillMaxWidth()) {
                    Laurel(Modifier.align(Alignment.BottomStart).padding(start = 2.dp, bottom = 4.dp), flip = false, scale = 1.3f)
                    Laurel(Modifier.align(Alignment.BottomEnd).padding(end = 2.dp, bottom = 4.dp), flip = true, scale = 1.3f)
                    Laurel(Modifier.align(Alignment.TopStart).padding(top = 6.dp), flip = false, scale = 0.55f)
                    Laurel(Modifier.align(Alignment.TopEnd).padding(top = 6.dp), flip = true, scale = 0.55f)
                    Column(Modifier.fillMaxWidth().padding(vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.size(206.dp), contentAlignment = Alignment.Center) {
                            Canvas(Modifier.fillMaxSize()) {
                                val stroke = 14.dp.toPx()
                                val arcSize = Size(this.size.width - stroke, this.size.height - stroke)
                                val topLeft = Offset(stroke / 2f, stroke / 2f)
                                drawArc(
                                    Color(0xFFE2D4BB), -90f, 360f, false, topLeft, arcSize,
                                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                                )
                                if (frac > 0f) {
                                    drawArc(
                                        Brush.sweepGradient(listOf(LbBrownLight, LbBrown, LbBrownLight)),
                                        -90f, 360f * frac, false, topLeft, arcSize,
                                        style = Stroke(width = stroke, cap = StrokeCap.Round)
                                    )
                                }
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                LbIcon(LbIconKind.BOOK_OPEN, size = 44.dp)
                                Text(
                                    "$done / $goal", color = LbTitle, fontSize = 40.sp, fontWeight = FontWeight.Bold,
                                    fontFamily = LibellumSerif, fontStyle = FontStyle.Italic, maxLines = 1
                                )
                                Text("libros", color = LbText, fontSize = 16.sp, fontFamily = LibellumSerif)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text("$pct% completado", color = LbText, fontSize = 15.sp, fontFamily = LibellumSerif, fontStyle = FontStyle.Italic)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            if (done >= goal) "¡Reto cumplido!\nPuedes subir tu meta con el +."
                            else "Te faltan $remaining ${if (remaining == 1) "libro" else "libros"}\npara alcanzar tu meta.",
                            color = LbTitle, fontSize = 15.sp, fontFamily = LibellumSerif,
                            textAlign = TextAlign.Center, lineHeight = 20.sp,
                            modifier = Modifier.padding(horizontal = 56.dp)
                        )
                    }
                }
            }
        }

        // ── Mi meta del año ──
        item {
            Column(Modifier.padding(horizontal = 18.dp)) {
                LbSectionHeader("Mi meta del año", icon = { LbIcon(LbIconKind.TARGET, size = 26.dp) })
                Spacer(Modifier.height(10.dp))
                LbCard(Modifier.fillMaxWidth(), padding = 12.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LbRoundButton(onClick = { onGoal(goal - 1) }, diameter = 48.dp) {
                            LbIcon(LbIconKind.MINUS, tint = LbBrown, size = 24.dp)
                        }
                        Text(
                            "$goal ${if (goal == 1) "libro" else "libros"}", color = LbTitle, fontSize = 24.sp,
                            fontWeight = FontWeight.SemiBold, fontFamily = LibellumSerif,
                            textAlign = TextAlign.Center, modifier = Modifier.weight(1f)
                        )
                        LbRoundButton(onClick = { onGoal(goal + 1) }, diameter = 48.dp) {
                            LbIcon(LbIconKind.PLUS, tint = LbBrown, size = 24.dp)
                        }
                    }
                }
            }
        }

        // ── Progreso por meses ──
        item {
            Column(Modifier.padding(horizontal = 18.dp)) {
                LbSectionHeader(
                    "Progreso por meses",
                    icon = { LbIcon(LbIconKind.CALENDAR, size = 26.dp) },
                    trailing = {
                        Text("$year", color = LbMuted, fontSize = 15.sp, fontFamily = LibellumSerif)
                    }
                )
                Spacer(Modifier.height(10.dp))
                LbCard(Modifier.fillMaxWidth(), padding = 10.dp) {
                    for (row in 0 until 2) {
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                            for (col in 0 until 6) {
                                val m = row * 6 + col
                                val n = perMonth[m]
                                val ok = n >= monthlyTarget
                                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        MONTHS_ES[m], color = if (m == month) LbBrown else LbText, fontSize = 13.sp,
                                        fontFamily = LibellumSerif,
                                        fontWeight = if (m == month) FontWeight.Bold else FontWeight.Normal
                                    )
                                    Text("$n/$monthlyTarget", color = LbMuted, fontSize = 12.sp, fontFamily = LibellumSerif)
                                    Spacer(Modifier.height(4.dp))
                                    Box(
                                        Modifier.size(22.dp).clip(CircleShape)
                                            .background(if (ok) LbBrown else Color.Transparent)
                                            .border(1.5.dp, if (ok || n > 0) LbBrown else LbLine, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (ok) LbIcon(LbIconKind.CHECK, tint = Color(0xFFFDF1DC), size = 13.dp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ── Hitos del reto ──
        item {
            LbSectionHeader(
                "Hitos del reto",
                icon = { LbIcon(LbIconKind.BADGE, size = 26.dp) },
                trailing = { LbLink("Ver todos") { milestonesDialog = true } },
                modifier = Modifier.padding(horizontal = 18.dp)
            )
        }
        item {
            Row(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                milestones.forEachIndexed { i, (p, count) ->
                    val reached = done >= count
                    val shape = RoundedCornerShape(16.dp)
                    Column(
                        Modifier.weight(1f)
                            .shadow(2.dp, shape, ambientColor = Color(0x22805020), spotColor = Color(0x22805020))
                            .clip(shape)
                            .background(Brush.verticalGradient(listOf(LbCardTop, LbCardBottom)))
                            .border(1.dp, LbCardEdge, shape)
                            .padding(vertical = 10.dp, horizontal = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        LbMedal(
                            if (i == 0) MedalTone.BRONZE else if (i < 3) MedalTone.SILVER else MedalTone.GOLD,
                            locked = !reached, diameter = 46.dp
                        )
                        Spacer(Modifier.height(4.dp))
                        Text("$p%", color = LbTitle, fontSize = 15.sp, fontWeight = FontWeight.Bold, fontFamily = LibellumSerif)
                        Text(
                            "$count ${if (count == 1) "libro" else "libros"}", color = LbMuted, fontSize = 11.sp,
                            fontFamily = LibellumSerif, maxLines = 1
                        )
                    }
                }
            }
        }

        // ── Consejos ──
        item {
            LbCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), padding = 14.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LbIcon(LbIconKind.BULB, size = 26.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Consejos para lograr tu meta", color = LbTitle, fontSize = 19.sp, fontWeight = FontWeight.Bold,
                        fontFamily = LibellumSerif, maxLines = 1
                    )
                }
                Spacer(Modifier.height(8.dp))
                if (remaining <= 0) {
                    Text(
                        "Ya alcanzaste tu meta de $year. Sube el objetivo con el + para seguir creciendo.",
                        color = LbText, fontSize = 14.sp, fontFamily = LibellumSerif, lineHeight = 20.sp
                    )
                } else {
                    Text(
                        "Para alcanzar tu objetivo, puedes leer:", color = LbText, fontSize = 14.sp,
                        fontFamily = LibellumSerif
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TipPill(Modifier.weight(1f), LbIconKind.BOOK_OPEN, "$booksPerMonth ${if (booksPerMonth == 1) "libro" else "libros"}", "por mes")
                        Box(
                            Modifier.size(28.dp).clip(CircleShape).background(LbBrown),
                            contentAlignment = Alignment.Center
                        ) { Text("o", color = Color(0xFFFDF1DC), fontSize = 14.sp, fontFamily = LibellumSerif) }
                        TipPill(Modifier.weight(1f), LbIconKind.DOC, "$pagesPerDay páginas", "diarias")
                    }
                    Text(
                        "Cálculo estimado con libros de unas 320 páginas.",
                        color = LbMuted, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
        }

        item {
            Image(
                painter = painterResource(R.drawable.reto_footer),
                contentDescription = null,
                contentScale = ContentScale.FillWidth,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }

    if (milestonesDialog) {
        AlertDialog(
            onDismissRequest = { milestonesDialog = false },
            containerColor = LbBg,
            title = { Text("Hitos del reto $year", color = LbTitle, fontFamily = LibellumSerif, fontStyle = FontStyle.Italic) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(10, 25, 50, 75, 100).forEach { p ->
                        val count = ceil(goal * p / 100.0).toInt().coerceAtLeast(1)
                        val ok = done >= count
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(22.dp).clip(CircleShape)
                                    .background(if (ok) LbBrown else Color.Transparent)
                                    .border(1.3.dp, if (ok) LbBrown else LbLine, CircleShape),
                                contentAlignment = Alignment.Center
                            ) { if (ok) LbIcon(LbIconKind.CHECK, tint = Color(0xFFFDF1DC), size = 12.dp) }
                            Spacer(Modifier.width(10.dp))
                            Text("$p% · $count ${if (count == 1) "libro" else "libros"}", color = LbText, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            Text(if (ok) "¡Logrado!" else "${minOf(done, count)}/$count", color = if (ok) LbBrown else LbMuted, fontSize = 12.sp)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { milestonesDialog = false }) { Text("Cerrar", color = LbBrown) } }
        )
    }
}

@Composable
private fun TipPill(modifier: Modifier, icon: LbIconKind, line1: String, line2: String) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier.clip(shape).background(Color(0xFFF6E8D0)).border(1.dp, LbCardEdge, shape)
            .padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        LbIcon(icon, size = 28.dp)
        Spacer(Modifier.width(8.dp))
        Column {
            Text(line1, color = LbTitle, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, fontFamily = LibellumSerif, maxLines = 1)
            Text(line2, color = LbMuted, fontSize = 12.sp, fontFamily = LibellumSerif, maxLines = 1)
        }
    }
}
