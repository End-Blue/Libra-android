# Libellum 0.9.13

## Novedades 0.9.13 — Racha, Resumen, Reto de lectura y Mi biblioteca con el nuevo diseño «papel dorado»
Sin icono de ajustes en estas cuatro pantallas (solo Inicio lo conserva).
- **Tu racha de lectura**: tarjeta con medallón de llama, día(s) consecutivo(s), botón «¡Hoy ya leíste!» (o «Marcar hoy como leído»), estadísticas (mejor racha, días leídos, tiempo total, leídos hoy), calendario con ‹ › por meses (✓ en días leídos, llama en días con 15 min o más) y logros con medallas (Primer día, Primera semana, Primer mes; «Ver todos» añade más).
- **Tu resumen**: tarjeta «Tu biblioteca» con «Ver biblioteca», estado de tus libros (cada casilla abre la biblioteca filtrada), actividad de lectura por día de la semana con selector Esta semana / Este mes / Este año, estadísticas literarias y reparto por género.
- **Reto de lectura**: anillo de progreso, meta del año con − / +, progreso por meses, hitos 25/50/75/100 % con medallas y consejos calculados (libros por mes y páginas diarias).
- **Mi biblioteca**: cabecera ilustrada, buscador y «Filtrar» (hoja con autor, género, formato y valoración), «Continuar leyendo» con progreso, tiempo restante y botón, pestañas Todos/Por leer/Leyendo/Terminados, «Ordenar por», vista de cuadrícula o lista y menú ⋮ en cada libro (Abrir, Ver ficha, Favorito).
- Nuevo: `StreakUi.kt`, `RecapUi.kt`, `ChallengeUi.kt`, `LibraryUi.kt`. Ilustraciones: `hero_streak`, `hero_recap`, `hero_challenge`, `hero_library`, `card_recap`, `card_continue`, `reto_footer` (res/drawable-nodpi; se pueden sustituir por versiones en alta resolución con el mismo nombre).
- Incluye el arreglo de OPDS de la 0.9.12 sin cambios.
