# Libellum 0.9.18 — Se elimina OPDS

- Eliminados `OpdsClient.kt` y `OpdsUi.kt` (catálogos, parser Atom/OPDS, descargas y pantalla «Explorar»).
- Quitada la entrada «Explorar OPDS» del menú Más y su ruta en `MainActivity`.
- `network_security_config.xml`: ya no se permite tráfico HTTP sin cifrar (solo se usaba para catálogos OPDS).
- Se mantiene el permiso INTERNET (diccionario y traducción).
