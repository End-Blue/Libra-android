@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.libra.reader

import android.Manifest
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.zIndex
import androidx.glance.appwidget.updateAll
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    // Libro que pide abrir el widget de la estantería
    private val openRequest = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        openRequest.value = intent?.getStringExtra("open_book_id")
        setContent { LibraApp(openRequest) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        openRequest.value = intent.getStringExtra("open_book_id")
    }
}

@Composable
fun LibraApp(openRequest: MutableState<String?>) {
    val context = LocalContext.current
    val db = remember { LibraryDatabase.get(context) }
    val dao = remember { db.libraryDao() }
    val highlightDao = remember { db.highlightDao() }

    val itemsFlow = remember { dao.observeAll() }
    val highlightsFlow = remember { highlightDao.observeAll() }
    val allItems by itemsFlow.collectAsState(initial = emptyList())
    val allHighlights by highlightsFlow.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    val controller by rememberMediaController()
    PlaybackPersistence(controller, dao)

    val prefs = remember { context.getSharedPreferences("libra_prefs", 0) }
    var showTutorial by remember { mutableStateOf(!prefs.getBoolean("tutorial_done", false)) }

    var selectedTab by remember { mutableStateOf("Panel") }
    var viewMode by remember { mutableStateOf("LISTA") }
    var status by remember { mutableStateOf("Libellum guarda tu biblioteca en este dispositivo.") }
    var busy by remember { mutableStateOf(false) }
    var opened by remember { mutableStateOf<LibraryItem?>(null) }
    var showScanner by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var editingHighlight by remember { mutableStateOf<Highlight?>(null) }
    var days by remember { mutableStateOf(Streak.days(context)) }
    var detailId by remember { mutableStateOf<String?>(null) }
    var showMore by remember { mutableStateOf(false) }
    var goal by remember { mutableIntStateOf(Streak.goal(context)) }

    // El widget pide abrir un libro concreto
    LaunchedEffect(openRequest.value, allItems) {
        val id = openRequest.value
        if (id != null) {
            allItems.firstOrNull { it.id == id }?.let {
                opened = it
                openRequest.value = null
            }
        }
    }
    // Se refresca el widget solo cuando cambia lo que muestra (no en cada página leída)
    val shelfSignature = remember(allItems) {
        allItems.joinToString("|") { it.id + it.isFavorite + it.statusKey() + (it.coverPath ?: "") }
    }
    LaunchedEffect(shelfSignature) { runCatching { ShelfWidget().updateAll(context) } }

    // ── Primera vez: se abre el escáner, que pide el permiso de documentos y detecta los libros solo ──
    var autoScanAsked by remember { mutableStateOf(prefs.getBoolean("auto_scan_asked", false)) }
    LaunchedEffect(showTutorial, autoScanAsked) {
        if (!showTutorial && !autoScanAsked) {
            showScanner = true
            autoScanAsked = true
            prefs.edit().putBoolean("auto_scan_asked", true).apply()
        }
    }

    // ── Lanzadores ────────────────────────────────────────────────────────────
    val bookPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            busy = true; status = "Importando…"
            status = withContext(Dispatchers.IO) {
                importUris(context.contentResolver, context.filesDir, uris, "BOOK", dao)
            }
            busy = false
        }
    }
    val audioPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            busy = true; status = "Importando audio…"
            status = withContext(Dispatchers.IO) {
                importUris(context.contentResolver, context.filesDir, uris, "AUDIO", dao)
            }
            busy = false
        }
    }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) scope.launch {
            busy = true; status = "Creando copia de seguridad…"
            status = Backup.export(context, dao, highlightDao, uri); busy = false
        }
    }
    val restoreLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) scope.launch {
            busy = true; status = "Restaurando copia de seguridad…"
            status = Backup.restore(context, dao, highlightDao, uri); busy = false
        }
    }

    val csvLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) scope.launch {
            busy = true; status = "Exportando CSV…"
            status = exportCsv(context, allItems.filter { it.mediaType == "BOOK" }, uri); busy = false
        }
    }

    // Antes de borrar se pide confirmación (un toque sin querer no debe borrar un libro)
    var pendingDelete by remember { mutableStateOf<LibraryItem?>(null) }
    val onDelete: (LibraryItem) -> Unit = { item -> pendingDelete = item }

    // ── Tutorial ──────────────────────────────────────────────────────────────
    if (showTutorial) {
        TutorialScreen(onFinish = {
            showTutorial = false
            prefs.edit().putBoolean("tutorial_done", true).apply()
        })
        return
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            background = Ink, surface = Panel, primary = Gold,
            onBackground = Cream, onSurface = Cream, onPrimary = Ink,
            surfaceVariant = Panel, onSurfaceVariant = Muted, outline = Line
        )
    ) {
        val current = opened
        if (current != null) {
            if (current.mediaType == "AUDIO") {
                AudioPlayerScreen(current, controller, onClose = { opened = null })
            } else {
                ReaderScreen(
                    item = current,
                    onClose = { opened = null },
                    onSave = { position, progress ->
                        scope.launch {
                            dao.updateProgress(current.id, position, progress)
                            val now = System.currentTimeMillis()
                            if (progress > 0) dao.markStarted(current.id, now)
                            if (progress >= 97) dao.markFinished(current.id, now)
                        }
                        Streak.markToday(context)
                        days = Streak.days(context)
                    },
                    highlightDao = highlightDao,
                    onUpdateItem = { updated -> scope.launch { dao.update(updated) } }
                )
            }
        } else {
            val toggleFav: (LibraryItem) -> Unit = { item ->
                scope.launch { dao.setFavorite(item.id, if (item.isFavorite == 1) 0 else 1) }
            }
            val books = allItems.filter { it.mediaType == "BOOK" }
            val filteredBooks = if (searchQuery.isBlank()) books
            else books.filter {
                it.title.contains(searchQuery, ignoreCase = true) ||
                    it.author.contains(searchQuery, ignoreCase = true)
            }
            // Biblioteca (lista) e Estantería intercambiadas: la pestaña principal abre la estantería
            val navItems = listOf("Panel", "Estantería", "Favoritos", "Racha", "Más")

            Scaffold(
                containerColor = Ink,
                bottomBar = {
                    NavigationBar(containerColor = Panel, contentColor = Cream) {
                        navItems.forEach { tab ->
                            val selected = if (tab == "Más") (showMore || selectedTab !in navItems) else selectedTab == tab
                            val tint = if (selected) Gold else Muted
                            NavigationBarItem(
                                selected = selected,
                                onClick = { if (tab == "Más") showMore = true else selectedTab = tab },
                                icon = {
                                    when (tab) {
                                        "Panel" -> LibIcon(LibIconKind.HOME, tint = tint, size = 24.dp, filled = selected)
                                        "Estantería" -> LibIcon(LibIconKind.SHELF, tint = tint, size = 24.dp, filled = selected)
                                        "Favoritos" -> LibIcon(LibIconKind.STAR, tint = tint, size = 24.dp, filled = selected)
                                        "Racha" -> Text("🔥", fontSize = 20.sp)
                                        else -> LibIcon(LibIconKind.LIST, tint = tint, size = 24.dp, filled = selected)
                                    }
                                },
                                label = { Text(tab, fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Gold, selectedTextColor = Gold,
                                    indicatorColor = Ink, unselectedIconColor = Muted,
                                    unselectedTextColor = Muted
                                )
                            )
                        }
                    }
                }
            ) { padding ->
                Column(
                    Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)
                ) {
                    // Nombre de la app siempre arriba a la izquierda, sin solaparse
                    Spacer(Modifier.height(10.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "LIBELLUM",
                            color = Gold,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 3.sp,
                            maxLines = 1
                        )
                        Spacer(Modifier.weight(1f))
                        if (selectedTab != "Panel") {
                            LibIconButton(LibIconKind.HELP, onClick = { showTutorial = true }, tint = Muted)
                        }
                    }
                    if (selectedTab != "Panel") {
                        Text(
                            when (selectedTab) {
                                "Estantería", "Estanterías", "Biblioteca" ->
                                    if (selectedTab == "Biblioteca") "Tu biblioteca" else "Mis estanterías"
                                "Favoritos" -> "Tus favoritos"
                                "Racha" -> "Racha de lectura"
                                "Notas" -> "Notas y citas"
                                "Audio" -> "Audiolibros"
                                "Reto" -> "Reto de lectura"
                                "Resumen" -> "Tu resumen"
                                else -> "Ajustes"
                            },
                            color = Cream, fontSize = 22.sp, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(8.dp))
                    } else {
                        Spacer(Modifier.height(6.dp))
                    }

                    // Buscador solo en la lista de libros (Biblioteca)
                    if (selectedTab == "Biblioteca") {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Buscar por título o autor…", color = Muted, fontSize = 14.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Cream, unfocusedTextColor = Cream,
                                focusedBorderColor = Gold, unfocusedBorderColor = Line,
                                focusedContainerColor = Panel, unfocusedContainerColor = Panel
                            ),
                            leadingIcon = { LibIcon(LibIconKind.SEARCH, tint = Muted, size = 20.dp) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty())
                                    LibIconButton(LibIconKind.CLOSE, onClick = { searchQuery = "" }, tint = Muted, iconSize = 18.dp)
                            },
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = {})
                        )
                        Spacer(Modifier.height(8.dp))
                    }

                    when (selectedTab) {
                        "Panel" -> DashboardScreen(
                            books = books, days = days, status = status, busy = busy,
                            onMarkToday = { Streak.markToday(context); days = Streak.days(context) },
                            onOpen = { opened = it },
                            onDetail = { detailId = it.id },
                            onImport = { bookPicker.launch(arrayOf("*/*")) },
                            onScan = { showScanner = true }
                        )
                        // Estantería en la pestaña principal (intercambiada con biblioteca)
                        "Estantería", "Estanterías" -> BookshelvesScreen(
                            books = books,
                            freeShelf = { st ->
                                ShelfScreen(
                                    books = books,
                                    onOpen = { detailId = it.id },
                                    onSetPose = { id, pose -> scope.launch { dao.setShelfPose(id, pose) } },
                                    onSetAllPoses = { pose ->
                                        scope.launch {
                                            dao.setAllShelfPoses(pose)
                                            dao.resetShelfPositions()
                                        }
                                    },
                                    onMove = { id, x, y -> scope.launch { dao.updateShelfPosition(id, x, y) } },
                                    onReset = { scope.launch { dao.resetShelfPositions() } },
                                    style = st,
                                    onSpineSize = { id, w, h -> scope.launch { dao.setSpineSize(id, w, h) } }
                                )
                            }
                        )
                        "Biblioteca" -> LibraryScreen2(
                            filteredBooks,
                            onDetail = { detailId = it.id },
                            onToggleFavorite = toggleFav,
                            onImport = { bookPicker.launch(arrayOf("*/*")) },
                            onScan = { showScanner = true }
                        )
                        "Favoritos" -> FavoritesScreen(books, onDetail = { detailId = it.id })
                        "Racha" -> StreakScreen(days, onMarkToday = { Streak.markToday(context); days = Streak.days(context) })
                        "Notas" -> AllHighlightsScreen(
                            highlights = allHighlights,
                            onEdit = { editingHighlight = it },
                            onDelete = { h -> scope.launch { highlightDao.deleteById(h.id) } }
                        )
                        "Audio" -> AudioScreen(
                            allItems.filter { it.mediaType == "AUDIO" },
                            onOpen = { opened = it }, onDelete = onDelete
                        )
                        "Reto" -> ChallengeScreen(books, goal, onGoal = { g ->
                            goal = g.coerceIn(1, 365)
                            Streak.setGoal(context, goal)
                        })
                        "Resumen" -> RecapScreen(books, allHighlights.size, days)
                        else -> SettingsScreen(
                            allItems.size, busy,
                            onExport = {
                                val stamp = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
                                exportLauncher.launch("libra-copia-$stamp.zip")
                            },
                            onImport = {
                                restoreLauncher.launch(arrayOf("application/zip",
                                    "application/octet-stream", "*/*"))
                            },
                            onShowTutorial = { showTutorial = true },
                            onExportCsv = {
                                val stamp = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
                                csvLauncher.launch("libellum-libros-$stamp.csv")
                            }
                        )
                    }
                }
            }

            // ── Menú «Más» ───────────────────────────────────────────────────
            if (showMore) {
                MoreSheet(
                    onPick = { key -> selectedTab = key; showMore = false },
                    onTutorial = { showMore = false; showTutorial = true },
                    onCsv = {
                        showMore = false
                        val stamp = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
                        csvLauncher.launch("libellum-libros-$stamp.csv")
                    },
                    onDismiss = { showMore = false }
                )
            }

            // ── Detalle del libro ────────────────────────────────────────────
            val detailItem = detailId?.let { id -> allItems.firstOrNull { it.id == id } }
            if (detailItem != null) {
                BookDetailSheet(
                    item = detailItem,
                    notesCount = allHighlights.count { it.bookId == detailItem.id },
                    onDismiss = { detailId = null },
                    onRead = { detailId = null; opened = detailItem },
                    onStatus = { st ->
                        scope.launch {
                            val now = System.currentTimeMillis()
                            dao.setStatus(detailItem.id, st)
                            if (st == "READING" || st == "FINISHED") dao.markStarted(detailItem.id, now)
                            if (st == "FINISHED") dao.markFinished(detailItem.id, now)
                        }
                    },
                    onRating = { r -> scope.launch { dao.setRating(detailItem.id, r) } },
                    onGenre = { g -> scope.launch { dao.setGenre(detailItem.id, g) } },
                    onReview = { r -> scope.launch { dao.setReview(detailItem.id, r) } },
                    onFavorite = { toggleFav(detailItem) },
                    onDelete = { detailId = null; pendingDelete = detailItem }
                )
            }
        }
    }

    pendingDelete?.let { item ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            containerColor = Panel,
            title = { Text("¿Quitar de la biblioteca?", color = Cream) },
            text = {
                Text(
                    "«${item.title}» se borrará de Libellum junto con sus notas. " +
                        "El archivo original de tu teléfono no se toca.",
                    color = Muted
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        removeItem(dao, item)
                        highlightDao.deleteByBook(item.id)
                    }
                    pendingDelete = null
                }) { Text("Quitar", color = Gold) }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) { Text("Cancelar", color = Muted) }
            }
        )
    }

    if (showScanner) {
        ScannerDialog(
            context = context,
            onImport = { uris ->
                scope.launch {
                    busy = true; status = "Importando desde escáner…"
                    status = withContext(Dispatchers.IO) {
                        importUris(context.contentResolver, context.filesDir, uris, "BOOK", dao)
                    }
                    busy = false
                }
            },
            onDismiss = { showScanner = false }
        )
    }

    editingHighlight?.let { h ->
        HighlightEditDialog(
            highlight = h,
            onSave = { updated ->
                scope.launch { highlightDao.update(updated) }
                editingHighlight = null
            },
            onDismiss = { editingHighlight = null }
        )
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// PANTALLAS
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun HomeScreen(
    books: List<LibraryItem>,
    onOpen: (LibraryItem) -> Unit,
    onDelete: (LibraryItem) -> Unit,
    onToggleFavorite: (LibraryItem) -> Unit
) {
    if (books.isEmpty()) {
        EmptyFeature("TU BIBLIOTECA COMIENZA AQUÍ",
            "Importa tus archivos EPUB, PDF, TXT, FB2, CBZ o usa el escáner automático. " +
            "Libellum guardará una copia privada en tu dispositivo.")
    } else {
        val favorites = books.filter { it.isFavorite == 1 }
        val rest = books.filter { it.isFavorite == 0 }
        LazyColumn {
            if (favorites.isNotEmpty()) {
                item {
                    Text("FAVORITOS · ${favorites.size}", color = Gold, fontSize = 11.sp,
                        letterSpacing = 1.sp, modifier = Modifier.padding(bottom = 4.dp))
                }
                items(favorites, key = { it.id }) { BookRow(it, onOpen, onDelete, onToggleFavorite) }
                item { Spacer(Modifier.height(12.dp)) }
            }
            item {
                Text("LIBROS · ${rest.size}", color = Gold, fontSize = 11.sp,
                    letterSpacing = 1.sp, modifier = Modifier.padding(bottom = 4.dp))
            }
            items(rest, key = { it.id }) { BookRow(it, onOpen, onDelete, onToggleFavorite) }
        }
    }
}

@Composable
fun LibraryScreen(
    books: List<LibraryItem>,
    viewMode: String,
    onViewModeChange: (String) -> Unit,
    onOpen: (LibraryItem) -> Unit,
    onDelete: (LibraryItem) -> Unit,
    onToggleFavorite: (LibraryItem) -> Unit,
    onSetPose: (String, String) -> Unit,
    onSetAllPoses: (String) -> Unit,
    onMove: (String, Float, Float) -> Unit,
    onResetShelf: () -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("${books.size} libros", color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
        listOf(
            "LISTA" to LibIconKind.LIST,
            "CUADRICULA" to LibIconKind.GRID,
            "ESTANTERIA" to LibIconKind.SHELF
        ).forEach { (mode, kind) ->
            LibIconButton(
                kind, onClick = { onViewModeChange(mode) },
                tint = if (viewMode == mode) Gold else Muted, filled = viewMode == mode
            )
        }
    }
    if (books.isEmpty()) {
        EmptyFeature("AÚN NO HAY LIBROS", "Pulsa «Importar» o «Escanear» para añadir tu colección.")
    } else when (viewMode) {
        "ESTANTERIA" -> ShelfScreen(books, onOpen, onSetPose, onSetAllPoses, onMove, onResetShelf)
        "CUADRICULA" -> LazyColumn {
            items(books.chunked(2)) { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    row.forEach { book ->
                        Column(
                            Modifier.weight(1f).padding(vertical = 8.dp).clickable { onOpen(book) }
                        ) {
                            BookCover(book, Modifier.fillMaxWidth().height(190.dp))
                            Spacer(Modifier.height(6.dp))
                            Text(book.title, color = Cream, fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text("${book.author} · ${book.format}", color = Muted, fontSize = 10.sp,
                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
        else -> LazyColumn {
            items(books, key = { it.id }) { BookRow(it, onOpen, onDelete, onToggleFavorite) }
        }
    }
}

@Composable
fun AudioScreen(audio: List<LibraryItem>, onOpen: (LibraryItem) -> Unit, onDelete: (LibraryItem) -> Unit) {
    if (audio.isEmpty()) {
        EmptyFeature("TUS AUDIOLIBROS",
            "Importa MP3, M4A, M4B, AAC, OGG, OPUS, WAV o FLAC. " +
            "Libellum recuerda por dónde ibas y sigue sonando con la pantalla apagada.")
    } else {
        Text("${audio.size} archivos de audio importados", color = Gold, fontSize = 11.sp)
        LazyColumn {
            items(audio, key = { it.id }) { BookRow(it, onOpen, onDelete, onToggleFavorite = {}) }
        }
    }
}

@Composable
fun SettingsScreen(
    itemCount: Int, busy: Boolean,
    onExport: () -> Unit, onImport: () -> Unit, onShowTutorial: () -> Unit,
    onExportCsv: () -> Unit = {}
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            EmptyFeature("ALMACENAMIENTO LOCAL",
                "Libellum mantiene $itemCount elementos en el almacenamiento privado de la aplicación.")
        }
        item {
            Button(onClick = onExport, enabled = !busy, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)
            ) { Text("Exportar copia de seguridad") }
        }
        item {
            OutlinedButton(onClick = onImport, enabled = !busy, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
            ) { Text("Restaurar desde una copia") }
        }
        item {
            OutlinedButton(onClick = onExportCsv, enabled = !busy, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
            ) { Text("Exportar lista de libros (CSV)") }
        }
        item {
            OutlinedButton(onClick = onShowTutorial, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
            ) {
                LibIcon(LibIconKind.HELP, tint = Gold, size = 18.dp)
                Spacer(Modifier.width(8.dp))
                Text("Ver tutorial de la app")
            }
        }
        item {
            Text("La copia es un archivo .zip con tus libros, audiolibros, portadas, progreso y " +
                "orden de la estantería. Guárdalo en Drive o en la tarjeta y restáuralo en otro teléfono.",
                color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// COMPONENTES REUTILIZABLES
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun EmptyFeature(title: String, description: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text(title, color = Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Text(description, color = Cream, fontSize = 14.sp, lineHeight = 21.sp)
        }
    }
}

@Composable
fun BookRow(
    item: LibraryItem,
    onOpen: (LibraryItem) -> Unit,
    onDelete: (LibraryItem) -> Unit,
    onToggleFavorite: (LibraryItem) -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clickable { onOpen(item) }.padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BookCover(item, Modifier.size(width = 48.dp, height = 66.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(item.title, color = Cream, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text("${item.author} · ${item.format}", color = Muted, fontSize = 11.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (item.progress > 0) {
                Spacer(Modifier.height(5.dp))
                LinearProgressIndicator(
                    progress = { item.progress / 100f },
                    color = Gold, trackColor = Panel,
                    modifier = Modifier.fillMaxWidth().height(3.dp)
                )
            }
        }
        LibIconButton(
            LibIconKind.STAR, onClick = { onToggleFavorite(item) },
            tint = if (item.isFavorite == 1) Gold else Muted, filled = item.isFavorite == 1
        )
        LibIconButton(LibIconKind.TRASH, onClick = { onDelete(item) }, tint = Muted, iconSize = 20.dp)
    }
}

private fun coverColor(title: String): Color {
    val palette = listOf(
        Color(0xFF6B3540), Color(0xFF35564D),
        Color(0xFF43506D), Color(0xFF7A5C3A), Color(0xFF3B3430)
    )
    return palette[abs(title.hashCode()) % palette.size]
}

@Composable
fun BookCover(item: LibraryItem, modifier: Modifier = Modifier, textSize: TextUnit = 10.sp) {
    val cover = remember(item.coverPath) {
        item.coverPath?.let { File(it) }?.takeIf { it.exists() }
    }
    Box(modifier.clip(RoundedCornerShape(7.dp)).background(coverColor(item.title)),
        contentAlignment = Alignment.Center) {
        if (cover != null) {
            AsyncImage(model = cover, contentDescription = item.title,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Text(item.title, color = Color(0xFFF3E6C8), fontSize = textSize, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, maxLines = 6, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(5.dp))
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// ESTANTERÍA: de frente, de pie (lomo), acostado y pila horizontal
// Referencia visual: verticales + pilas tumbadas en la misma balda
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Posturas:
 * - FRONT  → portada de frente
 * - SPINE  → de pie, se ve el lomo
 * - FLAT   → un solo libro tumbado en la balda
 * - STACK  → pila horizontal (varios libros tumbados uno encima de otro = «Pirámide»)
 */
/** Máximo de libros por torre: al llegar al cuarto, la torre se cierra y el siguiente libro inicia otra columna al lado. */
internal const val MAX_STACK_BOOKS = 4

internal fun shelfPose(item: LibraryItem): String = when (item.shelfOrientation) {
    "SPINE" -> "SPINE"
    "FLAT", "ACOSTADO" -> "FLAT"
    "STACK", "LYING", "HORIZONTAL", "PIRAMIDE", "PYRAMID" -> "STACK"
    // Las posturas inclinadas ya no existen: los libros guardados así pasan a estar de pie
    "LEAN", "TILTED", "LADEADO", "INCLINADO" -> "SPINE"
    else -> "FRONT"
}

/**
 * Tamaño visual según postura.
 * - SPINE: ancho = grosor del lomo, alto = altura del libro.
 * - STACK/FLAT: libro tumbado → el alto original pasa a ser la anchura horizontal,
 *   y el grosor del lomo pasa a ser la altura de cada capa de la pila
 *   (proporciones exactas como en la guía de implementación de pilas).
 * En STACK se mantiene un factor de compactación suave para que la torre no crezca
 * demasiado, pero se respeta la proporción del lomo original.
 */
private fun poseSize(book: LibraryItem, pose: String): Pair<Dp, Dp> {
    val customW = book.spineWidthDp
    val customH = book.spineHeightDp
    if (customW > 0 && customH > 0) {
        return when (pose) {
            "SPINE" -> customW.dp to customH.dp
            // width = altura original del libro; height = grosor del lomo (compactado levemente)
            "STACK" -> customH.dp to (customW * 0.72f).toInt().coerceIn(14, 28).dp
            "FLAT" -> customH.dp to (customW * 0.78f).toInt().coerceIn(12, 30).dp
            else -> (customW * 2.4f).toInt().coerceIn(56, 100).dp to customH.dp
        }
    }
    val hScale = 0.88f + (kotlin.math.abs(book.title.hashCode()) % 28) / 100f
    val wScale = 0.85f + (kotlin.math.abs((book.title + book.author).hashCode()) % 35) / 100f
    val baseH = (114 * hScale).toInt().coerceIn(88, 150)
    val baseW = (30 * wScale).toInt().coerceIn(22, 42)
    return when (pose) {
        "SPINE" -> baseW.dp to baseH.dp
        // STACK: width = baseH (largo del libro tumbado), height = grosor del lomo
        "STACK" -> baseH.dp to (baseW * 0.70f).toInt().coerceIn(14, 24).dp
        "FLAT" -> baseH.dp to (baseW * 0.75f).toInt().coerceIn(12, 26).dp
        else -> (baseW * 2.5f).toInt().coerceIn(58, 96).dp to baseH.dp
    }
}

private class ShelfLayout(val slots: Map<String, IntOffset>, val plankTops: List<Int>, val height: Int)

/**
 * Colocación automática realista.
 * Las pilas (STACK) se tratan como unidades independientes:
 * - Si los libros tienen posiciones guardadas (shelfX/Y ≥ 0), se agrupan por proximidad
 *   en X (mismo “hueco” de torre) para que modificar una pila no reordene las demás.
 * - Si no, se agrupan por orden de lista (comportamiento anterior).
 * Cada torre se ancla a la balda (Arrangement.Bottom equivalente): el libro inferior
 * apoya su canto inferior en el tope de la madera; los de encima se apilan sin hueco.
 */
private fun layoutShelf(books: List<LibraryItem>, areaW: Int, density: Density, legacy: Boolean = false): ShelfLayout {
    val gap = with(density) { 5.dp.roundToPx() }
    val padX = with(density) { 10.dp.roundToPx() }
    val plank = with(density) { 12.dp.roundToPx() }
    val topPad = with(density) { 18.dp.roundToPx() }
    val slots = HashMap<String, IntOffset>()
    val plankTops = ArrayList<Int>()

    data class Unit(val members: List<LibraryItem>, val w: Int, val h: Int)
    val units = ArrayList<Unit>()

    val stackBooks = books.filter { shelfPose(it) == "STACK" }
    val nonStack = books.filter { shelfPose(it) != "STACK" }

    // Agrupar STACK por proximidad de X cuando hay posiciones guardadas (aislamiento de torres)
    val used = HashSet<String>()
    val proximityPx = with(density) { 48.dp.roundToPx() }
    for (b in stackBooks) {
        if (b.id in used) continue
        val group = ArrayList<LibraryItem>()
        val bx = if (b.shelfX >= 0f) b.shelfX else -1f
        if (bx >= 0f) {
            // Torre con posiciones: agrupar por cercanía en X
            for (other in stackBooks) {
                if (other.id in used) continue
                val ox = if (other.shelfX >= 0f) other.shelfX else -1f
                val sameLevel = b.shelfY < 0f || other.shelfY < 0f ||
                    abs(b.shelfY - other.shelfY) * density.density < proximityPx * 2.5f
                if (ox >= 0f && sameLevel && abs(bx - ox) * density.density < proximityPx) {
                    group.add(other)
                    used.add(other.id)
                }
            }
        }
        if (group.isEmpty()) {
            // Fallback: agrupar consecutivos del listado original (máx. 6)
            val idx = books.indexOfFirst { it.id == b.id }
            if (idx >= 0) {
                var j = idx
                while (j < books.size && shelfPose(books[j]) == "STACK" && group.size < MAX_STACK_BOOKS) {
                    if (books[j].id !in used) {
                        group.add(books[j])
                        used.add(books[j].id)
                    }
                    j++
                }
            }
            if (group.isEmpty()) {
                group.add(b)
                used.add(b.id)
            }
        }
        // Ordenar de abajo (más anchos) hacia arriba para apilado estable
        val ordered = group.sortedWith(
            compareByDescending<LibraryItem> { poseSize(it, "STACK").first.value }
                .thenBy { it.shelfY }
        )
        // Torres de máximo MAX_STACK_BOOKS libros: lo que sobra forma otra columna al lado
        ordered.chunked(MAX_STACK_BOOKS).forEach { part ->
            val maxW = part.maxOf { with(density) { poseSize(it, "STACK").first.roundToPx() } }
            val sumH = part.sumOf { with(density) { poseSize(it, "STACK").second.roundToPx() } }
            units.add(Unit(part, maxW, sumH))
        }
    }

    for (b in nonStack) {
        val pose = shelfPose(b)
        val (w, h) = poseSize(b, pose)
        units.add(Unit(listOf(b), with(density) { w.roundToPx() }, with(density) { h.roundToPx() }))
    }

    // Mantener un orden determinista: primero unidades con posición guardada (por X), luego el resto
    units.sortBy { u ->
        val first = u.members.firstOrNull()
        when {
            first == null -> 9999f
            first.shelfX >= 0f -> first.shelfX
            else -> 5000f + books.indexOfFirst { it.id == first.id }.toFloat()
        }
    }

    // Altura de balda constante (no depende de las posturas): al tocar una balda, las demás NO se mueven
    val fixedRowH = with(density) {
        val maxSpine = books.maxOfOrNull { poseSize(it, "SPINE").second.roundToPx() } ?: 0
        val maxLayer = books.maxOfOrNull { poseSize(it, "STACK").second.roundToPx() } ?: 0
        maxOf(maxSpine, MAX_STACK_BOOKS * maxLayer, 120.dp.roundToPx())
    }
    var rowTop = topPad
    var cursor = padX
    val row = ArrayList<Unit>()

    fun flush() {
        if (row.isEmpty()) return
        val rowH = if (legacy) row.maxOf { it.h } else maxOf(fixedRowH, row.maxOf { it.h })
        var x = padX
        row.forEach { u ->
            if (u.members.size > 1 || shelfPose(u.members[0]) == "STACK") {
                // Pila horizontal anclada a la balda (equivalente a Arrangement.Bottom)
                var yOff = 0
                // members ya ordenados de abajo hacia arriba conceptualmente; asReversed para dibujar desde base
                u.members.asReversed().forEach { b ->
                    val bh = with(density) { poseSize(b, "STACK").second.roundToPx() }
                    val bw = with(density) { poseSize(b, "STACK").first.roundToPx() }
                    val bx = x + (u.w - bw) / 2
                    // Canto inferior del libro apoyado exactamente sobre el de abajo / la balda
                    slots[b.id] = IntOffset(bx, rowTop + rowH - yOff - bh)
                    yOff += bh
                }
            } else {
                val b = u.members[0]
                slots[b.id] = IntOffset(x, rowTop + rowH - u.h)
            }
            x += u.w + gap
        }
        plankTops.add(rowTop + rowH)
        rowTop += rowH + plank + topPad
        row.clear()
        cursor = padX
    }

    for (u in units) {
        if (cursor + u.w > areaW - padX && row.isNotEmpty()) flush()
        row.add(u)
        cursor += u.w + gap
    }
    flush()
    return ShelfLayout(slots, plankTops, (plankTops.lastOrNull() ?: topPad) + plank + topPad / 2)
}

/**
 * Asigna posturas mixtas realistas a una lista de libros (verticales + torres),
 * como en la imagen de referencia. Devuelve mapa id → pose.
 */
internal fun realisticMixPoses(books: List<LibraryItem>): Map<String, String> {
    if (books.isEmpty()) return emptyMap()
    val result = LinkedHashMap<String, String>()
    var i = 0
    var lastWasTower = false
    while (i < books.size) {
        val roll = kotlin.math.abs((books[i].title + i).hashCode()) % 10
        when {
            // ~30%: empezar una torre de 2–4 libros tumbados (nunca pegada a otra torre)
            roll < 3 && i + 1 < books.size && !lastWasTower -> {
                val n = 2 + (roll % 3) // 2..4
                val take = minOf(n, books.size - i)
                repeat(take) { result[books[i + it].id] = "STACK" }
                i += take
                lastWasTower = true
            }
            // resto: de pie (lomo)
            else -> {
                result[books[i].id] = "SPINE"
                i++
                lastWasTower = false
            }
        }
    }
    return result
}

internal fun Color.shade(f: Float): Color = Color(
    (red * f).coerceIn(0f, 1f), (green * f).coerceIn(0f, 1f), (blue * f).coerceIn(0f, 1f), alpha
)

/** Gira un composable 90° ocupando el espacio girado (para el título del lomo). */
private fun Modifier.rotateVertical(): Modifier = layout { measurable, constraints ->
    val placeable = measurable.measure(Constraints(0, constraints.maxHeight, 0, constraints.maxWidth))
    layout(placeable.height, placeable.width) {
        placeable.placeWithLayer(
            (placeable.height - placeable.width) / 2,
            (placeable.width - placeable.height) / 2
        ) { rotationZ = 90f }
    }
}

private val COLOR_FAMILIES = listOf(
    "Rojo", "Naranja", "Amarillo", "Verde", "Azul", "Morado", "Rosa", "Marrón", "Gris", "Negro", "Blanco"
)

/** Familia de color de un lomo (para poder buscar libros por color). */
private fun colorFamily(c: Color): String {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(c.toArgb(), hsv)
    val h = hsv[0]; val s = hsv[1]; val v = hsv[2]
    return when {
        v < 0.18f -> "Negro"
        s < 0.12f -> if (v > 0.85f) "Blanco" else "Gris"
        h < 15f || h >= 345f -> if (s < 0.4f && v > 0.7f) "Rosa" else "Rojo"
        h < 45f -> if (v < 0.65f) "Marrón" else "Naranja"
        h < 70f -> if (v < 0.55f) "Marrón" else "Amarillo"
        h < 165f -> "Verde"
        h < 255f -> "Azul"
        h < 300f -> "Morado"
        else -> "Rosa"
    }
}

private val spineColorCache = HashMap<String, Color>()

private fun averageColor(path: String): Color? {
    val options = BitmapFactory.Options().apply { inSampleSize = 16 }
    val bmp = BitmapFactory.decodeFile(path, options) ?: return null
    var r = 0L
    var g = 0L
    var b = 0L
    var n = 0
    // Se promedia la franja izquierda de la portada: es lo más parecido al color del lomo
    val xMax = maxOf(1, bmp.width / 4)
    for (x in 0 until xMax) {
        for (y in 0 until bmp.height) {
            val px = bmp.getPixel(x, y)
            r += (px shr 16) and 0xFF
            g += (px shr 8) and 0xFF
            b += px and 0xFF
            n++
        }
    }
    if (n == 0) return null
    return Color(r / n / 255f, g / n / 255f, b / n / 255f)
}

/** Color del lomo: promedio de la portada; si no hay portada, un color según el título. */
@Composable
internal fun rememberSpineColor(book: LibraryItem): Color {
    val fallback = remember(book.title) { coverColor(book.title) }
    val color by produceState(spineColorCache[book.coverPath ?: ""] ?: fallback, book.coverPath) {
        val path = book.coverPath
        if (path != null) {
            val cached = spineColorCache[path]
            if (cached != null) {
                value = cached
            } else {
                val c = withContext(Dispatchers.IO) { averageColor(path) }
                if (c != null) {
                    spineColorCache[path] = c
                    value = c
                }
            }
        }
    }
    return color
}

@Composable
internal fun FrontFace(book: LibraryItem, pagesEdge: Boolean = true) {
    Box(Modifier.fillMaxSize().clip(RoundedCornerShape(3.dp))) {
        BookCover(book, Modifier.fillMaxSize(), textSize = 9.sp)
        // pliegue del lomo en sombra, a la izquierda
        Box(
            Modifier.align(Alignment.CenterStart).fillMaxHeight().width(7.dp)
                .background(Brush.horizontalGradient(listOf(Color(0xAA000000), Color.Transparent)))
        )
        // canto de las páginas, a la derecha
        if (pagesEdge) Box(Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(3.dp).background(Color(0xFFEFE6D2)))
    }
}

/** Lomo del libro: de pie (vertical) o acostado (horizontal). Se ve el canto con título y bandas. */
@Composable
internal fun SpineFace(
    book: LibraryItem, vertical: Boolean, colorOverride: Long? = null,
    corner: Dp = 3.dp, pages: Boolean = true
) {
    val autoColor = rememberSpineColor(book)
    val base = (colorOverride?.let { Color(it) } ?: autoColor).let { if (it.luminance() > 0.8f) it.shade(0.8f) else it }
    val textColor = if (base.luminance() > 0.5f) Color(0xFF1B1B1B) else Color(0xFFF3E6C8)
    val brush = if (vertical) {
        Brush.horizontalGradient(listOf(base.shade(0.65f), base.shade(1.18f), base, base.shade(0.55f)))
    } else {
        Brush.verticalGradient(listOf(base.shade(1.18f), base, base.shade(0.6f)))
    }
    val band = textColor.copy(alpha = 0.55f)
    Box(
        Modifier.fillMaxSize().clip(RoundedCornerShape(corner)).background(brush),
        contentAlignment = Alignment.Center
    ) {
        if (vertical) {
            Box(Modifier.align(Alignment.TopCenter).padding(top = 7.dp).fillMaxWidth().height(2.dp).background(band))
            Box(Modifier.align(Alignment.TopCenter).padding(top = 11.dp).fillMaxWidth().height(1.dp).background(band))
            Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 7.dp).fillMaxWidth().height(2.dp).background(band))
            Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 11.dp).fillMaxWidth().height(1.dp).background(band))
            Text(
                book.title, color = textColor, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(vertical = 16.dp).rotateVertical()
            )
        } else {
            Box(Modifier.align(Alignment.CenterStart).padding(start = 7.dp).fillMaxHeight().width(2.dp).background(band))
            Box(Modifier.align(Alignment.CenterStart).padding(start = 11.dp).fillMaxHeight().width(1.dp).background(band))
            // extremo con las páginas a la vista
            if (pages) {
                Box(Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(8.dp).background(Color(0xFFEFE6D2)))
                Box(Modifier.align(Alignment.CenterEnd).padding(end = 3.dp).fillMaxHeight().width(1.dp).background(Color(0x33000000)))
            }
            Text(
                book.title, color = textColor, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(start = 18.dp, end = if (pages) 16.dp else 8.dp)
            )
        }
    }
}

@Composable
internal fun ShelfScreen(
    books: List<LibraryItem>,
    onOpen: (LibraryItem) -> Unit,
    onSetPose: (String, String) -> Unit,
    onSetAllPoses: (String) -> Unit,
    onMove: (String, Float, Float) -> Unit,
    onReset: () -> Unit,
    style: ShelfStyle = ShelfStyle(),
    onSpineSize: (String, Int, Int) -> Unit = { _, _, _ -> }
) {
    val wallDef = remember(style.wall) { wallOf(style.wall) }
    val woodDef = remember(style.wood) { woodOf(style.wood) }
    var selectedId by remember { mutableStateOf<String?>(null) }
    val selected = books.firstOrNull { it.id == selectedId }

    // Adornos colocados a mano (null = todavía no se han guardado: la primera vez se parte de los del tema)
    val ctx = LocalContext.current
    var placed by remember { mutableStateOf(ShelfStyleStore.loadPlaced(ctx)) }
    // Colores de lomo elegidos a mano (id → ARGB) y filtros de búsqueda
    var colorOverrides by remember { mutableStateOf(ShelfStyleStore.loadBookColors(ctx)) }
    var query by remember { mutableStateOf("") }
    var showFilters by remember { mutableStateOf(false) }
    var nudgeRequest by remember { mutableStateOf<Pair<String, Float>?>(null) }
    var fGenre by remember { mutableStateOf("") }
    var fAuthor by remember { mutableStateOf("") }
    var fStatus by remember { mutableStateOf("") }
    var fFormat by remember { mutableStateOf("") }
    var fSize by remember { mutableStateOf("") }
    var fColor by remember { mutableStateOf("") }
    val filtersActive = query.isNotBlank() || fGenre.isNotEmpty() || fAuthor.isNotEmpty() ||
        fStatus.isNotEmpty() || fFormat.isNotEmpty() || fSize.isNotEmpty() || fColor.isNotEmpty()
    fun matchesFilters(b: LibraryItem): Boolean {
        val q = query.trim()
        val h = poseSize(b, "SPINE").second.value
        val sizeLabel = if (h < 100f) "Chicos" else if (h <= 130f) "Medianos" else "Grandes"
        return (q.isEmpty() || b.title.contains(q, true) || b.author.contains(q, true) ||
            b.genreLabel().contains(q, true)) &&
            (fGenre.isEmpty() || b.genreLabel() == fGenre) &&
            (fAuthor.isEmpty() || b.author == fAuthor) &&
            (fStatus.isEmpty() || statusLabel(b.statusKey()) == fStatus) &&
            (fFormat.isEmpty() || b.format == fFormat) &&
            (fSize.isEmpty() || sizeLabel == fSize)
    }
    var selectedDecoId by remember { mutableStateOf<String?>(null) }
    var showDecoPicker by remember { mutableStateOf(false) }
    var pendingAdd by remember { mutableStateOf<DecoDef?>(null) }
    var reseedRequest by remember { mutableStateOf(false) }
    // Torres pedidas por el usuario: se colocan sobre la tabla de una balda (máx. MAX_STACK_BOOKS por columna)
    var pyramidRequest by remember { mutableStateOf<Set<String>?>(null) }
    // Aviso cuando se suelta un libro sobre una torre ya completa
    var towerFullNotice by remember { mutableStateOf(false) }
    var noRoomNotice by remember { mutableStateOf(false) }
    // Cambio de postura pedido desde el editor (id, postura): se resuelve dentro de la estantería, sin pisar a nadie
    var poseRequest by remember { mutableStateOf<Pair<String, String>?>(null) }
    // Selector de pirámide: el usuario elige qué libros apilar; el sistema los centra y apila solo
    var showPyramidPicker by remember { mutableStateOf(false) }
    var pyramidSeedId by remember { mutableStateOf<String?>(null) } // libro que abrió el selector
    var pyramidSelection by remember { mutableStateOf<Set<String>>(emptySet()) }
    // Modo apilar en la propia estantería (como vídeo de referencia): toca libros y pulsa «Apilarlos»
    var stackSelectMode by remember { mutableStateOf(false) }
    var stackSelection by remember { mutableStateOf<Set<String>>(emptySet()) }
    // Libro que se está arrastrando (para resaltar huecos con línea discontinua)
    var draggingBookId by remember { mutableStateOf<String?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val selectedDeco = placed?.firstOrNull { it.id == selectedDecoId }
    fun commitPlaced(list: List<PlacedDeco>) {
        placed = list
        ShelfStyleStore.savePlaced(ctx, list)
    }

    /**
     * Pila horizontal (torre de libros tumbados).
     * - Proporciones: ancho de cada capa = altura original del libro; alto de capa = grosor del lomo.
     * - Anclaje firme a la balda (sin flotar): el libro inferior apoya su canto inferior
     *   y los siguientes se apilan con interlineado 0.
     * - Solo se tocan los libros de esta torre; el resto de pilas permanece intacto
     *   (aislamiento de estado por stack).
     */
    fun applyPyramid(ids: Set<String>) {
        // La colocación real se hace dentro de la estantería (conoce las baldas): ver pyramidRequest
        if (ids.isNotEmpty()) pyramidRequest = ids
    }

    /** Mezcla realista: verticales + pilas en la misma estantería. */
    fun applyRealisticMix() {
        val mix = realisticMixPoses(books)
        mix.forEach { (id, pose) ->
            onSetPose(id, pose)
            onMove(id, -1f, -1f) // que el layout automático coloque con colisiones
        }
    }

    Box(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize()) {
        // Barra superior minimalista: título, buscar, filtros y menú «···»
        ShelfTopBar(
            stackSelectMode = stackSelectMode,
            query = query,
            onQuery = { query = it },
            filtersActive = filtersActive,
            onOpenFilters = { showFilters = true },
            onOrder = onReset,
            onAllPoses = onSetAllPoses,
            onMix = { applyRealisticMix() },
            onAddDeco = { showDecoPicker = true },
            onThemeDecos = { reseedRequest = true }
        )
        if (filtersActive && !stackSelectMode) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (fColor.isEmpty()) "${books.count { matchesFilters(it) }} de ${books.size} libros"
                    else "Libros de color ${fColor.lowercase()} resaltados",
                    color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f)
                )
                TextButton(onClick = {
                    query = ""; fGenre = ""; fAuthor = ""; fStatus = ""; fFormat = ""; fSize = ""; fColor = ""
                }) { Text("Limpiar", color = Gold, fontSize = 11.sp) }
            }
        }
        Spacer(Modifier.height(4.dp))

        // Estantería con scroll si hace falta; el panel de edición queda fijo abajo
        LazyColumn(Modifier.weight(1f)) {
            item {
                Column {

                BoxWithConstraints(Modifier.fillMaxWidth()) {
                    val density = LocalDensity.current
                    val areaW = constraints.maxWidth
                    val poseKey = books.map { it.id to shelfPose(it) }
                    val layout = remember(poseKey, areaW) { layoutShelf(books, areaW, density) }
                    val areaH = maxOf(layout.height, with(density) { 360.dp.roundToPx() })
                    val dpx = density.density

                    // Margen de colisión entre libros (dp → px): evita que se toquen o se monten
                    val bookGapPx = 4f * dpx

                    /** Rectángulo (en px) que ocupa un libro: su sitio guardado o el automático. */
                    fun bookRect(b: LibraryItem): Rect {
                        val dims = poseSize(b, shelfPose(b))
                        val bw = dims.first.value * dpx
                        val bh = dims.second.value * dpx
                        val slot = layout.slots[b.id] ?: IntOffset.Zero
                        val l = (if (b.shelfX >= 0f) b.shelfX * dpx else slot.x.toFloat())
                            .coerceIn(0f, (areaW - bw).coerceAtLeast(0f))
                        val t = (if (b.shelfY >= 0f) b.shelfY * dpx else slot.y.toFloat())
                            .coerceIn(0f, (areaH - bh).coerceAtLeast(0f))
                        return Rect(l, t, l + bw, t + bh)
                    }

                    /**
                     * Libros que forman la misma torre que `seed` (sin contar `exceptId`):
                     * tumbados, solapados en X y apoyados canto con canto.
                     */
                    fun towerOf(seed: LibraryItem, exceptId: String): List<LibraryItem> {
                        val tol = 3f * dpx
                        val tower = arrayListOf(seed)
                        var grew = true
                        while (grew) {
                            grew = false
                            for (o in books) {
                                if (o.id == exceptId || tower.any { it.id == o.id }) continue
                                val p = shelfPose(o)
                                if (p != "STACK" && p != "FLAT") continue
                                val ro = bookRect(o)
                                val touches = tower.any { t ->
                                    val rt = bookRect(t)
                                    val overlapX = minOf(ro.right, rt.right) - maxOf(ro.left, rt.left)
                                    overlapX > 0.4f * minOf(ro.width, rt.width) &&
                                        (abs(ro.bottom - rt.top) <= tol || abs(ro.top - rt.bottom) <= tol)
                                }
                                if (touches) { tower.add(o); grew = true }
                            }
                        }
                        return tower
                    }

                    /** ¿Se solapa el rect candidato con otros libros (con margen de colisión)? */
                    fun overlapsAny(
                        id: String, left: Float, top: Float, w: Float, h: Float,
                        skip: Set<String> = emptySet()
                    ): Boolean {
                        val candidate = Rect(
                            left - bookGapPx, top - bookGapPx,
                            left + w + bookGapPx, top + h + bookGapPx
                        )
                        for (b in books) {
                            if (b.id == id || b.id in skip) continue
                            val r = bookRect(b)
                            if (candidate.overlaps(r)) return true
                        }
                        return false
                    }

                    /** Fija en su sitio actual a los libros sin posición guardada (no se reacomodan al tocar otros). */
                    fun pinUnsaved(except: Set<String>) {
                        books.forEach { o ->
                            if (o.id !in except && (o.shelfX < 0f || o.shelfY < 0f)) {
                                val r0 = bookRect(o)
                                onMove(o.id, r0.left / dpx, r0.top / dpx)
                            }
                        }
                    }

                    /**
                     * Coloca el libro SIN solaparse con ningún otro y sin salir de su balda:
                     * 1) la balda es la de donde se suelta (nunca salta a otra) y el libro se apoya en su madera
                     * 2) soltado sobre una torre con sitio (máx. MAX_STACK_BOOKS y bajo el techo) se apila encima
                     * 3) si el sitio está ocupado, usa el hueco libre más cercano de ESA balda
                     * 4) si no hay hueco, vuelve a donde estaba: no roba espacio ni se monta sobre otros
                     */
                    fun resolveBookPlacement(id: String, xDp: Float, yDp: Float): Pair<Float, Float> {
                        val b = books.firstOrNull { it.id == id } ?: return xDp to yDp
                        val pose = shelfPose(b)
                        val dims = poseSize(b, pose)
                        val bw = dims.first.value * dpx
                        val bh = dims.second.value * dpx
                        val maxX = (areaW - bw).coerceAtLeast(0f)
                        val maxY = (areaH - bh).coerceAtLeast(0f)
                        val x = (xDp * dpx).coerceIn(0f, maxX)
                        val yDrop = (yDp * dpx).coerceIn(0f, maxY)
                        val cx = x + bw / 2f
                        val planks = layout.plankTops.sorted().map { it.toFloat() }
                        if (planks.isEmpty()) return (x / dpx) to (yDrop / dpx)
                        val plankThick = 12f * dpx
                        // Balda donde se suelta: la primera cuya madera queda por debajo del centro del libro
                        val idx = planks.indexOfFirst { it >= yDrop + bh * 0.5f }.let { if (it < 0) planks.lastIndex else it }
                        val floorY = planks[idx]
                        val bandTop = if (idx == 0) 0f else planks[idx - 1] + plankThick
                        val restY = (floorY - bh).coerceIn(0f, maxY)

                        // ── Torre: soltado sobre una torre / libro tumbado de ESTA balda ──
                        run {
                            var seed: LibraryItem? = null
                            var seedD = Float.MAX_VALUE
                            for (other in books) {
                                if (other.id == id) continue
                                val op = shelfPose(other)
                                if (op != "STACK" && op != "FLAT") continue
                                val r = bookRect(other)
                                if (r.bottom > floorY + 4f * dpx || r.top < bandTop - 2f * dpx) continue
                                if (cx < r.left - 8f * dpx || cx > r.right + 8f * dpx) continue
                                val d = abs((yDrop + bh) - r.top)
                                if (d < seedD) { seedD = d; seed = other }
                            }
                            val sd = seed ?: return@run
                            if (!(pose == "STACK" || pose == "FLAT" || seedD < 24f * dpx)) return@run
                            val tower = towerOf(sd, id)
                            if (tower.size >= MAX_STACK_BOOKS) { towerFullNotice = true; return@run }
                            val towerIds = tower.map { it.id }.toSet()
                            val stackW = poseSize(b, "STACK").first.value * dpx
                            val stackH = poseSize(b, "STACK").second.value * dpx
                            val tl = tower.minOf { bookRect(it).left }
                            val tr = tower.maxOf { bookRect(it).right }
                            val topY = tower.minOf { bookRect(it).top }
                            val maxSx = (areaW - stackW).coerceAtLeast(0f)
                            val sx = (cx - stackW / 2f)
                                .coerceIn((tl - stackW * 0.25f).coerceAtLeast(0f), (tr - stackW * 0.75f).coerceAtLeast(0f))
                                .coerceIn(0f, maxSx)
                            val sy = topY - stackH
                            if (sy < bandTop || overlapsAny(id, sx, sy, stackW, stackH, towerIds)) {
                                towerFullNotice = true
                                return@run
                            }
                            if (pose != "STACK") onSetPose(id, "STACK")
                            tower.forEach { if (shelfPose(it) != "STACK") onSetPose(it.id, "STACK") }
                            return (sx / dpx) to (sy / dpx)
                        }

                        // ── Colocación libre en ESA balda, sin pisar a nadie ──
                        if (!overlapsAny(id, x, restY, bw, bh)) return (x / dpx) to (restY / dpx)
                        var bestX = Float.NaN
                        var bestDist = Float.MAX_VALUE
                        var probe = 0f
                        while (probe <= maxX) {
                            if (!overlapsAny(id, probe, restY, bw, bh)) {
                                val d = abs(probe - x)
                                if (d < bestDist) { bestDist = d; bestX = probe }
                            }
                            probe += 2f * dpx
                        }
                        if (!bestX.isNaN()) return (bestX / dpx) to (restY / dpx)
                        // Sin hueco en esa balda: vuelve a su sitio
                        noRoomNotice = true
                        val original = bookRect(b)
                        return (original.left / dpx) to (original.top / dpx)
                    }

                    /** Al soltar un adorno cerca de una balda o del canto superior de un libro, se apoya en él. */
                    fun snapDeco(x: Float, y: Float, w: Float, h: Float): Pair<Float, Float> {
                        val cx = x + w / 2f
                        val bottom = y + h
                        var best = Float.NaN
                        var bestD = 36f * dpx
                        layout.plankTops.forEach { top ->
                            val d = abs(top - bottom)
                            if (d <= bestD) { bestD = d; best = top.toFloat() }
                        }
                        books.forEach { b ->
                            val r = bookRect(b)
                            if (cx >= r.left && cx <= r.right) {
                                val d = abs(r.top - bottom)
                                if (d <= bestD) { bestD = d; best = r.top }
                            }
                        }
                        return if (best.isNaN()) x to y else x to (best - h)
                    }

                    /**
                     * Mover un libro: resuelve colisiones (no solapa ni empuja a otros) y
                     * arrastra adornos que tenía encima. Devuelve la posición final en dp.
                     * Guarda la posición anterior para «Deshacer» y muestra snackbar.
                     */
                    val moveBookWithDecos: (String, Float, Float) -> Pair<Float, Float> = { id, nx, ny ->
                        val b = books.firstOrNull { it.id == id }
                        towerFullNotice = false
                        noRoomNotice = false
                        // Los demás libros se quedan donde están: se fija su sitio actual para que no se reacomoden
                        pinUnsaved(setOf(id))
                        val (rx, ry) = resolveBookPlacement(id, nx, ny)
                        val towerWasFull = towerFullNotice
                        val noRoom = noRoomNotice
                        val cur = placed
                        if (b != null && !cur.isNullOrEmpty()) {
                            val r = bookRect(b)
                            val dx = rx * dpx - r.left
                            val dy = ry * dpx - r.top
                            val moved = cur.map { d ->
                                val def = decoOf(d.key)
                                if (def == null) {
                                    d
                                } else {
                                    val cx = d.x * dpx + def.w * d.scale * dpx / 2f
                                    val bottom = d.y * dpx + def.h * d.scale * dpx
                                    if (cx >= r.left && cx <= r.right && abs(bottom - r.top) <= 3f * dpx) {
                                        d.copy(
                                            x = ((d.x * dpx + dx) / dpx).coerceAtLeast(0f),
                                            y = ((d.y * dpx + dy) / dpx).coerceAtLeast(0f)
                                        )
                                    } else d
                                }
                            }
                            commitPlaced(moved)
                        }
                        onMove(id, rx, ry)
                        // Sin aviso de «Libro movido»; solo se avisa cuando algo no cabe
                        val notice = when {
                            towerWasFull -> "Esa torre no admite más libros (máx. $MAX_STACK_BOOKS): el libro quedó al lado"
                            noRoom -> "No hay espacio libre en esa balda: el libro volvió a su sitio"
                            else -> null
                        }
                        if (notice != null) {
                            scope.launch {
                                snackbarHostState.showSnackbar(message = notice, duration = SnackbarDuration.Short)
                            }
                        }
                        rx to ry
                    }

                    // Primera vez (o «Los del tema»): se colocan los adornos del tema sobre cada balda
                    LaunchedEffect(layout, areaW, reseedRequest) {
                        if (reseedRequest) {
                            commitPlaced(seedDecos(style, layout.plankTops, areaW, density))
                            selectedDecoId = null
                            reseedRequest = false
                        } else if (placed == null) {
                            // Solo se guarda si el tema trae adornos: así una vista sin tema no «congela» una lista vacía
                            val seeded = seedDecos(style, layout.plankTops, areaW, density)
                            if (seeded.isEmpty()) placed = seeded else commitPlaced(seeded)
                        }
                    }
                    // Orden de la estantería (se ejecuta cuando todo está quieto, 0,45 s después del último cambio):
                    // 1) lo apoyado en una balda se mueve con ella si la balda cambia de sitio
                    // 2) ningún libro puede pisar a otro: si hay solapes (datos antiguos), se reubica en un hueco de su balda
                    // 3) lo que quedó sin apoyo cae a su balda (no se queda «bailando» en el vacío)
                    val booksNow by rememberUpdatedState(books)
                    val posSig = books.map { listOf(it.id, it.shelfOrientation, it.shelfX, it.shelfY) }
                    LaunchedEffect(layout, posSig) {
                        delay(450)
                        val bs = booksNow
                        val newDp = layout.plankTops.sorted().map { it / dpx }
                        if (bs.isEmpty() || newDp.isEmpty()) return@LaunchedEffect
                        val old = ShelfStyleStore.loadPlanks(ctx)
                            ?: layoutShelf(bs, areaW, density, legacy = true).plankTops.sorted().map { it / dpx }
                        ShelfStyleStore.savePlanks(ctx, newDp)
                        val areaWdp = areaW / dpx
                        val edge = 0f
                        // x, y, w, h (dp) de cada libro tal como se ve ahora
                        val rects = LinkedHashMap<String, FloatArray>()
                        bs.forEach { b ->
                            val (w, h) = poseSize(b, shelfPose(b))
                            val slot = layout.slots[b.id]
                            val x = if (b.shelfX >= 0f) b.shelfX else (slot?.x ?: 0) / dpx
                            val y = if (b.shelfY >= 0f) b.shelfY else (slot?.y ?: 0) / dpx
                            rects[b.id] = floatArrayOf(x, y, w.value, h.value)
                        }
                        val dirty = HashSet<String>()
                        fun shelfIdx(cyDp: Float): Int =
                            newDp.indexOfFirst { it >= cyDp }.let { if (it < 0) newDp.lastIndex else it }

                        // 1) Baldas que cambiaron de sitio
                        val planksMoved = old.size != newDp.size || old.indices.any { abs(old[it] - newDp[it]) >= 0.5f }
                        fun deltaFor(bottomDp: Float): Float {
                            val i = old.indexOfFirst { it >= bottomDp - 10f }.let { if (it < 0) old.lastIndex else it }
                            return newDp[i.coerceAtMost(newDp.lastIndex)] - old[i]
                        }
                        if (planksMoved) {
                            bs.forEach { b ->
                                if (b.shelfX < 0f || b.shelfY < 0f) return@forEach
                                val r = rects[b.id] ?: return@forEach
                                val d = deltaFor(r[1] + r[3])
                                if (abs(d) > 0.5f) { r[1] = (r[1] + d).coerceAtLeast(0f); dirty.add(b.id) }
                            }
                            val cur = placed
                            if (!cur.isNullOrEmpty()) {
                                var changed = false
                                val shifted = cur.map { d ->
                                    val def = decoOf(d.key) ?: return@map d
                                    val dd = deltaFor(d.y + def.h * d.scale)
                                    if (abs(dd) > 0.5f) { changed = true; d.copy(y = (d.y + dd).coerceAtLeast(0f)) } else d
                                }
                                if (changed) commitPlaced(shifted)
                            }
                        }

                        fun hits(id: String, x: Float, y: Float, w: Float, h: Float, only: Collection<String>? = null): Boolean {
                            val ids = only ?: rects.keys
                            for (oid in ids) {
                                if (oid == id) continue
                                val o = rects[oid] ?: continue
                                val ox = minOf(x + w, o[0] + o[2]) - maxOf(x, o[0])
                                val oy = minOf(y + h, o[1] + o[3]) - maxOf(y, o[1])
                                if (ox > 1f && oy > 1f) return true
                            }
                            return false
                        }

                        // 2) Nada se pisa: los que chocan buscan hueco en SU balda
                        val accepted = ArrayList<String>()
                        for (b in bs.sortedBy { rects[it.id]!![0] }) {
                            val r = rects[b.id]!!
                            if (hits(b.id, r[0], r[1], r[2], r[3], accepted)) {
                                val floor = newDp[shelfIdx(r[1] + r[3] / 2f)]
                                val ty = (floor - r[3]).coerceAtLeast(0f)
                                var bestX = Float.NaN
                                var bestD = Float.MAX_VALUE
                                var px = edge
                                while (px + r[2] <= areaWdp - edge) {
                                    if (!hits(b.id, px, ty, r[2], r[3], accepted)) {
                                        val d = abs(px - r[0])
                                        if (d < bestD) { bestD = d; bestX = px }
                                    }
                                    px += 2f
                                }
                                if (!bestX.isNaN()) { r[0] = bestX; r[1] = ty; dirty.add(b.id) }
                            }
                            accepted.add(b.id)
                        }

                        // 3) Gravedad: lo que no está apoyado cae a su balda si hay sitio
                        for (b in bs) {
                            val r = rects[b.id]!!
                            val floor = newDp[shelfIdx(r[1] + r[3] / 2f)]
                            val bottom = r[1] + r[3]
                            if (abs(bottom - floor) <= 3f) continue
                            val supported = rects.entries.any { (oid, o) ->
                                oid != b.id && abs(o[1] - bottom) <= 3f &&
                                    minOf(r[0] + r[2], o[0] + o[2]) - maxOf(r[0], o[0]) > 1f
                            }
                            if (supported) continue
                            val ty = (floor - r[3]).coerceAtLeast(0f)
                            if (ty > r[1] && !hits(b.id, r[0], ty, r[2], r[3])) { r[1] = ty; dirty.add(b.id) }
                        }

                        dirty.forEach { id -> rects[id]?.let { r -> onMove(id, r[0], r[1]) } }
                    }
                    // Cambio de postura (de pie / acostado / portada): conserva la base apoyada y solo se aplica
                    // si cabe en un hueco libre de la misma balda; si no cabe, el libro se queda como estaba.
                    LaunchedEffect(poseRequest) {
                        val req = poseRequest ?: return@LaunchedEffect
                        poseRequest = null
                        val (pid, newPose) = req
                        val b = books.firstOrNull { it.id == pid } ?: return@LaunchedEffect
                        val oldR = bookRect(b)
                        val nw = poseSize(b, newPose).first.value * dpx
                        val nh = poseSize(b, newPose).second.value * dpx
                        val ny = (oldR.bottom - nh).coerceAtLeast(0f)
                        val maxX = (areaW - nw).coerceAtLeast(0f)
                        var bestX = Float.NaN
                        var bestD = Float.MAX_VALUE
                        var probe = 0f
                        while (probe <= maxX) {
                            if (!overlapsAny(pid, probe, ny, nw, nh)) {
                                val d = abs(probe - oldR.left)
                                if (d < bestD) { bestD = d; bestX = probe }
                            }
                            probe += 2f * dpx
                        }
                        if (bestX.isNaN()) {
                            scope.launch { snackbarHostState.showSnackbar("No hay espacio en esta balda para ese formato") }
                            return@LaunchedEffect
                        }
                        pinUnsaved(setOf(pid))
                        onSetPose(pid, newPose)
                        onMove(pid, bestX / dpx, ny / dpx)
                    }
                    // Mover el libro unos puntos a izquierda/derecha dentro de su balda (flechas del editor)
                    LaunchedEffect(nudgeRequest) {
                        val req = nudgeRequest ?: return@LaunchedEffect
                        nudgeRequest = null
                        val (nid, dxDp) = req
                        val nb = books.firstOrNull { it.id == nid } ?: return@LaunchedEffect
                        val nr = bookRect(nb)
                        moveBookWithDecos(nid, nr.left / dpx + dxDp, nr.top / dpx)
                    }
                    // Torre nueva: individual, en la balda del libro que se editó, en un hueco libre
                    // (no se suma a torres hechas ni sube/baja a otras baldas) y apoyada en la madera.
                    LaunchedEffect(pyramidRequest) {
                        val ids = pyramidRequest ?: return@LaunchedEffect
                        pyramidRequest = null
                        val chosen = books.filter { it.id in ids }
                        val planks = layout.plankTops.sorted().map { it.toFloat() }
                        if (chosen.isEmpty() || planks.isEmpty()) return@LaunchedEffect
                        val plankPx = 12f * dpx
                        val gapPx = 6f * dpx
                        val edge = 12f * dpx
                        // Balda de destino: la del libro que se estaba editando (el primero de la selección)
                        val anchor = books.firstOrNull { it.id == ids.first() } ?: chosen.first()
                        val ra = bookRect(anchor)
                        val pi = planks.indices.minByOrNull { abs(planks[it] - ra.bottom) } ?: 0
                        val floorY = planks[pi]
                        val bandTop = if (pi == 0) 0f else planks[pi - 1] + plankPx
                        val freeH = (floorY - bandTop).coerceAtLeast(40f * dpx) - 4f * dpx
                        // Más anchos abajo; máx. MAX_STACK_BOOKS y que quepa bajo el techo de la balda
                        val sorted = chosen.sortedByDescending { poseSize(it, "STACK").first.value }
                        val tower = ArrayList<LibraryItem>()
                        var curH = 0f
                        for (b in sorted) {
                            val h = poseSize(b, "STACK").second.value * dpx
                            if (tower.size >= MAX_STACK_BOOKS || (tower.isNotEmpty() && curH + h > freeH)) break
                            tower.add(b); curH += h
                        }
                        val towerW = tower.maxOf { poseSize(it, "STACK").first.value * dpx }
                        // Huecos ocupados en ESA balda por los demás libros (torres incluidas)
                        val occupied = ArrayList<Pair<Float, Float>>()
                        books.forEach { o ->
                            if (o.id in ids) return@forEach
                            val r = bookRect(o)
                            val cy = (r.top + r.bottom) / 2f
                            if (cy >= bandTop && cy <= floorY + plankPx) occupied.add(r.left to r.right)
                        }
                        fun fits(x: Float) = x >= edge && x + towerW <= areaW - edge &&
                            occupied.none { (l, r) -> x < r + gapPx && x + towerW > l - gapPx }
                        // Hueco libre más cercano a donde estaba el libro
                        var bestX = Float.NaN
                        var bestD = Float.MAX_VALUE
                        var probe = edge
                        while (probe + towerW <= areaW - edge) {
                            if (fits(probe)) {
                                val d = abs(probe - ra.left)
                                if (d < bestD) { bestD = d; bestX = probe }
                            }
                            probe += 2f * dpx
                        }
                        if (bestX.isNaN()) {
                            scope.launch { snackbarHostState.showSnackbar("No hay hueco libre en esta balda para la torre") }
                            return@LaunchedEffect
                        }
                        // Los demás libros sin posición guardada se fijan donde están (no se reacomodan al crear la torre)
                        pinUnsaved(ids)
                        var bottom = floorY
                        tower.forEach { b ->
                            val (w, h) = poseSize(b, "STACK")
                            val bx = bestX + (towerW - w.value * dpx) / 2f
                            bottom -= h.value * dpx
                            onSetPose(b.id, "STACK")
                            onMove(b.id, bx / dpx, bottom / dpx)
                        }
                    }
                    // Adorno nuevo elegido en el catálogo: aparece sobre la primera balda
                    LaunchedEffect(pendingAdd) {
                        val def = pendingAdd
                        if (def != null) {
                            val top = layout.plankTops.firstOrNull()?.toFloat() ?: (areaH / 2f)
                            val nd = PlacedDeco(
                                id = java.util.UUID.randomUUID().toString(),
                                key = def.key,
                                x = ((areaW - def.w * dpx) / 2f) / dpx,
                                y = (top - def.h * dpx) / dpx
                            )
                            commitPlaced(placed.orEmpty() + nd)
                            selectedDecoId = nd.id
                            selectedId = null
                            pendingAdd = null
                        }
                    }

                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(with(density) { areaH.toDp() })
                            .clip(RoundedCornerShape(14.dp))
                            .drawBehind { drawWall(wallDef); drawFrameSides(style) }
                            .drawWithContent { drawContent(); drawLight(style.light) }
                    ) {
                        layout.plankTops.forEach { top ->
                            Canvas(
                                Modifier
                                    .offset { IntOffset(0, top) }
                                    .fillMaxWidth()
                                    .height(12.dp)
                            ) { drawWoodRect(woodDef, Offset.Zero, size) }
                        }
                        // Adornos colocados a mano: se arrastran, se agrandan, se colorean y se apoyan solos
                        placed.orEmpty().forEach { d ->
                            key(d.id) {
                                ShelfDecoItem(
                                    deco = d, areaW = areaW, areaH = areaH,
                                    isSelected = selectedDecoId == d.id,
                                    onSelect = { selectedDecoId = d.id; selectedId = null },
                                    snap = { x, y, w, h -> snapDeco(x, y, w, h) },
                                    onCommit = { nx, ny ->
                                        commitPlaced(placed.orEmpty().map { if (it.id == d.id) it.copy(x = nx, y = ny) else it })
                                    }
                                )
                            }
                        }
                        // Huecos de balda con línea discontinua mientras se arrastra un libro
                        if (draggingBookId != null) {
                            val dash = PathEffect.dashPathEffect(floatArrayOf(12f, 10f), 0f)
                            Canvas(Modifier.fillMaxSize()) {
                                layout.plankTops.forEach { top ->
                                    val left = 8f * dpx
                                    val right = size.width - 8f * dpx
                                    val slotH = 28f * dpx
                                    drawRoundRect(
                                        color = Gold.copy(alpha = 0.55f),
                                        topLeft = Offset(left, top - slotH),
                                        size = androidx.compose.ui.geometry.Size(right - left, slotH),
                                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f),
                                        style = Stroke(width = 2f * dpx, pathEffect = dash)
                                    )
                                }
                            }
                        }
                        books.forEach { book ->
                            key(book.id) {
                                val inStackSel = stackSelectMode && book.id in stackSelection
                                ShelfBook(
                                    book, layout.slots[book.id] ?: IntOffset.Zero, areaW, areaH,
                                    isSelected = if (stackSelectMode) inStackSel else selectedId == book.id,
                                    stackHighlight = inStackSel,
                                    dragEnabled = !stackSelectMode,
                                    colorOverride = colorOverrides[book.id],
                                    dimmed = filtersActive && !matchesFilters(book),
                                    colorFilter = fColor,
                                    onSelect = {
                                        if (stackSelectMode) {
                                            if (book.id in stackSelection) {
                                                stackSelection = stackSelection - book.id
                                            } else if (stackSelection.size < MAX_STACK_BOOKS) {
                                                stackSelection = stackSelection + book.id
                                            } else {
                                                scope.launch {
                                                    snackbarHostState.showSnackbar("Máximo $MAX_STACK_BOOKS libros por torre")
                                                }
                                            }
                                        } else {
                                            selectedId = if (selectedId == it.id) null else it.id
                                            selectedDecoId = null
                                        }
                                    },
                                    onDragState = { dragging ->
                                        draggingBookId = if (dragging) book.id else null
                                    },
                                    onMove = moveBookWithDecos
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                }
            }
            item { if (selected != null) Spacer(Modifier.height(300.dp)) }
        }

        if (stackSelectMode) {
            Spacer(Modifier.height(240.dp)) // hueco para el panel inferior
        } else if (selected == null) {
            Text(
                "Toca un libro o adorno para editarlo · Mantén pulsado para mover",
                color = Muted, fontSize = 12.sp, lineHeight = 18.sp,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        }
    }

    // Panel «Armar torre» (modo selección): mismo papel, bordes finos y dorado que el resto de la app
    if (stackSelectMode) {
        TowerBuilderBar(
            picked = stackSelection.mapNotNull { sid -> books.firstOrNull { it.id == sid } },
            onRemove = { rid -> stackSelection = stackSelection - rid },
            onCancel = { stackSelectMode = false; stackSelection = emptySet() },
            onConfirm = {
                if (stackSelection.size >= 2) applyPyramid(stackSelection)
                stackSelectMode = false
                stackSelection = emptySet()
            },
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }

    // Edición de libro: panel compacto fijo abajo (la estantería sigue visible y el cambio se ve en vivo)
    if (selected != null && !stackSelectMode) {
        BookShelfEditorPanel(
            book = selected,
            onSetPose = { pose ->
                if (pose == "STACK") {
                    // Torre nueva e individual: solo empieza con el libro tocado
                    stackSelection = setOf(selected.id)
                    stackSelectMode = true
                    selectedId = null
                } else {
                    // Se resuelve dentro de la estantería: misma balda, sin pisar a otros libros
                    poseRequest = selected.id to pose
                }
            },
            onSpineSize = { w, h -> onSpineSize(selected.id, w, h) },
            palette = remember(style.palette) { paletteOf(style.palette).colors },
            colorOverride = colorOverrides[selected.id],
            onColor = { col ->
                val m = HashMap(colorOverrides)
                if (col == null) m.remove(selected.id) else m[selected.id] = col
                colorOverrides = m
                ShelfStyleStore.saveBookColors(ctx, m)
            },
            onNudge = { dx -> nudgeRequest = selected.id to dx },
            onOpen = { onOpen(selected); selectedId = null },
            onDone = { selectedId = null },
            modifier = Modifier.align(Alignment.BottomCenter).padding(horizontal = 4.dp, vertical = 4.dp)
        )
    }

    SnackbarHost(
        hostState = snackbarHostState,
        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = if (stackSelectMode) 236.dp else if (selected != null) 300.dp else 8.dp)
    )
    } // Box raíz

    // Selector de libros para la pirámide: el sistema los apila y centra solo
    if (showPyramidPicker) {
        AlertDialog(
            onDismissRequest = { showPyramidPicker = false },
            containerColor = Panel,
            title = {
                Text("Torre de libros", color = Cream, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Elige los libros de la torre. Quedarán tumbados uno encima de otro, centrados, como en una librería real.",
                        color = Muted, fontSize = 13.sp, lineHeight = 18.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = {
                            pyramidSelection = books.map { it.id }.toSet()
                        }) { Text("Todos", color = Gold, fontSize = 12.sp) }
                        TextButton(onClick = {
                            pyramidSelection = emptySet()
                        }) { Text("Ninguno", color = Gold, fontSize = 12.sp) }
                    }
                    androidx.compose.foundation.lazy.LazyColumn(
                        Modifier.heightIn(max = 320.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(books, key = { it.id }) { b ->
                            val checked = b.id in pyramidSelection
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (checked) Gold.copy(alpha = 0.15f) else Color.Transparent)
                                    .clickable {
                                        pyramidSelection = if (checked) pyramidSelection - b.id
                                        else pyramidSelection + b.id
                                    }
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    if (checked) "☑" else "☐",
                                    color = if (checked) Gold else Muted,
                                    fontSize = 16.sp
                                )
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        b.title, color = Cream, fontSize = 13.sp, maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(b.author, color = Muted, fontSize = 11.sp, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        applyPyramid(pyramidSelection)
                        showPyramidPicker = false
                    },
                    enabled = pyramidSelection.isNotEmpty()
                ) {
                    Text("Crear pila", color = Gold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPyramidPicker = false }) {
                    Text("Cancelar", color = Muted)
                }
            }
        )
    }

    // Edición de decoración: misma ventana emergente (sin scroll en la estantería)
    if (selectedDeco != null) {
        ModalBottomSheet(
            onDismissRequest = { selectedDecoId = null },
            containerColor = Panel
        ) {
            DecoEditorPanel(
                deco = selectedDeco,
                onChange = { nd -> commitPlaced(placed.orEmpty().map { if (it.id == nd.id) nd else it }) },
                onDuplicate = {
                    val copy = selectedDeco.copy(
                        id = java.util.UUID.randomUUID().toString(),
                        x = selectedDeco.x + 14f
                    )
                    commitPlaced(placed.orEmpty() + copy)
                    selectedDecoId = copy.id
                },
                onDelete = {
                    commitPlaced(placed.orEmpty().filter { it.id != selectedDeco.id })
                    selectedDecoId = null
                },
                onDone = { selectedDecoId = null },
                asSheetContent = true
            )
        }
    }

    if (showFilters) {
        ShelfFilterSheet(
            genres = books.map { it.genreLabel() }.distinct().sorted(),
            authors = books.map { it.author }.distinct().sorted(),
            formats = books.map { it.format }.distinct().sorted(),
            colors = COLOR_FAMILIES,
            fGenre = fGenre, fAuthor = fAuthor, fStatus = fStatus,
            fFormat = fFormat, fSize = fSize, fColor = fColor,
            onGenre = { fGenre = it }, onAuthor = { fAuthor = it }, onStatus = { fStatus = it },
            onFormat = { fFormat = it }, onSize = { fSize = it }, onColor = { fColor = it },
            onClear = {
                query = ""; fGenre = ""; fAuthor = ""; fStatus = ""; fFormat = ""; fSize = ""; fColor = ""
            },
            onDismiss = { showFilters = false }
        )
    }

    if (showDecoPicker) {
        DecoPickerDialog(
            onPick = { d -> pendingAdd = d; showDecoPicker = false },
            onDismiss = { showDecoPicker = false }
        )
    }
}

/** Adornos del tema, uno junto a otro sobre el extremo derecho de cada balda (punto de partida editable). */
private fun seedDecos(style: ShelfStyle, plankTops: List<Int>, areaW: Int, density: Density): List<PlacedDeco> {
    val out = ArrayList<PlacedDeco>()
    val px = density.density
    plankTops.forEachIndexed { idx, top ->
        var dx = areaW - 10f * px
        pickDecos(style, 31, idx, 120f).forEach { d ->
            val dw = d.w * px
            val dh = d.h * px
            dx -= dw
            out.add(PlacedDeco(java.util.UUID.randomUUID().toString(), d.key, dx / px, (top - dh) / px))
            dx -= 6f * px
        }
    }
    return out
}

/** Panel de edición del libro en estantería libre (ventana emergente o Card). */
/**
 * Editor del libro dentro de la balda: panel compacto y fijo (no tapa la estantería).
 * Conserva todo lo que ya tenías (forma, tamaño rápido S/M/L/XL/Automático, alto y ancho, color del lomo,
 * Abrir y Listo) y suma al estilo Mistbook: mover el libro con flechas y «ajuste fino» plegable.
 */
@Composable
private fun BookShelfEditorPanel(
    book: LibraryItem,
    onSetPose: (String) -> Unit,
    onSpineSize: (Int, Int) -> Unit,
    palette: List<Color>,
    colorOverride: Long?,
    onColor: (Long?) -> Unit,
    onNudge: (Float) -> Unit,
    onOpen: () -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier
) {
    val spineNow = poseSize(book, "SPINE")
    val autoDims = remember(book.id) { poseSize(book.copy(spineWidthDp = 0, spineHeightDp = 0), "SPINE") }
    var w by remember(book.id) { mutableFloatStateOf(spineNow.first.value.coerceIn(16f, 56f)) }
    var h by remember(book.id) { mutableFloatStateOf(spineNow.second.value.coerceIn(70f, 190f)) }
    var fine by remember(book.id) { mutableStateOf(false) }
    val pose = shelfPose(book)
    val isAuto = book.spineWidthDp == 0 && book.spineHeightDp == 0
    val chipColors = FilterChipDefaults.filterChipColors(
        selectedContainerColor = Gold, selectedLabelColor = Ink, labelColor = Cream
    )
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            Modifier
                .heightIn(max = 340.dp)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Cabecera: portada, título y cerrar
            Row(verticalAlignment = Alignment.CenterVertically) {
                BookCover(book, Modifier.size(width = 34.dp, height = 50.dp))
                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                    Text(
                        book.title, color = Cream, fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Text(book.author, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                LibIconButton(LibIconKind.CLOSE, onClick = onDone, tint = Muted, iconSize = 18.dp)
            }

            // Forma (Portada, De pie, Acostado, Torre) + mover en la balda
            Text("CÓMO SE VE", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    "FRONT" to "Portada",
                    "SPINE" to "De pie",
                    "FLAT" to "Acostado",
                    "STACK" to "Torre"
                ).forEach { (p, label) ->
                    FilterChip(
                        selected = pose == p,
                        onClick = { onSetPose(p) },
                        label = { Text(label, fontSize = 12.sp) },
                        colors = chipColors
                    )
                }
            }
            if (pose != "STACK") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Mover en la balda", color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    LibIconButton(LibIconKind.CHEVRON_LEFT, onClick = { onNudge(-8f) }, tint = Gold, iconSize = 22.dp)
                    LibIconButton(LibIconKind.CHEVRON_RIGHT, onClick = { onNudge(8f) }, tint = Gold, iconSize = 22.dp)
                }
            }

            // Tamaño rápido + ajuste fino
            Text("TAMAÑO", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    "S" to (20f to 90f),
                    "M" to (26f to 114f),
                    "L" to (34f to 140f),
                    "XL" to (44f to 170f)
                ).forEach { (label, pair) ->
                    FilterChip(
                        selected = !isAuto && w.toInt() == pair.first.toInt() && h.toInt() == pair.second.toInt(),
                        onClick = { w = pair.first; h = pair.second; onSpineSize(w.toInt(), h.toInt()) },
                        label = { Text(label, fontSize = 12.sp) },
                        colors = chipColors
                    )
                }
                FilterChip(
                    selected = isAuto,
                    onClick = {
                        w = autoDims.first.value; h = autoDims.second.value
                        onSpineSize(0, 0)
                    },
                    label = { Text("Automático", fontSize = 12.sp) },
                    colors = chipColors
                )
                FilterChip(
                    selected = fine,
                    onClick = { fine = !fine },
                    label = { Text("Ajuste fino", fontSize = 12.sp) },
                    colors = chipColors
                )
            }
            if (fine) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Altura", color = Muted, fontSize = 12.sp, modifier = Modifier.width(54.dp))
                    Slider(
                        value = h,
                        onValueChange = { h = it; onSpineSize(w.toInt(), h.toInt()) },
                        valueRange = 70f..190f,
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold)
                    )
                    Text("${h.toInt()}", color = Cream, fontSize = 12.sp, modifier = Modifier.width(30.dp))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Grosor", color = Muted, fontSize = 12.sp, modifier = Modifier.width(54.dp))
                    Slider(
                        value = w,
                        onValueChange = { w = it; onSpineSize(w.toInt(), h.toInt()) },
                        valueRange = 16f..56f,
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold)
                    )
                    Text("${w.toInt()}", color = Cream, fontSize = 12.sp, modifier = Modifier.width(30.dp))
                }
            }

            // Color del lomo
            Text("COLOR DEL LOMO", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = colorOverride == null,
                    onClick = { onColor(null) },
                    label = { Text("Auto", fontSize = 12.sp) },
                    colors = chipColors
                )
                palette.forEach { c ->
                    val argb = c.toArgb().toLong() and 0xFFFFFFFFL
                    val on = colorOverride == argb
                    Box(
                        Modifier.size(28.dp).clip(androidx.compose.foundation.shape.CircleShape).background(c)
                            .border(if (on) 3.dp else 1.dp, if (on) Gold else Line,
                                androidx.compose.foundation.shape.CircleShape)
                            .clickable { onColor(argb) }
                    )
                }
            }
            if (pose == "FRONT") {
                Text("El color se ve cuando el libro está de pie o acostado.", color = Muted, fontSize = 11.sp)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onOpen, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)
                ) { Text("Abrir", fontSize = 12.sp) }
                OutlinedButton(
                    onClick = onDone, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Cream)
                ) { Text("Listo", fontSize = 12.sp) }
            }
        }
    }
}

@Composable
private fun ShelfBook(
    book: LibraryItem,
    slot: IntOffset,
    areaW: Int,
    areaH: Int,
    isSelected: Boolean,
    stackHighlight: Boolean = false,
    dragEnabled: Boolean = true,
    colorOverride: Long? = null,
    dimmed: Boolean = false,
    colorFilter: String = "",
    onSelect: (LibraryItem) -> Unit,
    onDragState: (Boolean) -> Unit = {},
    /** Devuelve posición final en dp tras aplicar colisión / snap a balda. */
    onMove: (String, Float, Float) -> Pair<Float, Float>
) {
    val density = LocalDensity.current
    val pose = shelfPose(book)
    val dims = poseSize(book, pose)
    val autoColor = rememberSpineColor(book)
    val dim = dimmed || (colorFilter.isNotEmpty() &&
        colorFamily(colorOverride?.let { Color(it) } ?: autoColor) != colorFilter)
    val bw = with(density) { dims.first.roundToPx() }
    val bh = with(density) { dims.second.roundToPx() }
    val maxX = (areaW - bw).coerceAtLeast(0)
    val maxY = (areaH - bh).coerceAtLeast(0)
    val px = density.density   // la posición guardada está en dp
    // Claves estables: si el libro tiene posición explícita, no depender del slot del layout
    // automático (evita que al actualizar otra torre se mueva esta).
    var x by remember(book.id, book.shelfX, areaW, bw) {
        mutableFloatStateOf(
            (if (book.shelfX >= 0f) book.shelfX * px else slot.x.toFloat()).coerceIn(0f, maxX.toFloat())
        )
    }
    var y by remember(book.id, book.shelfY, areaH, bh) {
        mutableFloatStateOf(
            (if (book.shelfY >= 0f) book.shelfY * px else slot.y.toFloat()).coerceIn(0f, maxY.toFloat())
        )
    }
    var dragging by remember { mutableStateOf(false) }

    // Sincronizar solo cuando cambian las coordenadas del propio libro o su pose.
    // No reaccionar a cambios de slot de otras unidades (aislamiento de pilas).
    LaunchedEffect(book.shelfX, book.shelfY, pose, areaW, areaH, bw, bh) {
        if (!dragging) {
            if (book.shelfX >= 0f) {
                x = (book.shelfX * px).coerceIn(0f, maxX.toFloat())
            } else {
                x = slot.x.toFloat().coerceIn(0f, maxX.toFloat())
            }
            if (book.shelfY >= 0f) {
                y = (book.shelfY * px).coerceIn(0f, maxY.toFloat())
            } else {
                y = slot.y.toFloat().coerceIn(0f, maxY.toFloat())
            }
        }
    }

    Box(
        Modifier
            .offset { IntOffset(x.roundToInt(), y.roundToInt()) }
            // Los libros más altos se dibujan encima: así la cara superior de uno no tapa al que va encima
            .zIndex(
                (if (dragging) 20f else if (isSelected || stackHighlight) 10f else 0f) +
                    (1f - ((if (book.shelfY >= 0f) book.shelfY * px else slot.y.toFloat()) / areaH.coerceAtLeast(1))
                        .coerceIn(0f, 1f))
            )
            .graphicsLayer { alpha = if (dim) 0.22f else 1f }
            .size(dims.first, dims.second)
            .then(if (dragging) Modifier.shadow(12.dp, RoundedCornerShape(3.dp)) else Modifier)
            .then(
                when {
                    dragging -> Modifier.border(
                        2.dp, Gold.copy(alpha = 0.9f), RoundedCornerShape(4.dp)
                    )
                    stackHighlight || isSelected -> Modifier.border(
                        2.dp, Gold, RoundedCornerShape(4.dp)
                    )
                    else -> Modifier
                }
            )
            .then(
                if (dragEnabled) {
                    Modifier.pointerInput(book.id, maxX, maxY) {
                        // Mantener pulsado y arrastrar: el scroll de la estantería sigue funcionando
                        detectDragGesturesAfterLongPress(
                            onDragStart = {
                                dragging = true
                                onDragState(true)
                            },
                            onDragEnd = {
                                dragging = false
                                onDragState(false)
                                // Al soltar: colisión + snap a balda; no solapa ni empuja a otros
                                val (rx, ry) = onMove(book.id, x / px, y / px)
                                x = (rx * px).coerceIn(0f, maxX.toFloat())
                                y = (ry * px).coerceIn(0f, maxY.toFloat())
                            },
                            onDragCancel = {
                                dragging = false
                                onDragState(false)
                            }
                        ) { change, drag ->
                            change.consume()
                            x = (x + drag.x).coerceIn(0f, maxX.toFloat())
                            y = (y + drag.y).coerceIn(0f, maxY.toFloat())
                        }
                    }
                } else Modifier
            )
            .clickable { onSelect(book) }
    ) {
        // Libro con volumen (3D): de pie, acostado/pila o de frente
        Book3D(book, pose, colorOverride)
        // Contorno discontinuo extra mientras se arrastra (como en el vídeo de referencia)
        if (dragging) {
            Canvas(Modifier.fillMaxSize()) {
                val dash = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)
                drawRoundRect(
                    color = Color(0xFFFFE08A),
                    topLeft = Offset.Zero,
                    size = size,
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(4.dp.toPx(), 4.dp.toPx()),
                    style = Stroke(width = 2.5.dp.toPx(), pathEffect = dash)
                )
            }
        }
    }
}


/** Panel inferior para armar una torre: hasta MAX_STACK_BOOKS huecos con las portadas elegidas. */
@Composable
private fun TowerBuilderBar(
    picked: List<LibraryItem>,
    onRemove: (String) -> Unit,
    onCancel: () -> Unit,
    onConfirm: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    Column(
        modifier
            .fillMaxWidth()
            .shadow(10.dp, shape)
            .background(Panel, shape)
            .border(1.dp, Line, shape)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "ARMAR TORRE", color = Cream, fontSize = 12.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 1.sp,
                modifier = Modifier.weight(1f)
            )
            Text(
                "${picked.size}/$MAX_STACK_BOOKS", color = Gold,
                fontSize = 12.sp, fontWeight = FontWeight.Bold
            )
        }
        Text(
            if (picked.size < 2) "Toca en la estantería los libros que quieras apilar (mín. 2, máx. $MAX_STACK_BOOKS)."
            else "Los más anchos quedan abajo. Toca un libro de aquí para quitarlo.",
            color = Muted, fontSize = 11.sp, lineHeight = 15.sp
        )
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            repeat(MAX_STACK_BOOKS) { i ->
                val b = picked.getOrNull(i)
                if (b != null) {
                    Box(
                        Modifier
                            .size(width = 44.dp, height = 62.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .border(2.dp, Gold, RoundedCornerShape(6.dp))
                            .clickable { onRemove(b.id) }
                    ) { BookCover(b, Modifier.fillMaxSize()) }
                } else {
                    Box(
                        Modifier
                            .size(width = 44.dp, height = 62.dp)
                            .drawBehind {
                                drawRoundRect(
                                    color = Muted.copy(alpha = 0.6f),
                                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(6.dp.toPx()),
                                    style = Stroke(
                                        width = 1.5.dp.toPx(),
                                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))
                                    )
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) { Text("+", color = Muted, fontSize = 16.sp) }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(
                onClick = onCancel,
                modifier = Modifier.weight(1f).height(46.dp),
                shape = RoundedCornerShape(24.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Gold),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
            ) { Text("Cancelar", fontSize = 14.sp) }
            Button(
                onClick = onConfirm,
                enabled = picked.size >= 2,
                modifier = Modifier.weight(1.4f).height(46.dp),
                shape = RoundedCornerShape(24.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Gold, contentColor = Ink,
                    disabledContainerColor = Line, disabledContentColor = Muted
                )
            ) { Text("Hacer torre", fontWeight = FontWeight.SemiBold, fontSize = 14.sp) }
        }
    }
}
