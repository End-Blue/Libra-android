@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.libra.reader

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.Rect
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.view.ActionMode
import android.view.GestureDetector
import android.view.Menu
import android.view.MenuItem
import android.view.MotionEvent
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.util.UUID
import java.util.zip.ZipFile
import kotlin.math.abs
import kotlin.math.absoluteValue

// ══════════════════════════════════════════════════════════════════════════════
// PANTALLA PRINCIPAL DEL LECTOR
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun ReaderScreen(
    item: LibraryItem,
    onClose: () -> Unit,
    onSave: (Long, Int) -> Unit,
    highlightDao: HighlightDao,
    onUpdateItem: (LibraryItem) -> Unit   // para guardar readingMode, bookmarkStyle
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val activity = context as? Activity
    val sp = remember { context.getSharedPreferences("libra_reading_prefs", 0) }

    BackHandler(onBack = onClose)

    var showMenu by remember { mutableStateOf(false) }
    var showHighlights by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showContents by remember { mutableStateOf(false) }
    // Chrome del lector: oculto al leer; un toque lo muestra/oculta
    var showChrome by remember { mutableStateOf(false) }
    // Progreso actualizado por el lector (capítulo / página)
    var liveProgress by remember { mutableIntStateOf(item.progress.coerceIn(0, 100)) }
    var liveChapterLabel by remember { mutableStateOf("") }
    var readingPrefs by remember {
        mutableStateOf(
            ReadingPrefs(
                themeMode = sp.getInt("themeMode", 2),
                fontSizeSp = sp.getInt("fontSizeSp", 18),
                lineHeight = sp.getFloat("lineHeight", 1.55f),
                marginDp = sp.getInt("marginDp", 20),
                brightness = sp.getFloat("brightness", 1f),
                fontFamily = sp.getString("fontFamily", "serif") ?: "serif",
                pageTurnStyle = sp.getString("pageTurnStyle", "slide") ?: "slide",
                orientation = sp.getString("orientation", "auto") ?: "auto",
                showNavButtons = sp.getBoolean("showNavButtons", true),
                leftHanded = sp.getBoolean("leftHanded", false)
            )
        )
    }

    // Persistir y aplicar orientación
    LaunchedEffect(readingPrefs) {
        sp.edit()
            .putInt("themeMode", readingPrefs.themeMode)
            .putInt("fontSizeSp", readingPrefs.fontSizeSp)
            .putFloat("lineHeight", readingPrefs.lineHeight)
            .putInt("marginDp", readingPrefs.marginDp)
            .putFloat("brightness", readingPrefs.brightness)
            .putString("fontFamily", readingPrefs.fontFamily)
            .putString("pageTurnStyle", readingPrefs.pageTurnStyle)
            .putString("orientation", readingPrefs.orientation)
            .putBoolean("showNavButtons", readingPrefs.showNavButtons)
            .putBoolean("leftHanded", readingPrefs.leftHanded)
            .apply()
        when (readingPrefs.orientation) {
            "portrait" -> activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            "landscape" -> activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            else -> activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    val highlights by highlightDao.observeByBook(item.id).collectAsState(initial = emptyList())
    var editingHighlight by remember { mutableStateOf<Highlight?>(null) }

    // Al abrir: muestra opciones un momento y luego solo el texto
    LaunchedEffect(item.id) {
        showChrome = true
        kotlinx.coroutines.delay(2200)
        if (!showSettings && !showContents && !showHighlights) showChrome = false
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Ink)
            .systemBarsPadding()
    ) {
        // ── Solo el texto del libro ───────────────────────────────────────────
        Box(Modifier.fillMaxSize()) {
            val progressCb: (Long, Int) -> Unit = { pos, pct ->
                liveProgress = pct.coerceIn(0, 100)
                onSave(pos, pct)
            }
            val immersivePrefs = readingPrefs.copy(showNavButtons = showChrome && readingPrefs.showNavButtons)
            when (item.format.lowercase()) {
                "epub" -> EpubReader(
                    item, progressCb, highlightDao, onUpdateItem, immersivePrefs, { readingPrefs = it },
                    showContents = showContents,
                    onContentsDismiss = { showContents = false },
                    onChapterLabel = { liveChapterLabel = it },
                    onToggleChrome = { showChrome = !showChrome }
                )
                "pdf"  -> PdfReader(item, progressCb, item.readingMode, highlightDao, onUpdateItem)
                "txt"  -> TextFileReader(item, progressCb, fb2 = false, highlightDao, onUpdateItem, immersivePrefs)
                "fb2"  -> TextFileReader(item, progressCb, fb2 = true,  highlightDao, onUpdateItem, immersivePrefs)
                "cbz"  -> CbzReader(item, progressCb, item.readingMode)
                else   -> Message(
                    "Los archivos CBR (RAR) todavía no se pueden leer dentro de Libellum. " +
                    "Conviértelo a CBZ y vuelve a importarlo."
                )
            }
            if (item.bookmarkStyle == "RIBBON") {
                BookmarkRibbon(Modifier.align(Alignment.TopEnd).padding(end = 22.dp))
            }
        }

        // Franja superior táctil cuando las opciones están ocultas (no interfiere con el texto)
        if (!showChrome) {
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .height(36.dp)
                    .clickable { showChrome = true }
            )
        }

        // ── Opciones: aparecen al tocar la franja superior o el centro del EPUB ─
        if (showChrome) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(Ink.copy(alpha = 0.94f))
                        .clickable { showChrome = false }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onClose) {
                        LibIcon(LibIconKind.CHEVRON_LEFT, tint = Gold, size = 18.dp)
                        Spacer(Modifier.width(2.dp))
                        Text("Volver", color = Gold)
                    }
                    Text(
                        item.title, color = Cream, fontSize = 13.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    LibIconButton(LibIconKind.LIST, onClick = { showContents = true }, tint = Cream)
                    LibIconButton(LibIconKind.NOTES, onClick = { showHighlights = true }, tint = Cream)
                    LibIconButton(LibIconKind.TEXT_SIZE, onClick = { showSettings = true }, tint = Cream)
                }
                Column(
                    Modifier
                        .fillMaxWidth()
                        .background(Ink.copy(alpha = 0.94f))
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    LinearProgressIndicator(
                        progress = { liveProgress / 100f },
                        modifier = Modifier.fillMaxWidth().height(3.dp),
                        color = Gold,
                        trackColor = Muted.copy(alpha = 0.25f)
                    )
                    if (liveChapterLabel.isNotBlank()) {
                        Text(liveChapterLabel, color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 2.dp))
                    }
                }
                // Zona central: tocar para ocultar opciones y volver al texto
                Spacer(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .clickable(
                            interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                            indication = null
                        ) { showChrome = false }
                )
            }
        }

        // ── Separador de página: tarjeta con la portada ───────────────────────
        if (item.bookmarkStyle == "COVER") {
            BookmarkDivider(item)
        }
    }

    // Contenido / avance para formatos sin TOC propio (PDF, TXT, CBZ…)
    if (showContents && item.format.lowercase() != "epub") {
        ModalBottomSheet(
            onDismissRequest = { showContents = false },
            containerColor = Panel
        ) {
            Column(
                Modifier
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 24.dp)
            ) {
                Text("AVANCE", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { liveProgress / 100f },
                    modifier = Modifier.fillMaxWidth().height(8.dp),
                    color = Gold,
                    trackColor = Muted.copy(alpha = 0.25f)
                )
                Text(
                    "${liveProgress}% leído",
                    color = Cream, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp)
                )
                if (liveChapterLabel.isNotBlank()) {
                    Text(liveChapterLabel, color = Muted, fontSize = 12.sp)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "En EPUB verás aquí la lista de capítulos. En este formato el avance se guarda por posición de lectura.",
                    color = Muted, fontSize = 12.sp, lineHeight = 18.sp
                )
            }
        }
    }

    // ── Hoja de notas del libro ───────────────────────────────────────────────
    if (showHighlights) {
        ModalBottomSheet(
            onDismissRequest = { showHighlights = false },
            containerColor = Panel
        ) {
            Column(Modifier.navigationBarsPadding().padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
                Text(
                    "NOTAS DE ESTE LIBRO",
                    color = Gold, fontSize = 13.sp,
                    fontWeight = FontWeight.Bold, letterSpacing = 1.sp
                )
                Spacer(Modifier.height(12.dp))
                BookHighlightsScreen(
                    highlights = highlights,
                    onEdit = { editingHighlight = it },
                    onDelete = { h -> scope.launch { highlightDao.deleteById(h.id) } }
                )
            }
        }
    }

    // ── Hoja de ajustes del lector ────────────────────────────────────────────
    if (showSettings) {
        ReaderSettingsSheet(
            item = item,
            prefs = readingPrefs,
            onPrefsChange = { readingPrefs = it },
            onDismiss = { showSettings = false },
            onUpdateItem = onUpdateItem
        )
    }

    // ── Diálogo de edición de nota ────────────────────────────────────────────
    editingHighlight?.let { h ->
        HighlightEditDialog(
            highlight = h,
            onSave = { updated ->
                scope.launch { highlightDao.update(updated) }
                editingHighlight = null
            },
            onDismiss = { editingHighlight = null }
        )
    }
}

// ── Ajustes del lector ────────────────────────────────────────────────────────

@Composable
fun ReaderSettingsSheet(
    item: LibraryItem,
    prefs: ReadingPrefs,
    onPrefsChange: (ReadingPrefs) -> Unit,
    onDismiss: () -> Unit,
    onUpdateItem: (LibraryItem) -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Panel
    ) {
        Column(
            Modifier
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                "AJUSTES",
                color = Gold, fontSize = 14.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp,
                modifier = Modifier.padding(top = 4.dp)
            )

            // Temas de color (blanco / sepia / oscuro / negro) — como en el video
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                listOf(
                    2 to Color(0xFFFFFFFF),
                    1 to Color(0xFFF4ECD8),
                    0 to Color(0xFF2A2F3A),
                    3 to Color(0xFF000000)
                ).forEach { (mode, c) ->
                    Box(
                        Modifier
                            .size(40.dp)
                            .background(c, RoundedCornerShape(20.dp))
                            .border(
                                width = if (prefs.themeMode == mode) 2.5.dp else 1.dp,
                                color = if (prefs.themeMode == mode) Gold else Muted.copy(alpha = 0.35f),
                                shape = RoundedCornerShape(20.dp)
                            )
                            .clickable { onPrefsChange(prefs.copy(themeMode = mode)) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (prefs.themeMode == mode) {
                            Text("✓", color = if (mode == 2 || mode == 1) Color.Black else Gold, fontSize = 15.sp)
                        }
                    }
                }
            }

            // Fila rápida: Tamaño · Margen · Interlineado · Brillo (iconos estilo video)
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                QuickSettingButton("Aa", "Tamaño") {
                    // ciclo simple de tamaños
                    val next = when {
                        prefs.fontSizeSp < 16 -> 16
                        prefs.fontSizeSp < 20 -> 20
                        prefs.fontSizeSp < 24 -> 24
                        else -> 14
                    }
                    onPrefsChange(prefs.copy(fontSizeSp = next))
                }
                QuickSettingButton("≡", "Margen") {
                    val next = when {
                        prefs.marginDp < 16 -> 16
                        prefs.marginDp < 24 -> 24
                        prefs.marginDp < 32 -> 32
                        else -> 12
                    }
                    onPrefsChange(prefs.copy(marginDp = next))
                }
                QuickSettingButton("☰", "Interlineado") {
                    val next = when {
                        prefs.lineHeight < 1.4f -> 1.45f
                        prefs.lineHeight < 1.7f -> 1.75f
                        prefs.lineHeight < 2.0f -> 2.05f
                        else -> 1.3f
                    }
                    onPrefsChange(prefs.copy(lineHeight = next))
                }
                QuickSettingButton("☀", "Brillo") {
                    val next = when {
                        prefs.brightness < 0.55f -> 0.7f
                        prefs.brightness < 0.85f -> 0.95f
                        else -> 0.45f
                    }
                    onPrefsChange(prefs.copy(brightness = next))
                }
            }

            // Sliders detallados
            Text("Tamaño de letra: ${prefs.fontSizeSp}", color = Cream, fontSize = 13.sp)
            Slider(
                value = prefs.fontSizeSp.toFloat(),
                onValueChange = { onPrefsChange(prefs.copy(fontSizeSp = it.toInt())) },
                valueRange = 12f..32f,
                colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold)
            )
            Text("Margen: ${prefs.marginDp} dp", color = Cream, fontSize = 13.sp)
            Slider(
                value = prefs.marginDp.toFloat(),
                onValueChange = { onPrefsChange(prefs.copy(marginDp = it.toInt())) },
                valueRange = 8f..40f,
                colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold)
            )
            Text("Interlineado: ${"%.2f".format(prefs.lineHeight)}", color = Cream, fontSize = 13.sp)
            Slider(
                value = prefs.lineHeight,
                onValueChange = { onPrefsChange(prefs.copy(lineHeight = it)) },
                valueRange = 1.2f..2.2f,
                colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold)
            )
            Text("Brillo de página", color = Cream, fontSize = 13.sp)
            Slider(
                value = prefs.brightness,
                onValueChange = { onPrefsChange(prefs.copy(brightness = it)) },
                valueRange = 0.35f..1f,
                colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold)
            )

            // Tipo de letra
            Text("Tipo de letra", color = Cream, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("serif" to "Serif", "sans" to "Sans", "classic" to "Clásica").forEach { (id, label) ->
                    FilterChip(
                        selected = prefs.fontFamily == id,
                        onClick = { onPrefsChange(prefs.copy(fontFamily = id)) },
                        label = { Text(label, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Gold,
                            selectedLabelColor = Ink,
                            labelColor = Cream
                        )
                    )
                }
            }

            HorizontalDivider(color = Muted.copy(alpha = 0.3f))

            // Deshabilitar botones de navegación
            Row(
                Modifier.fillMaxWidth().clickable {
                    onPrefsChange(prefs.copy(showNavButtons = !prefs.showNavButtons))
                },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = !prefs.showNavButtons,
                    onCheckedChange = { onPrefsChange(prefs.copy(showNavButtons = !it)) },
                    colors = CheckboxDefaults.colors(checkedColor = Gold, uncheckedColor = Muted)
                )
                Text("Deshabilitar botones de navegación", color = Cream, fontSize = 13.sp)
            }

            // ORIENTACIÓN
            Text("ORIENTACIÓN", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                listOf(
                    "auto" to "Auto rotar",
                    "portrait" to "Retrato",
                    "landscape" to "Paisaje"
                ).forEach { (id, label) ->
                    FilterChip(
                        selected = prefs.orientation == id,
                        onClick = { onPrefsChange(prefs.copy(orientation = id)) },
                        label = { Text(label, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Gold,
                            selectedLabelColor = Ink,
                            labelColor = Cream
                        )
                    )
                }
            }

            // CAMBIAR PÁGINAS (estilos de animación)
            Text("CAMBIAR PÁGINAS", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PageTurnChip("Retirada", "curl", prefs.pageTurnStyle) { onPrefsChange(prefs.copy(pageTurnStyle = it)) }
                    PageTurnChip("Superposición", "fade", prefs.pageTurnStyle) { onPrefsChange(prefs.copy(pageTurnStyle = it)) }
                    PageTurnChip("Cambio", "slide", prefs.pageTurnStyle) { onPrefsChange(prefs.copy(pageTurnStyle = it)) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PageTurnChip("Voluta", "scroll", prefs.pageTurnStyle) { onPrefsChange(prefs.copy(pageTurnStyle = it)) }
                    PageTurnChip("Sin animación", "none", prefs.pageTurnStyle) { onPrefsChange(prefs.copy(pageTurnStyle = it)) }
                    PageTurnChip("Desplazamiento", "slide", prefs.pageTurnStyle) { onPrefsChange(prefs.copy(pageTurnStyle = it)) }
                }
            }

            // Mano izquierda
            Row(
                Modifier.fillMaxWidth().clickable {
                    onPrefsChange(prefs.copy(leftHanded = !prefs.leftHanded))
                },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = prefs.leftHanded,
                    onCheckedChange = { onPrefsChange(prefs.copy(leftHanded = it)) },
                    colors = CheckboxDefaults.colors(checkedColor = Gold, uncheckedColor = Muted)
                )
                Text("Volteando con la mano izquierda", color = Cream, fontSize = 13.sp)
            }

            HorizontalDivider(color = Muted.copy(alpha = 0.3f))

            Text(
                "Pasar de hoja: desliza el dedo, toca el borde izquierdo o derecho, o usa las flechas.",
                color = Muted, fontSize = 11.sp, lineHeight = 16.sp
            )

            // Separador visual
            Text("Separador de página", color = Cream, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilterChip(
                    selected = item.bookmarkStyle == "RIBBON" || item.bookmarkStyle.isBlank(),
                    onClick = { onUpdateItem(item.copy(bookmarkStyle = "RIBBON")) },
                    label = { Text("Cinta") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Gold,
                        selectedLabelColor = Ink,
                        labelColor = Cream
                    )
                )
            }
        }
    }
}

@Composable
private fun QuickSettingButton(symbol: String, label: String, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(6.dp)
    ) {
        Box(
            Modifier
                .size(48.dp)
                .background(Ink.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                .border(1.dp, Muted.copy(alpha = 0.25f), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(symbol, color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(4.dp))
        Text(label, color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun PageTurnChip(label: String, style: String, current: String, onSelect: (String) -> Unit) {
    FilterChip(
        selected = current == style,
        onClick = { onSelect(style) },
        label = { Text(label, fontSize = 11.sp) },
        modifier = Modifier.height(36.dp),
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = Gold,
            selectedLabelColor = Ink,
            labelColor = Cream
        )
    )
}

// ── Separador visual de página ─────────────────────────────────────────────────

@Composable
fun BookmarkDivider(item: LibraryItem) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(48.dp)
            .background(Panel)
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BookCover(item, Modifier.size(width = 25.dp, height = 36.dp))
        Spacer(Modifier.width(10.dp))
        Text("Continuarás aquí", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.weight(1f))
        LibIcon(LibIconKind.BOOKMARK, tint = Gold, size = 20.dp, filled = true)
    }
}

/** Marcapáginas de tela: rectángulo rojo con muesca en V y un hilo dorado en el centro. */
@Composable
fun BookmarkRibbon(modifier: Modifier = Modifier) {
    Canvas(modifier.size(width = 26.dp, height = 78.dp)) {
        val w = size.width
        val h = size.height
        val path = Path().apply {
            moveTo(0f, 0f)
            lineTo(w, 0f)
            lineTo(w, h)
            lineTo(w / 2f, h - w * 0.6f)
            lineTo(0f, h)
            close()
        }
        drawPath(path, Color(0xFFB3322F))
        drawRect(Color(0x33FFFFFF), topLeft = Offset(w * 0.12f, 0f), size = Size(w * 0.14f, h - w * 0.7f))
        drawRect(Gold, topLeft = Offset(w * 0.46f, 0f), size = Size(w * 0.08f, h - w * 0.65f))
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// HELPERS COMUNES
// ══════════════════════════════════════════════════════════════════════════════

@Composable
private fun Message(text: String) {
    Box(Modifier.fillMaxSize().padding(28.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Cream, fontSize = 15.sp, lineHeight = 22.sp, textAlign = TextAlign.Center)
    }
}

/**
 * Detecta el deslizamiento horizontal acumulando el recorrido completo del dedo
 * (comparar solo el delta de cada evento casi nunca llega al umbral).
 */
@Composable
private fun Modifier.pageSwipe(onNext: () -> Unit, onPrev: () -> Unit): Modifier {
    val next by rememberUpdatedState(onNext)
    val prev by rememberUpdatedState(onPrev)
    return pointerInput(Unit) {
        var total = 0f
        detectHorizontalDragGestures(
            onDragStart = { total = 0f },
            onDragEnd = { if (total < -80f) next() else if (total > 80f) prev() },
            onDragCancel = { total = 0f }
        ) { _, amount -> total += amount }
    }
}

/** Animación de paso de página según el estilo elegido en ajustes */
@Composable
private fun <T> PagedContent(
    state: T,
    goingForward: Boolean,
    pageTurnStyle: String = "slide",
    modifier: Modifier = Modifier,
    content: @Composable (T) -> Unit
) {
    val forward = goingForward
    AnimatedContent(
        targetState = state,
        transitionSpec = {
            when (pageTurnStyle) {
                "none" -> EnterTransition.None togetherWith ExitTransition.None
                "fade" -> fadeIn(tween(280)) togetherWith fadeOut(tween(280))
                "curl" -> {
                    // Aproximación a “retirada / curl”: slide + scale suave
                    if (forward) {
                        (slideInHorizontally(tween(320)) { it / 2 } + fadeIn(tween(320)) +
                            scaleIn(initialScale = 0.92f, animationSpec = tween(320)))
                            .togetherWith(
                                slideOutHorizontally(tween(320)) { -it / 3 } + fadeOut(tween(280)) +
                                    scaleOut(targetScale = 0.96f, animationSpec = tween(320))
                            )
                    } else {
                        (slideInHorizontally(tween(320)) { -it / 2 } + fadeIn(tween(320)) +
                            scaleIn(initialScale = 0.92f, animationSpec = tween(320)))
                            .togetherWith(
                                slideOutHorizontally(tween(320)) { it / 3 } + fadeOut(tween(280)) +
                                    scaleOut(targetScale = 0.96f, animationSpec = tween(320))
                            )
                    }
                }
                "scroll" -> {
                    // Voluta / scroll vertical-ish
                    if (forward) {
                        (slideInVertically(tween(300)) { it / 4 } + fadeIn(tween(250)))
                            .togetherWith(slideOutVertically(tween(300)) { -it / 4 } + fadeOut(tween(250)))
                    } else {
                        (slideInVertically(tween(300)) { -it / 4 } + fadeIn(tween(250)))
                            .togetherWith(slideOutVertically(tween(300)) { it / 4 } + fadeOut(tween(250)))
                    }
                }
                else -> { // slide (Cambio / Desplazamiento)
                    if (forward) {
                        (slideInHorizontally(tween(240)) { it } + fadeIn(tween(200)))
                            .togetherWith(slideOutHorizontally(tween(240)) { -it } + fadeOut(tween(200)))
                    } else {
                        (slideInHorizontally(tween(240)) { -it } + fadeIn(tween(200)))
                            .togetherWith(slideOutHorizontally(tween(240)) { it } + fadeOut(tween(200)))
                    }
                }
            }
        },
        label = "page_anim",
        modifier = modifier
    ) { s -> content(s) }
}

// ══════════════════════════════════════════════════════════════════════════════
// EPUB — páginas reales: el capítulo se reparte en columnas del ancho de la pantalla
// y cada «hoja» es una columna (un solo WebView por capítulo, sin recargar).
// ══════════════════════════════════════════════════════════════════════════════

private const val EPUB_HOST = "libra.local"

private class EpubTheme {
    @Volatile var mode: Int = 2          // 0 dark, 1 sepia, 2 white, 3 black
    @Volatile var fontSizePx: Int = 18
    @Volatile var lineHeight: Float = 1.55f
    @Volatile var marginPx: Int = 20
}

/** Preferencias de lectura en memoria (se aplican a EPUB/TXT) */
data class ReadingPrefs(
    val themeMode: Int = 2,       // 0 oscuro, 1 sepia, 2 blanco, 3 negro
    val fontSizeSp: Int = 18,
    val lineHeight: Float = 1.55f,
    val marginDp: Int = 20,
    val brightness: Float = 1f,   // 0.3 .. 1.0
    val fontFamily: String = "serif",  // serif | sans | classic
    // Nuevas opciones inspiradas en el lector de referencia
    val pageTurnStyle: String = "slide", // slide | fade | curl | none | scroll
    val orientation: String = "auto",    // auto | portrait | landscape
    val showNavButtons: Boolean = true,
    val leftHanded: Boolean = false      // voltear con mano izquierda
)

private fun chapterUrl(path: String): String =
    Uri.Builder().scheme("https").authority(EPUB_HOST)
        .encodedPath("/" + Uri.encode(path, "/")).build().toString()

private fun styleFor(prefs: ReadingPrefs): String {
    val (bg, fg, link) = when (prefs.themeMode) {
        0 -> Triple("#0B1426", "#F3E6C8", "#D4AF37") // oscuro Libellum
        1 -> Triple("#F4ECD8", "#3B2F1E", "#8A5A1F") // sepia
        3 -> Triple("#000000", "#E0E0E0", "#88AAFF") // negro (fg más claro para contraste)
        else -> Triple("#FFFFFF", "#111111", "#1A5FB4") // blanco
    }
    val pad = prefs.marginDp.coerceIn(8, 48)
    val fs = prefs.fontSizeSp.coerceIn(12, 32)
    val lh = prefs.lineHeight.coerceIn(1.2f, 2.4f)
    val ff = when (prefs.fontFamily) {
        "sans" -> "sans-serif"
        "classic" -> "Georgia, 'Times New Roman', serif"
        else -> "serif"
    }
    // Paginación reflowable tipo Kindle / Google Play Libros:
    // - Cada «página» es una columna del ANCHO de la pantalla llena de varias líneas de texto.
    // - El body tiene altura fija = viewport → el texto fluye de arriba abajo y, al llenar
    //   la altura, salta a la siguiente columna (siguiente hoja).
    // - Al pasar de hoja el texto continúa exactamente donde terminó; no hay scroll horizontal
    //   de una sola línea ni carrusel de caracteres.
    return (
        "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no\">" +
        "<style>" +
        // ── Reset fuerte: anular CSS del EPUB que fuerza una sola línea o scroll horizontal ──
        "html,body,div,span,p,h1,h2,h3,h4,h5,h6,li,td,th,blockquote,section,article,aside," +
        "header,footer,main,nav,figure,figcaption,pre,code,a,em,i,b,strong,small,cite,font{" +
        "box-sizing:border-box !important;" +
        "white-space:normal !important;" +          // NUNCA nowrap: el texto debe partir en líneas
        "word-wrap:break-word !important;" +
        "overflow-wrap:break-word !important;" +
        "word-break:normal !important;" +
        "writing-mode:horizontal-tb !important;" +  // nunca vertical-rl / sideways
        "direction:ltr !important;" +
        "text-orientation:mixed !important;" +
        "float:none !important;" +
        "position:static !important;" +
        "max-width:100% !important;" +
        "orphans:2 !important;widows:2 !important;" +
        "break-before:auto !important;break-after:auto !important;" +
        "-webkit-column-break-before:auto !important;-webkit-column-break-after:auto !important;" +
        "page-break-before:auto !important;page-break-after:auto !important;}" +
        // html: scroll horizontal programático entre páginas; sin scroll vertical ni barra visible
        "html{width:100% !important;height:100% !important;" +
        "overflow-x:auto !important;overflow-y:hidden !important;" +
        "margin:0 !important;padding:0 !important;background:$bg !important;" +
        "-ms-overflow-style:none !important;scrollbar-width:none !important;}" +
        "html::-webkit-scrollbar{display:none !important;width:0 !important;height:0 !important;}" +
        // body: altura fija = viewport → el texto llena la página en vertical y pasa a la
        // siguiente columna (hoja). column-width = 100vw = una página completa visible.
        "body{display:block !important;width:auto !important;" +
        "height:100vh !important;max-height:100vh !important;min-height:100vh !important;" +
        "margin:0 !important;padding:${pad}px !important;box-sizing:border-box !important;" +
        "-webkit-column-width:100vw !important;column-width:100vw !important;" +
        "-webkit-column-gap:0px !important;column-gap:0px !important;" +
        "-webkit-column-fill:auto !important;column-fill:auto !important;" +
        "-webkit-column-rule:none !important;column-rule:none !important;" +
        "background:$bg !important;color:$fg !important;" +
        "font-size:${fs}px !important;line-height:$lh !important;font-family:$ff !important;" +
        "overflow:visible !important;max-width:none !important;" +
        "text-align:start !important;" +
        "white-space:normal !important;" +
        "word-wrap:break-word !important;overflow-wrap:break-word !important;" +
        "-webkit-hyphens:auto !important;hyphens:auto !important;}" +
        // Párrafos y bloques: bloque vertical, ancho completo de la columna
        "p,div,section,article,blockquote,li,h1,h2,h3,h4,h5,h6{" +
        "display:block !important;width:auto !important;max-width:100% !important;" +
        "white-space:normal !important;float:none !important;}" +
        "p,div,span,li,td,th,h1,h2,h3,h4,h5,h6,blockquote,section,article,em,i,b,strong,small,cite,pre,font,a{" +
        "color:inherit !important;font-size:inherit !important;line-height:inherit !important;" +
        "font-family:inherit !important;white-space:normal !important;}" +
        "h1{font-size:1.5em !important;}h2{font-size:1.3em !important;}h3{font-size:1.15em !important;}" +
        "h4,h5,h6{font-size:1.05em !important;}" +
        "small{font-size:0.85em !important;}" +
        "h1,h2,h3,h4,h5,h6{margin-top:0.5em !important;margin-bottom:0.4em !important;" +
        "break-after:avoid !important;-webkit-column-break-after:avoid !important;}" +
        "p{margin-top:0 !important;margin-bottom:0.65em !important;text-indent:0 !important;}" +
        "a{color:$link !important;}" +
        "pre,code{white-space:pre-wrap !important;word-break:break-word !important;}" +
        "table{width:100% !important;table-layout:fixed !important;border-collapse:collapse !important;}" +
        "ul,ol{padding-left:1.2em !important;margin:0.4em 0 !important;}" +
        // Imágenes: visibles, centradas, caben en la página
        "img,svg,video,image,picture{display:block !important;margin-left:auto !important;margin-right:auto !important;" +
        "max-width:100% !important;max-height:calc(100% - ${pad * 2}px) !important;" +
        "height:auto !important;width:auto !important;min-width:0 !important;min-height:0 !important;" +
        "object-fit:contain !important;visibility:visible !important;opacity:1 !important;" +
        "break-inside:avoid !important;-webkit-column-break-inside:avoid !important;" +
        "page-break-inside:avoid !important;background:transparent !important;border:0 !important;}" +
        "figure,figcaption,picture{display:block !important;max-width:100% !important;" +
        "break-inside:avoid !important;-webkit-column-break-inside:avoid !important;}" +
        "*{-webkit-user-select:text !important;user-select:text !important;}" +
        "span[style*=\"background-color\"]{color:inherit !important;}" +
        "div,section,article,aside,header,footer,main,nav{height:auto !important;min-height:0 !important;max-height:none !important;}" +
        "img[src],img[data-src],svg image{display:block !important;visibility:visible !important;opacity:1 !important;}" +
        "</style>"
    )
}

private val IC = RegexOption.IGNORE_CASE
private val SCRIPT_SELF_REGEX = Regex("<script\\b[^>]*/\\s*>", IC)
private val SCRIPT_REGEX = Regex("<script\\b[\\s\\S]*?</script\\s*>", IC)
private val TITLE_SELF_REGEX = Regex("<title\\b[^>]*/\\s*>", IC)
private val TITLE_REGEX = Regex("<title\\b[\\s\\S]*?</title\\s*>", IC)
private val XML_PROLOG_REGEX = Regex("^\\s*<\\?xml[^>]*\\?>")
private val SELF_CLOSING_REGEX = Regex("<([a-zA-Z][a-zA-Z0-9:_-]*)(\\s[^<>]*?)?\\s*/>")
private val VOID_TAGS = setOf(
    "area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"
)

/**
 * Los capítulos EPUB son XHTML, pero el WebView los lee como HTML. En HTML una etiqueta como
 * <title/> o <div/> NO se cierra sola y se «traga» todo el capítulo (la página sale en blanco).
 * Aquí se quitan los scripts y el título, y se convierten las etiquetas autocerradas en pares.
 */
private fun fixHtml(raw: String): String {
    var s = raw.replace(XML_PROLOG_REGEX, "")
    s = SCRIPT_SELF_REGEX.replace(s, "")
    s = SCRIPT_REGEX.replace(s, "")
    s = TITLE_SELF_REGEX.replace(s, "")
    s = TITLE_REGEX.replace(s, "")
    s = SELF_CLOSING_REGEX.replace(s) { m ->
        val name = m.groupValues[1]
        if (name.lowercase() in VOID_TAGS) m.value else "<" + name + m.groupValues[2] + "></" + name + ">"
    }
    return s
}

/**
 * Inyecta CSS de lectura y reescribe rutas relativas de imágenes/CSS/fuentes
 * a URLs absolutas https://libra.local/... para que el WebView las pida
 * por shouldInterceptRequest y se vean correctamente (no espacios en blanco).
 */
private fun injectStyle(
    rawHtml: String,
    prefs: ReadingPrefs,
    chapterPath: String = "",
    pkg: EpubPackage? = null
): String {
    var html = fixHtml(rawHtml)
    if (pkg != null && chapterPath.isNotBlank()) {
        html = rewriteResourceUrls(html, chapterPath, pkg)
    }
    val style = styleFor(prefs)
    val index = html.indexOf("</head>", ignoreCase = true)
    return if (index >= 0) html.substring(0, index) + style + html.substring(index) else style + html
}

/** ¿Es una URL externa o especial que no debe reescribirse? */
private fun isExternalOrSpecial(href: String): Boolean {
    if (href.isEmpty()) return true
    val h = href.trim()
    return h.startsWith("#") ||
        h.startsWith("data:", ignoreCase = true) ||
        h.startsWith("javascript:", ignoreCase = true) ||
        h.startsWith("http://", ignoreCase = true) ||
        h.startsWith("https://", ignoreCase = true) ||
        h.startsWith("mailto:", ignoreCase = true) ||
        h.startsWith("blob:", ignoreCase = true)
}

/** Convierte src/href relativos de img, image, source, link, video, audio a https://libra.local/ruta */
private fun rewriteResourceUrls(html: String, chapterPath: String, pkg: EpubPackage): String {
    // Atributos entre comillas
    val attrPattern = Regex(
        """(?i)(\b(?:src|href|xlink:href|poster)\s*=\s*)(["'])([^"']+)\2"""
    )
    var out = attrPattern.replace(html) { m ->
        val prefix = m.groupValues[1]
        val quote = m.groupValues[2]
        val href = m.groupValues[3].trim()
        if (isExternalOrSpecial(href)) {
            m.value
        } else {
            val resolved = pkg.resolveRelative(chapterPath, href)
            val abs = "https://$EPUB_HOST/" + resolved.trimStart('/')
            "$prefix$quote$abs$quote"
        }
    }
    // Atributos sin comillas (algunos EPUB mal formados): src=ruta.jpg
    val unquoted = Regex(
        """(?i)(\b(?:src|href|xlink:href|poster)\s*=\s*)([^\s"'>=]+)"""
    )
    out = unquoted.replace(out) { m ->
        val prefix = m.groupValues[1]
        val href = m.groupValues[2].trim()
        if (isExternalOrSpecial(href) || href.startsWith("https://$EPUB_HOST")) {
            m.value
        } else {
            val resolved = pkg.resolveRelative(chapterPath, href)
            val abs = "https://$EPUB_HOST/" + resolved.trimStart('/')
            "$prefix\"$abs\""
        }
    }
    // url(...) en estilos inline del HTML
    out = rewriteCssUrls(out, chapterPath, pkg)
    return out
}

/** Reescribe url(...) relativas dentro de CSS o de bloques style= */
private fun rewriteCssUrls(css: String, basePath: String, pkg: EpubPackage): String {
    val urlPattern = Regex(
        """(?i)(url\s*\(\s*)(["']?)([^"')]+)\2(\s*\))"""
    )
    return urlPattern.replace(css) { m ->
        val prefix = m.groupValues[1]
        val quote = m.groupValues[2]
        val href = m.groupValues[3].trim()
        val suffix = m.groupValues[4]
        if (isExternalOrSpecial(href) || href.startsWith("https://$EPUB_HOST")) {
            m.value
        } else {
            val resolved = pkg.resolveRelative(basePath, href)
            val abs = "https://$EPUB_HOST/" + resolved.trimStart('/')
            "$prefix$quote$abs$quote$suffix"
        }
    }
}

/** Lee un TXT: UTF-8 si es válido; si no, Windows-1252/Latin-1 (típico de archivos viejos en español). */
internal fun readTextSmart(file: File): String {
    val bytes = file.readBytes()
    return try {
        Charsets.UTF_8.newDecoder()
            .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
            .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
            .decode(java.nio.ByteBuffer.wrap(bytes)).toString().removePrefix("\uFEFF")
    } catch (_: Exception) {
        String(bytes, charset("windows-1252"))
    }
}

internal fun themeBgColor(mode: Int): Int = when (mode) {
    0 -> 0xFF0B1426.toInt()
    1 -> 0xFFF4ECD8.toInt()
    3 -> 0xFF000000.toInt()
    else -> 0xFFFFFFFF.toInt()
}

private fun emptyResponse(status: Int, reason: String) =
    WebResourceResponse("text/plain", "utf-8", status, reason, emptyMap(),
        ByteArrayInputStream(ByteArray(0)))

private fun serveEpub(pkg: EpubPackage, theme: EpubTheme, uri: Uri, prefs: ReadingPrefs): WebResourceResponse {
    if (uri.host != EPUB_HOST) return emptyResponse(403, "Blocked")
    return try {
        // path puede venir codificado (%20, etc.)
        val rawPath = uri.path?.removePrefix("/") ?: return emptyResponse(404, "Not found")
        val path = try {
            java.net.URLDecoder.decode(rawPath.replace("+", "%2B"), "UTF-8")
        } catch (_: Exception) {
            rawPath
        }
        val bytes = pkg.readBytes(path) ?: return emptyResponse(404, "Not found")
        val mime = pkg.mimeOf(path)
        if (mime.contains("html") || mime.contains("xhtml")) {
            val styled = injectStyle(
                String(bytes, Charsets.UTF_8),
                prefs.copy(
                    themeMode = theme.mode,
                    fontSizeSp = theme.fontSizePx,
                    lineHeight = theme.lineHeight,
                    marginDp = theme.marginPx
                ),
                chapterPath = path,
                pkg = pkg
            )
            WebResourceResponse(
                "text/html", "utf-8",
                ByteArrayInputStream(styled.toByteArray(Charsets.UTF_8))
            )
        } else if (mime.contains("css") || path.endsWith(".css", ignoreCase = true)) {
            // CSS del libro: reescribir url(...) relativas para que imágenes/fuentes carguen
            val cssText = String(bytes, Charsets.UTF_8)
            val rewritten = rewriteCssUrls(cssText, path, pkg)
            val headers = mapOf(
                "Access-Control-Allow-Origin" to "*",
                "Cache-Control" to "max-age=3600"
            )
            WebResourceResponse(
                "text/css", "utf-8", 200, "OK", headers,
                ByteArrayInputStream(rewritten.toByteArray(Charsets.UTF_8))
            )
        } else {
            // Imágenes, fuentes y resto: MIME correcto + cabeceras
            val headers = mapOf(
                "Access-Control-Allow-Origin" to "*",
                "Cache-Control" to "max-age=3600",
                "Content-Length" to bytes.size.toString()
            )
            // Algunos WebView fallan si encoding no es null en binarios
            WebResourceResponse(mime, null, 200, "OK", headers, ByteArrayInputStream(bytes))
        }
    } catch (_: Exception) {
        emptyResponse(404, "Not found")
    }
}

@Composable
private fun EpubReader(
    item: LibraryItem,
    onSave: (Long, Int) -> Unit,
    highlightDao: HighlightDao,
    onUpdateItem: (LibraryItem) -> Unit,
    prefs: ReadingPrefs,
    onPrefsChange: (ReadingPrefs) -> Unit,
    showContents: Boolean = false,
    onContentsDismiss: () -> Unit = {},
    onChapterLabel: (String) -> Unit = {},
    onToggleChrome: () -> Unit = {}
) {
    val pkg = remember(item.id) { runCatching { EpubPackage(File(item.localPath)) }.getOrNull() }
    DisposableEffect(pkg) { onDispose { pkg?.close() } }
    if (pkg == null || pkg.spine.isEmpty()) {
        Message("No se pudo abrir este EPUB. Puede estar dañado o protegido con DRM.")
        return
    }

    val theme = remember { EpubTheme() }
    theme.mode = prefs.themeMode
    theme.fontSizePx = prefs.fontSizeSp
    theme.lineHeight = prefs.lineHeight
    theme.marginPx = prefs.marginDp

    val highlightsFlow = remember(item.id) { highlightDao.observeByBook(item.id) }
    val allHighlights by highlightsFlow.collectAsState(initial = emptyList())

    var spineIndex by remember(item.id) {
        mutableIntStateOf(item.lastPosition.toInt().coerceIn(0, pkg.spine.lastIndex))
    }
    var subPage by remember { mutableIntStateOf(0) }          // hoja dentro del capítulo (0-based)
    var subPageCount by remember { mutableIntStateOf(1) }
    var startAtEnd by remember { mutableStateOf(false) }      // al retroceder de capítulo: ir a su última hoja
    var anchor by remember { mutableStateOf<String?>(null) }  // al abrir un enlace del índice
    val webViewRef = remember { mutableStateOf<WebView?>(null) }
    val scope = rememberCoroutineScope()

    // Etiquetas legibles de capítulos a partir del path del spine
    val chapterLabels = remember(pkg.spine) {
        pkg.spine.mapIndexed { i, path ->
            val name = path.substringAfterLast('/').substringBeforeLast('.')
                .replace('_', ' ').replace('-', ' ')
            if (name.isBlank() || name.all { it.isDigit() }) "Capítulo ${i + 1}"
            else name.replaceFirstChar { it.uppercase() }
        }
    }
    LaunchedEffect(spineIndex, subPage, subPageCount) {
        val pct = ((spineIndex + (subPage + 1).toFloat() / subPageCount.coerceAtLeast(1))
            / pkg.spine.size.coerceAtLeast(1) * 100).toInt().coerceIn(0, 100)
        onChapterLabel("Cap. ${spineIndex + 1}/${pkg.spine.size} · ${chapterLabels.getOrElse(spineIndex) { "Capítulo" }} · Hoja ${subPage + 1}/$subPageCount")
        onSave(spineIndex.toLong(), pct)
    }

    var dictWord by remember { mutableStateOf<String?>(null) }
    var pendingHighlight by remember { mutableStateOf<String?>(null) }

    // Subrayados del capítulo actual, como JSON, para pintarlos dentro de la página
    val highlightsJson = remember(allHighlights, spineIndex) {
        val arr = JSONArray()
        allHighlights.filter { it.chapterIndex == spineIndex }.forEach { h ->
            arr.put(
                JSONObject()
                    .put("t", h.selectedText)
                    .put("c", String.format("#%06X", (h.colorArgb and 0xFFFFFFL).toInt()))
            )
        }
        arr.toString()
    }

    fun goPage(p: Int) {
        subPage = p
        webViewRef.value?.evaluateJavascript("libraUserGo($p);", null)
    }

    fun nextPage() {
        if (subPage < subPageCount - 1) {
            goPage(subPage + 1)
        } else if (spineIndex < pkg.spine.lastIndex) {
            startAtEnd = false
            anchor = null
            spineIndex++
        }
    }

    fun prevPage() {
        if (subPage > 0) {
            goPage(subPage - 1)
        } else if (spineIndex > 0) {
            startAtEnd = true
            anchor = null
            spineIndex--
        }
    }

    fun openLink(target: Int, id: String?) {
        if (target == spineIndex) {
            if (id != null) {
                webViewRef.value?.evaluateJavascript("libraGoAnchor(${JSONObject.quote(id)});", null)
            }
        } else {
            startAtEnd = false
            anchor = id
            spineIndex = target
        }
    }

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            EpubWebView(
                pkg = pkg,
                theme = theme,
                index = spineIndex,
                prefs = prefs,
                highlightsJson = highlightsJson,
                startAtEnd = startAtEnd,
                anchor = anchor,
                modifier = Modifier.fillMaxSize(),
                onDefine = { w -> dictWord = w },
                onHighlight = { t -> pendingHighlight = t },
                onWebViewReady = { wv -> webViewRef.value = wv },
                onMetrics = { total, page ->
                    subPageCount = total.coerceAtLeast(1)
                    subPage = page.coerceIn(0, subPageCount - 1)
                    startAtEnd = false
                    anchor = null
                },
                onTurn = { forward -> if (forward) nextPage() else prevPage() },
                onChapterLink = { target, id -> openLink(target, id) },
                onToggleChrome = onToggleChrome
            )
            // Veladura de brillo (no intercepta toques)
            if (prefs.brightness < 0.99f) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = (1f - prefs.brightness).coerceIn(0f, 0.65f)))
                )
            }
        }

        if (prefs.showNavButtons) {
            Row(
                Modifier.fillMaxWidth().background(Panel).padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (prefs.leftHanded) {
                    LibIconButton(LibIconKind.CHEVRON_RIGHT, onClick = { prevPage() }, tint = Gold)
                } else {
                    LibIconButton(LibIconKind.CHEVRON_LEFT, onClick = { prevPage() }, tint = Gold)
                }
                Text(
                    "Cap. ${spineIndex + 1}/${pkg.spine.size} · Hoja ${subPage + 1}/$subPageCount",
                    color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center
                )
                if (prefs.leftHanded) {
                    LibIconButton(LibIconKind.CHEVRON_LEFT, onClick = { nextPage() }, tint = Gold)
                } else {
                    LibIconButton(LibIconKind.CHEVRON_RIGHT, onClick = { nextPage() }, tint = Gold)
                }
                LibIconButton(
                    LibIconKind.THEME,
                    onClick = { onPrefsChange(prefs.copy(themeMode = (prefs.themeMode + 1) % 4)) },
                    tint = Gold
                )
            }
        }
    }

    // Panel de capítulos y avance
    if (showContents) {
        ModalBottomSheet(
            onDismissRequest = onContentsDismiss,
            containerColor = Panel
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 24.dp)
            ) {
                Text("CONTENIDO", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(Modifier.height(8.dp))
                Text("Avance del libro", color = Cream, fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                val pct = ((spineIndex + (subPage + 1).toFloat() / subPageCount.coerceAtLeast(1))
                    / pkg.spine.size.coerceAtLeast(1) * 100).toInt().coerceIn(0, 100)
                LinearProgressIndicator(
                    progress = { pct / 100f },
                    modifier = Modifier.fillMaxWidth().height(6.dp),
                    color = Gold,
                    trackColor = Muted.copy(alpha = 0.25f)
                )
                Text(
                    "$pct% · Cap. ${spineIndex + 1} de ${pkg.spine.size} · Hoja ${subPage + 1}/$subPageCount",
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)
                )
                Spacer(Modifier.height(14.dp))
                Text("CAPÍTULOS", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(Modifier.height(6.dp))
                LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    items(pkg.spine.size) { i ->
                        val selected = i == spineIndex
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    startAtEnd = false
                                    anchor = null
                                    spineIndex = i
                                    onContentsDismiss()
                                }
                                .background(if (selected) Gold.copy(alpha = 0.15f) else Color.Transparent)
                                .padding(vertical = 10.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "${i + 1}.",
                                color = if (selected) Gold else Muted,
                                fontSize = 12.sp,
                                modifier = Modifier.width(28.dp)
                            )
                            Text(
                                chapterLabels.getOrElse(i) { "Capítulo ${i + 1}" },
                                color = if (selected) Cream else Cream.copy(alpha = 0.85f),
                                fontSize = 14.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            if (selected) {
                                Text("●", color = Gold, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    dictWord?.let { w ->
        DictionaryDialog(word = w, onDismiss = { dictWord = null })
    }
    pendingHighlight?.let { text ->
        HighlightColorPicker(
            selectedText = text,
            onConfirm = { colorArgb, note ->
                scope.launch {
                    highlightDao.insert(
                        Highlight(
                            id = UUID.randomUUID().toString(),
                            bookId = item.id,
                            bookTitle = item.title,
                            chapterIndex = spineIndex,
                            chapterTitle = "Capítulo ${spineIndex + 1}",
                            selectedText = text,
                            note = note,
                            colorArgb = colorArgb
                        )
                    )
                }
                pendingHighlight = null
            },
            onDismiss = { pendingHighlight = null }
        )
    }
}

private const val ID_DEFINE = 7001
private const val ID_HIGHLIGHT = 7002

/** Convierte el resultado de evaluateJavascript (un literal JSON) en texto normal. */
private fun decodeJsString(raw: String?): String {
    if (raw.isNullOrEmpty() || raw == "null") return ""
    return try {
        JSONArray("[$raw]").optString(0, "")
    } catch (_: Exception) {
        ""
    }
}

/**
 * WebView con menú de selección propio: «Copiar · Diccionario · Subrayar».
 * Así solo se abre UNA ventana a la vez y la barra nativa no se queda debajo.
 */
private class LibraWebView(context: Context) : WebView(context) {
    var onDefine: ((String) -> Unit)? = null
    var onHighlight: ((String) -> Unit)? = null

    override fun startActionMode(callback: ActionMode.Callback?): ActionMode? =
        super.startActionMode(wrap(callback))

    override fun startActionMode(callback: ActionMode.Callback?, type: Int): ActionMode? =
        super.startActionMode(wrap(callback), type)

    /** Deja «Copiar» y añade las dos acciones propias (Chromium añade Compartir, Buscar, etc.). */
    private fun decorate(menu: Menu) {
        for (i in menu.size() - 1 downTo 0) {
            val id = menu.getItem(i).itemId
            if (id != android.R.id.copy && id != ID_DEFINE && id != ID_HIGHLIGHT) menu.removeItem(id)
        }
        if (menu.findItem(ID_DEFINE) == null) menu.add(Menu.NONE, ID_DEFINE, Menu.NONE, "Diccionario")
        if (menu.findItem(ID_HIGHLIGHT) == null) menu.add(Menu.NONE, ID_HIGHLIGHT, Menu.NONE, "Subrayar")
    }

    private fun wrap(original: ActionMode.Callback?): ActionMode.Callback? {
        if (original == null) return null
        return object : ActionMode.Callback2() {
            override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
                original.onCreateActionMode(mode, menu)
                decorate(menu)
                return true
            }

            override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
                original.onPrepareActionMode(mode, menu)
                decorate(menu)
                return true
            }

            override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
                if (item.itemId == ID_DEFINE || item.itemId == ID_HIGHLIGHT) {
                    val define = item.itemId == ID_DEFINE
                    // Primero se lee la selección y solo después se cierra el menú (cerrarlo la borra)
                    evaluateJavascript("window.getSelection().toString()") { raw ->
                        val text = decodeJsString(raw).trim()
                        if (text.isNotEmpty()) {
                            if (define) onDefine?.invoke(text) else onHighlight?.invoke(text)
                        }
                        mode.finish()
                    }
                    return true
                }
                return original.onActionItemClicked(mode, item)
            }

            override fun onDestroyActionMode(mode: ActionMode) {
                original.onDestroyActionMode(mode)
            }

            override fun onGetContentRect(mode: ActionMode, view: View, outRect: Rect) {
                if (original is ActionMode.Callback2) {
                    original.onGetContentRect(mode, view, outRect)
                } else {
                    super.onGetContentRect(mode, view, outRect)
                }
            }
        }
    }
}

private class WebState {
    var key: String = ""
    var loaded: Boolean = false
    var applied: String = ""
}

/** Puente JS → Kotlin (los métodos se llaman desde un hilo del WebView: se vuelve al hilo principal). */
private class EpubBridge(
    private val metricsCb: (Int, Int) -> Unit,
    private val turnCb: (Boolean) -> Unit,
    private val chromeCb: () -> Unit = {}
) {
    private val main = Handler(Looper.getMainLooper())

    @JavascriptInterface
    fun onMetrics(total: Int, page: Int) {
        main.post { metricsCb(total, page) }
    }

    @JavascriptInterface
    fun onTurn(forward: Boolean) {
        main.post { turnCb(forward) }
    }

    @JavascriptInterface
    fun onToggleChrome() {
        main.post { chromeCb() }
    }
}

// Funciones JS del lector: paginación por columnas (flujo continuo), navegación, subrayados y toques.
// Modelo: body altura = 100vh + column-width = 100vw → el texto fluye columna a columna sin cortes.
private const val EPUB_JS = """
(function () {
  if (window.__libraReady) return;
  window.__libraReady = true;
  window.__libraPage = 0;
  window.__libraDone = {};

  // Ancho de una página = ancho visible del WebView (una columna)
  function pageWidth() {
    var iw = window.innerWidth || document.documentElement.clientWidth || 1;
    return iw < 1 ? 1 : iw;
  }
  // Número de hojas = scrollWidth / ancho de página (cada columna llena de líneas = una hoja)
  window.libraPages = function () {
    var iw = pageWidth();
    var sw = Math.max(
      document.documentElement.scrollWidth || 0,
      document.body ? document.body.scrollWidth : 0,
      document.documentElement.offsetWidth || 0
    );
    // redondeo hacia arriba para no perder la última fracción de texto
    var n = Math.ceil((sw - 1) / iw);
    return Math.max(1, n);
  };
  window.libraGo = function (n) {
    var iw = pageWidth();
    window.__libraPage = n;
    // scroll exacto a la columna (página) n — el texto de esa hoja se ve completo, multilínea
    window.scrollTo(Math.round(n * iw), 0);
  };
  function pageOfAnchor(anchor, total) {
    var el = document.getElementById(anchor) || document.getElementsByName(anchor)[0];
    var page = 0;
    if (el) {
      var r = el.getBoundingClientRect();
      var iw = window.innerWidth || 1;
      page = Math.floor((r.left + (window.scrollX || window.pageXOffset || 0)) / iw);
    }
    return Math.max(0, Math.min(total - 1, page));
  }
  // Limpia márgenes enormes, nowrap y <br> repetidos; fuerza texto multilínea vertical
  window.libraSanitize = function () {
    try {
      var limit = (window.innerHeight || 600) * 0.10;
      var body = document.body;
      if (body) {
        // Refuerzo de columnas y texto fluido (por si el CSS del libro lo anula después)
        body.style.setProperty('white-space', 'normal', 'important');
        body.style.setProperty('height', '100vh', 'important');
        body.style.setProperty('max-height', '100vh', 'important');
        body.style.setProperty('-webkit-column-width', '100vw', 'important');
        body.style.setProperty('column-width', '100vw', 'important');
        body.style.setProperty('-webkit-column-gap', '0px', 'important');
        body.style.setProperty('column-gap', '0px', 'important');
        body.style.setProperty('overflow', 'visible', 'important');
        body.style.setProperty('writing-mode', 'horizontal-tb', 'important');
      }
      var all = body ? body.getElementsByTagName('*') : [];
      var props = ['marginTop', 'marginBottom', 'paddingTop', 'paddingBottom'];
      var css = ['margin-top', 'margin-bottom', 'padding-top', 'padding-bottom'];
      for (var i = 0; i < all.length; i++) {
        var el = all[i];
        // Nunca una sola línea horizontal
        el.style.setProperty('white-space', 'normal', 'important');
        el.style.setProperty('writing-mode', 'horizontal-tb', 'important');
        if (el.style) {
          if (el.style.whiteSpace === 'nowrap') el.style.whiteSpace = 'normal';
        }
        var cs = window.getComputedStyle(el);
        for (var k = 0; k < props.length; k++) {
          var v = parseFloat(cs[props[k]]);
          if (v > limit) el.style.setProperty(css[k], '0.6em', 'important');
        }
      }
      var brs = body ? body.getElementsByTagName('br') : [];
      for (var j = brs.length - 1; j >= 0; j--) {
        var b = brs[j];
        var prev = b.previousSibling;
        while (prev && prev.nodeType === 3 && !prev.nodeValue.trim()) prev = prev.previousSibling;
        var prev2 = prev && prev.previousSibling;
        while (prev2 && prev2.nodeType === 3 && !prev2.nodeValue.trim()) prev2 = prev2.previousSibling;
        if (prev && prev.nodeName === 'BR' && prev2 && prev2.nodeName === 'BR' && b.parentNode) {
          b.parentNode.removeChild(b);
        }
      }
    } catch (e) {}
  };
  // Cuando cargan imágenes, se vuelve a medir el número de hojas (evita espacios en blanco / páginas cortadas)
  function watchImages() {
    try {
      var imgs = document.getElementsByTagName('img');
      for (var i = 0; i < imgs.length; i++) {
        var im = imgs[i];
        if (im.__libraWatched) continue;
        im.__libraWatched = true;
        // Forzar visibilidad por si el CSS del libro las oculta
        im.style.setProperty('visibility', 'visible', 'important');
        im.style.setProperty('opacity', '1', 'important');
        im.style.setProperty('display', 'block', 'important');
        im.style.setProperty('max-width', '100%', 'important');
        im.style.setProperty('height', 'auto', 'important');
        if (!im.complete) {
          im.addEventListener('load', function () {
            setTimeout(function () { if (window.libraRemeasure) window.libraRemeasure(); }, 40);
          });
          im.addEventListener('error', function () {
            // Si falla la carga, al menos no deje un hueco enorme
            this.style.maxHeight = '1px';
            this.style.margin = '0';
            setTimeout(function () { if (window.libraRemeasure) window.libraRemeasure(); }, 40);
          });
        }
      }
    } catch (e) {}
  }
  window.libraInit = function (startAtEnd, anchor) {
    window.libraSanitize();
    watchImages();
    // Forzar reflow para que scrollWidth refleje las columnas ya calculadas
    void document.body.offsetHeight;
    window.__libraEnd = !!startAtEnd;
    var total = window.libraPages();
    var page = 0;
    if (anchor) { page = pageOfAnchor(anchor, total); }
    else if (startAtEnd) { page = Math.max(0, total - 1); }
    window.libraGo(page);
    if (typeof LibraAndroid !== 'undefined') LibraAndroid.onMetrics(total, page);
    // Segunda pasada por si las imágenes tardan
    setTimeout(watchImages, 300);
    setTimeout(watchImages, 1200);
  };
  // Si cargan imágenes o tipografías después, el número de hojas cambia: se vuelve a medir.
  window.libraRemeasure = function () {
    watchImages();
    void document.body.offsetHeight;
    var total = window.libraPages();
    var page = window.__libraEnd ? Math.max(0, total - 1) : Math.min(window.__libraPage || 0, total - 1);
    window.libraGo(page);
    if (typeof LibraAndroid !== 'undefined') LibraAndroid.onMetrics(total, page);
  };
  window.libraUserGo = function (n) { window.__libraEnd = false; window.libraGo(n); };
  window.libraGoAnchor = function (anchor) {
    window.__libraEnd = false;
    var total = window.libraPages();
    var page = pageOfAnchor(anchor, total);
    window.libraGo(page);
    if (typeof LibraAndroid !== 'undefined') LibraAndroid.onMetrics(total, page);
  };

  function wrapRange(range, color) {
    var root = range.commonAncestorContainer;
    var nodes = [];
    if (root.nodeType === 3) { nodes.push(root); }
    else {
      var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
      var n;
      while ((n = walker.nextNode())) {
        var tag = n.parentNode && n.parentNode.nodeName;
        if (tag === 'SCRIPT' || tag === 'STYLE') continue;
        if (range.intersectsNode(n)) nodes.push(n);
      }
    }
    nodes.forEach(function (node) {
      var start = (node === range.startContainer) ? range.startOffset : 0;
      var end = (node === range.endContainer) ? range.endOffset : node.nodeValue.length;
      if (end <= start) return;
      if (!node.nodeValue.slice(start, end).trim()) return;
      var mid = start > 0 ? node.splitText(start) : node;
      if (end - start < mid.nodeValue.length) mid.splitText(end - start);
      var span = document.createElement('span');
      span.className = 'libra-hl';
      span.style.backgroundColor = color;
      span.style.color = '#1b1b1b';
      mid.parentNode.replaceChild(span, mid);
      span.appendChild(mid);
    });
  }

  // Pinta los subrayados guardados: busca cada texto y le pone fondo de color.
  window.libraApply = function (items) {
    try {
      var sel = window.getSelection();
      items.forEach(function (it) {
        var key = it.t + '|' + it.c;
        if (window.__libraDone[key]) return;
        window.__libraDone[key] = 1;
        it.t.split(/\n+/).forEach(function (part) {
          part = part.trim();
          if (part.length < 2) return;
          sel.removeAllRanges();
          if (window.find(part, false, false, true, false, false, false) && sel.rangeCount > 0) {
            wrapRange(sel.getRangeAt(0), it.c);
          }
        });
        sel.removeAllRanges();
      });
      window.scrollTo(window.__libraPage * (window.innerWidth || 1), 0);
    } catch (e) {}
  };

  // Bordes: pasar hoja. Centro: mostrar/ocultar opciones del lector.
  document.addEventListener('click', function (e) {
    var t = e.target;
    if (t && t.closest && t.closest('a')) return;
    var s = window.getSelection ? window.getSelection().toString() : '';
    if (s && s.length > 0) return;
    var x = e.clientX / (window.innerWidth || 1);
    if (x > 0.68) LibraAndroid.onTurn(true);
    else if (x < 0.32) LibraAndroid.onTurn(false);
    else if (LibraAndroid.onToggleChrome) LibraAndroid.onToggleChrome();
  });
})();
"""

@Composable
private fun EpubWebView(
    pkg: EpubPackage,
    theme: EpubTheme,
    index: Int,
    prefs: ReadingPrefs,
    highlightsJson: String,
    startAtEnd: Boolean,
    anchor: String?,
    modifier: Modifier = Modifier,
    onDefine: (String) -> Unit,
    onHighlight: (String) -> Unit,
    onWebViewReady: (WebView) -> Unit,
    onMetrics: (Int, Int) -> Unit,
    onTurn: (Boolean) -> Unit,
    onChapterLink: (Int, String?) -> Unit,
    onToggleChrome: () -> Unit = {}
) {
    val defineCb by rememberUpdatedState(onDefine)
    val highlightCb by rememberUpdatedState(onHighlight)
    val metricsCb by rememberUpdatedState(onMetrics)
    val turnCb by rememberUpdatedState(onTurn)
    val linkCb by rememberUpdatedState(onChapterLink)
    val chromeCb by rememberUpdatedState(onToggleChrome)
    val hlNow by rememberUpdatedState(highlightsJson)
    val startNow by rememberUpdatedState(startAtEnd)
    val anchorNow by rememberUpdatedState(anchor)

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            LibraWebView(ctx).apply {
                val state = WebState()
                tag = state
                setBackgroundColor(themeBgColor(prefs.themeMode))
                settings.javaScriptEnabled = true      // los <script> del libro se eliminan al servirlo
                settings.allowFileAccess = false
                settings.allowContentAccess = false
                settings.domStorageEnabled = false
                settings.loadsImagesAutomatically = true
                settings.blockNetworkImage = false
                settings.blockNetworkLoads = false
                // Layout: texto a ancho de pantalla, sin zoom raro que deje una sola línea
                settings.useWideViewPort = false
                settings.loadWithOverviewMode = false
                settings.textZoom = 100
                settings.setSupportZoom(false)
                settings.builtInZoomControls = false
                settings.displayZoomControls = false
                settings.layoutAlgorithm = android.webkit.WebSettings.LayoutAlgorithm.NORMAL
                isVerticalScrollBarEnabled = false
                isHorizontalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
                // this.* porque los parámetros de la función se llaman igual que las propiedades del WebView
                this.onDefine = { text -> defineCb(text) }
                this.onHighlight = { text -> highlightCb(text) }
                addJavascriptInterface(
                    EpubBridge(
                        { total, page -> metricsCb(total, page) },
                        { forward -> turnCb(forward) },
                        { chromeCb() }
                    ),
                    "LibraAndroid"
                )

                // Deslizar el dedo también pasa de hoja
                val detector = GestureDetector(
                    ctx,
                    object : GestureDetector.SimpleOnGestureListener() {
                        override fun onFling(
                            e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float
                        ): Boolean {
                            val start = e1 ?: return false
                            val dx = e2.x - start.x
                            val dy = e2.y - start.y
                            if (abs(dx) > 120f && abs(dx) > abs(dy) * 1.4f && abs(velocityX) > 350f) {
                                turnCb(dx < 0)
                            }
                            return false
                        }
                    }
                )
                setOnTouchListener { _, event ->
                    detector.onTouchEvent(event)
                    false
                }

                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(
                        view: WebView?, request: WebResourceRequest?
                    ): WebResourceResponse? {
                        val uri = request?.url ?: return null
                        return serveEpub(pkg, theme, uri, prefs)
                    }

                    override fun shouldOverrideUrlLoading(
                        view: WebView?, request: WebResourceRequest?
                    ): Boolean {
                        val uri = request?.url ?: return true
                        if (uri.host != EPUB_HOST) return true      // nada sale a internet desde el libro
                        val path = uri.path?.removePrefix("/")
                        val target = if (path != null) pkg.spine.indexOf(path) else -1
                        if (target >= 0) {
                            linkCb(target, uri.fragment)            // lo gestiona el lector (índice, notas…)
                            return true
                        }
                        return false
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        val wv = view ?: return
                        val st = wv.tag as? WebState ?: return
                        st.loaded = true
                        st.applied = hlNow
                        val anchorJs = anchorNow?.let { JSONObject.quote(it) } ?: "null"
                        wv.evaluateJavascript(EPUB_JS, null)
                        wv.evaluateJavascript(
                            "setTimeout(function(){libraInit(" + startNow + "," + anchorJs + ");" +
                                "libraApply(" + hlNow + ");},180);" +
                                "setTimeout(function(){libraRemeasure();},700);" +
                                "setTimeout(function(){libraRemeasure();},1800);",
                            null
                        )
                    }
                }
            }
        },
        update = { wv ->
            val st = wv.tag as WebState
            wv.setBackgroundColor(themeBgColor(prefs.themeMode))
            onWebViewReady(wv)
            val url = chapterUrl(pkg.spine[index])
            val key = "$url|${prefs.themeMode}|${prefs.fontSizeSp}|${prefs.marginDp}|${prefs.lineHeight}|${prefs.fontFamily}"
            if (st.key != key) {
                st.key = key
                st.loaded = false
                st.applied = ""
                wv.loadUrl(url)
            } else if (st.loaded && st.applied != highlightsJson) {
                // Se acaba de crear un subrayado: se pinta sin recargar el capítulo
                st.applied = highlightsJson
                wv.evaluateJavascript("libraApply($highlightsJson);", null)
            }
        }
    )
}

// ══════════════════════════════════════════════════════════════════════════════
// PDF
// ══════════════════════════════════════════════════════════════════════════════

private class PdfHolder(file: File) {
    private val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(pfd)
    private val mutex = Mutex()
    val pageCount: Int = renderer.pageCount

    suspend fun render(index: Int, width: Int): Bitmap = mutex.withLock {
        withContext(Dispatchers.IO) {
            val page = renderer.openPage(index)
            try {
                val height = (width.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(android.graphics.Color.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                bmp
            } finally { page.close() }
        }
    }

    fun close() {
        runCatching { renderer.close() }
        runCatching { pfd.close() }
    }
}

@Composable
private fun PdfReader(
    item: LibraryItem,
    onSave: (Long, Int) -> Unit,
    readingMode: String,
    highlightDao: HighlightDao,
    onUpdateItem: (LibraryItem) -> Unit
) {
    val holder = remember(item.id) { runCatching { PdfHolder(File(item.localPath)) }.getOrNull() }
    DisposableEffect(holder) { onDispose { holder?.close() } }
    if (holder == null || holder.pageCount == 0) {
        Message("No se pudo abrir este PDF.")
        return
    }

    var index by remember(item.id) {
        mutableIntStateOf(item.lastPosition.toInt().coerceIn(0, holder.pageCount - 1))
    }
    var goingForward by remember { mutableStateOf(true) }
    LaunchedEffect(index) { onSave(index.toLong(), (index + 1) * 100 / holder.pageCount) }

    Column(Modifier.fillMaxSize()) {
        BoxWithConstraints(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .pageSwipe(
                    onNext = { if (index < holder.pageCount - 1) { goingForward = true; index++ } },
                    onPrev = { if (index > 0) { goingForward = false; index-- } }
                )
        ) {
            val widthPx = constraints.maxWidth.coerceAtLeast(1)
            PagedContent(state = index, goingForward = goingForward, modifier = Modifier.fillMaxSize()) { pg ->
                val bitmap by produceState<Bitmap?>(null, pg, widthPx) {
                    value = try { holder.render(pg, widthPx) } catch (_: Exception) { null }
                }
                bitmap?.let {
                    Image(
                        bitmap = it.asImageBitmap(),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                } ?: Box(Modifier.fillMaxSize().background(Panel))
            }
        }
        Row(
            Modifier.fillMaxWidth().background(Panel).padding(4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            LibIconButton(LibIconKind.CHEVRON_LEFT, onClick = { if (index > 0) { goingForward = false; index-- } }, tint = Gold)
            Text("${index + 1} / ${holder.pageCount}", color = Muted, fontSize = 12.sp)
            LibIconButton(LibIconKind.CHEVRON_RIGHT, onClick = { if (index < holder.pageCount - 1) { goingForward = true; index++ } }, tint = Gold)
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// TXT / FB2
// ══════════════════════════════════════════════════════════════════════════════

@Composable
private fun TextFileReader(
    item: LibraryItem,
    onSave: (Long, Int) -> Unit,
    fb2: Boolean,
    highlightDao: HighlightDao,
    onUpdateItem: (LibraryItem) -> Unit,
    prefs: ReadingPrefs = ReadingPrefs()
) {
    val loaded by produceState<List<String>?>(null, item.id) {
        value = withContext(Dispatchers.IO) {
            try {
                val file = File(item.localPath)
                if (fb2) Fb2Parser.parse(file).paragraphs
                else readTextSmart(file).split(Regex("\\r?\\n"))
            } catch (_: Exception) { emptyList() }
        }
    }
    when {
        loaded == null -> Message("Abriendo…")
        loaded!!.isEmpty() -> Message("No se pudo leer el contenido de este archivo.")
        else -> ParagraphList(loaded!!, item, onSave, highlightDao, prefs)
    }
}

@Composable
private fun ParagraphList(
    paragraphs: List<String>,
    item: LibraryItem,
    onSave: (Long, Int) -> Unit,
    highlightDao: HighlightDao,
    prefs: ReadingPrefs = ReadingPrefs()
) {
    val highlights by highlightDao.observeByBook(item.id).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var fontSize by remember(prefs.fontSizeSp) { mutableIntStateOf(prefs.fontSizeSp) }
    LaunchedEffect(prefs.fontSizeSp) { fontSize = prefs.fontSizeSp }
    val pageBg = when (prefs.themeMode) {
        0 -> Color(0xFF0B1426)
        1 -> Color(0xFFF4ECD8)
        3 -> Color(0xFF000000)
        else -> Color(0xFFFFFFFF)
    }
    val pageFg = when (prefs.themeMode) {
        0 -> Color(0xFFF3E6C8)
        1 -> Color(0xFF3B2F1E)
        3 -> Color(0xFFCCCCCC)
        else -> Color(0xFF111111)
    }

    var dictWord by remember { mutableStateOf<String?>(null) }
    var pendingText by remember { mutableStateOf<Pair<String, Int>?>(null) }

// Páginas adaptadas a pantalla: agrupa párrafos en "hojas".
    // Ajusta la cantidad de caracteres según tamaño de fuente, interlineado y márgenes
    // para que el contenido refluya y continúe en la siguiente página.
    val pages = remember(paragraphs, prefs.fontSizeSp, prefs.marginDp, prefs.lineHeight) {
        val marginFactor = (28.0 / prefs.marginDp.coerceIn(8, 40)).coerceIn(0.7, 1.4)
        val charsPerPage = (2000.0 * (18.0 / prefs.fontSizeSp) * (1.55 / prefs.lineHeight) * marginFactor)
            .toInt().coerceIn(600, 4500)
        val result = mutableListOf<List<Pair<Int, String>>>()
        var bucket = mutableListOf<Pair<Int, String>>()
        var count = 0
        paragraphs.forEachIndexed { i, p ->
            if (p.isBlank()) return@forEachIndexed
            bucket.add(i to p)
            count += p.length
            if (count >= charsPerPage) {
                result.add(bucket.toList())
                bucket = mutableListOf()
                count = 0
            }
        }
        if (bucket.isNotEmpty()) result.add(bucket.toList())
        if (result.isEmpty()) listOf(listOf(0 to "")) else result.toList()
    }
    var pageIndex by remember(item.id) {
        mutableIntStateOf(
            item.lastPosition.toInt().coerceIn(0, (pages.size - 1).coerceAtLeast(0))
        )
    }
    LaunchedEffect(pageIndex, pages.size) {
        if (pageIndex > pages.lastIndex) pageIndex = pages.lastIndex.coerceAtLeast(0)
        onSave(pageIndex.toLong(), ((pageIndex + 1) * 100 / pages.size.coerceAtLeast(1)))
    }
    var goingForward by remember { mutableStateOf(true) }

    val goNext = {
        if (pageIndex < pages.lastIndex) { goingForward = true; pageIndex++ }
    }
    val goPrev = {
        if (pageIndex > 0) { goingForward = false; pageIndex-- }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(pageBg)
            .graphicsLayer { alpha = prefs.brightness }
    ) {
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = prefs.marginDp.dp, vertical = 12.dp)
                .pageSwipe(
                    onNext = if (prefs.leftHanded) goPrev else goNext,
                    onPrev = if (prefs.leftHanded) goNext else goPrev
                )
        ) {
            PagedContent(
                state = pageIndex,
                goingForward = goingForward,
                pageTurnStyle = prefs.pageTurnStyle,
                modifier = Modifier.fillMaxSize()
            ) { pi ->
                val leaf = pages.getOrNull(pi).orEmpty()
                // Preferimos que cada hoja quepa sin scroll; si se desborda, permite scroll suave
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                    leaf.forEach { (i, p) ->
                        val match = highlights.firstOrNull { h ->
                            h.chapterIndex == i || p.contains(h.selectedText)
                        }
                        val bg = match?.let { Color(it.colorArgb).copy(alpha = 0.35f) }
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .then(if (bg != null) Modifier.background(bg, RoundedCornerShape(6.dp)) else Modifier)
                                .padding(vertical = 4.dp)
                        ) {
                            SelectableText(
                                text = p,
                                fontSize = fontSize,
                                lineHeightMult = prefs.lineHeight,
                                fontFamily = prefs.fontFamily,
                                color = pageFg,
                                onWordLongPress = { word -> dictWord = word },
                                onTextSelected = { text -> pendingText = text to i }
                            )
                        }
                    }
                }
            }
        }
        if (prefs.showNavButtons) {
            Row(
                Modifier.fillMaxWidth().background(Panel).padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                if (prefs.leftHanded) {
                    LibIconButton(LibIconKind.CHEVRON_RIGHT, onClick = goPrev, tint = Gold)
                    Text("${pageIndex + 1} / ${pages.size}", color = Muted, fontSize = 12.sp)
                    LibIconButton(LibIconKind.CHEVRON_LEFT, onClick = goNext, tint = Gold)
                } else {
                    LibIconButton(LibIconKind.CHEVRON_LEFT, onClick = goPrev, tint = Gold)
                    Text("${pageIndex + 1} / ${pages.size}", color = Muted, fontSize = 12.sp)
                    LibIconButton(LibIconKind.CHEVRON_RIGHT, onClick = goNext, tint = Gold)
                }
            }
        }
    }

    dictWord?.let { DictionaryDialog(word = it, onDismiss = { dictWord = null }) }

    pendingText?.let { (text, parIdx) ->
        HighlightColorPicker(
            selectedText = text,
            onConfirm = { colorArgb, note ->
                scope.launch {
                    highlightDao.insert(
                        Highlight(
                            id = UUID.randomUUID().toString(),
                            bookId = item.id,
                            bookTitle = item.title,
                            chapterIndex = parIdx,
                            chapterTitle = "Párrafo ${parIdx + 1}",
                            selectedText = text,
                            note = note,
                            colorArgb = colorArgb
                        )
                    )
                }
                pendingText = null
            },
            onDismiss = { pendingText = null }
        )
    }
}

/** Texto seleccionable con callback al mantener pulsado */
@Composable
private fun SelectableText(
    text: String,
    fontSize: Int,
    lineHeightMult: Float = 1.55f,
    fontFamily: String = "serif",
    color: Color,
    onWordLongPress: (String) -> Unit,
    onTextSelected: (String) -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }
    var lastSelected by remember { mutableStateOf("") }
    var askWord by remember { mutableStateOf(false) }
    var wordInput by remember { mutableStateOf("") }

    Box(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .pointerInput(Unit) {
                detectTapGestures(
                    onLongPress = {
                        // En texto plano, abrimos el picker con todo el párrafo
                        lastSelected = text
                        showMenu = true
                    }
                )
            }
    ) {
        val ff = when (fontFamily) {
            "sans" -> FontFamily.SansSerif
            "classic" -> FontFamily.Serif
            else -> FontFamily.Serif
        }
        Text(
            text, color = color,
            fontSize = fontSize.sp,
            lineHeight = (fontSize * lineHeightMult).sp,
            fontFamily = ff
        )
    }

    if (showMenu) {
        AlertDialog(
            onDismissRequest = { showMenu = false },
            containerColor = Panel,
            title = { Text("Opciones de texto", color = Cream) },
            text = {
                Column {
                    TextButton(onClick = {
                        showMenu = false
                        wordInput = ""
                        askWord = true
                    }) {
                        LibIcon(LibIconKind.DICTIONARY, tint = Gold, size = 18.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("Buscar una palabra", color = Gold)
                    }
                    TextButton(onClick = {
                        showMenu = false
                        onTextSelected(text)
                    }) {
                        LibIcon(LibIconKind.NOTES, tint = Gold, size = 18.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("Subrayar párrafo", color = Gold)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showMenu = false }) { Text("Cancelar", color = Muted) }
            }
        )
    }

    if (askWord) {
        AlertDialog(
            onDismissRequest = { askWord = false },
            containerColor = Panel,
            title = { Text("¿Qué palabra buscas?", color = Cream) },
            text = {
                OutlinedTextField(
                    value = wordInput,
                    onValueChange = { wordInput = it },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Cream, unfocusedTextColor = Cream,
                        focusedBorderColor = Gold, unfocusedBorderColor = Muted
                    )
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    askWord = false
                    if (wordInput.isNotBlank()) onWordLongPress(wordInput.trim())
                }) { Text("Buscar", color = Gold) }
            },
            dismissButton = {
                TextButton(onClick = { askWord = false }) { Text("Cancelar", color = Muted) }
            }
        )
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// CBZ
// ══════════════════════════════════════════════════════════════════════════════

@Composable
private fun CbzReader(
    item: LibraryItem,
    onSave: (Long, Int) -> Unit,
    readingMode: String
) {
    val zip = remember(item.id) { runCatching { ZipFile(File(item.localPath)) }.getOrNull() }
    DisposableEffect(zip) { onDispose { runCatching { zip?.close() } } }
    if (zip == null) { Message("No se pudo abrir este CBZ."); return }

    val pages = remember(zip) {
        zip.entries().toList()
            .filter { !it.isDirectory && it.name.substringAfterLast('.').lowercase() in IMAGE_EXTENSIONS }
            .sortedBy { naturalKey(it.name) }
            .map { it.name }
    }
    if (pages.isEmpty()) { Message("Este CBZ no contiene imágenes."); return }

    var index by remember(item.id) {
        mutableIntStateOf(item.lastPosition.toInt().coerceIn(0, pages.lastIndex))
    }
    var goingForward by remember { mutableStateOf(true) }
    LaunchedEffect(index) { onSave(index.toLong(), (index + 1) * 100 / pages.size) }

    Column(Modifier.fillMaxSize()) {
        BoxWithConstraints(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .pageSwipe(
                    onNext = { if (index < pages.lastIndex) { goingForward = true; index++ } },
                    onPrev = { if (index > 0) { goingForward = false; index-- } }
                )
        ) {
            val widthPx = constraints.maxWidth.coerceAtLeast(1)
            PagedContent(state = index, goingForward = goingForward, modifier = Modifier.fillMaxSize()) { pg ->
                val bitmap by produceState<Bitmap?>(null, pages[pg], widthPx) {
                    value = withContext(Dispatchers.IO) {
                        try {
                            val entry = zip.getEntry(pages[pg])
                            val bytes = zip.getInputStream(entry).use { it.readBytes() }
                            decodeSampled(bytes, widthPx)
                        } catch (_: Exception) { null }
                    }
                }
                bitmap?.let {
                    Image(
                        bitmap = it.asImageBitmap(),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                } ?: Box(Modifier.fillMaxSize().background(Panel))
            }
        }
        Row(
            Modifier.fillMaxWidth().background(Panel).padding(4.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            LibIconButton(LibIconKind.CHEVRON_LEFT, onClick = { if (index > 0) { goingForward = false; index-- } }, tint = Gold)
            Text("${index + 1} / ${pages.size}", color = Muted, fontSize = 12.sp)
            LibIconButton(LibIconKind.CHEVRON_RIGHT, onClick = { if (index < pages.lastIndex) { goingForward = true; index++ } }, tint = Gold)
        }
    }
}

