# Libellum — Android 0.7.0

Proyecto Android nativo con Kotlin, Jetpack Compose, Room y Media3.

## Novedades 0.7.0
- Texto de TXT/FB2 y EPUB visible (arreglado color del texto y etiquetas autocerradas del EPUB).
- Interfaz nueva «papel»: Panel con racha, Biblioteca con filtros y detalle del libro, Favoritos, Racha, menú «Más».
- Estanterías por categoría (portadas o lomos, tamaños S/M/L, ajustar lomos) y modo libre.
- Reto de lectura, Resumen y exportar CSV.
- Widget «Mi estantería» para la pantalla de inicio.

## Funciones
- Biblioteca local (Room): importación múltiple de EPUB, PDF, TXT, FB2, CBZ y CBR, y de audiolibros MP3, M4A, M4B, AAC, OGG, OPUS, WAV y FLAC. Cada archivo se copia al almacenamiento privado de la app.
- Escáner automático: con el permiso «Acceso a todos los archivos» (documentos y libros), Libellum busca EPUB, PDF, TXT, FB2 y CBZ en todo el teléfono y la SD, con filtro por tipo. Se abre solo la primera vez.
- Portadas y metadatos automáticos (EPUB, PDF, CBZ, FB2 y audio).
- Lector: EPUB, PDF, TXT, FB2 y CBZ, con modo de scroll vertical o pasar hoja, tamaño de letra y temas. Guarda por dónde ibas. CBR se importa pero aún no se lee.
- Subrayados y notas por libro, con colores pastel y vista global en la pestaña «Notas».
- Al seleccionar texto en un EPUB aparece «Copiar · Diccionario · Subrayar»; los subrayados se ven pintados en la página.
- EPUB con hojas reales (columnas): se pasa de hoja deslizando, tocando los bordes o con las flechas; los enlaces del índice funcionan.
- Iconos propios dibujados a mano (sin librerías de iconos).
- Estantería con tres posturas: de frente, de lado (canto) y acostado; se mueven manteniendo pulsado.
- Audiolibros con reproducción en segundo plano, ±15/30 s, velocidad y posición guardada.
- Favoritos, búsqueda por título o autor y separador de página.
- Biblioteca en lista, cuadrícula o estantería con movimiento libre de los libros.
- Copias de seguridad exportables (.zip) con libros, audios, portadas, progreso, favoritos, orden de la estantería y notas.

## Limitaciones conocidas
- CBR (RAR) no se lee todavía.
- En EPUB se guarda el capítulo, no la posición exacta dentro del capítulo.
- Los EPUB con DRM no se abren.
- Android no permite elegir la carpeta «Descargas» completa en el escáner; para esos archivos usa «Importar».

## Compilar
- Android Studio Ladybug o posterior, JDK 17, Android SDK 35.
- Sin Android Studio: sube `LibellumAndroid.zip` y el workflow `.github/workflows/build.yml` a GitHub; el APK sale en Actions → artefacto `app-debug`.
