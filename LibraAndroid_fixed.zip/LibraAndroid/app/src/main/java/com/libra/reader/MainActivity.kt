package com.libra.reader

import android.Manifest
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.zIndex
import androidx.glance.appwidget.updateAll
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    // Libro que pide abrir el widget de la estantería
    private val openRequest = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        openRequest.value = intent?.getStringExtra("open_book_id")
        setContent { LibraApp(openRequest) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        openRequest.value = intent.getStringExtra("open_book_id")
    }
}

@Composable
fun LibraApp(openRequest: MutableState<String?>) {
    val context = LocalContext.current
    val db = remember { LibraryDatabase.get(context) }
    val dao = remember { db.libraryDao() }
    val highlightDao = remember { db.highlightDao() }

    val itemsFlow = remember { dao.observeAll() }
    val highlightsFlow = remember { highlightDao.observeAll() }
    val allItems by itemsFlow.collectAsState(initial = emptyList())
    val allHighlights by highlightsFlow.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    val controller by rememberMediaController()
    PlaybackPersistence(controller, dao)

    val prefs = remember { context.getSharedPreferences("libra_prefs", 0) }
    var showTutorial by remember { mutableStateOf(!prefs.getBoolean("tutorial_done", false)) }

    var selectedTab by remember { mutableStateOf("Panel") }
    var viewMode by remember { mutableStateOf("LISTA") }
    var status by remember { mutableStateOf("Libellum guarda tu biblioteca en este dispositivo.") }
    var busy by remember { mutableStateOf(false) }
    var opened by remember { mutableStateOf<LibraryItem?>(null) }
    var showScanner by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var editingHighlight by remember { mutableStateOf<Highlight?>(null) }
    var days by remember { mutableStateOf(Streak.days(context)) }
    var detailId by remember { mutableStateOf<String?>(null) }
    var showMore by remember { mutableStateOf(false) }
    var goal by remember { mutableIntStateOf(Streak.goal(context)) }

    // El widget pide abrir un libro concreto
    LaunchedEffect(openRequest.value, allItems) {
        val id = openRequest.value
        if (id != null) {
            allItems.firstOrNull { it.id == id }?.let {
                opened = it
                openRequest.value = null
            }
        }
    }
    // Se refresca el widget solo cuando cambia lo que muestra (no en cada página leída)
    val shelfSignature = remember(allItems) {
        allItems.joinToString("|") { it.id + it.isFavorite + it.statusKey() + (it.coverPath ?: "") }
    }
    LaunchedEffect(shelfSignature) { runCatching { ShelfWidget().updateAll(context) } }

    // ── Primera vez: se abre el escáner, que pide el permiso de documentos y detecta los libros solo ──
    var autoScanAsked by remember { mutableStateOf(prefs.getBoolean("auto_scan_asked", false)) }
    LaunchedEffect(showTutorial, autoScanAsked) {
        if (!showTutorial && !autoScanAsked) {
            showScanner = true
            autoScanAsked = true
            prefs.edit().putBoolean("auto_scan_asked", true).apply()
        }
    }

    // ── Lanzadores ────────────────────────────────────────────────────────────
    val bookPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            busy = true; status = "Importando…"
            status = withContext(Dispatchers.IO) {
                importUris(context.contentResolver, context.filesDir, uris, "BOOK", dao)
            }
            busy = false
        }
    }
    val audioPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            busy = true; status = "Importando audio…"
            status = withContext(Dispatchers.IO) {
                importUris(context.contentResolver, context.filesDir, uris, "AUDIO", dao)
            }
            busy = false
        }
    }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) scope.launch {
            busy = true; status = "Creando copia de seguridad…"
            status = Backup.export(context, dao, highlightDao, uri); busy = false
        }
    }
    val restoreLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) scope.launch {
            busy = true; status = "Restaurando copia de seguridad…"
            status = Backup.restore(context, dao, highlightDao, uri); busy = false
        }
    }

    val csvLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) scope.launch {
            busy = true; status = "Exportando CSV…"
            status = exportCsv(context, allItems.filter { it.mediaType == "BOOK" }, uri); busy = false
        }
    }

    // Antes de borrar se pide confirmación (un toque sin querer no debe borrar un libro)
    var pendingDelete by remember { mutableStateOf<LibraryItem?>(null) }
    val onDelete: (LibraryItem) -> Unit = { item -> pendingDelete = item }

    // ── Tutorial ──────────────────────────────────────────────────────────────
    if (showTutorial) {
        TutorialScreen(onFinish = {
            showTutorial = false
            prefs.edit().putBoolean("tutorial_done", true).apply()
        })
        return
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            background = Ink, surface = Panel, primary = Gold,
            onBackground = Cream, onSurface = Cream, onPrimary = Ink,
            surfaceVariant = Panel, onSurfaceVariant = Muted, outline = Line
        )
    ) {
        val current = opened
        if (current != null) {
            if (current.mediaType == "AUDIO") {
                AudioPlayerScreen(current, controller, onClose = { opened = null })
            } else {
                ReaderScreen(
                    item = current,
                    onClose = { opened = null },
                    onSave = { position, progress ->
                        scope.launch {
                            dao.updateProgress(current.id, position, progress)
                            val now = System.currentTimeMillis()
                            if (progress > 0) dao.markStarted(current.id, now)
                            if (progress >= 97) dao.markFinished(current.id, now)
                        }
                        Streak.markToday(context)
                        days = Streak.days(context)
                    },
                    highlightDao = highlightDao,
                    onUpdateItem = { updated -> scope.launch { dao.update(updated) } }
                )
            }
        } else {
            val toggleFav: (LibraryItem) -> Unit = { item ->
                scope.launch { dao.setFavorite(item.id, if (item.isFavorite == 1) 0 else 1) }
            }
            val books = allItems.filter { it.mediaType == "BOOK" }
            val filteredBooks = if (searchQuery.isBlank()) books
            else books.filter {
                it.title.contains(searchQuery, ignoreCase = true) ||
                    it.author.contains(searchQuery, ignoreCase = true)
            }
            val navItems = listOf("Panel", "Biblioteca", "Favoritos", "Racha", "Más")

            Scaffold(
                containerColor = Ink,
                bottomBar = {
                    NavigationBar(containerColor = Panel, contentColor = Cream) {
                        navItems.forEach { tab ->
                            val selected = if (tab == "Más") (showMore || selectedTab !in navItems) else selectedTab == tab
                            val tint = if (selected) Gold else Muted
                            NavigationBarItem(
                                selected = selected,
                                onClick = { if (tab == "Más") showMore = true else selectedTab = tab },
                                icon = {
                                    when (tab) {
                                        "Panel" -> LibIcon(LibIconKind.HOME, tint = tint, size = 24.dp, filled = selected)
                                        "Biblioteca" -> LibIcon(LibIconKind.LIBRARY, tint = tint, size = 24.dp, filled = selected)
                                        "Favoritos" -> LibIcon(LibIconKind.STAR, tint = tint, size = 24.dp, filled = selected)
                                        "Racha" -> Text("🔥", fontSize = 20.sp)
                                        else -> LibIcon(LibIconKind.LIST, tint = tint, size = 24.dp, filled = selected)
                                    }
                                },
                                label = { Text(tab, fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Gold, selectedTextColor = Gold,
                                    indicatorColor = Ink, unselectedIconColor = Muted,
                                    unselectedTextColor = Muted
                                )
                            )
                        }
                    }
                }
            ) { padding ->
                Column(
                    Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)
                ) {
                    Spacer(Modifier.height(14.dp))
                    if (selectedTab != "Panel") {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("LIBELLUM", color = Gold, fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                                Text(
                                    when (selectedTab) {
                                        "Biblioteca" -> "Tu biblioteca"
                                        "Estanterías" -> "Mis estanterías"
                                        "Favoritos" -> "Tus favoritos"
                                        "Racha" -> "Racha de lectura"
                                        "Notas" -> "Notas y citas"
                                        "Audio" -> "Audiolibros"
                                        "Reto" -> "Reto de lectura"
                                        "Resumen" -> "Tu resumen"
                                        else -> "Ajustes"
                                    },
                                    color = Cream, fontSize = 24.sp, fontWeight = FontWeight.SemiBold
                                )
                            }
                            LibIconButton(LibIconKind.HELP, onClick = { showTutorial = true }, tint = Muted)
                        }
                        Spacer(Modifier.height(8.dp))
                    }

                    if (selectedTab == "Biblioteca") {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Buscar por título o autor…", color = Muted, fontSize = 14.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Cream, unfocusedTextColor = Cream,
                                focusedBorderColor = Gold, unfocusedBorderColor = Line,
                                focusedContainerColor = Panel, unfocusedContainerColor = Panel
                            ),
                            leadingIcon = { LibIcon(LibIconKind.SEARCH, tint = Muted, size = 20.dp) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty())
                                    LibIconButton(LibIconKind.CLOSE, onClick = { searchQuery = "" }, tint = Muted, iconSize = 18.dp)
                            },
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = {})
                        )
                        Spacer(Modifier.height(8.dp))
                    }

                    when (selectedTab) {
                        "Panel" -> DashboardScreen(
                            books = books, days = days, status = status, busy = busy,
                            onMarkToday = { Streak.markToday(context); days = Streak.days(context) },
                            onOpen = { opened = it },
                            onDetail = { detailId = it.id },
                            onImport = { bookPicker.launch(arrayOf("*/*")) },
                            onScan = { showScanner = true }
                        )
                        "Biblioteca" -> LibraryScreen2(
                            filteredBooks,
                            onDetail = { detailId = it.id },
                            onToggleFavorite = toggleFav,
                            onImport = { bookPicker.launch(arrayOf("*/*")) },
                            onScan = { showScanner = true }
                        )
                        "Estanterías" -> BookshelvesScreen(
                            books = books,
                            onDetail = { detailId = it.id },
                            onSpineSize = { id, w, h -> scope.launch { dao.setSpineSize(id, w, h) } },
                            freeShelf = {
                                ShelfScreen(
                                    books, { detailId = it.id },
                                    { id, pose -> scope.launch { dao.setShelfPose(id, pose) } },
                                    { pose ->
                                        scope.launch {
                                            dao.setAllShelfPoses(pose)
                                            dao.resetShelfPositions()
                                        }
                                    },
                                    { id, x, y -> scope.launch { dao.updateShelfPosition(id, x, y) } },
                                    { scope.launch { dao.resetShelfPositions() } }
                                )
                            }
                        )
                        "Favoritos" -> FavoritesScreen(books, onDetail = { detailId = it.id })
                        "Racha" -> StreakScreen(days, onMarkToday = { Streak.markToday(context); days = Streak.days(context) })
                        "Notas" -> AllHighlightsScreen(
                            highlights = allHighlights,
                            onEdit = { editingHighlight = it },
                            onDelete = { h -> scope.launch { highlightDao.deleteById(h.id) } }
                        )
                        "Audio" -> AudioScreen(
                            allItems.filter { it.mediaType == "AUDIO" },
                            onOpen = { opened = it }, onDelete = onDelete
                        )
                        "Reto" -> ChallengeScreen(books, goal, onGoal = { g ->
                            goal = g.coerceIn(1, 365)
                            Streak.setGoal(context, goal)
                        })
                        "Resumen" -> RecapScreen(books, allHighlights.size, days)
                        else -> SettingsScreen(
                            allItems.size, busy,
                            onExport = {
                                val stamp = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
                                exportLauncher.launch("libra-copia-$stamp.zip")
                            },
                            onImport = {
                                restoreLauncher.launch(arrayOf("application/zip",
                                    "application/octet-stream", "*/*"))
                            },
                            onShowTutorial = { showTutorial = true },
                            onExportCsv = {
                                val stamp = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
                                csvLauncher.launch("libellum-libros-$stamp.csv")
                            }
                        )
                    }
                }
            }

            // ── Menú «Más» ───────────────────────────────────────────────────
            if (showMore) {
                MoreSheet(
                    onPick = { key -> selectedTab = key; showMore = false },
                    onTutorial = { showMore = false; showTutorial = true },
                    onCsv = {
                        showMore = false
                        val stamp = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
                        csvLauncher.launch("libellum-libros-$stamp.csv")
                    },
                    onDismiss = { showMore = false }
                )
            }

            // ── Detalle del libro ────────────────────────────────────────────
            val detailItem = detailId?.let { id -> allItems.firstOrNull { it.id == id } }
            if (detailItem != null) {
                BookDetailSheet(
                    item = detailItem,
                    notesCount = allHighlights.count { it.bookId == detailItem.id },
                    onDismiss = { detailId = null },
                    onRead = { detailId = null; opened = detailItem },
                    onStatus = { st ->
                        scope.launch {
                            val now = System.currentTimeMillis()
                            dao.setStatus(detailItem.id, st)
                            if (st == "READING" || st == "FINISHED") dao.markStarted(detailItem.id, now)
                            if (st == "FINISHED") dao.markFinished(detailItem.id, now)
                        }
                    },
                    onRating = { r -> scope.launch { dao.setRating(detailItem.id, r) } },
                    onGenre = { g -> scope.launch { dao.setGenre(detailItem.id, g) } },
                    onReview = { r -> scope.launch { dao.setReview(detailItem.id, r) } },
                    onFavorite = { toggleFav(detailItem) },
                    onDelete = { detailId = null; pendingDelete = detailItem }
                )
            }
        }
    }

    pendingDelete?.let { item ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            containerColor = Panel,
            title = { Text("¿Quitar de la biblioteca?", color = Cream) },
            text = {
                Text(
                    "«${item.title}» se borrará de Libellum junto con sus notas. " +
                        "El archivo original de tu teléfono no se toca.",
                    color = Muted
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        removeItem(dao, item)
                        highlightDao.deleteByBook(item.id)
                    }
                    pendingDelete = null
                }) { Text("Quitar", color = Gold) }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) { Text("Cancelar", color = Muted) }
            }
        )
    }

    if (showScanner) {
        ScannerDialog(
            context = context,
            onImport = { uris ->
                scope.launch {
                    busy = true; status = "Importando desde escáner…"
                    status = withContext(Dispatchers.IO) {
                        importUris(context.contentResolver, context.filesDir, uris, "BOOK", dao)
                    }
                    busy = false
                }
            },
            onDismiss = { showScanner = false }
        )
    }

    editingHighlight?.let { h ->
        HighlightEditDialog(
            highlight = h,
            onSave = { updated ->
                scope.launch { highlightDao.update(updated) }
                editingHighlight = null
            },
            onDismiss = { editingHighlight = null }
        )
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// PANTALLAS
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun HomeScreen(
    books: List<LibraryItem>,
    onOpen: (LibraryItem) -> Unit,
    onDelete: (LibraryItem) -> Unit,
    onToggleFavorite: (LibraryItem) -> Unit
) {
    if (books.isEmpty()) {
        EmptyFeature("TU BIBLIOTECA COMIENZA AQUÍ",
            "Importa tus archivos EPUB, PDF, TXT, FB2, CBZ o usa el escáner automático. " +
            "Libellum guardará una copia privada en tu dispositivo.")
    } else {
        val favorites = books.filter { it.isFavorite == 1 }
        val rest = books.filter { it.isFavorite == 0 }
        LazyColumn {
            if (favorites.isNotEmpty()) {
                item {
                    Text("FAVORITOS · ${favorites.size}", color = Gold, fontSize = 11.sp,
                        letterSpacing = 1.sp, modifier = Modifier.padding(bottom = 4.dp))
                }
                items(favorites, key = { it.id }) { BookRow(it, onOpen, onDelete, onToggleFavorite) }
                item { Spacer(Modifier.height(12.dp)) }
            }
            item {
                Text("LIBROS · ${rest.size}", color = Gold, fontSize = 11.sp,
                    letterSpacing = 1.sp, modifier = Modifier.padding(bottom = 4.dp))
            }
            items(rest, key = { it.id }) { BookRow(it, onOpen, onDelete, onToggleFavorite) }
        }
    }
}

@Composable
fun LibraryScreen(
    books: List<LibraryItem>,
    viewMode: String,
    onViewModeChange: (String) -> Unit,
    onOpen: (LibraryItem) -> Unit,
    onDelete: (LibraryItem) -> Unit,
    onToggleFavorite: (LibraryItem) -> Unit,
    onSetPose: (String, String) -> Unit,
    onSetAllPoses: (String) -> Unit,
    onMove: (String, Float, Float) -> Unit,
    onResetShelf: () -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("${books.size} libros", color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
        listOf(
            "LISTA" to LibIconKind.LIST,
            "CUADRICULA" to LibIconKind.GRID,
            "ESTANTERIA" to LibIconKind.SHELF
        ).forEach { (mode, kind) ->
            LibIconButton(
                kind, onClick = { onViewModeChange(mode) },
                tint = if (viewMode == mode) Gold else Muted, filled = viewMode == mode
            )
        }
    }
    if (books.isEmpty()) {
        EmptyFeature("AÚN NO HAY LIBROS", "Pulsa «Importar» o «Escanear» para añadir tu colección.")
    } else when (viewMode) {
        "ESTANTERIA" -> ShelfScreen(books, onOpen, onSetPose, onSetAllPoses, onMove, onResetShelf)
        "CUADRICULA" -> LazyColumn {
            items(books.chunked(2)) { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    row.forEach { book ->
                        Column(
                            Modifier.weight(1f).padding(vertical = 8.dp).clickable { onOpen(book) }
                        ) {
                            BookCover(book, Modifier.fillMaxWidth().height(190.dp))
                            Spacer(Modifier.height(6.dp))
                            Text(book.title, color = Cream, fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text("${book.author} · ${book.format}", color = Muted, fontSize = 10.sp,
                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
        else -> LazyColumn {
            items(books, key = { it.id }) { BookRow(it, onOpen, onDelete, onToggleFavorite) }
        }
    }
}

@Composable
fun AudioScreen(audio: List<LibraryItem>, onOpen: (LibraryItem) -> Unit, onDelete: (LibraryItem) -> Unit) {
    if (audio.isEmpty()) {
        EmptyFeature("TUS AUDIOLIBROS",
            "Importa MP3, M4A, M4B, AAC, OGG, OPUS, WAV o FLAC. " +
            "Libellum recuerda por dónde ibas y sigue sonando con la pantalla apagada.")
    } else {
        Text("${audio.size} archivos de audio importados", color = Gold, fontSize = 11.sp)
        LazyColumn {
            items(audio, key = { it.id }) { BookRow(it, onOpen, onDelete, onToggleFavorite = {}) }
        }
    }
}

@Composable
fun SettingsScreen(
    itemCount: Int, busy: Boolean,
    onExport: () -> Unit, onImport: () -> Unit, onShowTutorial: () -> Unit,
    onExportCsv: () -> Unit = {}
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            EmptyFeature("ALMACENAMIENTO LOCAL",
                "Libellum mantiene $itemCount elementos en el almacenamiento privado de la aplicación.")
        }
        item {
            Button(onClick = onExport, enabled = !busy, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)
            ) { Text("Exportar copia de seguridad") }
        }
        item {
            OutlinedButton(onClick = onImport, enabled = !busy, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
            ) { Text("Restaurar desde una copia") }
        }
        item {
            OutlinedButton(onClick = onExportCsv, enabled = !busy, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
            ) { Text("Exportar lista de libros (CSV)") }
        }
        item {
            OutlinedButton(onClick = onShowTutorial, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
            ) {
                LibIcon(LibIconKind.HELP, tint = Gold, size = 18.dp)
                Spacer(Modifier.width(8.dp))
                Text("Ver tutorial de la app")
            }
        }
        item {
            Text("La copia es un archivo .zip con tus libros, audiolibros, portadas, progreso y " +
                "orden de la estantería. Guárdalo en Drive o en la tarjeta y restáuralo en otro teléfono.",
                color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// COMPONENTES REUTILIZABLES
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun EmptyFeature(title: String, description: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text(title, color = Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Text(description, color = Cream, fontSize = 14.sp, lineHeight = 21.sp)
        }
    }
}

@Composable
fun BookRow(
    item: LibraryItem,
    onOpen: (LibraryItem) -> Unit,
    onDelete: (LibraryItem) -> Unit,
    onToggleFavorite: (LibraryItem) -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clickable { onOpen(item) }.padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BookCover(item, Modifier.size(width = 48.dp, height = 66.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(item.title, color = Cream, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text("${item.author} · ${item.format}", color = Muted, fontSize = 11.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (item.progress > 0) {
                Spacer(Modifier.height(5.dp))
                LinearProgressIndicator(
                    progress = { item.progress / 100f },
                    color = Gold, trackColor = Panel,
                    modifier = Modifier.fillMaxWidth().height(3.dp)
                )
            }
        }
        LibIconButton(
            LibIconKind.STAR, onClick = { onToggleFavorite(item) },
            tint = if (item.isFavorite == 1) Gold else Muted, filled = item.isFavorite == 1
        )
        LibIconButton(LibIconKind.TRASH, onClick = { onDelete(item) }, tint = Muted, iconSize = 20.dp)
    }
}

private fun coverColor(title: String): Color {
    val palette = listOf(
        Color(0xFF6B3540), Color(0xFF35564D),
        Color(0xFF43506D), Color(0xFF7A5C3A), Color(0xFF3B3430)
    )
    return palette[abs(title.hashCode()) % palette.size]
}

@Composable
fun BookCover(item: LibraryItem, modifier: Modifier = Modifier, textSize: TextUnit = 10.sp) {
    val cover = remember(item.coverPath) {
        item.coverPath?.let { File(it) }?.takeIf { it.exists() }
    }
    Box(modifier.clip(RoundedCornerShape(7.dp)).background(coverColor(item.title)),
        contentAlignment = Alignment.Center) {
        if (cover != null) {
            AsyncImage(model = cover, contentDescription = item.title,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Text(item.title, color = Color(0xFFF3E6C8), fontSize = textSize, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, maxLines = 6, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(5.dp))
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// ESTANTERÍA: de frente (portada), de lado (se ve el canto) y acostado
// ══════════════════════════════════════════════════════════════════════════════

/** Postura del libro en la estantería: FRONT, SPINE o LYING (los valores antiguos se convierten). */
internal fun shelfPose(item: LibraryItem): String = when (item.shelfOrientation) {
    "SPINE" -> "SPINE"
    "LYING", "HORIZONTAL" -> "LYING"
    else -> "FRONT"
}

private fun poseSize(pose: String): Pair<Dp, Dp> = when (pose) {
    "SPINE" -> 30.dp to 114.dp
    "LYING" -> 114.dp to 30.dp
    else -> 76.dp to 114.dp
}

private class ShelfLayout(val slots: Map<String, IntOffset>, val plankTops: List<Int>, val height: Int)

/** Colocación automática: libros en filas, apoyados sobre una balda cada fila. */
private fun layoutShelf(books: List<LibraryItem>, areaW: Int, density: Density): ShelfLayout {
    val gap = with(density) { 6.dp.roundToPx() }
    val padX = with(density) { 10.dp.roundToPx() }
    val plank = with(density) { 12.dp.roundToPx() }
    val topPad = with(density) { 16.dp.roundToPx() }
    val slots = HashMap<String, IntOffset>()
    val plankTops = ArrayList<Int>()
    val row = ArrayList<Triple<LibraryItem, Int, Int>>()
    var rowTop = topPad
    var cursor = padX

    fun flush() {
        if (row.isEmpty()) return
        val rowH = row.maxOf { it.third }
        var x = padX
        row.forEach { (b, w, h) ->
            slots[b.id] = IntOffset(x, rowTop + rowH - h)
            x += w + gap
        }
        plankTops.add(rowTop + rowH)
        rowTop += rowH + plank + topPad
        row.clear()
        cursor = padX
    }

    for (b in books) {
        val (w, h) = poseSize(shelfPose(b))
        val bw = with(density) { w.roundToPx() }
        val bh = with(density) { h.roundToPx() }
        if (cursor + bw > areaW - padX && row.isNotEmpty()) flush()
        row.add(Triple(b, bw, bh))
        cursor += bw + gap
    }
    flush()
    return ShelfLayout(slots, plankTops, (plankTops.lastOrNull() ?: topPad) + plank + topPad / 2)
}

private fun Color.shade(f: Float): Color = Color(
    (red * f).coerceIn(0f, 1f), (green * f).coerceIn(0f, 1f), (blue * f).coerceIn(0f, 1f), alpha
)

/** Gira un composable 90° ocupando el espacio girado (para el título del lomo). */
private fun Modifier.rotateVertical(): Modifier = layout { measurable, constraints ->
    val placeable = measurable.measure(Constraints(0, constraints.maxHeight, 0, constraints.maxWidth))
    layout(placeable.height, placeable.width) {
        placeable.placeWithLayer(
            (placeable.height - placeable.width) / 2,
            (placeable.width - placeable.height) / 2
        ) { rotationZ = 90f }
    }
}

private val spineColorCache = HashMap<String, Color>()

private fun averageColor(path: String): Color? {
    val options = BitmapFactory.Options().apply { inSampleSize = 16 }
    val bmp = BitmapFactory.decodeFile(path, options) ?: return null
    var r = 0L
    var g = 0L
    var b = 0L
    var n = 0
    // Se promedia la franja izquierda de la portada: es lo más parecido al color del lomo
    val xMax = maxOf(1, bmp.width / 4)
    for (x in 0 until xMax) {
        for (y in 0 until bmp.height) {
            val px = bmp.getPixel(x, y)
            r += (px shr 16) and 0xFF
            g += (px shr 8) and 0xFF
            b += px and 0xFF
            n++
        }
    }
    if (n == 0) return null
    return Color(r / n / 255f, g / n / 255f, b / n / 255f)
}

/** Color del lomo: promedio de la portada; si no hay portada, un color según el título. */
@Composable
private fun rememberSpineColor(book: LibraryItem): Color {
    val fallback = remember(book.title) { coverColor(book.title) }
    val color by produceState(spineColorCache[book.coverPath ?: ""] ?: fallback, book.coverPath) {
        val path = book.coverPath
        if (path != null) {
            val cached = spineColorCache[path]
            if (cached != null) {
                value = cached
            } else {
                val c = withContext(Dispatchers.IO) { averageColor(path) }
                if (c != null) {
                    spineColorCache[path] = c
                    value = c
                }
            }
        }
    }
    return color
}

@Composable
private fun FrontFace(book: LibraryItem) {
    Box(Modifier.fillMaxSize().clip(RoundedCornerShape(3.dp))) {
        BookCover(book, Modifier.fillMaxSize(), textSize = 9.sp)
        // pliegue del lomo en sombra, a la izquierda
        Box(
            Modifier.align(Alignment.CenterStart).fillMaxHeight().width(7.dp)
                .background(Brush.horizontalGradient(listOf(Color(0xAA000000), Color.Transparent)))
        )
        // canto de las páginas, a la derecha
        Box(Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(3.dp).background(Color(0xFFEFE6D2)))
    }
}

/** Lomo del libro: de pie (vertical) o acostado (horizontal). Se ve el canto con título y bandas. */
@Composable
private fun SpineFace(book: LibraryItem, vertical: Boolean) {
    val base = rememberSpineColor(book).let { if (it.luminance() > 0.8f) it.shade(0.8f) else it }
    val textColor = if (base.luminance() > 0.5f) Color(0xFF1B1B1B) else Color(0xFFF3E6C8)
    val brush = if (vertical) {
        Brush.horizontalGradient(listOf(base.shade(0.65f), base.shade(1.18f), base, base.shade(0.55f)))
    } else {
        Brush.verticalGradient(listOf(base.shade(1.18f), base, base.shade(0.6f)))
    }
    val band = textColor.copy(alpha = 0.55f)
    Box(
        Modifier.fillMaxSize().clip(RoundedCornerShape(3.dp)).background(brush),
        contentAlignment = Alignment.Center
    ) {
        if (vertical) {
            Box(Modifier.align(Alignment.TopCenter).padding(top = 7.dp).fillMaxWidth().height(2.dp).background(band))
            Box(Modifier.align(Alignment.TopCenter).padding(top = 11.dp).fillMaxWidth().height(1.dp).background(band))
            Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 7.dp).fillMaxWidth().height(2.dp).background(band))
            Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 11.dp).fillMaxWidth().height(1.dp).background(band))
            Text(
                book.title, color = textColor, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(vertical = 16.dp).rotateVertical()
            )
        } else {
            Box(Modifier.align(Alignment.CenterStart).padding(start = 7.dp).fillMaxHeight().width(2.dp).background(band))
            Box(Modifier.align(Alignment.CenterStart).padding(start = 11.dp).fillMaxHeight().width(1.dp).background(band))
            // extremo con las páginas a la vista
            Box(Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(8.dp).background(Color(0xFFEFE6D2)))
            Box(Modifier.align(Alignment.CenterEnd).padding(end = 3.dp).fillMaxHeight().width(1.dp).background(Color(0x33000000)))
            Text(
                book.title, color = textColor, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(start = 18.dp, end = 16.dp)
            )
        }
    }
}

@Composable
fun ShelfScreen(
    books: List<LibraryItem>,
    onOpen: (LibraryItem) -> Unit,
    onSetPose: (String, String) -> Unit,
    onSetAllPoses: (String) -> Unit,
    onMove: (String, Float, Float) -> Unit,
    onReset: () -> Unit
) {
    var selectedId by remember { mutableStateOf<String?>(null) }
    val selected = books.firstOrNull { it.id == selectedId }

    LazyColumn {
        item {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "TOCA UN LIBRO PARA EDITARLO · MANTÉNLO PULSADO PARA MOVERLO",
                        color = Muted, fontSize = 10.sp, letterSpacing = 1.sp,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = onReset) { Text("Ordenar", color = Gold, fontSize = 11.sp) }
                }
                // Cambiar la postura de todos los libros de una vez
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Todos:", color = Muted, fontSize = 11.sp)
                    listOf("FRONT" to "De frente", "SPINE" to "De lado", "LYING" to "Acostados").forEach { (pose, label) ->
                        TextButton(onClick = { onSetAllPoses(pose) }) {
                            Text(label, color = Gold, fontSize = 11.sp)
                        }
                    }
                }
                Spacer(Modifier.height(4.dp))

                BoxWithConstraints(Modifier.fillMaxWidth()) {
                    val density = LocalDensity.current
                    val areaW = constraints.maxWidth
                    val poseKey = books.map { it.id to shelfPose(it) }
                    val layout = remember(poseKey, areaW) { layoutShelf(books, areaW, density) }
                    val areaH = maxOf(layout.height, with(density) { 360.dp.roundToPx() })

                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(with(density) { areaH.toDp() })
                            .clip(RoundedCornerShape(14.dp))
                            .background(Brush.verticalGradient(listOf(Color(0xFF3A261B), Color(0xFF281A12))))
                    ) {
                        layout.plankTops.forEach { top ->
                            Box(
                                Modifier
                                    .offset { IntOffset(0, top) }
                                    .fillMaxWidth()
                                    .height(12.dp)
                                    .background(Brush.verticalGradient(listOf(Color(0xFFC49A66), Color(0xFF8A6238))))
                            )
                        }
                        books.forEach { book ->
                            key(book.id) {
                                ShelfBook(
                                    book, layout.slots[book.id] ?: IntOffset.Zero, areaW, areaH,
                                    isSelected = selectedId == book.id,
                                    onSelect = { selectedId = if (selectedId == it.id) null else it.id },
                                    onMove = onMove
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))

                // Panel de edición del libro elegido
                if (selected != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Panel),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                BookCover(selected, Modifier.size(width = 40.dp, height = 58.dp))
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        selected.title, color = Cream, fontWeight = FontWeight.SemiBold,
                                        fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
                                    )
                                    Text(selected.author, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            Text("Cómo se ve en la estantería", color = Muted, fontSize = 11.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("FRONT" to "De frente", "SPINE" to "De lado", "LYING" to "Acostado").forEach { (pose, label) ->
                                    FilterChip(
                                        selected = shelfPose(selected) == pose,
                                        onClick = { onSetPose(selected.id, pose) },
                                        label = { Text(label, fontSize = 12.sp) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = Gold,
                                            selectedLabelColor = Ink,
                                            labelColor = Cream
                                        )
                                    )
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { onOpen(selected) },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)
                                ) { Text("Abrir libro") }
                                OutlinedButton(
                                    onClick = { selectedId = null },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Muted)
                                ) { Text("Listo") }
                            }
                        }
                    }
                } else {
                    Text(
                        "Elige un libro para verlo de frente, de lado (se ve el canto) o acostado, y para abrirlo.",
                        color = Muted, fontSize = 12.sp, lineHeight = 18.sp
                    )
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun ShelfBook(
    book: LibraryItem,
    slot: IntOffset,
    areaW: Int,
    areaH: Int,
    isSelected: Boolean,
    onSelect: (LibraryItem) -> Unit,
    onMove: (String, Float, Float) -> Unit
) {
    val density = LocalDensity.current
    val pose = shelfPose(book)
    val dims = poseSize(pose)
    val bw = with(density) { dims.first.roundToPx() }
    val bh = with(density) { dims.second.roundToPx() }
    val maxX = (areaW - bw).coerceAtLeast(0)
    val maxY = (areaH - bh).coerceAtLeast(0)
    val px = density.density   // la posición guardada está en dp
    var x by remember(book.id, book.shelfX, areaW, bw, slot.x) {
        mutableFloatStateOf(
            (if (book.shelfX >= 0f) book.shelfX * px else slot.x.toFloat()).coerceIn(0f, maxX.toFloat())
        )
    }
    var y by remember(book.id, book.shelfY, areaH, bh, slot.y) {
        mutableFloatStateOf(
            (if (book.shelfY >= 0f) book.shelfY * px else slot.y.toFloat()).coerceIn(0f, maxY.toFloat())
        )
    }
    var dragging by remember { mutableStateOf(false) }

    Box(
        Modifier
            .offset { IntOffset(x.roundToInt(), y.roundToInt()) }
            .zIndex(if (dragging) 20f else if (isSelected) 10f else 0f)
            .size(dims.first, dims.second)
            .shadow(if (dragging) 10.dp else 3.dp, RoundedCornerShape(3.dp))
            .then(if (isSelected) Modifier.border(2.dp, Gold, RoundedCornerShape(4.dp)) else Modifier)
            .pointerInput(book.id, maxX, maxY) {
                // Mantener pulsado y arrastrar: así deslizar el dedo por la estantería sigue haciendo scroll
                detectDragGesturesAfterLongPress(
                    onDragStart = { dragging = true },
                    onDragEnd = {
                        dragging = false
                        onMove(book.id, x / px, y / px)
                    },
                    onDragCancel = { dragging = false }
                ) { change, drag ->
                    change.consume()
                    x = (x + drag.x).coerceIn(0f, maxX.toFloat())
                    y = (y + drag.y).coerceIn(0f, maxY.toFloat())
                }
            }
            .clickable { onSelect(book) }
    ) {
        when (pose) {
            "SPINE" -> SpineFace(book, vertical = true)
            "LYING" -> SpineFace(book, vertical = false)
            else -> FrontFace(book)
        }
    }
}
