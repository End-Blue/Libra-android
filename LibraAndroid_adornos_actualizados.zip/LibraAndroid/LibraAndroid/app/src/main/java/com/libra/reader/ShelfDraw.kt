package com.libra.reader

import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ══════════════════════════════════════════════════════════════════════════════
// Dibujo de la estantería personalizada (todo con Canvas, sin imágenes)
// ══════════════════════════════════════════════════════════════════════════════

internal fun plankDp(thickness: Int): Int = when (thickness) { 0 -> 7; 2 -> 15; else -> 11 }

// ── Pared ────────────────────────────────────────────────────────────────────
internal fun DrawScope.drawWall(wall: WallDef) {
    val w = size.width
    val h = size.height
    if (wall.pattern == 9) {
        drawRect(Brush.verticalGradient(listOf(wall.base, wall.accent)), Offset.Zero, size)
        return
    }
    drawRect(wall.base, Offset.Zero, size)
    when (wall.pattern) {
        1 -> {
            val step = 18.dp.toPx()
            var x = 0f
            var i = 0
            while (x < w) {
                if (i % 2 == 0) drawRect(wall.accent.copy(alpha = 0.55f), Offset(x, 0f), Size(step, h))
                x += step
                i++
            }
        }
        2 -> {
            val bh = 14.dp.toPx()
            val bw = 36.dp.toPx()
            val sw = 1.5.dp.toPx()
            var y = 0f
            var r = 0
            while (y < h) {
                drawLine(wall.accent, Offset(0f, y), Offset(w, y), sw)
                var x = if (r % 2 == 0) 0f else -bw / 2f
                while (x < w) {
                    drawLine(wall.accent, Offset(x, y), Offset(x, y + bh), sw)
                    x += bw
                }
                y += bh
                r++
            }
        }
        3 -> {
            val s = 26.dp.toPx()
            val r = 3.5.dp.toPx()
            var gy = 0
            while (gy * s / 2f < h + s) {
                var gx = 0
                while (gx * s < w + s) {
                    val cx = gx * s + (if (gy % 2 == 0) 0f else s / 2f)
                    val cy = gy * s / 2f
                    val p = Path().apply {
                        moveTo(cx, cy - r); lineTo(cx + r, cy); lineTo(cx, cy + r); lineTo(cx - r, cy); close()
                    }
                    drawPath(p, wall.accent)
                    gx++
                }
                gy++
            }
        }
        4 -> {
            val step = 24.dp.toPx()
            var x = 0f
            var i = 0
            while (x < w) {
                if (i % 2 == 1) drawRect(Color.Black.copy(alpha = 0.06f), Offset(x, 0f), Size(step, h))
                drawLine(wall.accent, Offset(x, 0f), Offset(x, h), 1.dp.toPx())
                x += step
                i++
            }
        }
        5 -> {
            for (i in 0 until 160) {
                val fx = ((i * 7919) % 1000) / 1000f
                val fy = ((i * 104729) % 1000) / 1000f
                val rad = (0.8f + (i % 4) * 0.5f).dp.toPx()
                drawCircle(wall.accent.copy(alpha = 0.7f), rad, Offset(fx * w, fy * h))
            }
        }
        6 -> {
            val step = 6.dp.toPx()
            var y = 0f
            while (y < h) { drawLine(wall.accent.copy(alpha = 0.3f), Offset(0f, y), Offset(w, y), 0.6.dp.toPx()); y += step }
            var x = 0f
            while (x < w) { drawLine(wall.accent.copy(alpha = 0.3f), Offset(x, 0f), Offset(x, h), 0.6.dp.toPx()); x += step }
        }
        7 -> {
            drawRect(Brush.verticalGradient(listOf(wall.base, Color(0xFF1F2745))), Offset.Zero, size)
            for (i in 0 until 90) {
                val fx = ((i * 7919) % 997) / 997f
                val fy = ((i * 6007) % 991) / 991f
                val bright = i % 7 == 0
                drawCircle(
                    (if (bright) Color(0xFFFFF1B8) else wall.accent).copy(alpha = if (bright) 0.95f else 0.7f),
                    (if (bright) 1.6f else 0.9f).dp.toPx(), Offset(fx * w, fy * h)
                )
            }
        }
        8 -> {
            val s = 22.dp.toPx()
            var gy = 0
            while (gy * s < h + s) {
                var gx = 0
                while (gx * s < w + s) {
                    val cx = gx * s + (if (gy % 2 == 0) 0f else s / 2f)
                    drawCircle(wall.accent, 3.dp.toPx(), Offset(cx, gy * s))
                    gx++
                }
                gy++
            }
        }
    }
}

/** Laterales de madera de la estantería («Con laterales») */
internal fun DrawScope.drawFrameSides(style: ShelfStyle) {
    if (style.frame != "SIDES") return
    val wd = woodOf(style.wood)
    val sideW = 9.dp.toPx()
    drawRect(
        Brush.horizontalGradient(listOf(wd.light, wd.dark), startX = 0f, endX = sideW),
        Offset.Zero, Size(sideW, size.height)
    )
    drawRect(
        Brush.horizontalGradient(listOf(wd.dark, wd.light), startX = size.width - sideW, endX = size.width),
        Offset(size.width - sideW, 0f), Size(sideW, size.height)
    )
}

// ── Madera ───────────────────────────────────────────────────────────────────
internal fun DrawScope.drawWoodRect(wd: WoodDef, topLeft: Offset, sz: Size) {
    drawRect(
        Brush.verticalGradient(listOf(wd.light, wd.dark), startY = topLeft.y, endY = topLeft.y + sz.height),
        topLeft, sz
    )
    val x0 = topLeft.x
    val x1 = topLeft.x + sz.width
    when (wd.kind) {
        0 -> {
            val n = maxOf(2, (sz.height / 3.dp.toPx()).toInt())
            for (i in 1..n) {
                val y = topLeft.y + sz.height * i / (n + 1f)
                drawLine(wd.grain, Offset(x0, y), Offset(x1, y), 0.8.dp.toPx())
            }
        }
        1, 3 -> {
            val n = maxOf(2, (sz.height / 3.5f.dp.toPx()).toInt())
            val step = 36.dp.toPx()
            for (i in 1..n) {
                val y = topLeft.y + sz.height * i / (n + 1f)
                val amp = (1.2f + (i % 3) * 0.8f).dp.toPx()
                val path = Path()
                path.moveTo(x0, y)
                var x = x0
                var up = i % 2 == 0
                while (x < x1) {
                    path.quadraticBezierTo(x + step / 2f, if (up) y - amp else y + amp, x + step, y)
                    x += step
                    up = !up
                }
                drawPath(path, wd.grain, style = Stroke(width = 0.8.dp.toPx()))
            }
            if (wd.kind == 3) {
                var kx = x0 + 40.dp.toPx()
                var k = 0
                while (kx < x1) {
                    val ky = topLeft.y + sz.height * (0.35f + (k % 3) * 0.15f)
                    drawOval(wd.grain, Offset(kx, ky), Size(9.dp.toPx(), minOf(5.dp.toPx(), sz.height * 0.5f)))
                    kx += 110.dp.toPx()
                    k++
                }
            }
        }
        4 -> {
            var x = x0 + 90.dp.toPx()
            while (x < x1) {
                drawLine(wd.grain, Offset(x, topLeft.y), Offset(x, topLeft.y + sz.height), 1.dp.toPx())
                x += 90.dp.toPx() + 17.dp.toPx()
            }
            val n = maxOf(1, (sz.height / 4.dp.toPx()).toInt())
            for (i in 1..n) {
                val y = topLeft.y + sz.height * i / (n + 1f)
                drawLine(wd.grain.copy(alpha = 0.18f), Offset(x0, y), Offset(x1, y), 0.7.dp.toPx())
            }
        }
        5 -> {
            var x = x0 + 60.dp.toPx()
            while (x < x1) {
                drawRect(wd.grain, Offset(x, topLeft.y), Size(2.dp.toPx(), sz.height))
                x += 70.dp.toPx()
            }
        }
        else -> Unit
    }
    drawRect(Color.White.copy(alpha = 0.22f), topLeft, Size(sz.width, 1.5.dp.toPx()))
    drawRect(
        Color.Black.copy(alpha = 0.28f),
        Offset(topLeft.x, topLeft.y + sz.height - 1.5.dp.toPx()), Size(sz.width, 1.5.dp.toPx())
    )
}

/** Balda de madera (con escuadras opcionales debajo). */
@Composable
internal fun WoodPlank(style: ShelfStyle, modifier: Modifier = Modifier) {
    val wd = woodOf(style.wood)
    val th = plankDp(style.thickness)
    Canvas(modifier.fillMaxWidth().height(th.dp)) { drawWoodRect(wd, Offset.Zero, size) }
    if (style.frame == "BRACKETS") {
        Canvas(Modifier.fillMaxWidth().height(14.dp)) {
            val bw = 14.dp.toPx()
            listOf(size.width * 0.12f, size.width * 0.88f - bw).forEach { x ->
                val p = Path().apply {
                    moveTo(x, 0f); lineTo(x + bw, 0f); lineTo(x, size.height); close()
                }
                drawPath(p, wd.dark)
                drawPath(p, wd.light.copy(alpha = 0.35f), style = Stroke(width = 1.dp.toPx()))
            }
        }
    }
}

// ── Luz ambiente ─────────────────────────────────────────────────────────────
internal fun DrawScope.drawLight(kind: String) {
    val w = size.width
    val h = size.height
    when (kind) {
        "WARM" -> drawRect(
            Brush.radialGradient(listOf(Color(0x55FFC773), Color.Transparent), center = Offset(w / 2f, 0f), radius = w * 0.95f),
            Offset.Zero, size
        )
        "COOL" -> drawRect(
            Brush.radialGradient(listOf(Color(0x449FC4FF), Color.Transparent), center = Offset(w / 2f, 0f), radius = w * 0.95f),
            Offset.Zero, size
        )
        "SUNSET" -> drawRect(
            Brush.horizontalGradient(listOf(Color(0x55FF8A3D), Color.Transparent, Color(0x33B04A7A))),
            Offset.Zero, size
        )
        "LAMP" -> {
            drawRect(
                Brush.radialGradient(listOf(Color(0x66FFD27A), Color.Transparent), center = Offset(w * 0.82f, 0f), radius = w * 0.85f),
                Offset.Zero, size
            )
            drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color(0x40000000))), Offset.Zero, size)
        }
        "FAIRY" -> {
            val y0 = 5.dp.toPx()
            val yc = 26.dp.toPx()
            val path = Path().apply { moveTo(0f, y0); quadraticBezierTo(w / 2f, yc, w, y0) }
            drawPath(path, Color(0x88331F14), style = Stroke(width = 1.2.dp.toPx()))
            val n = maxOf(6, (w / 30.dp.toPx()).toInt())
            val colors = listOf(Color(0xFFFFD27A), Color(0xFFFFB3A7), Color(0xFFFFF1B8), Color(0xFFB8E6FF))
            for (i in 0..n) {
                val t = i / n.toFloat()
                val x = w * t
                val y = y0 + 2f * (1f - t) * t * (yc - y0) + 3.dp.toPx()
                val c = colors[i % colors.size]
                drawCircle(c.copy(alpha = 0.28f), 8.dp.toPx(), Offset(x, y))
                drawCircle(c, 2.6.dp.toPx(), Offset(x, y))
            }
        }
        else -> Unit
    }
}

// ── Lomo con estilo ──────────────────────────────────────────────────────────
private val TITLE_SCALE = listOf(0.85f, 1f, 1.15f)

private fun foilColorOf(key: String, dark: Boolean): Color =
    FOIL_COLORS.firstOrNull { it.key == key }?.color ?: (if (dark) Color(0xFFD4AF37) else Color(0xFF86592F))

private fun titleColorOf(key: String, dark: Boolean, foil: Color): Color = when (key) {
    "cream" -> Color(0xFFF3E6C8)
    "gold" -> if (dark) Color(0xFFD4AF37) else Color(0xFF86592F)
    "ink" -> Color(0xFF1B2A41)
    "white" -> Color(0xFFFFFFFF)
    else -> if (dark) Color(0xFFF3E6C8) else Color(0xFF1B2A41)
}

private fun DrawScope.drawDiamond(cx: Float, cy: Float, r: Float, c: Color) {
    val p = Path().apply { moveTo(cx, cy - r); lineTo(cx + r, cy); lineTo(cx, cy + r); lineTo(cx - r, cy); close() }
    drawPath(p, c)
}

private fun DrawScope.drawFoil(kind: String, c: Color) {
    val w = size.width
    val h = size.height
    val t = 2.dp.toPx()
    when (kind) {
        "single" -> drawRect(c.copy(alpha = 0.85f), Offset(0f, h * 0.06f), Size(w, t))
        "double" -> {
            drawRect(c.copy(alpha = 0.85f), Offset(0f, h * 0.06f), Size(w, t))
            drawRect(c.copy(alpha = 0.85f), Offset(0f, h * 0.94f), Size(w, t))
        }
        "ornate" -> {
            val th = 1.3.dp.toPx()
            drawRect(c.copy(alpha = 0.85f), Offset(0f, h * 0.05f), Size(w, th))
            drawRect(c.copy(alpha = 0.85f), Offset(0f, h * 0.085f), Size(w, th))
            drawRect(c.copy(alpha = 0.85f), Offset(0f, h * 0.915f), Size(w, th))
            drawRect(c.copy(alpha = 0.85f), Offset(0f, h * 0.95f), Size(w, th))
            drawDiamond(w / 2f, h * 0.125f, 2.6.dp.toPx(), c)
            drawDiamond(w / 2f, h * 0.875f, 2.6.dp.toPx(), c)
        }
        "frame" -> drawRect(
            c.copy(alpha = 0.85f), Offset(3.dp.toPx(), 3.dp.toPx()),
            Size(w - 6.dp.toPx(), h - 6.dp.toPx()), style = Stroke(width = 1.2.dp.toPx())
        )
        else -> Unit
    }
}

/** (inicio del texto, largo disponible) como fracción del alto del lomo */
private fun textRegion(foil: String): Pair<Float, Float> = when (foil) {
    "none" -> 0.06f to 0.88f
    "single" -> 0.12f to 0.82f
    "ornate" -> 0.17f to 0.66f
    "frame" -> 0.14f to 0.72f
    else -> 0.10f to 0.80f
}

@Composable
internal fun StyledSpine(
    title: String, color: Color, progress: Int, w: Int, h: Int,
    style: ShelfStyle, modifier: Modifier = Modifier
) {
    val dark = color.luminance() < 0.5f
    val foil = foilColorOf(style.foilColor, dark)
    val titleArgb = titleColorOf(style.titleColor, dark, foil).toArgb()
    val font = fontOf(style.font)
    val tf = remember(font.key) { Typeface.create(font.family, font.style) }
    val shown = if (style.caps) title.uppercase() else title
    val scale = TITLE_SCALE[style.titleSize.coerceIn(0, 2)]

    Canvas(modifier.size(w.dp, h.dp)) {
        val sw = size.width
        val sh = size.height
        drawRoundRect(color, cornerRadius = CornerRadius(3.dp.toPx()))

        // Material de la cubierta
        when (style.material) {
            "leather" -> {
                for (i in 0 until 36) {
                    val fx = ((i * 37) % 97) / 97f
                    val fy = ((i * 53) % 89) / 89f
                    drawCircle(Color.Black.copy(alpha = 0.10f), 0.8.dp.toPx(), Offset(fx * sw, fy * sh))
                }
                drawRoundRect(
                    foil.copy(alpha = 0.5f), Offset(2.dp.toPx(), 2.dp.toPx()),
                    Size(sw - 4.dp.toPx(), sh - 4.dp.toPx()), CornerRadius(2.dp.toPx()),
                    style = Stroke(
                        width = 0.8.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(4.dp.toPx(), 3.dp.toPx()))
                    )
                )
            }
            "cloth" -> {
                val step = 3.dp.toPx()
                var y = 0f
                while (y < sh) { drawLine(Color.Black.copy(alpha = 0.07f), Offset(0f, y), Offset(sw, y), 0.6.dp.toPx()); y += step }
                var x = 0f
                while (x < sw) { drawLine(Color.White.copy(alpha = 0.07f), Offset(x, 0f), Offset(x, sh), 0.6.dp.toPx()); x += step }
            }
            "emboss" -> {
                drawRect(
                    Color.Black.copy(alpha = 0.25f), Offset(3.dp.toPx(), 3.dp.toPx()),
                    Size(sw - 6.dp.toPx(), sh - 6.dp.toPx()), style = Stroke(width = 1.dp.toPx())
                )
                drawRect(
                    Color.White.copy(alpha = 0.2f), Offset(4.dp.toPx(), 4.dp.toPx()),
                    Size(sw - 6.dp.toPx(), sh - 6.dp.toPx()), style = Stroke(width = 0.8.dp.toPx())
                )
            }
            "gloss" -> drawRoundRect(
                brush = Brush.horizontalGradient(
                    listOf(Color.White.copy(alpha = 0.30f), Color.Transparent, Color.Black.copy(alpha = 0.18f))
                ),
                cornerRadius = CornerRadius(3.dp.toPx())
            )
            "rustic" -> {
                var y = 5.dp.toPx()
                while (y < sh) { drawRect(Color.Black.copy(alpha = 0.10f), Offset(0f, y), Size(sw, 1.5.dp.toPx())); y += 7.dp.toPx() }
                for (i in 0 until 6) {
                    val fx = ((i * 41) % 89) / 89f
                    drawLine(Color.White.copy(alpha = 0.08f), Offset(fx * sw, 0f), Offset(fx * sw, sh), 0.7.dp.toPx())
                }
            }
            else -> Unit
        }

        // Sombra del lomo (como antes) y adornos de lámina
        drawRect(Color.Black.copy(alpha = 0.14f), Offset.Zero, Size(sw * 0.14f, sh))
        drawFoil(style.foil, foil)

        // Título en vertical
        val (top, lenFrac) = textRegion(style.foil)
        drawIntoCanvas { canvas ->
            val paint = android.graphics.Paint().apply {
                isAntiAlias = true
                this.color = titleArgb
                this.typeface = tf
                textSize = minOf(12.sp.toPx() * scale, sw * 0.5f)
            }
            val maxLen = sh * lenFrac
            val n = paint.breakText(shown, true, maxLen, null)
            val text = if (n < shown.length && n > 1) shown.substring(0, n - 1) + "…" else shown.take(maxOf(n, 0))
            val nc = canvas.nativeCanvas
            nc.save()
            nc.translate(sw / 2f - paint.textSize * 0.35f, sh * top)
            nc.rotate(90f)
            nc.drawText(text, 0f, 0f, paint)
            nc.restore()
        }

        // Marca de progreso de lectura
        if (style.showProgress && progress in 1..100) {
            val ph = sh * progress / 100f
            drawRect(foil.copy(alpha = 0.9f), Offset(sw - 3.dp.toPx(), sh - ph), Size(2.dp.toPx(), ph))
        }
    }
}

// ── Decoraciones físicas ─────────────────────────────────────────────────────
/**
 * Dibuja un adorno. [tint] cambia su color principal (null = colores originales) y [scale] lo agranda
 * o lo encoge (el tamaño del componente cambia con él, así que ocupa su sitio real en la balda).
 */
@Composable
internal fun DecoView(def: DecoDef, modifier: Modifier = Modifier, tint: Color? = null, scale: Float = 1f) {
    Canvas(modifier.size((def.w * scale).dp, (def.h * scale).dp)) {
        val k = if (scale <= 0f) 1f else scale
        this.scale(k, k, pivot = Offset.Zero) {
            drawDeco(def.key, tint, size.width / k, size.height / k)
        }
    }
}

/** Tono más claro (f > 1) u oscuro (f < 1) del mismo color. */
private fun Color.tone(f: Float): Color = Color(
    (red * f).coerceIn(0f, 1f), (green * f).coerceIn(0f, 1f), (blue * f).coerceIn(0f, 1f), alpha
)

private fun DrawScope.drawDeco(key: String, tint: Color?, w: Float, h: Float) {
    fun o(x: Float, y: Float) = Offset(x * w, y * h)
    fun s(sw: Float, sh: Float) = Size(sw * w, sh * h)
    when (key) {
        "plant" -> {
            val leafA = Color(0xFF3F7D4A)
            val leafB = Color(0xFF5BA063)
            drawLine(leafA, o(0.5f, 0.62f), o(0.5f, 0.2f), 1.5.dp.toPx())
            drawOval(leafB, o(0.38f, 0.04f), s(0.24f, 0.34f))
            drawOval(leafA, o(0.08f, 0.26f), s(0.36f, 0.18f))
            drawOval(leafB, o(0.56f, 0.2f), s(0.36f, 0.18f))
            drawOval(leafA, o(0.14f, 0.44f), s(0.3f, 0.16f))
            drawOval(leafB, o(0.56f, 0.42f), s(0.3f, 0.16f))
            val pot = Path().apply {
                moveTo(0.22f * w, 0.6f * h); lineTo(0.78f * w, 0.6f * h)
                lineTo(0.68f * w, h); lineTo(0.32f * w, h); close()
            }
            val potC = tint ?: Color(0xFFC0673F)
            drawPath(pot, potC)
            drawRect(potC.tone(0.85f), o(0.18f, 0.56f), s(0.64f, 0.08f))
        }
        "cactus" -> {
            val g = Color(0xFF4C8C5A)
            drawRoundRect(g, o(0.36f, 0.1f), s(0.28f, 0.68f), CornerRadius(0.14f * w))
            drawRoundRect(g, o(0.1f, 0.36f), s(0.3f, 0.12f), CornerRadius(0.06f * w))
            drawRoundRect(g, o(0.1f, 0.24f), s(0.12f, 0.24f), CornerRadius(0.06f * w))
            drawRoundRect(g, o(0.6f, 0.44f), s(0.3f, 0.12f), CornerRadius(0.06f * w))
            drawRoundRect(g, o(0.78f, 0.32f), s(0.12f, 0.24f), CornerRadius(0.06f * w))
            drawCircle(Color(0xFFE88AA8), 0.07f * w, o(0.5f, 0.1f))
            val potC = tint ?: Color(0xFFD9A066)
            drawRoundRect(potC, o(0.24f, 0.76f), s(0.52f, 0.24f), CornerRadius(2.dp.toPx()))
            drawRect(potC.tone(0.85f), o(0.2f, 0.74f), s(0.6f, 0.06f))
        }
        "flowers" -> {
            val stem = Color(0xFF4E8A4F)
            listOf(0.3f, 0.5f, 0.7f).forEach { x -> drawLine(stem, o(0.5f, 0.6f), o(x, 0.2f), 1.3.dp.toPx()) }
            drawCircle(Color(0xFFE88AA8), 0.13f * w, o(0.3f, 0.2f))
            drawCircle(Color(0xFFF5D26B), 0.13f * w, o(0.5f, 0.12f))
            drawCircle(Color(0xFFF7F3EA), 0.13f * w, o(0.7f, 0.2f))
            drawCircle(Color(0xFFE0A93A), 0.05f * w, o(0.5f, 0.12f))
            val vase = Path().apply {
                moveTo(0.32f * w, 0.55f * h)
                lineTo(0.68f * w, 0.55f * h)
                quadraticBezierTo(0.9f * w, 0.78f * h, 0.7f * w, h)
                lineTo(0.3f * w, h)
                quadraticBezierTo(0.1f * w, 0.78f * h, 0.32f * w, 0.55f * h)
                close()
            }
            drawPath(vase, tint ?: Color(0xFF6FA8B8))
            drawRect(Color.White.copy(alpha = 0.25f), o(0.34f, 0.62f), s(0.08f, 0.26f))
        }
        "candle" -> {
            drawCircle(Color(0x44FFC773), 0.9f * w, o(0.5f, 0.22f))
            drawOval(Color(0xFFC9A24A), o(0.06f, 0.86f), s(0.88f, 0.14f))
            drawRoundRect(tint ?: Color(0xFFF3E9D2), o(0.3f, 0.36f), s(0.4f, 0.54f), CornerRadius(2.dp.toPx()))
            drawLine(Color(0xFF4A3A2A), o(0.5f, 0.36f), o(0.5f, 0.3f), 1.dp.toPx())
            val flame = Path().apply {
                moveTo(0.5f * w, 0.04f * h)
                quadraticBezierTo(0.72f * w, 0.2f * h, 0.5f * w, 0.32f * h)
                quadraticBezierTo(0.28f * w, 0.2f * h, 0.5f * w, 0.04f * h)
                close()
            }
            drawPath(flame, Color(0xFFF5A623))
            drawOval(Color(0xFFFFE08A), o(0.43f, 0.16f), s(0.14f, 0.14f))
        }
        "lamp" -> {
            drawCircle(Color(0x33FFD27A), 0.8f * w, o(0.5f, 0.4f))
            drawRoundRect(Color(0xFF5B4630), o(0.34f, 0.92f), s(0.32f, 0.08f), CornerRadius(2.dp.toPx()))
            drawRect(Color(0xFF5B4630), o(0.47f, 0.38f), s(0.06f, 0.56f))
            val shade = Path().apply {
                moveTo(0.22f * w, 0.08f * h); lineTo(0.78f * w, 0.08f * h)
                lineTo(0.95f * w, 0.4f * h); lineTo(0.05f * w, 0.4f * h); close()
            }
            drawPath(shade, tint ?: Color(0xFF2E5E4E))
            drawRect(Color(0xFFFFE8A3).copy(alpha = 0.5f), o(0.1f, 0.38f), s(0.8f, 0.04f))
        }
        "coffee" -> {
            val cupC = tint ?: Color(0xFFF7F3EA)
            drawOval(cupC.tone(0.92f), o(0.04f, 0.84f), s(0.84f, 0.16f))
            drawRoundRect(cupC, o(0.12f, 0.34f), s(0.6f, 0.56f), CornerRadius(0.18f * w))
            drawOval(Color(0xFF5A3A24), o(0.14f, 0.34f), s(0.56f, 0.12f))
            drawCircle(cupC, 0.14f * w, o(0.78f, 0.6f), style = Stroke(width = 2.dp.toPx()))
            listOf(0.3f, 0.5f).forEach { x ->
                val steam = Path().apply {
                    moveTo(x * w, 0.28f * h)
                    quadraticBezierTo((x + 0.08f) * w, 0.16f * h, x * w, 0.06f * h)
                }
                drawPath(steam, Color(0x88A8A39A), style = Stroke(width = 1.2.dp.toPx(), cap = StrokeCap.Round))
            }
        }
        "globe" -> {
            drawRoundRect(Color(0xFF6B4423), o(0.28f, 0.9f), s(0.44f, 0.1f), CornerRadius(2.dp.toPx()))
            drawRect(Color(0xFF6B4423), o(0.46f, 0.74f), s(0.08f, 0.18f))
            drawCircle(tint ?: Color(0xFF3E7CB1), 0.38f * w, o(0.5f, 0.4f))
            drawOval(Color(0xFF6BA36B), o(0.26f, 0.2f), s(0.22f, 0.2f))
            drawOval(Color(0xFF6BA36B), o(0.5f, 0.38f), s(0.2f, 0.26f))
            drawOval(Color.White.copy(alpha = 0.55f), o(0.34f, 0.1f), s(0.14f, 0.08f))
            drawOval(Color.White.copy(alpha = 0.35f), o(0.14f, 0.02f), s(0.72f, 0.76f), style = Stroke(width = 0.8.dp.toPx()))
        }
        "clock" -> {
            val caseC = tint ?: Color(0xFF6B4423)
            drawRoundRect(caseC, o(0.06f, 0.06f), s(0.88f, 0.84f), CornerRadius(0.2f * w))
            drawCircle(Color(0xFFF3E9D2), 0.34f * w, o(0.5f, 0.48f))
            for (i in 0 until 12) {
                val a = Math.toRadians(i * 30.0)
                val r1 = 0.28f * w
                val r2 = 0.32f * w
                drawLine(
                    Color(0xFF4A3A2A),
                    Offset(0.5f * w + (r1 * Math.sin(a)).toFloat(), 0.48f * h - (r1 * Math.cos(a)).toFloat()),
                    Offset(0.5f * w + (r2 * Math.sin(a)).toFloat(), 0.48f * h - (r2 * Math.cos(a)).toFloat()),
                    0.8.dp.toPx()
                )
            }
            drawLine(Color(0xFF2B2B33), o(0.5f, 0.48f), o(0.5f, 0.28f), 1.3.dp.toPx(), StrokeCap.Round)
            drawLine(Color(0xFF2B2B33), o(0.5f, 0.48f), o(0.66f, 0.54f), 1.3.dp.toPx(), StrokeCap.Round)
            drawRect(caseC.tone(0.7f), o(0.2f, 0.9f), s(0.12f, 0.1f))
            drawRect(caseC.tone(0.7f), o(0.68f, 0.9f), s(0.12f, 0.1f))
        }
        "hourglass" -> {
            val glass = Color(0x66BFD9E6)
            val sand = tint ?: Color(0xFFE0B85A)
            val top = Path().apply { moveTo(0.18f * w, 0.1f * h); lineTo(0.82f * w, 0.1f * h); lineTo(0.5f * w, 0.5f * h); close() }
            val bot = Path().apply { moveTo(0.5f * w, 0.5f * h); lineTo(0.82f * w, 0.9f * h); lineTo(0.18f * w, 0.9f * h); close() }
            drawPath(top, glass); drawPath(bot, glass)
            val sTop = Path().apply { moveTo(0.34f * w, 0.26f * h); lineTo(0.66f * w, 0.26f * h); lineTo(0.5f * w, 0.5f * h); close() }
            val sBot = Path().apply { moveTo(0.5f * w, 0.68f * h); lineTo(0.76f * w, 0.9f * h); lineTo(0.24f * w, 0.9f * h); close() }
            drawPath(sTop, sand); drawPath(sBot, sand)
            drawRoundRect(Color(0xFF6B4423), o(0.1f, 0.02f), s(0.8f, 0.09f), CornerRadius(2.dp.toPx()))
            drawRoundRect(Color(0xFF6B4423), o(0.1f, 0.89f), s(0.8f, 0.09f), CornerRadius(2.dp.toPx()))
        }
        "inkwell" -> {
            val bottleC = tint ?: Color(0xFF2A2F3A)
            drawRoundRect(bottleC, o(0.1f, 0.58f), s(0.62f, 0.42f), CornerRadius(3.dp.toPx()))
            drawRect(bottleC.tone(0.7f), o(0.26f, 0.5f), s(0.3f, 0.1f))
            drawRect(Color.White.copy(alpha = 0.18f), o(0.16f, 0.64f), s(0.08f, 0.26f))
            val quill = Path().apply {
                moveTo(0.4f * w, 0.52f * h)
                quadraticBezierTo(0.95f * w, 0.3f * h, 0.86f * w, 0.02f * h)
                quadraticBezierTo(0.5f * w, 0.14f * h, 0.4f * w, 0.52f * h)
                close()
            }
            drawPath(quill, Color(0xFFF3E9D2))
            drawLine(Color(0xFF8A7A5A), o(0.4f, 0.52f), o(0.84f, 0.06f), 1.dp.toPx())
        }
        "stack" -> {
            val bookC = tint
            drawRoundRect(bookC?.tone(0.8f) ?: Color(0xFF7A2E3A), o(0.02f, 0.66f), s(0.96f, 0.34f), CornerRadius(2.dp.toPx()))
            drawRoundRect(bookC ?: Color(0xFF2F4B6B), o(0.1f, 0.34f), s(0.8f, 0.32f), CornerRadius(2.dp.toPx()))
            drawRoundRect(bookC?.tone(1.25f) ?: Color(0xFFB5832F), o(0.18f, 0.04f), s(0.64f, 0.3f), CornerRadius(2.dp.toPx()))
            listOf(0.66f to 0.34f, 0.34f to 0.32f, 0.04f to 0.3f).forEach { (y, hh) ->
                drawLine(Color(0xFFF3E9D2), o(0.2f, y + hh * 0.5f), o(0.8f, y + hh * 0.5f), 1.dp.toPx())
            }
        }
        "glasses" -> {
            val c = tint ?: Color(0xFF2B2B33)
            val r = 0.42f * h
            drawCircle(c, r, o(0.27f, 0.5f), style = Stroke(width = 1.4.dp.toPx()))
            drawCircle(c, r, o(0.73f, 0.5f), style = Stroke(width = 1.4.dp.toPx()))
            drawLine(c, o(0.27f + 0.42f * h / w, 0.45f), o(0.73f - 0.42f * h / w, 0.45f), 1.4.dp.toPx())
            drawLine(c, o(0.0f, 0.4f), o(0.27f - 0.42f * h / w, 0.45f), 1.2.dp.toPx())
            drawLine(c, o(1.0f, 0.4f), o(0.73f + 0.42f * h / w, 0.45f), 1.2.dp.toPx())
        }
        "cat" -> {
            val c = tint ?: Color(0xFF2B2B33)
            val tail = Path().apply {
                moveTo(0.76f * w, 0.92f * h)
                quadraticBezierTo(1.05f * w, 0.8f * h, 0.9f * w, 0.52f * h)
            }
            drawPath(tail, c, style = Stroke(width = 0.07f * w, cap = StrokeCap.Round))
            drawOval(c, o(0.18f, 0.44f), s(0.62f, 0.56f))
            drawCircle(c, 0.2f * w, o(0.48f, 0.3f))
            val ear1 = Path().apply { moveTo(0.3f * w, 0.2f * h); lineTo(0.3f * w, 0.02f * h); lineTo(0.44f * w, 0.14f * h); close() }
            val ear2 = Path().apply { moveTo(0.66f * w, 0.2f * h); lineTo(0.66f * w, 0.02f * h); lineTo(0.52f * w, 0.14f * h); close() }
            drawPath(ear1, c); drawPath(ear2, c)
            drawCircle(Color(0xFFF5D26B), 0.035f * w, o(0.4f, 0.3f))
            drawCircle(Color(0xFFF5D26B), 0.035f * w, o(0.56f, 0.3f))
        }
        "owl" -> {
            val bodyC = tint ?: Color(0xFF8A6240)
            drawOval(bodyC, o(0.14f, 0.26f), s(0.72f, 0.72f))
            drawOval(Color(0xFFD9B98C), o(0.3f, 0.54f), s(0.4f, 0.4f))
            val e1 = Path().apply { moveTo(0.2f * w, 0.34f * h); lineTo(0.2f * w, 0.08f * h); lineTo(0.38f * w, 0.26f * h); close() }
            val e2 = Path().apply { moveTo(0.8f * w, 0.34f * h); lineTo(0.8f * w, 0.08f * h); lineTo(0.62f * w, 0.26f * h); close() }
            drawPath(e1, bodyC.tone(0.78f)); drawPath(e2, bodyC.tone(0.78f))
            drawCircle(Color(0xFFF7F3EA), 0.13f * w, o(0.36f, 0.38f))
            drawCircle(Color(0xFFF7F3EA), 0.13f * w, o(0.64f, 0.38f))
            drawCircle(Color(0xFF2B2B33), 0.06f * w, o(0.36f, 0.38f))
            drawCircle(Color(0xFF2B2B33), 0.06f * w, o(0.64f, 0.38f))
            val beak = Path().apply { moveTo(0.44f * w, 0.46f * h); lineTo(0.56f * w, 0.46f * h); lineTo(0.5f * w, 0.56f * h); close() }
            drawPath(beak, Color(0xFFE8903A))
        }
        "trophy" -> {
            val g = tint ?: Color(0xFFE8B63D)
            drawCircle(g, 0.14f * w, o(0.12f, 0.24f), style = Stroke(width = 0.06f * w))
            drawCircle(g, 0.14f * w, o(0.88f, 0.24f), style = Stroke(width = 0.06f * w))
            val cup = Path().apply {
                moveTo(0.2f * w, 0.04f * h); lineTo(0.8f * w, 0.04f * h)
                quadraticBezierTo(0.8f * w, 0.5f * h, 0.56f * w, 0.56f * h)
                lineTo(0.44f * w, 0.56f * h)
                quadraticBezierTo(0.2f * w, 0.5f * h, 0.2f * w, 0.04f * h)
                close()
            }
            drawPath(cup, g)
            drawRect(g, o(0.44f, 0.56f), s(0.12f, 0.26f))
            drawRoundRect(Color(0xFF6B4423), o(0.24f, 0.82f), s(0.52f, 0.18f), CornerRadius(2.dp.toPx()))
            drawRect(Color.White.copy(alpha = 0.35f), o(0.28f, 0.1f), s(0.08f, 0.3f))
        }
        "frame" -> {
            val frameC = tint ?: Color(0xFF7A5232)
            drawRoundRect(frameC, o(0.04f, 0.04f), s(0.92f, 0.78f), CornerRadius(2.dp.toPx()))
            drawRect(Color(0xFFF3E9D2), o(0.14f, 0.14f), s(0.72f, 0.58f))
            drawRect(Color(0xFFBFD9E6), o(0.14f, 0.14f), s(0.72f, 0.34f))
            val hill = Path().apply { moveTo(0.14f * w, 0.72f * h); lineTo(0.42f * w, 0.36f * h); lineTo(0.64f * w, 0.72f * h); close() }
            drawPath(hill, Color(0xFF5B8A5B))
            drawCircle(Color(0xFFF5D26B), 0.07f * w, o(0.7f, 0.26f))
            drawLine(frameC, o(0.5f, 0.82f), o(0.62f, 1f), 1.5.dp.toPx())
        }
        "bonsai" -> {
            // Maceta cerámica con bandas y tronco irregular; copa en capas.
            val pot = tint ?: Color(0xFF9B5944)
            drawOval(Color(0x44000000), o(0.12f, 0.91f), s(0.76f, 0.08f))
            drawRoundRect(Brush.horizontalGradient(listOf(pot.tone(0.72f), pot, pot.tone(1.22f))), o(0.18f, 0.7f), s(0.64f, 0.27f), CornerRadius(5.dp.toPx()))
            drawOval(pot.tone(0.72f), o(0.18f, 0.66f), s(0.64f, 0.12f))
            drawLine(Color(0xFF765039), o(0.5f, 0.72f), o(0.43f, 0.42f), 4.dp.toPx(), StrokeCap.Round)
            drawLine(Color(0xFF765039), o(0.43f, 0.48f), o(0.25f, 0.3f), 2.5.dp.toPx(), StrokeCap.Round)
            drawLine(Color(0xFF765039), o(0.45f, 0.5f), o(0.68f, 0.28f), 2.5.dp.toPx(), StrokeCap.Round)
            listOf(Triple(.25f,.25f,.25f), Triple(.48f,.18f,.28f), Triple(.7f,.27f,.24f), Triple(.4f,.38f,.24f), Triple(.65f,.4f,.2f)).forEach { (x,y,r) ->
                drawCircle(Color(0xFF244D35), r*w, o(x,y+0.025f))
                drawCircle(Color(0xFF477C4C), r*w*.78f, o(x-.025f,y-.025f))
                drawCircle(Color(0xFF78A65B).copy(alpha=.8f), r*w*.22f, o(x-.07f,y-.08f))
            }
            drawLine(Color(0xFFE5C18B), o(.24f,.76f), o(.76f,.76f), 1.dp.toPx())
        }
        "fern" -> {
            val leaf = Color(0xFF4D8750)
            drawRoundRect(tint ?: Color(0xFFB87950), o(.22f,.76f), s(.56f,.22f), CornerRadius(4.dp.toPx()))
            drawOval(Color(0xFF6B4734), o(.2f,.72f), s(.6f,.1f))
            drawLine(Color(0xFF47734A), o(.5f,.78f), o(.5f,.12f), 1.7.dp.toPx())
            for (i in 0..5) {
                val y=.2f+i*.095f; val spread=.12f+i*.025f
                val left=Path().apply { moveTo(.5f*w,y*h); quadraticBezierTo((.5f-spread*.5f)*w,(y-.04f)*h,(.5f-spread)*w,(y-.13f)*h); quadraticBezierTo((.5f-spread*.3f)*w,(y-.12f)*h,.5f*w,y*h); close() }
                val right=Path().apply { moveTo(.5f*w,y*h); quadraticBezierTo((.5f+spread*.5f)*w,(y-.04f)*h,(.5f+spread)*w,(y-.13f)*h); quadraticBezierTo((.5f+spread*.3f)*w,(y-.12f)*h,.5f*w,y*h); close() }
                drawPath(left, leaf.tone(if(i%2==0) .88f else 1.12f)); drawPath(right, leaf)
            }
        }
        "terrarium" -> {
            drawOval(Color(0x334A3020), o(.16f,.88f), s(.68f,.08f))
            drawRoundRect(Color(0x557FC3D8), o(.12f,.16f), s(.76f,.76f), CornerRadius(.22f*w), style=Stroke(width=1.5.dp.toPx()))
            drawOval(Color(0x668BC7D5), o(.12f,.12f), s(.76f,.16f), style=Stroke(width=1.dp.toPx()))
            drawOval(Color(0xFF8C6945), o(.18f,.78f), s(.64f,.12f))
            drawLine(Color(0xFF477B4C), o(.5f,.8f), o(.42f,.42f), 2.dp.toPx())
            drawLine(Color(0xFF477B4C), o(.5f,.72f), o(.68f,.48f), 1.5.dp.toPx())
            drawOval(Color(0xFF4F8B57), o(.25f,.38f), s(.32f,.16f)); drawOval(Color(0xFF6AA66B), o(.5f,.46f), s(.28f,.14f))
            drawCircle(Color(0xFFE6C36C), .035f*w, o(.32f,.72f)); drawCircle(Color(0xFFB86E56), .04f*w, o(.7f,.74f))
            drawLine(Color.White.copy(alpha=.6f), o(.22f,.25f), o(.22f,.66f), 1.6.dp.toPx())
        }
        "dragon" -> {
            val bronze=tint ?: Color(0xFF9A713C)
            val body=Path().apply { moveTo(.16f*w,.78f*h); cubicTo(.12f*w,.48f*h,.42f*w,.42f*h,.55f*w,.64f*h); cubicTo(.72f*w,.82f*h,.82f*w,.46f*h,.72f*w,.34f*h); cubicTo(.62f*w,.22f*h,.42f*w,.3f*h,.48f*w,.46f*h); cubicTo(.55f*w,.58f*h,.35f*w,.62f*h,.16f*w,.78f*h); close() }
            drawPath(body, Brush.linearGradient(listOf(bronze.tone(1.3f),bronze,bronze.tone(.58f)), o(.2f,.1f), o(.8f,.9f)))
            val wing=Path().apply { moveTo(.43f*w,.52f*h); lineTo(.18f*w,.12f*h); lineTo(.5f*w,.28f*h); lineTo(.66f*w,.08f*h); lineTo(.68f*w,.48f*h); close() }
            drawPath(wing,bronze.tone(1.12f)); drawLine(Color(0xFF4D3825),o(.43f,.5f),o(.22f,.16f),1.dp.toPx()); drawLine(Color(0xFF4D3825),o(.43f,.5f),o(.51f,.3f),1.dp.toPx())
            drawCircle(Color(0xFFFFD36B),.025f*w,o(.78f,.31f)); drawLine(bronze.tone(.65f),o(.78f,.36f),o(.91f,.28f),2.dp.toPx(),StrokeCap.Round)
            drawOval(Color(0xFF5A402B),o(.08f,.84f),s(.84f,.1f))
        }
        "bust" -> {
            val stone=tint ?: Color(0xFF9A958A)
            drawRoundRect(Color(0xFF514B45),o(.18f,.82f),s(.64f,.16f),CornerRadius(3.dp.toPx()))
            drawRoundRect(stone.tone(.78f),o(.28f,.66f),s(.44f,.2f),CornerRadius(5.dp.toPx()))
            drawOval(Brush.horizontalGradient(listOf(stone.tone(.72f),stone,stone.tone(1.2f))),o(.2f,.28f),s(.6f,.48f))
            drawCircle(stone,o(.5f,.24f).let{.22f*w},o(.5f,.22f))
            drawOval(stone.tone(.72f),o(.27f,.04f),s(.46f,.22f)); drawOval(stone,o(.3f,.08f),s(.4f,.15f))
            drawLine(Color(0xFF49443F),o(.37f,.28f),o(.44f,.28f),1.dp.toPx()); drawLine(Color(0xFF49443F),o(.56f,.28f),o(.63f,.28f),1.dp.toPx())
            drawLine(stone.tone(.62f),o(.5f,.3f),o(.48f,.4f),1.dp.toPx()); drawLine(Color(0xFF514B45),o(.43f,.48f),o(.57f,.48f),1.dp.toPx())
        }
        "astrolabe" -> {
            val gold=tint ?: Color(0xFFC69A48)
            drawCircle(Color(0xFF4B3524),.43f*w,o(.5f,.43f)); drawCircle(gold,.4f*w,o(.5f,.4f),style=Stroke(width=2.dp.toPx()))
            drawCircle(gold,.29f*w,o(.5f,.4f),style=Stroke(width=1.dp.toPx())); drawCircle(gold,.12f*w,o(.5f,.4f),style=Stroke(width=1.dp.toPx()))
            for(i in 0..11){ val a=Math.toRadians(i*30.0); drawLine(gold,o(.5f+.31f*kotlin.math.sin(a).toFloat(),.4f-.31f*kotlin.math.cos(a).toFloat()),o(.5f+.37f*kotlin.math.sin(a).toFloat(),.4f-.37f*kotlin.math.cos(a).toFloat()),1.dp.toPx()) }
            drawLine(Color(0xFFE9D6A0),o(.5f,.06f),o(.5f,.82f),1.dp.toPx()); drawLine(gold,o(.18f,.4f),o(.82f,.4f),1.dp.toPx())
            drawLine(gold,o(.5f,.4f),o(.7f,.17f),2.dp.toPx()); drawCircle(Color(0xFFE9D6A0),.035f*w,o(.5f,.4f))
            drawRoundRect(Color(0xFF76502E),o(.35f,.84f),s(.3f,.1f),CornerRadius(2.dp.toPx()))
        }
        "lantern" -> {
            val metal=tint ?: Color(0xFF705034)
            drawOval(Color(0x55FFB94F),o(.18f,.3f),s(.64f,.55f))
            drawArc(metal,180f,180f,false,o(.28f,.02f),s(.44f,.3f),style=Stroke(width=2.dp.toPx()))
            drawRoundRect(metal,o(.12f,.22f),s(.76f,.68f),CornerRadius(5.dp.toPx()))
            drawRoundRect(Color(0x99FFD987),o(.25f,.32f),s(.5f,.46f),CornerRadius(3.dp.toPx()))
            drawRoundRect(Color(0xFFFFC45C),o(.44f,.48f),s(.12f,.23f),CornerRadius(4.dp.toPx()))
            drawPath(Path().apply{moveTo(.5f*w,.37f*h);quadraticTo(.68f*w,.52f,.5f*w,.7f*h);quadraticTo(.32f*w,.52f,.5f*w,.37f*h);close()},Color(0xFFFFE7A1))
            drawLine(metal,o(.12f,.3f),o(.88f,.3f),2.dp.toPx()); drawLine(metal,o(.12f,.8f),o(.88f,.8f),2.dp.toPx()); drawLine(Color.White.copy(alpha=.35f),o(.31f,.34f),o(.31f,.72f),1.dp.toPx())
            drawRoundRect(metal,o(.08f,.88f),s(.84f,.1f),CornerRadius(3.dp.toPx()))
        }
        "chest" -> {
            val wood=tint ?: Color(0xFF8B5736)
            drawOval(Color(0x44000000),o(.08f,.84f),s(.84f,.12f))
            drawRoundRect(Brush.verticalGradient(listOf(wood.tone(1.25f),wood,wood.tone(.65f))),o(.08f,.34f),s(.84f,.58f),CornerRadius(5.dp.toPx()))
            drawArc(wood.tone(1.2f),180f,180f,false,o(.08f,.08f),s(.84f,.52f))
            drawLine(Color(0xFFD4AF65),o(.12f,.48f),o(.88f,.48f),3.dp.toPx()); drawLine(Color(0xFFD4AF65),o(.12f,.78f),o(.88f,.78f),2.dp.toPx())
            drawRoundRect(Color(0xFFD4AF65),o(.42f,.48f),s(.16f,.26f),CornerRadius(3.dp.toPx())); drawCircle(Color(0xFF604328),.035f*w,o(.5f,.61f))
            drawLine(Color(0xFFE8C77F),o(.2f,.34f),o(.2f,.88f),1.5.dp.toPx()); drawLine(Color(0xFFE8C77F),o(.8f,.34f),o(.8f,.88f),1.5.dp.toPx())
        }
        "telescope" -> {
            val brass=tint ?: Color(0xFFB18A4A)
            drawLine(Color(0xFF5A4530),o(.18f,.86f),o(.5f,.46f),2.dp.toPx()); drawLine(Color(0xFF5A4530),o(.82f,.86f),o(.5f,.46f),2.dp.toPx()); drawLine(Color(0xFF5A4530),o(.5f,.46f),o(.5f,.92f),2.dp.toPx())
            drawLine(brass,o(.16f,.34f),o(.78f,.08f),8.dp.toPx(),StrokeCap.Round); drawLine(brass.tone(1.35f),o(.2f,.31f),o(.8f,.05f),2.dp.toPx(),StrokeCap.Round)
            drawLine(Color(0xFF5B4430),o(.08f,.37f),o(.23f,.3f),11.dp.toPx(),StrokeCap.Round); drawLine(Color(0xFF5B4430),o(.74f,.1f),o(.9f,.02f),13.dp.toPx(),StrokeCap.Round)
            drawCircle(Color(0xFF6D9BA8),.035f*w,o(.89f,.04f))
        }
        "scroll" -> {
            val paper=tint ?: Color(0xFFE5D0A2)
            drawRoundRect(paper,o(.14f,.2f),s(.72f,.66f),CornerRadius(5.dp.toPx()))
            drawOval(paper.tone(.78f),o(.08f,.16f),s(.22f,.72f)); drawOval(paper.tone(1.12f),o(.7f,.16f),s(.22f,.72f))
            drawLine(Color(0xFF8A6840),o(.3f,.38f),o(.7f,.38f),1.dp.toPx()); drawLine(Color(0xFF8A6840),o(.3f,.5f),o(.64f,.5f),1.dp.toPx()); drawLine(Color(0xFF8A6840),o(.3f,.62f),o(.68f,.62f),1.dp.toPx())
            drawPath(Path().apply{moveTo(.43f*w,.2f*h);lineTo(.5f*w,.04f*h);lineTo(.57f*w,.2f*h);close()},Color(0xFFB68A4A))
            drawLine(Color(0xFFB68A4A),o(.5f,.04f),o(.5f,.92f),1.dp.toPx())
        }
        "skull" -> {
            val bone=tint ?: Color(0xFFE4D8C1)
            drawRoundRect(Color(0xFF5A4534),o(.18f,.74f),s(.64f,.16f),CornerRadius(3.dp.toPx()))
            drawOval(Brush.horizontalGradient(listOf(bone.tone(.78f),bone,bone.tone(1.12f))),o(.16f,.08f),s(.68f,.72f))
            drawRoundRect(bone.tone(.82f),o(.3f,.62f),s(.4f,.28f),CornerRadius(5.dp.toPx()))
            drawCircle(Color(0xFF493B32),.105f*w,o(.35f,.48f)); drawCircle(Color(0xFF493B32),.105f*w,o(.65f,.48f))
            val nose=Path().apply{moveTo(.5f*w,.52f*h);lineTo(.43f*w,.66f*h);lineTo(.57f*w,.66f*h);close()}; drawPath(nose,Color(0xFF493B32))
            for(i in 0..3) drawLine(Color(0xFF6E5A48),o(.38f+i*.08f,.72f),o(.38f+i*.08f,.84f),1.dp.toPx())
        }
        "crystal" -> {
            val gem=tint ?: Color(0xFF75A9B8)
            val a=Path().apply{moveTo(.5f*w,.02f*h);lineTo(.88f*w,.34f*h);lineTo(.68f*w,.9f*h);lineTo(.28f*w,.9f*h);lineTo(.1f*w,.34f*h);close()}
            drawPath(a,Brush.linearGradient(listOf(gem.tone(1.35f),gem,gem.tone(.65f)),o(.1f,.1f),o(.9f,.9f)))
            drawLine(Color.White.copy(alpha=.75f),o(.5f,.02f),o(.5f,.9f),1.dp.toPx()); drawLine(Color.White.copy(alpha=.45f),o(.5f,.02f),o(.1f,.34f),1.dp.toPx()); drawLine(gem.tone(.55f),o(.5f,.02f),o(.68f,.9f),1.dp.toPx())
            drawPath(Path().apply{moveTo(.1f*w,.34f*h);lineTo(.5f*w,.34f*h);lineTo(.28f*w,.9f*h);close()},Color.White.copy(alpha=.16f))
            drawOval(Color(0xFF70523A),o(.18f,.88f),s(.64f,.1f))
        }
        "bookend" -> {
            val stone=tint ?: Color(0xFFB28B55)
            drawRoundRect(Color(0xFF55402D),o(.12f,.84f),s(.76f,.12f),CornerRadius(2.dp.toPx()))
            val shape=Path().apply{moveTo(.2f*w,.84f*h);lineTo(.2f*w,.18f*h);quadraticTo(.2f*w,.06f*h,.34f*w,.06f*h);lineTo(.68f*w,.06f*h);lineTo(.68f*w,.84f*h);close()}
            drawPath(shape,Brush.horizontalGradient(listOf(stone.tone(.72f),stone,stone.tone(1.2f))))
            drawPath(Path().apply{moveTo(.34f*w,.22f*h);lineTo(.54f*w,.22f*h);lineTo(.54f*w,.66f*h);lineTo(.34f*w,.66f*h);close()},Color(0xFF5D4935).copy(alpha=.35f))
            drawLine(Color(0xFFEAD49B),o(.2f,.18f),o(.68f,.18f),1.dp.toPx())
            drawCircle(Color(0xFFEAD49B),.035f*w,o(.44f,.42f))
        }
        "potion" -> {
            val liquid=tint ?: Color(0xFF4E9B83)
            drawRoundRect(Color(0xFF8A6840),o(.34f,.04f),s(.32f,.14f),CornerRadius(2.dp.toPx()))
            drawRoundRect(Color(0xFFB78B4D),o(.28f,.14f),s(.44f,.1f),CornerRadius(2.dp.toPx()))
            drawPath(Path().apply{moveTo(.34f*w,.24f*h);lineTo(.66f*w,.24f*h);lineTo(.86f*w,.48f*h);lineTo(.8f*w,.92f*h);quadraticTo(.5f*w,1.02f*h,.2f*w,.92f*h);lineTo(.14f*w,.48f*h);close()},Color(0x668AC8D2))
            drawPath(Path().apply{moveTo(.2f*w,.62f*h);lineTo(.8f*w,.62f*h);lineTo(.8f*w,.9f*h);quadraticTo(.5f*w,.98f*h,.2f*w,.9f*h);close()},liquid)
            drawLine(Color.White.copy(alpha=.6f),o(.27f,.4f),o(.24f,.75f),1.6.dp.toPx())
            drawCircle(Color(0xFFE8C77B),.035f*w,o(.5f,.72f)); drawCircle(Color(0xFFE8C77B),.02f*w,o(.42f,.82f))
        }
        else -> Unit
    }
}
