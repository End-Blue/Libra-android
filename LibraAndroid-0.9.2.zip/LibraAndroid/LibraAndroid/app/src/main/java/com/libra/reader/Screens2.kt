@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.libra.reader

import android.content.Context
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ══════════════════════════════════════════════════════════════════════════════
// AYUDAS COMUNES
// ══════════════════════════════════════════════════════════════════════════════

/** Estado efectivo: el que eligió el lector o, si no hay, el que dice el progreso. */
internal fun LibraryItem.statusKey(): String = when {
    status.isNotEmpty() -> status
    progress >= 97 -> "FINISHED"
    progress > 0 -> "READING"
    else -> "TBR"
}

internal fun statusLabel(s: String): String = when (s) {
    "READING" -> "Leyendo"
    "FINISHED" -> "Terminado"
    else -> "Por leer"
}

internal val STATUS_KEYS = listOf("TBR", "READING", "FINISHED")

internal val GENRES = listOf(
    "Fantasía", "Ciencia ficción", "Romance", "Misterio", "Terror", "Histórica",
    "Clásicos", "Ensayo", "Biografía", "Infantil", "Superación", "Otro"
)

internal fun LibraryItem.genreLabel(): String = genre.ifBlank { "Sin género" }

private val DAY_FMT get() = SimpleDateFormat("dd/MM/yyyy", Locale("es"))

@Composable
internal fun PaperCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Panel)
            .border(1.dp, Line, RoundedCornerShape(16.dp))
            .padding(14.dp),
        content = content
    )
}

@Composable
internal fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text, color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold,
        letterSpacing = 1.5.sp, modifier = modifier
    )
}

@Composable
internal fun Stars(rating: Int, modifier: Modifier = Modifier, size: Int = 14, onChange: ((Int) -> Unit)? = null) {
    Row(modifier) {
        for (i in 1..5) {
            Text(
                if (i <= rating) "★" else "☆",
                color = if (i <= rating) Gold else Muted,
                fontSize = size.sp,
                modifier = if (onChange != null) {
                    Modifier.clickable { onChange(if (i == rating) 0 else i) }.padding(horizontal = 3.dp)
                } else Modifier
            )
        }
    }
}

@Composable
private fun SmallChip(text: String) {
    Text(
        text, color = Gold, fontSize = 10.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Gold.copy(alpha = 0.12f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    )
}

// ══════════════════════════════════════════════════════════════════════════════
// PANEL (INICIO)
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun DashboardScreen(
    books: List<LibraryItem>,
    days: Set<String>,
    status: String,
    busy: Boolean,
    onMarkToday: () -> Unit,
    onOpen: (LibraryItem) -> Unit,
    onDetail: (LibraryItem) -> Unit,
    onImport: () -> Unit,
    onScan: () -> Unit
) {
    val streak = remember(days) { Streak.current(days) }
    val readToday = Streak.key() in days
    val reading = remember(books) { books.filter { it.statusKey() == "READING" }.sortedByDescending { it.startedAt } }
    val recent = remember(books) { books.sortedByDescending { it.addedAt }.take(14) }
    val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    val greeting = if (hour < 12) "Buenos días" else if (hour < 19) "Buenas tardes" else "Buenas noches"
    val dateText = remember {
        SimpleDateFormat("EEEE d 'de' MMMM", Locale("es")).format(Date()).replaceFirstChar { it.uppercase() }
    }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Column {
                Text(greeting, color = Cream, fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
                Text(dateText, color = Muted, fontSize = 13.sp)
            }
        }
        item {
            PaperCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🔥", fontSize = 30.sp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("$streak ${if (streak == 1) "día" else "días"} seguidos", color = Cream,
                            fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("Tu racha de lectura", color = Muted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
                WeekDots(days)
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = onMarkToday,
                    enabled = !readToday,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)
                ) { Text(if (readToday) "✓ Hoy ya leíste" else "Marcar hoy como leído") }
            }
        }
        item { SectionTitle("LEYENDO AHORA") }
        if (reading.isEmpty()) {
            item {
                PaperCard(Modifier.fillMaxWidth()) {
                    Text("Aún no tienes libros en lectura. Abre uno de tu biblioteca para empezar.",
                        color = Cream, fontSize = 14.sp, lineHeight = 20.sp)
                }
            }
        } else {
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(reading, key = { it.id }) { b ->
                        ReadingCard(b, Modifier.fillParentMaxWidth(0.92f), onOpen, onDetail)
                    }
                }
            }
        }
        if (recent.isNotEmpty()) {
            item { SectionTitle("AÑADIDOS RECIENTEMENTE") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(recent, key = { it.id }) { b ->
                        Column(Modifier.width(90.dp).clickable { onDetail(b) }) {
                            BookCover(b, Modifier.size(width = 90.dp, height = 130.dp))
                            Spacer(Modifier.height(4.dp))
                            Text(b.title, color = Cream, fontSize = 11.sp, maxLines = 2,
                                overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onImport, enabled = !busy, modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)
                ) {
                    LibIcon(LibIconKind.PLUS, tint = Ink, size = 18.dp)
                    Spacer(Modifier.width(6.dp))
                    Text("Importar", fontSize = 13.sp)
                }
                OutlinedButton(
                    onClick = onScan, enabled = !busy, modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
                ) {
                    LibIcon(LibIconKind.SCAN, tint = Gold, size = 18.dp)
                    Spacer(Modifier.width(6.dp))
                    Text("Escanear", fontSize = 13.sp)
                }
            }
        }
        item { Text(status, color = Muted, fontSize = 11.sp) }
    }
}

@Composable
private fun WeekDots(days: Set<String>) {
    val today = Streak.key()
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Streak.weekKeys().forEach { (label, key) ->
            val done = key in days
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(label, color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(4.dp))
                Box(
                    Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(if (done) Gold else Color.Transparent)
                        .border(
                            if (key == today) 2.dp else 1.dp,
                            if (done || key == today) Gold else Line,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) { if (done) Text("✓", color = Ink, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun ReadingCard(
    b: LibraryItem,
    modifier: Modifier,
    onOpen: (LibraryItem) -> Unit,
    onDetail: (LibraryItem) -> Unit
) {
    PaperCard(modifier.clickable { onDetail(b) }) {
        Row {
            BookCover(b, Modifier.size(width = 70.dp, height = 100.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(b.title, color = Cream, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                    maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(b.author, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SmallChip(b.format)
                    if (b.genre.isNotBlank()) SmallChip(b.genre)
                }
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { b.progress / 100f },
                    color = Gold, trackColor = Line,
                    modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(50))
                )
                Text("${b.progress}% leído", color = Muted, fontSize = 11.sp,
                    modifier = Modifier.padding(top = 3.dp))
            }
        }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = { onOpen(b) }, modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)
        ) { Text("Continuar leyendo") }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// BIBLIOTECA con filtros
// ══════════════════════════════════════════════════════════════════════════════

@Composable
internal fun FilterMenu(label: String, value: String, options: List<String>, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        FilterChip(
            selected = value.isNotEmpty(),
            onClick = { open = true },
            label = { Text(if (value.isEmpty()) label else value, maxLines = 1, fontSize = 12.sp) },
            colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = Gold, selectedLabelColor = Ink, labelColor = Cream
            )
        )
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(text = { Text("Todos") }, onClick = { onPick(""); open = false })
            options.forEach { o ->
                DropdownMenuItem(text = { Text(o) }, onClick = { onPick(o); open = false })
            }
        }
    }
}

/** Valor de texto que se recuerda al cambiar de pestaña o cerrar la app (filtros, búsquedas…). */
@Composable
internal fun rememberPrefString(key: String, default: String): MutableState<String> {
    val prefs = androidx.compose.ui.platform.LocalContext.current.getSharedPreferences("libra_prefs", 0)
    val st = remember(key) { mutableStateOf(prefs.getString(key, default) ?: default) }
    LaunchedEffect(st.value) { prefs.edit().putString(key, st.value).apply() }
    return st
}

@Composable
internal fun rememberPrefBool(key: String, default: Boolean): MutableState<Boolean> {
    val prefs = androidx.compose.ui.platform.LocalContext.current.getSharedPreferences("libra_prefs", 0)
    val st = remember(key) { mutableStateOf(prefs.getBoolean(key, default)) }
    LaunchedEffect(st.value) { prefs.edit().putBoolean(key, st.value).apply() }
    return st
}

@Composable
fun LibraryScreen2(
    books: List<LibraryItem>,
    onDetail: (LibraryItem) -> Unit,
    onToggleFavorite: (LibraryItem) -> Unit,
    onImport: () -> Unit,
    onScan: () -> Unit
) {
    var statusFilter by rememberPrefString("ui_lib_status", "")
    var author by rememberPrefString("ui_lib_author", "")
    var genre by rememberPrefString("ui_lib_genre", "")
    var format by rememberPrefString("ui_lib_format", "")
    var minRating by rememberPrefString("ui_lib_rating", "")
    var grid by rememberPrefBool("ui_lib_grid", true)

    val filtered = books.filter { b ->
        (statusFilter.isEmpty() || b.statusKey() == statusFilter) &&
            (author.isEmpty() || b.author == author) &&
            (genre.isEmpty() || b.genreLabel() == genre) &&
            (format.isEmpty() || b.format == format) &&
            (minRating.isEmpty() || b.rating >= minRating.first().digitToInt())
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("" to "Todos", "TBR" to "Por leer", "READING" to "Leyendo", "FINISHED" to "Terminados")
                .forEach { (k, label) ->
                    val n = if (k.isEmpty()) books.size else books.count { it.statusKey() == k }
                    FilterChip(
                        selected = statusFilter == k,
                        onClick = { statusFilter = k },
                        label = { Text("$label · $n", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Gold, selectedLabelColor = Ink, labelColor = Cream
                        )
                    )
                }
        }
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterMenu("Autor", author, books.map { it.author }.distinct().sorted()) { author = it }
            FilterMenu("Género", genre, books.map { it.genreLabel() }.distinct().sorted()) { genre = it }
            FilterMenu("Formato", format, books.map { it.format }.distinct().sorted()) { format = it }
            FilterMenu("Valoración", minRating, listOf("1+", "2+", "3+", "4+", "5")) { minRating = it }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${filtered.size} libros", color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
            LibIconButton(LibIconKind.GRID, onClick = { grid = true },
                tint = if (grid) Gold else Muted, filled = grid)
            LibIconButton(LibIconKind.LIST, onClick = { grid = false },
                tint = if (!grid) Gold else Muted, filled = !grid)
        }
        if (books.isEmpty()) {
            EmptyFeature("AÚN NO HAY LIBROS", "Importa tus archivos o usa el escáner para añadir tu colección.")
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onImport, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)) { Text("Importar") }
                OutlinedButton(onClick = onScan, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)) { Text("Escanear") }
            }
        } else if (filtered.isEmpty()) {
            Text("Ningún libro coincide con los filtros.", color = Muted, fontSize = 13.sp,
                modifier = Modifier.padding(top = 16.dp))
        } else if (grid) {
            CoverGrid(filtered, onDetail, Modifier.weight(1f))
        } else {
            LazyColumn(Modifier.weight(1f)) {
                items(filtered, key = { it.id }) { b -> BookLine(b, onDetail, onToggleFavorite) }
            }
        }
    }
}

@Composable
internal fun CoverGrid(books: List<LibraryItem>, onDetail: (LibraryItem) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier, verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 6.dp)) {
        items(books.chunked(3)) { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { b ->
                    Column(Modifier.weight(1f).clickable { onDetail(b) }) {
                        BookCover(b, Modifier.fillMaxWidth().height(150.dp))
                        Spacer(Modifier.height(4.dp))
                        Text(b.title, color = Cream, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                            maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(b.author, color = Muted, fontSize = 10.sp, maxLines = 1,
                            overflow = TextOverflow.Ellipsis)
                        if (b.rating > 0) Stars(b.rating, size = 11)
                        else if (b.progress in 1..96) {
                            LinearProgressIndicator(
                                progress = { b.progress / 100f }, color = Gold, trackColor = Line,
                                modifier = Modifier.fillMaxWidth().padding(top = 3.dp).height(3.dp)
                            )
                        }
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun BookLine(b: LibraryItem, onDetail: (LibraryItem) -> Unit, onToggleFavorite: (LibraryItem) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onDetail(b) }.padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BookCover(b, Modifier.size(width = 48.dp, height = 68.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(b.title, color = Cream, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text("${b.author} · ${b.format}", color = Muted, fontSize = 11.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallChip(statusLabel(b.statusKey()))
                if (b.rating > 0) Stars(b.rating, size = 11)
            }
        }
        LibIconButton(
            LibIconKind.STAR, onClick = { onToggleFavorite(b) },
            tint = if (b.isFavorite == 1) Gold else Muted, filled = b.isFavorite == 1
        )
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// DETALLE DEL LIBRO (hoja inferior)
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun BookDetailSheet(
    item: LibraryItem,
    notesCount: Int,
    onDismiss: () -> Unit,
    onRead: () -> Unit,
    onStatus: (String) -> Unit,
    onRating: (Int) -> Unit,
    onGenre: (String) -> Unit,
    onReview: (String) -> Unit,
    onFavorite: () -> Unit,
    onDelete: () -> Unit
) {
    var review by remember(item.id) { mutableStateOf(item.review) }
    var genre by remember(item.id) { mutableStateOf(item.genre) }
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = {
            if (review != item.review) onReview(review)
            onDismiss()
        },
        sheetState = state,
        containerColor = Panel
    ) {
        Column(
            Modifier
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row {
                BookCover(item, Modifier.size(width = 96.dp, height = 140.dp))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.title, color = Cream, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                        maxLines = 3, overflow = TextOverflow.Ellipsis)
                    Text(item.author, color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        SmallChip(item.format)
                        SmallChip("${item.progress}%")
                        if (notesCount > 0) SmallChip("$notesCount notas")
                    }
                    Spacer(Modifier.height(8.dp))
                    Stars(item.rating, size = 22, onChange = onRating)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onRead, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)
                ) { Text(if (item.progress > 0) "Continuar" else "Leer") }
                OutlinedButton(
                    onClick = onFavorite, shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
                ) { Text(if (item.isFavorite == 1) "★ Favorito" else "☆ Favorito") }
            }

            SectionTitle("ESTADO")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                STATUS_KEYS.forEach { k ->
                    FilterChip(
                        selected = item.statusKey() == k,
                        onClick = { onStatus(k) },
                        label = { Text(statusLabel(k)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Gold, selectedLabelColor = Ink, labelColor = Cream
                        )
                    )
                }
            }

            SectionTitle("GÉNERO")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GENRES.forEach { g ->
                    FilterChip(
                        selected = genre == g,
                        onClick = { genre = if (genre == g) "" else g; onGenre(genre) },
                        label = { Text(g, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Gold, selectedLabelColor = Ink, labelColor = Cream
                        )
                    )
                }
            }
            OutlinedTextField(
                value = genre,
                onValueChange = { genre = it },
                placeholder = { Text("O escribe otro género…", color = Muted, fontSize = 13.sp) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { onGenre(genre.trim()) }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Cream, unfocusedTextColor = Cream,
                    focusedBorderColor = Gold, unfocusedBorderColor = Line
                )
            )

            SectionTitle("MI RESEÑA")
            OutlinedTextField(
                value = review,
                onValueChange = { review = it },
                placeholder = { Text("¿Qué te pareció?", color = Muted, fontSize = 13.sp) },
                minLines = 3,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Cream, unfocusedTextColor = Cream,
                    focusedBorderColor = Gold, unfocusedBorderColor = Line
                )
            )
            TextButton(onClick = { onReview(review); onGenre(genre.trim()) }) {
                Text("Guardar reseña y género", color = Gold)
            }

            SectionTitle("DATOS")
            Text(
                "Añadido: ${DAY_FMT.format(Date(item.addedAt))}" +
                    (if (item.startedAt > 0) "\nEmpezado: ${DAY_FMT.format(Date(item.startedAt))}" else "") +
                    (if (item.finishedAt > 0) "\nTerminado: ${DAY_FMT.format(Date(item.finishedAt))}" else ""),
                color = Muted, fontSize = 12.sp, lineHeight = 18.sp
            )
            TextButton(onClick = onDelete) { Text("Quitar de la biblioteca", color = Color(0xFFB3322F)) }
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// FAVORITOS
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun FavoritesScreen(books: List<LibraryItem>, onDetail: (LibraryItem) -> Unit) {
    val favs = books.filter { it.isFavorite == 1 }
    if (favs.isEmpty()) {
        EmptyFeature("SIN FAVORITOS", "Abre un libro y márcalo con ☆ Favorito: aparecerá aquí.")
    } else {
        Text("${favs.size} favoritos", color = Muted, fontSize = 12.sp)
        CoverGrid(favs, onDetail, Modifier.fillMaxSize())
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// RACHA
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun StreakScreen(days: Set<String>, onMarkToday: () -> Unit) {
    val current = remember(days) { Streak.current(days) }
    val best = remember(days) { Streak.best(days) }
    val readToday = Streak.key() in days
    val cal = remember { Calendar.getInstance() }
    val year = cal.get(Calendar.YEAR)
    val month = cal.get(Calendar.MONTH)
    val first = Calendar.getInstance().apply { set(year, month, 1) }
    val offset = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7
    val dim = first.getActualMaximum(Calendar.DAY_OF_MONTH)
    val rows = (offset + dim + 6) / 7
    val monthName = remember {
        SimpleDateFormat("MMMM yyyy", Locale("es")).format(first.time).replaceFirstChar { it.uppercase() }
    }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            PaperCard(Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🔥", fontSize = 48.sp)
                    Text("$current", color = Cream, fontSize = 48.sp, fontWeight = FontWeight.Bold)
                    Text(if (current == 1) "día seguido" else "días seguidos", color = Muted, fontSize = 14.sp)
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = onMarkToday, enabled = !readToday, shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)
                    ) { Text(if (readToday) "✓ Hoy ya leíste" else "Marcar hoy como leído") }
                    Text("Abrir un libro y avanzar también cuenta como día leído.", color = Muted,
                        fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp), textAlign = TextAlign.Center)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("Mejor racha", "$best", Modifier.weight(1f))
                StatTile("Días leídos", "${days.size}", Modifier.weight(1f))
            }
        }
        item {
            PaperCard(Modifier.fillMaxWidth()) {
                SectionTitle(monthName.uppercase())
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth()) {
                    listOf("L", "M", "X", "J", "V", "S", "D").forEach {
                        Text(it, color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1f))
                    }
                }
                for (r in 0 until rows) {
                    Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                        for (c in 0 until 7) {
                            val day = r * 7 + c - offset + 1
                            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                                if (day in 1..dim) {
                                    val key = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day)
                                    val done = key in days
                                    Box(
                                        Modifier.size(32.dp).clip(CircleShape)
                                            .background(if (done) Gold else Color.Transparent)
                                            .border(
                                                if (key == Streak.key()) 2.dp else 0.dp,
                                                if (key == Streak.key()) Gold else Color.Transparent, CircleShape
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("$day", fontSize = 12.sp, color = if (done) Ink else Cream)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    PaperCard(modifier) {
        Text(value, color = Cream, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1,
            overflow = TextOverflow.Ellipsis)
        Text(label, color = Muted, fontSize = 11.sp)
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// RETO DE LECTURA
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun ChallengeScreen(books: List<LibraryItem>, goal: Int, onGoal: (Int) -> Unit) {
    val year = Calendar.getInstance().get(Calendar.YEAR)
    val done = books.count { b ->
        b.statusKey() == "FINISHED" && (b.finishedAt == 0L ||
            Calendar.getInstance().apply { timeInMillis = b.finishedAt }.get(Calendar.YEAR) == year)
    }
    val frac = (done.toFloat() / goal.coerceAtLeast(1)).coerceIn(0f, 1f)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        PaperCard(Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                SectionTitle("RETO $year")
                Spacer(Modifier.height(12.dp))
                Box(contentAlignment = Alignment.Center) {
                    Canvas(Modifier.size(170.dp)) {
                        val stroke = 16.dp.toPx()
                        val arcSize = Size(size.width - stroke, size.height - stroke)
                        val topLeft = Offset(stroke / 2f, stroke / 2f)
                        drawArc(Line, -90f, 360f, false, topLeft, arcSize,
                            style = Stroke(width = stroke, cap = StrokeCap.Round))
                        if (frac > 0f) {
                            drawArc(Gold, -90f, 360f * frac, false, topLeft, arcSize,
                                style = Stroke(width = stroke, cap = StrokeCap.Round))
                        }
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("$done / $goal", color = Cream, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        Text("libros", color = Muted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    if (done >= goal) "¡Reto cumplido! 🎉" else "Te faltan ${goal - done} para tu meta.",
                    color = Cream, fontSize = 14.sp
                )
            }
        }
        PaperCard(Modifier.fillMaxWidth()) {
            SectionTitle("MI META DEL AÑO")
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { onGoal(goal - 1) }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)) { Text("−") }
                Text("$goal libros", color = Cream, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                OutlinedButton(onClick = { onGoal(goal + 1) }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)) { Text("+") }
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// RESUMEN
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun RecapScreen(books: List<LibraryItem>, notesCount: Int, days: Set<String>) {
    val rated = books.filter { it.rating > 0 }
    val avg = if (rated.isEmpty()) "—" else String.format(Locale.US, "%.1f", rated.map { it.rating }.average())
    val topGenre = books.filter { it.genre.isNotBlank() }.groupingBy { it.genre }.eachCount()
        .maxByOrNull { it.value }?.key ?: "—"
    val topAuthor = books.filter { it.author != "Autor no identificado" }.groupingBy { it.author }.eachCount()
        .maxByOrNull { it.value }?.key ?: "—"
    val tiles = listOf(
        "Libros" to "${books.size}",
        "Terminados" to "${books.count { it.statusKey() == "FINISHED" }}",
        "Leyendo" to "${books.count { it.statusKey() == "READING" }}",
        "Por leer" to "${books.count { it.statusKey() == "TBR" }}",
        "Valoración media" to avg,
        "Notas y subrayados" to "$notesCount",
        "Días leídos" to "${days.size}",
        "Mejor racha" to "${Streak.best(days)}",
        "Género favorito" to topGenre,
        "Autor más leído" to topAuthor
    )
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        items(tiles.chunked(2)) { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { (l, v) -> StatTile(l, v, Modifier.weight(1f)) }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// MENÚ «MÁS»
// ══════════════════════════════════════════════════════════════════════════════

private val MORE_TILES = listOf(
    Triple("Panel", "🏠", "Panel"),
    Triple("Estantería", "🪵", "Estantería"),
    Triple("Biblioteca", "📚", "Biblioteca"),
    Triple("Favoritos", "⭐", "Favoritos"),
    Triple("Notas", "📝", "Notas y citas"),
    Triple("Audio", "🎧", "Audiolibros"),
    Triple("Reto", "🏆", "Reto de lectura"),
    Triple("Resumen", "📊", "Resumen"),
    Triple("Racha", "🔥", "Racha"),
    Triple("Ajustes", "⚙️", "Ajustes")
)

@Composable
fun MoreSheet(
    onPick: (String) -> Unit,
    onTutorial: () -> Unit,
    onCsv: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Panel) {
        Column(
            Modifier.navigationBarsPadding().padding(horizontal = 16.dp).padding(bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Libellum", color = Cream, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            MORE_TILES.chunked(3).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { (key, icon, label) ->
                        Column(
                            Modifier.weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Ink)
                                .border(1.dp, Line, RoundedCornerShape(14.dp))
                                .clickable { onPick(key) }
                                .padding(vertical = 14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(icon, fontSize = 24.sp)
                            Spacer(Modifier.height(4.dp))
                            Text(label, color = Cream, fontSize = 11.sp, textAlign = TextAlign.Center)
                        }
                    }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onTutorial, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)) { Text("Tutorial") }
                OutlinedButton(onClick = onCsv, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)) { Text("Exportar CSV") }
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// EXPORTAR CSV
// ══════════════════════════════════════════════════════════════════════════════

private fun csv(v: String): String = "\"" + v.replace("\"", "\"\"").replace("\n", " ") + "\""

suspend fun exportCsv(context: Context, books: List<LibraryItem>, uri: Uri): String = withContext(Dispatchers.IO) {
    try {
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        fun d(t: Long) = if (t > 0) fmt.format(Date(t)) else ""
        val out = context.contentResolver.openOutputStream(uri, "w")
            ?: return@withContext "No se pudo crear el archivo."
        out.bufferedWriter(Charsets.UTF_8).use { w ->
            w.write("\uFEFF")
            w.write("Título,Autor,Formato,Estado,Progreso,Valoración,Género,Favorito,Añadido,Empezado,Terminado,Reseña\n")
            books.forEach { b ->
                w.write(
                    listOf(
                        csv(b.title), csv(b.author), csv(b.format), csv(statusLabel(b.statusKey())),
                        "${b.progress}", "${b.rating}", csv(b.genre), if (b.isFavorite == 1) "sí" else "no",
                        d(b.addedAt), d(b.startedAt), d(b.finishedAt), csv(b.review)
                    ).joinToString(",") + "\n"
                )
            }
        }
        "CSV exportado con ${books.size} libros."
    } catch (e: Exception) {
        "No se pudo exportar: ${e.message ?: "error desconocido"}"
    }
}
