package com.libra.reader

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Barra de acciones de la selección de texto del lector.
 *
 *  · Fila de colores: un toque resalta la selección con ese color (sin diálogo); «Nota» abre el selector con nota.
 *  · Fila de acciones (desplazable): Copiar · Buscar · Compartir · Definir · Frase · Quitar (solo si la selección
 *    toca un resaltado) · Limpiar.
 *  · [preview] muestra lo seleccionado, útil cuando es un único signo («,», «.») difícil de ver.
 *  · [atTop] la coloca arriba cuando la selección está en la parte baja de la hoja (para no taparla).
 */
@Composable
internal fun SelectionActionBar(
    modifier: Modifier,
    atTop: Boolean,
    preview: String,
    hasHighlight: Boolean,
    onColor: (Long) -> Unit,
    onNote: () -> Unit,
    onCopy: () -> Unit,
    onSearch: () -> Unit,
    onShare: () -> Unit,
    onDefine: () -> Unit,
    onSentence: () -> Unit,
    onRemove: () -> Unit,
    onClear: () -> Unit
) {
    val shape = if (atTop) RoundedCornerShape(bottomStart = 18.dp, bottomEnd = 18.dp)
    else RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp)
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = shape,
        color = Panel,
        shadowElevation = 12.dp
    ) {
        Column(
            Modifier
                .then(if (atTop) Modifier.statusBarsPadding() else Modifier.navigationBarsPadding())
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            val shown = preview.ifBlank { "espacio" }
            Text(
                "“$shown”",
                color = Muted,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                HIGHLIGHT_COLORS.forEach { (argb, name) ->
                    Box(
                        Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color(argb))
                            .border(1.dp, Muted, CircleShape)
                            .clickable { onColor(argb) }
                            .semantics { contentDescription = "Resaltar en $name" }
                    )
                    Spacer(Modifier.width(6.dp))
                }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onNote) { Text("Nota", color = Gold, fontSize = 13.sp) }
            }
            Spacer(Modifier.height(4.dp))
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                BarChip("Copiar", onClick = onCopy)
                BarChip("Buscar", onClick = onSearch)
                BarChip("Compartir", onClick = onShare)
                BarChip("Definir", onClick = onDefine)
                BarChip("Frase", onClick = onSentence)
                if (hasHighlight) BarChip("Quitar resaltado", tint = Gold, onClick = onRemove)
                BarChip("Limpiar", tint = Muted, onClick = onClear)
            }
        }
    }
}

@Composable
private fun BarChip(label: String, tint: Color = Cream, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Ink)
            .border(1.dp, Line, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = tint, fontSize = 13.sp, maxLines = 1) }
}
