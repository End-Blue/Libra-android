package com.libra.reader

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextPaint
import android.text.style.ForegroundColorSpan
import android.text.style.LeadingMarginSpan
import android.text.style.StyleSpan
import android.util.LruCache
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max
import kotlin.math.min

// ══════════════════════════════════════════════════════════════════════════════
// PAGINACIÓN Y DIBUJO DE PÁGINAS (motor nativo, sin WebView)
// ══════════════════════════════════════════════════════════════════════════════

/** Colores del tema de lectura (el mismo reparto que usaba el lector anterior). */
internal class ReaderPalette(val bg: Int, val fg: Int, val link: Int)

internal fun readerPalette(themeMode: Int): ReaderPalette = when (themeMode) {
    0 -> ReaderPalette(0xFF0B1426.toInt(), 0xFFF3E6C8.toInt(), 0xFFD4AF37.toInt())   // noche
    1 -> ReaderPalette(0xFFF4ECD8.toInt(), 0xFF3B2F1E.toInt(), 0xFF8A5A1F.toInt())   // papel (pergamino cálido)
    3 -> ReaderPalette(0xFF000000.toInt(), 0xFFE0E0E0.toInt(), 0xFF88AAFF.toInt())   // negro
    else -> ReaderPalette(0xFFFFFFFF.toInt(), 0xFF111111.toInt(), 0xFF1A5FB4.toInt())// blanco
}

private val typefaceCache = ConcurrentHashMap<String, Typeface>()

internal fun readerTypeface(ctx: Context, family: String): Typeface = typefaceCache.getOrPut(family) {
    when (family) {
        "sans" -> Typeface.SANS_SERIF
        "classic" -> runCatching { Typeface.createFromAsset(ctx.assets, "fonts/lora.ttf") }.getOrDefault(Typeface.SERIF)
        else -> Typeface.SERIF
    }
}

/** Todo lo que afecta a la composición de una página. Si cambia algo, se vuelve a paginar. */
internal class LayoutConfig(
    val widthPx: Int,
    val heightPx: Int,
    val marginPx: Int,
    val topPx: Int,
    val bottomPx: Int,
    val textSizePx: Float,
    val lineMult: Float,
    val typeface: Typeface,
    val familyKey: String,
    val justify: Boolean,
    val indent: Boolean,
    val fg: Int,
    val bg: Int,
    val link: Int,
    val density: Float
) {
    val key: String =
        "$widthPx|$heightPx|$marginPx|$topPx|$bottomPx|$textSizePx|$lineMult|$familyKey|$justify|$indent|$fg|$bg|$link"
}

// ── Elementos de una página ──────────────────────────────────────────────────

internal sealed class PageItem {
    abstract val top: Float
    abstract val bottom: Float
}

internal class TextItem(
    val block: TextBlock,
    val layout: StaticLayout,
    val firstLine: Int,
    val lineEnd: Int,          // exclusivo
    val x: Float,
    override val top: Float
) : PageItem() {
    override val bottom: Float get() = top + (layout.getLineTop(lineEnd) - layout.getLineTop(firstLine))
    val globalStart: Int get() = block.start + layout.getLineStart(firstLine)
    val globalEnd: Int get() = block.start + layout.getLineEnd(lineEnd - 1)
}

internal class ImageItem(val block: ImageBlock, val rect: RectF) : PageItem() {
    override val top: Float get() = rect.top
    override val bottom: Float get() = rect.bottom
}

internal class RuleItem(val block: RuleBlock, override val top: Float, val height: Float) : PageItem() {
    override val bottom: Float get() = top + height
}

internal class PageSpec(
    val chapter: Int,
    val number: Int,
    val items: List<PageItem>,
    val start: Int,
    val end: Int
)

/** Número de la página de [pages] que contiene el carácter [offset]. */
internal fun List<PageSpec>.indexForOffset(offset: Int): Int {
    if (isEmpty()) return 0
    var best = 0
    for (i in indices) if (this[i].start <= offset) best = i else break
    return best
}

// ── Imágenes ─────────────────────────────────────────────────────────────────

internal class ImageStore(private val read: (String) -> ByteArray?) {
    private val dims = ConcurrentHashMap<String, IntArray>()
    private val cache = object : LruCache<String, Bitmap>(28 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    private val warned = ConcurrentHashMap.newKeySet<String>()

    /** Lectura que nunca lanza: un recurso dañado o ausente devuelve null (y se registra una sola vez). */
    private fun safeRead(path: String): ByteArray? {
        val b = runCatching { read(path) }.getOrNull()
        if (b == null && warned.add(path)) readerLog("imagen no disponible: $path")
        return b
    }

    fun bytes(path: String): ByteArray? = safeRead(path)

    /** Tamaño original (ancho, alto) o null si no se puede leer la imagen. */
    fun size(path: String): Pair<Int, Int>? {
        val d = dims.getOrPut(path) {
            val b = safeRead(path)
            if (b == null) intArrayOf(0, 0) else {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                runCatching { BitmapFactory.decodeByteArray(b, 0, b.size, o) }
                intArrayOf(max(o.outWidth, 0), max(o.outHeight, 0))
            }
        }
        return if (d[0] > 0 && d[1] > 0) d[0] to d[1] else null
    }

    /** Imagen decodificada con la nitidez justa para [targetW] píxeles de ancho. */
    fun bitmap(path: String, targetW: Int): Bitmap? {
        val key = "$path@${targetW / 64}"
        cache.get(key)?.let { return it }
        val b = safeRead(path) ?: return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        runCatching { BitmapFactory.decodeByteArray(b, 0, b.size, o) }
        var sample = 1
        while (o.outWidth / (sample * 2) >= targetW && sample < 16) sample *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = runCatching { BitmapFactory.decodeByteArray(b, 0, b.size, o2) }.getOrNull() ?: return null
        cache.put(key, bmp)
        return bmp
    }
}

// ── Composición de un bloque de texto ────────────────────────────────────────

private fun sizeMult(kind: BlockKind): Float = when (kind) {
    BlockKind.H1 -> 1.45f
    BlockKind.H2 -> 1.25f
    BlockKind.H3 -> 1.12f
    else -> 1f
}

private fun isHeading(kind: BlockKind) = kind == BlockKind.H1 || kind == BlockKind.H2 || kind == BlockKind.H3

private fun leftExtra(kind: BlockKind, em: Float): Int = if (kind == BlockKind.QUOTE) (1.4f * em).toInt() else 0

internal fun buildBlockLayout(b: TextBlock, cfg: LayoutConfig, indentFirst: Boolean): StaticLayout {
    val em = cfg.textSizePx
    val width = (cfg.widthPx - 2 * cfg.marginPx - leftExtra(b.kind, em)).coerceAtLeast(40)
    val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = em * sizeMult(b.kind)
        color = cfg.fg
        typeface = if (b.kind == BlockKind.PRE) Typeface.MONOSPACE else cfg.typeface
    }
    val sb = SpannableStringBuilder(b.text)
    if (isHeading(b.kind) && sb.isNotEmpty()) {
        sb.setSpan(StyleSpan(Typeface.BOLD), 0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }
    for (ls in sb.getSpans(0, sb.length, LinkSpan::class.java)) {
        sb.setSpan(
            ForegroundColorSpan(cfg.link), sb.getSpanStart(ls), sb.getSpanEnd(ls),
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
    }
    if (indentFirst && sb.isNotEmpty()) {
        sb.setSpan(LeadingMarginSpan.Standard((1.6f * em).toInt(), 0), 0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }
    if (b.kind == BlockKind.LIST && sb.isNotEmpty()) {
        sb.setSpan(LeadingMarginSpan.Standard(0, (1.2f * em).toInt()), 0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }
    val centered = b.centered || b.kind == BlockKind.SCENE || isHeading(b.kind)
    val builder = StaticLayout.Builder.obtain(sb, 0, sb.length, paint, width)
        .setAlignment(if (centered) Layout.Alignment.ALIGN_CENTER else Layout.Alignment.ALIGN_NORMAL)
        .setLineSpacing(0f, if (isHeading(b.kind)) 1.15f else cfg.lineMult)
        .setIncludePad(false)
        .setBreakStrategy(Layout.BREAK_STRATEGY_HIGH_QUALITY)
        .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NORMAL)
    if (cfg.justify && !centered && b.kind != BlockKind.PRE) {
        builder.setJustificationMode(Layout.JUSTIFICATION_MODE_INTER_WORD)
    }
    return builder.build()
}

// ══════════════════════════════════════════════════════════════════════════════
// Paginador: reparte los bloques de un capítulo en páginas completas
//   · una imagen nunca se parte ni se deforma (se escala entera dentro de la página)
//   · sin líneas viudas/huérfanas sueltas y con el título unido a su primer párrafo
// ══════════════════════════════════════════════════════════════════════════════

internal class Paginator(private val cfg: LayoutConfig, private val images: ImageStore) {

    fun paginate(doc: ChapterDoc): List<PageSpec> {
        val em = cfg.textSizePx
        val availW = (cfg.widthPx - 2 * cfg.marginPx).toFloat()
        val pageTop = cfg.topPx.toFloat()
        val pageBottom = (cfg.heightPx - cfg.bottomPx).toFloat()
        val pages = ArrayList<PageSpec>()
        var items = ArrayList<PageItem>()
        var y = pageTop
        var pStart = -1
        var pEnd = 0

        fun newPage() {
            if (items.isNotEmpty()) {
                pages.add(PageSpec(doc.index, pages.size, items, max(pStart, 0), pEnd))
            }
            items = ArrayList()
            y = pageTop
            pStart = -1
        }

        fun mark(start: Int, end: Int) {
            if (pStart < 0) pStart = start
            pEnd = end
        }

        var prevPara = false
        for (block in doc.blocks) {
            when (block) {
                is TextBlock -> {
                    val indentFirst = cfg.indent && block.kind == BlockKind.PARAGRAPH && prevPara
                    val layout = buildBlockLayout(block, cfg, indentFirst)
                    val n = layout.lineCount
                    if (n == 0) continue
                    val heading = isHeading(block.kind)
                    val before = when {
                        heading -> em * 1.2f
                        block.kind == BlockKind.SCENE -> em * 0.7f
                        else -> 0f
                    }
                    val after = when {
                        heading -> em * 0.8f
                        block.kind == BlockKind.SCENE -> em * 0.7f
                        block.kind == BlockKind.LIST -> em * 0.25f
                        cfg.indent -> em * 0.2f
                        else -> em * 0.65f
                    }
                    val x = cfg.marginPx + leftExtra(block.kind, em).toFloat()

                    // título: si no cabe con un par de líneas del texto siguiente, pasa a la página siguiente
                    if (heading && y > pageTop) {
                        val hh = layout.getLineBottom(n - 1) - layout.getLineTop(0)
                        val need = hh + before + after + cfg.textSizePx * cfg.lineMult * 2.2f
                        if (y + need > pageBottom) newPage()
                    }

                    var line = 0
                    var first = true
                    while (line < n) {
                        val sb = if (first && y > pageTop) before else 0f
                        val avail = pageBottom - y - sb
                        var end = line
                        while (end < n && layout.getLineBottom(end) - layout.getLineTop(line) <= avail + 0.5f) end++
                        val fits = end - line
                        val remaining = n - line
                        if (fits == 0) {
                            if (items.isNotEmpty()) { newPage(); continue }
                            end = line + 1                      // página vacía: se fuerza una línea para avanzar
                        } else if (fits < remaining) {
                            if (first && fits < 2 && items.isNotEmpty() && remaining >= 2) { newPage(); continue }
                            if (remaining - fits == 1 && fits > 2) end -= 1
                        }
                        y += sb
                        val item = TextItem(block, layout, line, end, x, y)
                        items.add(item)
                        mark(item.globalStart, item.globalEnd)
                        y += layout.getLineTop(end) - layout.getLineTop(line)
                        line = end
                        first = false
                        if (line < n) newPage()
                    }
                    y += after
                    prevPara = block.kind == BlockKind.PARAGRAPH || block.kind == BlockKind.QUOTE || block.kind == BlockKind.LIST
                }

                is ImageBlock -> {
                    val size = images.size(block.path)
                    if (size == null) {
                        readerLog("imagen sin tamaño legible (${block.path}); se omite en el capítulo ${doc.index}")
                        prevPara = false; continue
                    }
                    val iw = size.first.toFloat()
                    val ih = size.second.toFloat()
                    val gap = em * 0.6f
                    val maxH = pageBottom - pageTop
                    var scale = min(availW / iw, maxH / ih)
                    scale = min(scale, 1.6f)
                    var w = iw * scale
                    var h = ih * scale
                    if (y > pageTop && y + gap + h > pageBottom) {
                        val room = pageBottom - y - gap
                        if (room >= h * 0.7f) {
                            val k = room / h
                            w *= k; h *= k
                        } else newPage()
                    }
                    if (y > pageTop) y += gap
                    val left = cfg.marginPx + (availW - w) / 2f
                    val rect = RectF(left, y, left + w, y + h)
                    items.add(ImageItem(block, rect))
                    mark(block.start, block.start + 1)
                    y += h + gap
                    prevPara = false
                }

                is RuleBlock -> {
                    val h = em * 1.2f
                    if (y > pageTop && y + h > pageBottom) newPage()
                    items.add(RuleItem(block, y, h))
                    mark(block.start, block.start + 1)
                    y += h
                    prevPara = false
                }
            }
        }
        newPage()
        if (pages.isEmpty()) pages.add(PageSpec(doc.index, 0, emptyList(), 0, 0))
        return pages
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// Dibujo de una página en un bitmap
// ══════════════════════════════════════════════════════════════════════════════

internal class HlRange(val start: Int, val end: Int, val color: Int)

internal object PageRenderer {

    fun render(
        spec: PageSpec,
        cfg: LayoutConfig,
        images: ImageStore,
        highlights: List<HlRange>,
        selection: IntRange?,
        header: String,
        footer: String
    ): Bitmap {
        val bmp = Bitmap.createBitmap(cfg.widthPx, cfg.heightPx, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(cfg.bg)

        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        val path = Path()
        val bounds = RectF()
        val w = cfg.widthPx.toFloat()
        val d = cfg.density

        // Lomo suave a la izquierda (da sensación de libro sin molestar a la lectura)
        val shade = android.graphics.LinearGradient(
            0f, 0f, 14f * d, 0f, 0x14000000, 0x00000000, android.graphics.Shader.TileMode.CLAMP
        )
        fill.shader = shade
        c.drawRect(0f, 0f, 14f * d, cfg.heightPx.toFloat(), fill)
        fill.shader = null

        for (item in spec.items) {
            when (item) {
                is TextItem -> {
                    val lay = item.layout
                    val base = item.top - lay.getLineTop(item.firstLine)
                    c.save()
                    c.clipRect(0f, item.top, w, item.bottom)
                    c.translate(item.x, base)
                    for (h in highlights) {
                        val s = max(h.start, item.globalStart)
                        val e = min(h.end, item.globalEnd)
                        if (s < e) {
                            path.reset()
                            lay.getSelectionPath(s - item.block.start, e - item.block.start, path)
                            // Un solo carácter estrecho (".", ",", ";"…): se ensancha a un ancho mínimo para que se vea
                            if (e - s <= 2) {
                                path.computeBounds(bounds, true)
                                val minW = lay.paint.textSize * 0.55f
                                if (bounds.width() < minW) {
                                    val cx = bounds.centerX()
                                    path.reset()
                                    path.addRoundRect(
                                        RectF(cx - minW / 2f, bounds.top, cx + minW / 2f, bounds.bottom),
                                        minW * 0.22f, minW * 0.22f, Path.Direction.CW
                                    )
                                }
                            }
                            fill.color = h.color
                            c.drawPath(path, fill)
                        }
                    }
                    if (selection != null) {
                        val s = max(selection.first, item.globalStart)
                        val e = min(selection.last + 1, item.globalEnd)
                        if (s < e) {
                            path.reset()
                            lay.getSelectionPath(s - item.block.start, e - item.block.start, path)
                            fill.color = 0x664A90E2
                            c.drawPath(path, fill)
                        }
                    }
                    lay.draw(c)
                    c.restore()
                }
                is ImageItem -> {
                    val bm = images.bitmap(item.block.path, item.rect.width().toInt())
                    if (bm != null) {
                        val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
                        c.drawBitmap(bm, null, item.rect, p)
                    }
                }
                is RuleItem -> {
                    fill.color = (cfg.fg and 0x00FFFFFF) or 0x66000000
                    val cy = item.top + item.height / 2f
                    for (k in -1..1) c.drawCircle(w / 2f + k * 14f * d, cy, 2f * d, fill)
                }
            }
        }

        // Cabecera (título del capítulo) y pie (avance), discretos como en un libro
        val label = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = (cfg.fg and 0x00FFFFFF) or 0x99000000.toInt()
            textSize = 11f * d
            typeface = Typeface.SANS_SERIF
            textAlign = Paint.Align.CENTER
        }
        if (header.isNotBlank()) {
            val shown = android.text.TextUtils.ellipsize(header, label, w - 2 * cfg.marginPx, android.text.TextUtils.TruncateAt.END)
            c.drawText(shown.toString(), w / 2f, 24f * d, label)
        }
        if (footer.isNotBlank()) {
            c.drawText(footer, w / 2f, cfg.heightPx - 14f * d, label)
        }
        return bmp
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// Búsqueda por coordenadas (selección, enlaces, imágenes)
// ══════════════════════════════════════════════════════════════════════════════

/** Desplazamiento (en el texto del capítulo) del carácter más cercano al punto (x, y) de la página. */
internal fun PageSpec.charAt(x: Float, y: Float, strict: Boolean = false): Int? {
    var best: TextItem? = null
    var bestDist = Float.MAX_VALUE
    for (item in items) {
        if (item !is TextItem) continue
        val dist = when {
            y < item.top -> item.top - y
            y > item.bottom -> y - item.bottom
            else -> 0f
        }
        if (dist < bestDist) { bestDist = dist; best = item }
    }
    val it = best ?: return null
    if (strict && (bestDist > 0f || x < it.x - 6f || x > it.x + it.layout.width + 6f)) return null
    val lay = it.layout
    val localY = (y - it.top + lay.getLineTop(it.firstLine)).toInt()
    val line = lay.getLineForVertical(localY).coerceIn(it.firstLine, it.lineEnd - 1)
    val off = lay.getOffsetForHorizontal(line, x - it.x).coerceIn(0, it.block.text.length)
    return it.block.start + off
}

/**
 * Índice del carácter que está justo BAJO el punto (x, y), o null si el punto no cae sobre una línea de texto.
 * [charAt] devuelve el límite de carácter más cercano (la «posición del cursor»): sirve para los manejadores, pero
 * para saber qué carácter tocó el dedo hay que decidir si cae a la izquierda o a la derecha de ese límite.
 * Así se pueden elegir signos aislados («.», «,») sin que el redondeo escoja el carácter vecino.
 */
internal fun PageSpec.glyphAt(x: Float, y: Float): Int? {
    var hit: TextItem? = null
    for (item in items) {
        if (item is TextItem && y >= item.top && y <= item.bottom) { hit = item; break }
    }
    val it = hit ?: return null
    val lay = it.layout
    if (x < it.x - 6f || x > it.x + lay.width + 6f) return null
    val localY = (y - it.top + lay.getLineTop(it.firstLine)).toInt()
    val line = lay.getLineForVertical(localY).coerceIn(it.firstLine, it.lineEnd - 1)
    val lx = x - it.x
    val lineStart = lay.getLineStart(line)
    val lineEnd = lay.getLineEnd(line)
    if (lineEnd <= lineStart) return null
    val caret = lay.getOffsetForHorizontal(line, lx).coerceIn(lineStart, lineEnd)
    // el cursor está en un límite: si el dedo queda a su derecha toca el carácter que empieza ahí; si no, el anterior
    val pick = if (caret < lineEnd && lx >= lay.getPrimaryHorizontal(caret)) caret else caret - 1
    return it.block.start + pick.coerceIn(lineStart, lineEnd - 1)
}

internal fun PageSpec.imageAt(x: Float, y: Float): ImageBlock? {
    for (item in items) if (item is ImageItem && item.rect.contains(x, y)) return item.block
    return null
}

/** Enlace pulsado en (x, y), si lo hay. */
internal fun PageSpec.linkAt(x: Float, y: Float): String? {
    for (item in items) {
        if (item !is TextItem || y < item.top || y > item.bottom) continue
        val lay = item.layout
        val localY = (y - item.top + lay.getLineTop(item.firstLine)).toInt()
        val line = lay.getLineForVertical(localY).coerceIn(item.firstLine, item.lineEnd - 1)
        val off = lay.getOffsetForHorizontal(line, x - item.x).coerceIn(0, item.block.text.length)
        val text = item.block.text
        if (text is Spanned) {
            val lo = max(off - 1, 0)
            val hi = min(off + 1, text.length)
            val spans = text.getSpans(lo, hi, LinkSpan::class.java)
            if (spans.isNotEmpty()) return spans[0].href
        }
    }
    return null
}

/** Rectángulo que envuelve el texto [start, end) en esta página (para colocar la barra de selección). */
internal fun PageSpec.rangeBounds(start: Int, end: Int): RectF? {
    var out: RectF? = null
    for (item in items) {
        if (item !is TextItem) continue
        val b = item.block.start
        val s = max(start, item.globalStart)
        val e = min(end, item.globalEnd)
        if (s >= e) continue
        val lay = item.layout
        val l1 = lay.getLineForOffset(s - b)
        val l2 = lay.getLineForOffset(max(e - 1 - b, 0))
        val base = item.top - lay.getLineTop(item.firstLine)
        val x1 = item.x + lay.getPrimaryHorizontal(s - b)
        val x2 = item.x + lay.getPrimaryHorizontal(e - b)
        val r = if (l1 == l2) RectF(min(x1, x2), base + lay.getLineTop(l1), max(x1, x2), base + lay.getLineBottom(l2))
        else RectF(item.x, base + lay.getLineTop(l1), item.x + lay.width, base + lay.getLineBottom(l2))
        val cur = out
        if (cur == null) out = r else cur.union(r)
    }
    return out
}

/** Un rectángulo por cada línea de texto seleccionada en esta página (para pintar la selección). */
internal fun PageSpec.selectionRects(start: Int, end: Int, minWidth: Float = 0f): List<RectF> {
    val out = ArrayList<RectF>()
    for (item in items) {
        if (item !is TextItem) continue
        val b = item.block.start
        val s = max(start, item.globalStart)
        val e = min(end, item.globalEnd)
        if (s >= e) continue
        val lay = item.layout
        val l1 = lay.getLineForOffset(s - b)
        val l2 = lay.getLineForOffset(max(e - 1 - b, 0))
        val base = item.top - lay.getLineTop(item.firstLine)
        for (l in l1..l2) {
            val ls = max(s - b, lay.getLineStart(l))
            val le = min(e - b, lay.getLineEnd(l))
            val left = item.x + lay.getPrimaryHorizontal(ls)
            val right = item.x + if (le >= lay.getLineEnd(l)) lay.getLineRight(l) else lay.getPrimaryHorizontal(le)
            var rl = min(left, right)
            var rr = max(left, right)
            if (minWidth > 0f && rr - rl < minWidth) {                 // un signo suelto: ensanchar alrededor de su centro
                val cx = (rl + rr) / 2f
                rl = cx - minWidth / 2f; rr = cx + minWidth / 2f
            }
            out.add(RectF(rl, base + lay.getLineTop(l), rr, base + lay.getLineBottom(l)))
        }
    }
    return out
}
