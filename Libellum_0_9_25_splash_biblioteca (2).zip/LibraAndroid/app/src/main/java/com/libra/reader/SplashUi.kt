package com.libra.reader

import android.provider.Settings
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// ══════════════════════════════════════════════════════════════════════════════
// SPLASH / CARGA — escena de la biblioteca (imagen de referencia) + animación
//
// Recursos (res/drawable-nodpi):
//   splash_bg.webp      escena sin el icono del libro ni las ondas (704×1520)
//   splash_feather.webp pluma dorada recortada con alfa (385×886)
// "Libellum" y "28:12" ya van dibujados en splash_bg.
//
// Secuencia (ms):
//      0      la escena se ve de inmediato (sin fundido); ligero zoom lento durante toda la carga
//    250– 600  el libro pequeño de la mesa aparece, abierto
//    600–1530  5 páginas, una a una, cada vez más rápidas (látigo + rebote)
//   1600–2110  ráfaga de 9 páginas casi de golpe, con resplandor y motas
//   2200–2650  el libro se cierra (tapa gruesa con látigo) y rebota; se centra
//   2650–3050  aparece una pluma dorada junto al libro cerrado y se posa
//   2900–3950  tres ondas doradas concéntricas por la mesa
//   3950–4330  fundido hacia la interfaz principal (solo cuando la app está lista)
//
// • Toda la animación depende de UN reloj (`clock`): determinista y barata.
// • Un toque en cualquier punto la salta (fundido corto).
// • Con «escala de duración de animación = 0» se muestra solo el estado final
//   (libro cerrado + pluma), con un fundido simple de ~1,8 s.
// • Solo en arranque en frío (ver `LibraAppWithSplash`).
// ══════════════════════════════════════════════════════════════════════════════

private const val TOTAL_MS = 3950f
private const val TOTAL_REDUCED_MS = 1800f
private const val FROZEN_MS = 3300f          // fotograma que se muestra con movimiento reducido

private const val IMG_W = 704f
private const val IMG_H = 1520f
private const val BOOK_X = 352f              // centro del libro pequeño en la imagen
private const val BOOK_Y = 1209f
private const val BOOK_PW_IMG = 112f         // ancho de una página, en px de imagen

// Pluma (sprite 385×886): punta de escribir y eje
private const val FEATHER_W = 385
private const val FEATHER_H = 886
private const val FEATHER_NIB_X = 128f
private const val FEATHER_NIB_Y = 878f
private const val FEATHER_AXIS_DEG = 15.7f   // inclinación del eje respecto a la vertical, en el sprite

private val SplNight = Color(0xFF0B0F1E)
private val SplPaper = Color(0xFFF3E6C8)
private val SplEdge = Color(0xFFD9C9A0)
private val SplEdgeDark = Color(0xFFB8A67C)
private val SplCover = Color(0xFF151C3C)
private val SplCoverDark = Color(0xFF0A0F22)
private val SplInk = Color(0xFF8C7A55)
private val SplGem = Color(0xFF2D5BD0)

/**
 * Punto de entrada: app + splash encima. `showSplashOnStart` = arranque en frío.
 *
 * Con splash, la app NO se compone en el primer fotograma: componerla es pesado y retrasaría
 * el primer fotograma (pantalla en blanco). Primero se pinta la escena; después se monta la app
 * por detrás mientras suena la animación, y la base de datos se abre en segundo plano.
 */
@Composable
fun LibraAppWithSplash(openRequest: MutableState<String?>, showSplashOnStart: Boolean) {
    val context = LocalContext.current
    var showSplash by remember { mutableStateOf(showSplashOnStart) }
    var mountApp by remember { mutableStateOf(!showSplashOnStart) }
    var appReady by remember { mutableStateOf(!showSplashOnStart) }

    if (showSplashOnStart) {
        LaunchedEffect(Unit) {
            withFrameNanos { }                                    // 1.º fotograma: solo la escena
            val warm = async(Dispatchers.IO) {                    // segundo plano: preferencias y BD
                runCatching {
                    context.getSharedPreferences("libra_prefs", 0).all
                    LibraryDatabase.get(context).libraryDao().observeAll().first()
                }
            }
            mountApp = true                                       // composición pesada, con la escena ya visible
            repeat(3) { withFrameNanos { } }                      // composición + primer layout y dibujo
            warm.await()
            appReady = true
        }
    }

    Box(Modifier.fillMaxSize()) {
        if (mountApp) LibraApp(openRequest)
        if (showSplash) SplashOverlay(appReady = appReady, onFinished = { showSplash = false })
    }
}

@Composable
internal fun SplashOverlay(appReady: Boolean, onFinished: () -> Unit) {
    val context = LocalContext.current
    val reduced = remember {
        runCatching {
            Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
        }.getOrDefault(false)
    }
    val total = if (reduced) TOTAL_REDUCED_MS else TOTAL_MS
    val clock = remember { mutableFloatStateOf(0f) }  // reloj propio de la animación (ms)
    val exit = remember { Animatable(0f) }            // 0 = visible; sube a 1 en el fundido final
    val skip = remember { Animatable(1f) }            // 1 = visible; baja a 0 si se toca para saltar
    val ready by rememberUpdatedState(appReady)
    val scope = rememberCoroutineScope()
    var finished by remember { mutableStateOf(false) }
    val finish: () -> Unit = { if (!finished) { finished = true; onFinished() } }
    val bg = ImageBitmap.imageResource(R.drawable.splash_bg)
    val featherImg = ImageBitmap.imageResource(R.drawable.splash_feather)

    LaunchedEffect(Unit) {
        // El reloj avanza con el tiempo real, pero un fotograma largo (p. ej. mientras se compone la
        // app) solo cuenta 34 ms: la animación no se salta nada, solo espera.
        var last = -1L
        while (clock.floatValue < total) {
            val now = withFrameNanos { it }
            if (last >= 0L) clock.floatValue = min(total, clock.floatValue + min((now - last) / 1_000_000f, 34f))
            last = now
        }
        // Animación terminada: si la app aún no está lista se mantiene el último fotograma (máx. 3 s)
        var waited = 0f
        var l2 = -1L
        while (!ready && waited < 3000f) {
            val now = withFrameNanos { it }
            if (l2 >= 0L) waited += (now - l2) / 1_000_000f
            l2 = now
        }
        exit.animateTo(1f, tween(380))
        finish()
    }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = (1f - exit.value) * skip.value }
            .background(SplNight)
            .pointerInput(Unit) {
                detectTapGestures {
                    scope.launch {
                        while (!ready) withFrameNanos { }          // nunca descubrir una app que aún no está lista
                        skip.animateTo(0f, tween(180)); finish()
                    }
                }
            }
    ) {
        // Todo lo que sigue comparte un zoom lento (1,00 → 1,035) para dar vida a la escena
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    val k = 1f + 0.035f * (clock.floatValue / total)
                    scaleX = k; scaleY = k
                    transformOrigin = TransformOrigin(0.5f, 0.6f)
                }
        ) {
            // Escena + resplandor + ondas
            Canvas(Modifier.fillMaxSize()) {
                val tv = if (reduced) FROZEN_MS else clock.floatValue
                drawScene(bg, tv, reduced)
            }
            // Libro pequeño
            Canvas(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val m = ImgMap(size.width, size.height)
                        val c = m.p(BOOK_X, BOOK_Y)
                        transformOrigin = TransformOrigin(c.x / size.width, c.y / size.height)
                        val a = smooth(seg(clock.floatValue, 250f, 600f))
                        alpha = a
                        val sc = 0.94f + 0.06f * a
                        scaleX = sc; scaleY = sc
                    }
            ) {
                val tv = if (reduced) FROZEN_MS else clock.floatValue
                val m = ImgMap(size.width, size.height)
                drawBook(tv, BOOK_PW_IMG * m.s, m.p(BOOK_X, BOOK_Y))
            }
            // Pluma y motas
            Canvas(Modifier.fillMaxSize()) {
                val tv = if (reduced) FROZEN_MS else clock.floatValue
                drawFeatherAndMotes(featherImg, tv, ImgMap(size.width, size.height), reduced)
            }
        }
    }
}

// ───────────────────────────── utilidades ─────────────────────────────

private fun clamp01(x: Float) = if (x < 0f) 0f else if (x > 1f) 1f else x
private fun seg(t: Float, a: Float, b: Float) = clamp01((t - a) / (b - a))
private fun smooth(x: Float): Float { val c = clamp01(x); return c * c * (3f - 2f * c) }
private fun easeOutCubic(x: Float): Float { val c = 1f - clamp01(x); return 1f - c * c * c }
private fun easeInOutCubic(x: Float): Float {
    val c = clamp01(x)
    return if (c < 0.5f) 4f * c * c * c else 1f - (-2f * c + 2f).let { it * it * it } / 2f
}
private fun fl(a: Float, b: Float, f: Float) = a + (b - a) * f
private fun frac(x: Float) = x - floor(x)

/** Correspondencia imagen → pantalla (la imagen cubre la pantalla recortando lo que sobre). */
private class ImgMap(w: Float, h: Float) {
    val s = max(w / IMG_W, h / IMG_H)
    val ox = (w - IMG_W * s) / 2f
    val oy = (h - IMG_H * s) / 2f
    fun p(x: Float, y: Float) = Offset(ox + x * s, oy + y * s)
}

// ───────────────────────────── calendario de páginas ─────────────────────────────

private class PageTurn(val start: Float, val dur: Float)

private const val SLOW_COUNT = 5
private const val CLOSE_START = 2200f
private const val CLOSE_DUR = 450f
private const val CLOSE_END = CLOSE_START + CLOSE_DUR

private val TURNS: List<PageTurn> = buildList {
    val starts = floatArrayOf(600f, 800f, 980f, 1130f, 1260f)
    val durs = floatArrayOf(420f, 380f, 340f, 300f, 270f)
    for (i in starts.indices) add(PageTurn(starts[i], durs[i]))
    for (i in 0 until 9) add(PageTurn(1600f + i * 34f, 240f))       // ráfaga final
}

/** Ángulo de la hoja: 0 = tumbada a la derecha, π = a la izquierda. */
private fun pageAngle(tp: PageTurn, t: Float): Float =
    PI.toFloat() * easeInOutCubic((t - tp.start) / tp.dur)

// ───────────────────────────── cámara 3D mínima ─────────────────────────────

/** Mesa = plano XY (x derecha, y a lo largo del lomo), z hacia arriba. Cámara delante y arriba. */
private class Cam(
    val cx: Float, val cy: Float,
    val se: Float, val ce: Float,       // sen/cos de la elevación
    val yc: Float, val ys: Float,       // cos/sen del giro (ligera inclinación del libro)
    val d: Float,                       // distancia de la cámara (perspectiva)
    val dx: Float                       // desplazamiento en x del libro (centra el libro cerrado)
) {
    fun proj(x0: Float, y: Float, z: Float): Offset {
        val x = x0 + dx
        val xr = x * yc - y * ys
        val yr = x * ys + y * yc
        val y1 = yr * se + z * ce
        val z1 = -yr * ce + z * se
        val k = d / (d - z1)
        return Offset(cx + xr * k, cy - y1 * k)
    }
}

private fun DrawScope.fillPoly(pts: Array<Offset>, color: Color, seam: Boolean = true) {
    val p = Path()
    p.moveTo(pts[0].x, pts[0].y)
    for (i in 1 until pts.size) p.lineTo(pts[i].x, pts[i].y)
    p.close()
    drawPath(p, color)
    if (seam) drawPath(p, color, style = Stroke(width = 0.9f))
}

private fun DrawScope.textLines(cam: Cam, x0: Float, x1: Float, z: Float, h2: Float, w: Float) {
    val col = SplInk.copy(alpha = 0.55f)
    for (j in 0..6) {
        val v = -h2 * 0.70f + j * (h2 * 1.40f / 6f)
        drawLine(col, cam.proj(x0, v, z), cam.proj(x1, v, z), strokeWidth = w)
    }
}

// ───────────────────────────── escena, resplandor y ondas ─────────────────────────────

private fun DrawScope.drawScene(bg: ImageBitmap, tv: Float, reduced: Boolean) {
    val m = ImgMap(size.width, size.height)
    drawImage(
        bg,
        srcSize = IntSize(bg.width, bg.height),
        dstOffset = IntOffset(m.ox.roundToInt(), m.oy.roundToInt()),
        dstSize = IntSize((IMG_W * m.s).roundToInt(), (IMG_H * m.s).roundToInt()),
        filterQuality = FilterQuality.High
    )
    val s = m.s
    val bc = m.p(BOOK_X, BOOK_Y)

    // Resplandor dorado alrededor del libro durante la ráfaga y el cierre
    val burst = smooth(seg(tv, 1500f, 1800f)) * (1f - smooth(seg(tv, 2150f, 2500f)))
    if (burst > 0f && !reduced) {
        val r = 190f * s
        drawCircle(
            Brush.radialGradient(listOf(GoldLight.copy(alpha = 0.42f * burst), Color.Transparent), center = bc, radius = r),
            radius = r, center = bc
        )
    }

    // Ondas doradas concéntricas por la mesa (bajo el libro)
    if (!reduced) {
        val rc = m.p(BOOK_X, BOOK_Y + 30f)
        for (k in 0..2) {
            val st = 2900f + k * 170f
            val p = seg(tv, st, st + 900f)
            if (p <= 0f || p >= 1f) continue
            val ep = easeOutCubic(p)
            val rx = 300f * s * ep
            val ry = rx * 0.22f
            val a = (1f - p) * (1f - p)
            val tl = Offset(rc.x - rx, rc.y - ry)
            val sz = Size(2f * rx, 2f * ry)
            drawOval(GoldLight.copy(alpha = 0.10f * a), tl, sz, style = Stroke(14f * s * (1f - 0.5f * ep)))
            drawOval(GoldBright.copy(alpha = 0.30f * a), tl, sz, style = Stroke(6f * s * (1f - 0.4f * ep)))
            drawOval(Color(0xFFFFE2A0).copy(alpha = 0.95f * a), tl, sz, style = Stroke(2.2f * s))
            for (j in 0 until 10) {                      // destellos que recorren el anillo
                val ang = (j / 10f + k * 0.037f + ep * 0.15f) * 2f * PI.toFloat()
                val tw = 0.5f + 0.5f * sin((tv / 90f) + j * 1.7f)
                drawCircle(
                    Color(0xFFFFF3D0).copy(alpha = a * (0.35f + 0.6f * tw)),
                    radius = (1.2f + 1.6f * tw) * s,
                    center = Offset(rc.x + rx * cos(ang), rc.y + ry * sin(ang))
                )
            }
        }
    }
}

// ───────────────────────────── el libro pequeño ─────────────────────────────

private fun DrawScope.drawBook(t: Float, pw: Float, c: Offset) {
    val h2 = pw * 0.65f                   // mitad del alto de página
    val thick = pw * 0.17f                // grosor total del bloque de páginas
    val coverT = pw * 0.05f               // grosor de la tapa
    val m = pw * 0.035f                   // margen de la tapa sobre las páginas
    val closing = t >= CLOSE_START
    val ec = easeInOutCubic(seg(t, CLOSE_START, CLOSE_END))
    val elev = Math.toRadians(55.0).toFloat()
    val yaw = Math.toRadians(-5.0).toFloat()
    val cam = Cam(c.x, c.y, sin(elev), cos(elev), cos(yaw), sin(yaw), pw * 3.6f, -pw * 0.5f * ec)

    val n = TURNS.size
    val unit = thick / (n + 6f)
    val turned = TURNS.count { t >= it.start + it.dur }
    val remaining = TURNS.count { t < it.start }
    val zR = unit * (remaining + 3f)      // altura del bloque derecho
    val zL = unit * (turned + 3f)         // altura del bloque izquierdo

    // Sombra bajo el libro
    val sc = cam.proj(0f, -h2 * 0.2f, -coverT)
    withTransform({ scale(1f, 0.38f, sc) }) {
        drawCircle(
            Brush.radialGradient(listOf(Color(0x66000000), Color.Transparent), center = sc, radius = pw * 1.4f),
            radius = pw * 1.4f, center = sc
        )
    }

    // Tapa (mitad derecha siempre; la izquierda viaja con la hoja gruesa al cerrar)
    val cL = -pw - m; val cR = pw + m; val cF = -h2 - m; val cB = h2 + m
    fun cover(xa: Float, xb: Float) {
        fillPoly(arrayOf(cam.proj(xa, cF, 0f), cam.proj(xb, cF, 0f), cam.proj(xb, cF, -coverT), cam.proj(xa, cF, -coverT)), SplCoverDark)
        fillPoly(arrayOf(cam.proj(xb, cF, 0f), cam.proj(xb, cB, 0f), cam.proj(xb, cB, -coverT), cam.proj(xb, cF, -coverT)), SplCoverDark)
        fillPoly(arrayOf(cam.proj(xa, cF, 0f), cam.proj(xb, cF, 0f), cam.proj(xb, cB, 0f), cam.proj(xa, cB, 0f)), SplCover)
        val gi = m * 0.45f
        val g = arrayOf(
            cam.proj(xa + gi, cF + gi, 0f), cam.proj(xb - gi, cF + gi, 0f),
            cam.proj(xb - gi, cB - gi, 0f), cam.proj(xa + gi, cB - gi, 0f)
        )
        val gp = Path().apply { moveTo(g[0].x, g[0].y); for (i in 1..3) lineTo(g[i].x, g[i].y); close() }
        drawPath(gp, GoldLight.copy(alpha = 0.8f), style = Stroke(width = 1.2f))
    }
    if (!closing) cover(cL, cR) else cover(0f, cR)

    // Bloque derecho (páginas aún sin pasar)
    fillPoly(arrayOf(cam.proj(0f, -h2, 0f), cam.proj(pw, -h2, 0f), cam.proj(pw, -h2, zR), cam.proj(0f, -h2, zR)), SplEdge)
    fillPoly(arrayOf(cam.proj(pw, -h2, 0f), cam.proj(pw, h2, 0f), cam.proj(pw, h2, zR), cam.proj(pw, -h2, zR)), SplEdgeDark)
    fillPoly(arrayOf(cam.proj(0f, -h2, zR), cam.proj(pw, -h2, zR), cam.proj(pw, h2, zR), cam.proj(0f, h2, zR)), SplPaper)
    if (!closing) textLines(cam, 0.14f * pw, 0.86f * pw, zR, h2, 1.2f)

    // Bloque izquierdo (páginas ya pasadas)
    if (!closing) {
        fillPoly(arrayOf(cam.proj(-pw, -h2, 0f), cam.proj(0f, -h2, 0f), cam.proj(0f, -h2, zL), cam.proj(-pw, -h2, zL)), SplEdge)
        fillPoly(arrayOf(cam.proj(-pw, -h2, zL), cam.proj(0f, -h2, zL), cam.proj(0f, h2, zL), cam.proj(-pw, h2, zL)), SplPaper)
        textLines(cam, -0.86f * pw, -0.14f * pw, zL, h2, 1.2f)
        // Sombra del lomo
        fillPoly(arrayOf(cam.proj(0f, -h2, zR), cam.proj(0.07f * pw, -h2, zR), cam.proj(0.07f * pw, h2, zR), cam.proj(0f, h2, zR)), Color(0x22000000), seam = false)
        fillPoly(arrayOf(cam.proj(-0.07f * pw, -h2, zL), cam.proj(0f, -h2, zL), cam.proj(0f, h2, zL), cam.proj(-0.07f * pw, h2, zL)), Color(0x22000000), seam = false)
    }

    // Hojas en vuelo (y rebote tras aterrizar las lentas)
    for (i in TURNS.indices) {
        val tp = TURNS[i]
        val slow = i < SLOW_COUNT
        val endT = tp.start + tp.dur
        if (t < tp.start || t >= endT + (if (slow) 450f else 0f)) continue
        val th = pageAngle(tp, t)
        val vel = (th - pageAngle(tp, t - 14f)) / 14f * 1000f            // rad/s
        val tau = (t - endT) / 1000f
        val bounce = if (slow && tau > 0f && tau < 0.45f) 0.32f * exp(-9f * tau) * max(0f, sin(22f * tau)) else 0f
        val lag = min(abs(vel) * 0.05f, 0.95f) + bounce                 // la punta se retrasa: látigo
        val landed = t >= endT
        val z0 = if (landed) zL else fl(zR + unit, zL + unit, th / PI.toFloat())

        val N = 12
        val ds = pw / N
        val xs = FloatArray(N + 1)
        val zs = FloatArray(N + 1)
        val ph = FloatArray(N + 1)
        xs[0] = 0f; zs[0] = z0
        for (s in 1..N) {
            val f = (s - 0.5f) / N
            val phi = th - lag * f * f * 1.2f
            ph[s] = phi
            xs[s] = xs[s - 1] + ds * cos(phi)
            zs[s] = max(zs[s - 1] + ds * sin(phi), 0f)
        }
        for (s in 1..N) {
            val shade = lerp(SplEdge, SplPaper, abs(cos(ph[s])) * 0.7f + 0.3f)
            fillPoly(
                arrayOf(
                    cam.proj(xs[s - 1], -h2, zs[s - 1]), cam.proj(xs[s], -h2, zs[s]),
                    cam.proj(xs[s], h2, zs[s]), cam.proj(xs[s - 1], h2, zs[s - 1])
                ),
                shade
            )
        }
        val lc = SplInk.copy(alpha = 0.5f)
        for (j in 0..5) {
            val v = -h2 * 0.68f + j * (h2 * 1.36f / 5f)
            for (s in 2 until N - 1) {
                drawLine(lc, cam.proj(xs[s], v, zs[s]), cam.proj(xs[s + 1], v, zs[s + 1]), strokeWidth = 1.1f)
            }
        }
        drawLine(SplEdgeDark, cam.proj(xs[N], -h2, zs[N]), cam.proj(xs[N], h2, zs[N]), strokeWidth = 1.5f)
    }

    // Cierre: la tapa izquierda + todas las páginas giran juntas como una hoja gruesa
    if (closing) {
        val pi = PI.toFloat()
        val th = pi * (1f - ec)
        val thPrev = pi * (1f - easeInOutCubic(seg(t - 14f, CLOSE_START, CLOSE_END)))
        val vel = (th - thPrev) / 14f * 1000f
        val lag = min(abs(vel) * 0.03f, 0.55f)                          // látigo suave
        val tauC = (t - CLOSE_END) / 1000f
        val zb = if (tauC > 0f && tauC < 0.5f) pw * 0.025f * exp(-10f * tauC) * abs(sin(24f * tauC)) else 0f
        val T = unit * (n + 3f) + coverT                                 // grosor total de la hoja gruesa
        val mid0 = zR + T / 2f
        val midPi = unit * (n + 3f) - T / 2f
        val z0 = fl(midPi, mid0, 1f - th / pi) + zb
        val N = 12
        val ds = pw / N
        val xs = FloatArray(N + 1)
        val zs = FloatArray(N + 1)
        val ph = FloatArray(N + 1)
        xs[0] = 0f; zs[0] = z0
        for (s in 1..N) {
            val f = (s - 0.5f) / N
            val phi = th + lag * f * f * 1.2f
            ph[s] = phi
            xs[s] = xs[s - 1] + ds * cos(phi)
            zs[s] = zs[s - 1] + ds * sin(phi)
        }
        val phv = FloatArray(N + 1)
        phv[0] = ph[1]; phv[N] = ph[N]
        for (i in 1 until N) phv[i] = (ph[i] + ph[i + 1]) / 2f
        val d = T / 2f
        val px = FloatArray(N + 1) { xs[it] + d * sin(phv[it]) }           // cara de las páginas
        val pz = FloatArray(N + 1) { zs[it] - d * cos(phv[it]) }
        val cx = FloatArray(N + 1) { xs[it] - d * sin(phv[it]) }           // cara de la tapa
        val cz = FloatArray(N + 1) { zs[it] + d * cos(phv[it]) }
        val pagesUp = th > pi / 2f

        fun paperFace() {
            for (s in 1..N) {
                val shade = lerp(SplEdge, SplPaper, abs(cos(ph[s])) * 0.7f + 0.3f)
                fillPoly(arrayOf(cam.proj(px[s - 1], -h2, pz[s - 1]), cam.proj(px[s], -h2, pz[s]), cam.proj(px[s], h2, pz[s]), cam.proj(px[s - 1], h2, pz[s - 1])), shade)
            }
            if (pagesUp) {
                val lc = SplInk.copy(alpha = 0.5f)
                for (j in 0..6) {
                    val v = -h2 * 0.70f + j * (h2 * 1.40f / 6f)
                    for (s in 2 until N - 1) drawLine(lc, cam.proj(px[s], v, pz[s]), cam.proj(px[s + 1], v, pz[s + 1]), strokeWidth = 1.2f)
                }
            }
        }
        fun coverFace() {
            for (s in 1..N) {
                val shade = lerp(SplCoverDark, SplCover, abs(cos(ph[s])) * 0.7f + 0.3f)
                fillPoly(arrayOf(cam.proj(cx[s - 1], -h2, cz[s - 1]), cam.proj(cx[s], -h2, cz[s]), cam.proj(cx[s], h2, cz[s]), cam.proj(cx[s - 1], h2, cz[s - 1])), shade)
            }
            if (!pagesUp) {
                val g = pw * 0.07f
                val gp = Path()
                for (i in 0..N) { val o = cam.proj(cx[i], -h2 + g, cz[i]); if (i == 0) gp.moveTo(o.x, o.y) else gp.lineTo(o.x, o.y) }
                for (i in N downTo 0) { val o = cam.proj(cx[i], h2 - g, cz[i]); gp.lineTo(o.x, o.y) }
                gp.close()
                drawPath(gp, GoldLight.copy(alpha = 0.85f), style = Stroke(width = 1.3f))
                val ga = smooth(seg(t, CLOSE_END - 150f, CLOSE_END + 200f))
                if (ga > 0f) {                                       // gema de la tapa
                    val gc = cam.proj(cx[N / 2], 0f, cz[N / 2])
                    val r = pw * 0.075f
                    drawOval(SplGem.copy(alpha = ga), Offset(gc.x - r, gc.y - r * 0.62f), Size(2f * r, 1.24f * r))
                    drawOval(GoldLight.copy(alpha = ga), Offset(gc.x - r, gc.y - r * 0.62f), Size(2f * r, 1.24f * r), style = Stroke(1.4f))
                    drawCircle(Color(0xFFBFD3FF).copy(alpha = 0.8f * ga), radius = r * 0.22f, center = Offset(gc.x - r * 0.25f, gc.y - r * 0.2f))
                }
            }
        }
        if (pagesUp) coverFace() else paperFace()                          // cara de abajo
        for (s in 1..N) {                                                  // canto frontal (grosor)
            fillPoly(arrayOf(cam.proj(px[s - 1], -h2, pz[s - 1]), cam.proj(px[s], -h2, pz[s]), cam.proj(cx[s], -h2, cz[s]), cam.proj(cx[s - 1], -h2, cz[s - 1])), SplEdge)
        }
        fillPoly(arrayOf(cam.proj(px[N], -h2, pz[N]), cam.proj(px[N], h2, pz[N]), cam.proj(cx[N], h2, cz[N]), cam.proj(cx[N], -h2, cz[N])), SplEdgeDark)
        if (pagesUp) paperFace() else coverFace()                          // cara de arriba
    }
}

// ───────────────────────────── pluma, motas ─────────────────────────────

private fun DrawScope.mote(pos: Offset, a: Float, r: Float) {
    drawCircle(GoldLight.copy(alpha = a * 0.25f), radius = r * 2.4f, center = pos)
    drawCircle(Color(0xFFFFF0C8).copy(alpha = a), radius = r, center = pos)
}

private fun DrawScope.drawFeatherAndMotes(img: ImageBitmap, t: Float, m: ImgMap, reduced: Boolean) {
    val s = m.s
    val bc = m.p(BOOK_X, BOOK_Y)

    // Motas doradas que suben del libro durante la ráfaga
    if (!reduced) {
        for (i in 0 until 22) {
            val r1 = frac(i * 0.61803f); val r2 = frac(i * 0.38197f + 0.3f); val r3 = frac(i * 0.7548f + 0.1f)
            val st = 1600f + r1 * 450f
            val p = seg(t, st, st + 650f)
            if (p <= 0f || p >= 1f) continue
            val pos = Offset(
                bc.x + (r2 * 2f - 1f) * 85f * s + sin(p * 6f + r3 * 6f) * 6f * s,
                bc.y - 10f * s - easeOutCubic(p) * (60f + 80f * r3) * s
            )
            mote(pos, sin(p * PI.toFloat()) * 0.95f, (1.1f + 1.6f * r3) * s)
        }
    }

    // Pluma: baja desde arriba y se posa junto al libro cerrado
    val fa = smooth(seg(t, 2650f, 2950f))
    if (fa <= 0f) return
    val k = 0.27f * s                                          // px de pantalla por px de sprite
    val rise = (1f - easeOutCubic(seg(t, 2650f, 3050f))) * 22f * s
    val tau = max(0f, t - 3000f) / 1000f
    val sway = 4f * exp(-4f * tau) * sin(14f * tau)
    val bob = if (t > 3050f) sin((t - 3050f) / 380f) * 2.5f * s else 0f
    val nibBase = m.p(385f, 1280f)
    val nib = Offset(nibBase.x, nibBase.y - rise + bob)
    val rotDeg = (52f - FEATHER_AXIS_DEG) + sway
    val axisRad = Math.toRadians((52f + sway).toDouble()).toFloat()
    val len = FEATHER_H * k

    // Sombra en la mesa y resplandor
    withTransform({ scale(1f, 0.25f, Offset(nibBase.x, nibBase.y + 4f * s)) }) {
        drawCircle(
            Brush.radialGradient(listOf(Color(0x66000000).copy(alpha = 0.4f * fa), Color.Transparent), center = Offset(nibBase.x, nibBase.y + 4f * s), radius = 38f * s),
            radius = 38f * s, center = Offset(nibBase.x, nibBase.y + 4f * s)
        )
    }
    val gc = Offset(nib.x + sin(axisRad) * len * 0.5f, nib.y - cos(axisRad) * len * 0.5f)
    drawCircle(
        Brush.radialGradient(listOf(GoldLight.copy(alpha = 0.30f * fa), Color.Transparent), center = gc, radius = len * 0.75f),
        radius = len * 0.75f, center = gc
    )
    withTransform({
        translate(nib.x, nib.y)
        rotate(rotDeg, Offset.Zero)
    }) {
        drawImage(
            img,
            srcSize = IntSize(FEATHER_W, FEATHER_H),
            dstOffset = IntOffset((-FEATHER_NIB_X * k).roundToInt(), (-FEATHER_NIB_Y * k).roundToInt()),
            dstSize = IntSize((FEATHER_W * k).roundToInt(), (FEATHER_H * k).roundToInt()),
            alpha = fa,
            filterQuality = FilterQuality.High
        )
    }

    // Destellos alrededor de la pluma al aparecer
    if (!reduced) {
        for (i in 0 until 14) {
            val r1 = frac(i * 0.61803f + 0.17f); val r2 = frac(i * 0.38197f + 0.5f); val r3 = frac(i * 0.7548f + 0.3f)
            val st = 2650f + r1 * 350f
            val p = seg(t, st, st + 600f)
            if (p <= 0f || p >= 1f) continue
            val along = r2 * len
            val pos = Offset(
                nib.x + sin(axisRad) * along + (r3 * 2f - 1f) * 22f * s,
                nib.y - cos(axisRad) * along - easeOutCubic(p) * 26f * s
            )
            mote(pos, sin(p * PI.toFloat()) * 0.95f, (1.0f + 1.5f * r3) * s)
        }
    }
}
