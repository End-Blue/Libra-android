# Selección y resaltado de texto a nivel de carácter

## Qué cambia
- **Signos sueltos:** mantener pulsado sobre un «.», «,», «;», símbolo o espacio selecciona ESE carácter
  (antes solo se podían seleccionar palabras). Sobre una letra o dígito se sigue seleccionando la palabra.
- **Arrastre tras la pulsación larga:** lento → carácter a carácter (incluye espacios y puntuación);
  rápido → por palabras. Nunca encoge por debajo de la unidad inicial.
- **Manejadores:** el ajuste ya era carácter/palabra según la velocidad; ahora el extremo contrario puede estar en otra hoja.
  En selecciones cortas de una línea los manejadores se separan hacia fuera para que sus zonas táctiles no se pisen.
- **Auto-giro (equivale al auto-scroll):** arrastrar el manejador final por debajo de la última línea (o el inicial por encima
  de la primera) ~0,45 s gira la hoja sin perder la selección; se repite cada ~1,2 s dentro del capítulo.
  Se desactiva con `SELECTION_AUTO_TURN = false` en `TextSelection.kt`.
- **Barra de acciones inferior** (`SelectionActionBar.kt`): 6 colores (un toque resalta), Nota, Copiar, Buscar, Compartir,
  Definir, Frase, Quitar resaltado (solo si la selección toca un resaltado) y Limpiar. Pasa arriba si la selección queda abajo.
- **Resaltados cortos:** un signo suelto se pinta con un ancho mínimo (rectángulo redondeado) para que se vea claro;
  los extremos de espacio se recortan al resaltar; resaltar de nuevo el mismo rango solo cambia el color.
- **Toque sobre un resaltado** usa el carácter BAJO el dedo (`glyphAt`), también para signos sueltos.

## Archivos
Nuevo: `SelectionActionBar.kt` · Modificados: `PageLayout.kt`, `TextSelection.kt`, `NativeReader.kt`
Sin cambios en base de datos ni en el formato de los resaltados guardados.
