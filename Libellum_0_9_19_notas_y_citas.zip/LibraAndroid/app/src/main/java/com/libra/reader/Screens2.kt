@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.libra.reader

import android.content.Context
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ══════════════════════════════════════════════════════════════════════════════
// AYUDAS COMUNES
// ══════════════════════════════════════════════════════════════════════════════

/** Estado efectivo: el que eligió el lector o, si no hay, el que dice el progreso. */
internal fun LibraryItem.statusKey(): String = when {
    status.isNotEmpty() -> status
    progress >= 97 -> "FINISHED"
    progress > 0 -> "READING"
    else -> "TBR"
}

internal fun statusLabel(s: String): String = when (s) {
    "READING" -> "Leyendo"
    "FINISHED" -> "Terminado"
    else -> "Por leer"
}

internal val STATUS_KEYS = listOf("TBR", "READING", "FINISHED")

internal val GENRES = listOf(
    "Fantasía", "Ciencia ficción", "Romance", "Misterio", "Terror", "Histórica",
    "Clásicos", "Ensayo", "Biografía", "Infantil", "Superación", "Otro"
)

internal fun LibraryItem.genreLabel(): String = genre.ifBlank { "Sin género" }

private val DAY_FMT get() = SimpleDateFormat("dd/MM/yyyy", Locale("es"))

@Composable
internal fun PaperCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Panel)
            .border(1.dp, Line, RoundedCornerShape(16.dp))
            .padding(14.dp),
        content = content
    )
}

@Composable
internal fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text, color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold,
        fontFamily = LibellumSerif,
        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
        letterSpacing = 1.0.sp, modifier = modifier
    )
}

@Composable
internal fun Stars(rating: Int, modifier: Modifier = Modifier, size: Int = 14, onChange: ((Int) -> Unit)? = null) {
    Row(modifier) {
        for (i in 1..5) {
            Text(
                if (i <= rating) "★" else "☆",
                color = if (i <= rating) Gold else Muted,
                fontSize = size.sp,
                modifier = if (onChange != null) {
                    Modifier.clickable { onChange(if (i == rating) 0 else i) }.padding(horizontal = 3.dp)
                } else Modifier
            )
        }
    }
}

@Composable
private fun SmallChip(text: String) {
    Text(
        text, color = Gold, fontSize = 10.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Gold.copy(alpha = 0.12f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    )
}

// ══════════════════════════════════════════════════════════════════════════════
// PANEL (INICIO)
// ══════════════════════════════════════════════════════════════════════════════


internal fun formatReadingTime(ms: Long): String {
    val minutes = (ms / 60_000L).coerceAtLeast(0L)
    val hours = minutes / 60
    val remainder = minutes % 60
    return if (hours > 0) "${hours} h ${remainder} min" else "${remainder} min"
}

// ══════════════════════════════════════════════════════════════════════════════
// BIBLIOTECA con filtros
// ══════════════════════════════════════════════════════════════════════════════

@Composable
internal fun FilterMenu(label: String, value: String, options: List<String>, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        FilterChip(
            selected = value.isNotEmpty(),
            onClick = { open = true },
            label = { Text(if (value.isEmpty()) label else value, maxLines = 1, fontSize = 12.sp) },
            colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = Gold, selectedLabelColor = Ink, labelColor = Cream
            )
        )
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(text = { Text("Todos") }, onClick = { onPick(""); open = false })
            options.forEach { o ->
                DropdownMenuItem(text = { Text(o) }, onClick = { onPick(o); open = false })
            }
        }
    }
}

/** Valor de texto que se recuerda al cambiar de pestaña o cerrar la app (filtros, búsquedas…). */
@Composable
internal fun rememberPrefString(key: String, default: String): MutableState<String> {
    val prefs = androidx.compose.ui.platform.LocalContext.current.getSharedPreferences("libra_prefs", 0)
    val st = remember(key) { mutableStateOf(prefs.getString(key, default) ?: default) }
    LaunchedEffect(st.value) { prefs.edit().putString(key, st.value).apply() }
    return st
}

@Composable
internal fun rememberPrefBool(key: String, default: Boolean): MutableState<Boolean> {
    val prefs = androidx.compose.ui.platform.LocalContext.current.getSharedPreferences("libra_prefs", 0)
    val st = remember(key) { mutableStateOf(prefs.getBoolean(key, default)) }
    LaunchedEffect(st.value) { prefs.edit().putBoolean(key, st.value).apply() }
    return st
}

// ══════════════════════════════════════════════════════════════════════════════
// DETALLE DEL LIBRO (hoja inferior)
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun BookDetailSheet(
    item: LibraryItem,
    notesCount: Int,
    onDismiss: () -> Unit,
    onRead: () -> Unit,
    onStatus: (String) -> Unit,
    onRating: (Int) -> Unit,
    onGenre: (String) -> Unit,
    onReview: (String) -> Unit,
    onFavorite: () -> Unit,
    onDelete: () -> Unit
) {
    var review by remember(item.id) { mutableStateOf(item.review) }
    var genre by remember(item.id) { mutableStateOf(item.genre) }
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = {
            if (review != item.review) onReview(review)
            onDismiss()
        },
        sheetState = state,
        containerColor = Panel
    ) {
        Column(
            Modifier
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row {
                BookCover(item, Modifier.size(width = 96.dp, height = 140.dp))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.title, color = Cream, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                        maxLines = 3, overflow = TextOverflow.Ellipsis)
                    Text(item.author, color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        SmallChip(item.format)
                        SmallChip(item.progressText())
                        if (notesCount > 0) SmallChip("$notesCount notas")
                    }
                    Spacer(Modifier.height(8.dp))
                    Stars(item.rating, size = 22, onChange = onRating)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onRead, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)
                ) { Text(if (item.progress > 0) "Continuar" else "Leer") }
                OutlinedButton(
                    onClick = onFavorite, shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
                ) { Text(if (item.isFavorite == 1) "★ Favorito" else "☆ Favorito") }
            }

            SectionTitle("ESTADO")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                STATUS_KEYS.forEach { k ->
                    FilterChip(
                        selected = item.statusKey() == k,
                        onClick = { onStatus(k) },
                        label = { Text(statusLabel(k)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Gold, selectedLabelColor = Ink, labelColor = Cream
                        )
                    )
                }
            }

            SectionTitle("GÉNERO")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GENRES.forEach { g ->
                    FilterChip(
                        selected = genre == g,
                        onClick = { genre = if (genre == g) "" else g; onGenre(genre) },
                        label = { Text(g, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Gold, selectedLabelColor = Ink, labelColor = Cream
                        )
                    )
                }
            }
            OutlinedTextField(
                value = genre,
                onValueChange = { genre = it },
                placeholder = { Text("O escribe otro género…", color = Muted, fontSize = 13.sp) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { onGenre(genre.trim()) }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Cream, unfocusedTextColor = Cream,
                    focusedBorderColor = Gold, unfocusedBorderColor = Line
                )
            )

            SectionTitle("MI RESEÑA")
            OutlinedTextField(
                value = review,
                onValueChange = { review = it },
                placeholder = { Text("¿Qué te pareció?", color = Muted, fontSize = 13.sp) },
                minLines = 3,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Cream, unfocusedTextColor = Cream,
                    focusedBorderColor = Gold, unfocusedBorderColor = Line
                )
            )
            TextButton(onClick = { onReview(review); onGenre(genre.trim()) }) {
                Text("Guardar reseña y género", color = Gold)
            }

            SectionTitle("DATOS")
            Text(
                "Añadido: ${DAY_FMT.format(Date(item.addedAt))}" +
                    (if (item.startedAt > 0) "\nEmpezado: ${DAY_FMT.format(Date(item.startedAt))}" else "") +
                    (if (item.finishedAt > 0) "\nTerminado: ${DAY_FMT.format(Date(item.finishedAt))}" else ""),
                color = Muted, fontSize = 12.sp, lineHeight = 18.sp
            )
            TextButton(onClick = onDelete) { Text("Quitar de la biblioteca", color = Color(0xFFB3322F)) }
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// FAVORITOS
// ══════════════════════════════════════════════════════════════════════════════

// ══════════════════════════════════════════════════════════════════════════════
// RACHA
// ══════════════════════════════════════════════════════════════════════════════

// ══════════════════════════════════════════════════════════════════════════════
// MENÚ «MÁS»
// ══════════════════════════════════════════════════════════════════════════════

private val MORE_TILES = listOf(
    Triple("Panel", "🏠", "Panel"),
    Triple("Estantería", "🪵", "Estantería"),
    Triple("Biblioteca", "📚", "Biblioteca"),
    Triple("Favoritos", "⭐", "Favoritos"),
    Triple("Notas", "📝", "Notas y citas"),
    Triple("Subrayados", "🖍️", "Subrayados"),
    Triple("Audio", "🎧", "Audiolibros"),
    Triple("Reto", "🏆", "Reto de lectura"),
    Triple("Resumen", "📊", "Resumen"),
    Triple("Racha", "🔥", "Racha"),
    Triple("Ajustes", "⚙️", "Ajustes")
)

@Composable
fun MoreSheet(
    onPick: (String) -> Unit,
    onTutorial: () -> Unit,
    onCsv: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Panel) {
        Column(
            Modifier.navigationBarsPadding().padding(horizontal = 16.dp).padding(bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Libellum", color = Cream, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            MORE_TILES.chunked(3).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { (key, icon, label) ->
                        Column(
                            Modifier.weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Ink)
                                .border(1.dp, Line, RoundedCornerShape(14.dp))
                                .clickable { onPick(key) }
                                .padding(vertical = 14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(icon, fontSize = 24.sp)
                            Spacer(Modifier.height(4.dp))
                            Text(label, color = Cream, fontSize = 11.sp, textAlign = TextAlign.Center)
                        }
                    }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onTutorial, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)) { Text("Tutorial") }
                OutlinedButton(onClick = onCsv, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)) { Text("Exportar CSV") }
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// EXPORTAR CSV
// ══════════════════════════════════════════════════════════════════════════════

private fun csv(v: String): String = "\"" + v.replace("\"", "\"\"").replace("\n", " ") + "\""

suspend fun exportCsv(context: Context, books: List<LibraryItem>, uri: Uri): String = withContext(Dispatchers.IO) {
    try {
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        fun d(t: Long) = if (t > 0) fmt.format(Date(t)) else ""
        val out = context.contentResolver.openOutputStream(uri, "w")
            ?: return@withContext "No se pudo crear el archivo."
        out.bufferedWriter(Charsets.UTF_8).use { w ->
            w.write("\uFEFF")
            w.write("Título,Autor,Formato,Estado,Progreso,Valoración,Género,Favorito,Añadido,Empezado,Terminado,Reseña\n")
            books.forEach { b ->
                w.write(
                    listOf(
                        csv(b.title), csv(b.author), csv(b.format), csv(statusLabel(b.statusKey())),
                        "${b.progressPct()}", "${b.rating}", csv(b.genre), if (b.isFavorite == 1) "sí" else "no",
                        d(b.addedAt), d(b.startedAt), d(b.finishedAt), csv(b.review)
                    ).joinToString(",") + "\n"
                )
            }
        }
        "CSV exportado con ${books.size} libros."
    } catch (e: Exception) {
        "No se pudo exportar: ${e.message ?: "error desconocido"}"
    }
}
