package com.libra.reader

import android.app.Application
import androidx.compose.runtime.Immutable
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

// ══════════════════════════════════════════════════════════════════════════════
// NOTAS Y CITAS — estado y lógica
//   Room (quote_notes + library_items) → NotesViewModel → NotesUiState (StateFlow) → NotesScreen
// ══════════════════════════════════════════════════════════════════════════════

internal enum class NotesFilter { ALL, BY_BOOK, FAVORITES, RECENT }

/** Para qué se abrió el selector de libros: filtrar la lista o cambiar el libro de una nota. */
internal sealed interface BookPicker {
    data object Filter : BookPicker
    data class Change(val noteId: String) : BookPicker
}

@Immutable
internal data class NotesUiState(
    val allNotes: List<QuoteNote> = emptyList(),
    val availableBooks: List<LibraryItem> = emptyList(),
    val selectedFilter: NotesFilter = NotesFilter.ALL,
    val selectedBookFilter: String? = null,
    val recentAscending: Boolean = false,          // «Recientes» ↓ más nuevas primero · «Antiguas» ↑
    val draftText: String = "",
    val selectedBookForDraft: String? = null,
    val draftMarkedFavorite: Boolean = false,
    val draftError: Boolean = false,
    val isSaving: Boolean = false,
    val activeMenuNoteId: String? = null,
    val editingNote: QuoteNote? = null,
    val pendingDeleteId: String? = null,
    val bookPicker: BookPicker? = null
) {
    /** Notas visibles según el filtro activo. */
    val notes: List<QuoteNote>
        get() {
            val base = when (selectedFilter) {
                NotesFilter.FAVORITES -> allNotes.filter { it.isFavorite == 1 }
                NotesFilter.BY_BOOK ->
                    if (selectedBookFilter == null) allNotes else allNotes.filter { it.bookId == selectedBookFilter }
                else -> allNotes
            }
            val asc = selectedFilter == NotesFilter.RECENT && recentAscending
            return if (asc) base.sortedBy { it.createdAt } else base.sortedByDescending { it.createdAt }
        }

    fun bookOf(id: String): LibraryItem? = if (id.isBlank()) null else availableBooks.firstOrNull { it.id == id }

    /** Libros que tienen al menos una nota (opciones del filtro «Por libro»): id → título. */
    val booksWithNotes: List<Pair<String, String>>
        get() = allNotes.filter { it.bookId.isNotBlank() }
            .map { it.bookId to (bookOf(it.bookId)?.title ?: it.bookTitle) }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }

    val selectedBookFilterTitle: String?
        get() = selectedBookFilter?.let { id -> bookOf(id)?.title ?: allNotes.firstOrNull { it.bookId == id }?.bookTitle }
}

internal class NotesViewModel(app: Application) : AndroidViewModel(app) {
    private val db = LibraryDatabase.get(app)
    private val noteDao = db.quoteNoteDao()

    private val _ui = MutableStateFlow(NotesUiState())
    val uiState: StateFlow<NotesUiState> = _ui.asStateFlow()

    init {
        // Las notas y la biblioteca se observan: cualquier cambio (aquí o en otras pantallas) llega al instante.
        viewModelScope.launch {
            combine(noteDao.observeAll(), db.libraryDao().observeAll()) { notes, items ->
                notes to items.filter { it.mediaType == "BOOK" }.sortedBy { it.title.lowercase() }
            }.collect { (notes, books) ->
                _ui.update { it.copy(allNotes = notes, availableBooks = books) }
            }
        }
    }

    // ── Borrador (tarjeta «Nueva nota o cita») ────────────────────────────────
    fun onDraftChange(text: String) = _ui.update { it.copy(draftText = text, draftError = false) }
    fun toggleDraftFavorite() = _ui.update { it.copy(draftMarkedFavorite = !it.draftMarkedFavorite) }
    fun selectDraftBook(id: String?) = _ui.update { it.copy(selectedBookForDraft = id) }

    fun saveDraft() {
        val s = _ui.value
        if (s.isSaving) return
        val text = s.draftText.trim()
        if (text.isEmpty()) {                       // nunca se guardan notas vacías
            _ui.update { it.copy(draftError = true) }
            return
        }
        _ui.update { it.copy(isSaving = true, draftError = false) }
        val book = s.selectedBookForDraft?.let { s.bookOf(it) }
        viewModelScope.launch {
            try {
                noteDao.upsert(
                    QuoteNote(
                        id = UUID.randomUUID().toString(), text = text,
                        bookId = book?.id.orEmpty(), bookTitle = book?.title.orEmpty(),
                        isFavorite = if (s.draftMarkedFavorite) 1 else 0
                    )
                )
                // borrador limpio tras guardar con éxito (se conserva el libro elegido para la siguiente nota)
                _ui.update { it.copy(draftText = "", draftMarkedFavorite = false, isSaving = false) }
            } catch (e: Exception) {
                readerLog("notas: no se pudo guardar la nota: ${e.message}")
                _ui.update { it.copy(isSaving = false) }
            }
        }
    }

    // ── Filtros ───────────────────────────────────────────────────────────────
    fun selectFilter(f: NotesFilter) = _ui.update {
        when {
            f == NotesFilter.RECENT && it.selectedFilter == NotesFilter.RECENT ->
                it.copy(recentAscending = !it.recentAscending)           // segundo toque: invierte el orden
            f == NotesFilter.RECENT -> it.copy(selectedFilter = f, recentAscending = false)
            else -> it.copy(selectedFilter = f)
        }
    }

    fun selectBookFilter(id: String?) = _ui.update {
        if (id == null) it.copy(selectedBookFilter = null, selectedFilter = NotesFilter.ALL, bookPicker = null)
        else it.copy(selectedBookFilter = id, selectedFilter = NotesFilter.BY_BOOK, bookPicker = null)
    }

    // ── Menú, favorito, edición, libro y borrado ─────────────────────────────
    fun openMenu(id: String?) = _ui.update { it.copy(activeMenuNoteId = id) }
    fun openBookPicker(p: BookPicker?) = _ui.update { it.copy(bookPicker = p, activeMenuNoteId = null) }

    fun toggleFavorite(note: QuoteNote) {
        _ui.update { it.copy(activeMenuNoteId = null) }
        viewModelScope.launch { noteDao.setFavorite(note.id, if (note.isFavorite == 1) 0 else 1) }
    }

    fun startEdit(note: QuoteNote) = _ui.update { it.copy(editingNote = note, activeMenuNoteId = null) }
    fun cancelEdit() = _ui.update { it.copy(editingNote = null) }

    fun saveEdit(text: String) {
        val note = _ui.value.editingNote ?: return
        val t = text.trim()
        if (t.isEmpty()) return
        _ui.update { it.copy(editingNote = null) }
        viewModelScope.launch { noteDao.updateText(note.id, t) }
    }

    fun changeBook(noteId: String, bookId: String?) {
        val book = bookId?.let { _ui.value.bookOf(it) }
        _ui.update { it.copy(bookPicker = null) }
        viewModelScope.launch { noteDao.setBook(noteId, book?.id.orEmpty(), book?.title.orEmpty()) }
    }

    fun requestDelete(id: String) = _ui.update { it.copy(pendingDeleteId = id, activeMenuNoteId = null) }
    fun dismissDelete() = _ui.update { it.copy(pendingDeleteId = null) }
    fun confirmDelete() {
        val id = _ui.value.pendingDeleteId ?: return
        _ui.update { it.copy(pendingDeleteId = null) }
        viewModelScope.launch { noteDao.deleteById(id) }
    }
}
