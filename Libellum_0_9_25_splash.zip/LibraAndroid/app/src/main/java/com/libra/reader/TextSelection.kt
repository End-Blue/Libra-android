package com.libra.reader

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import java.text.BreakIterator
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// ══════════════════════════════════════════════════════════════════════════════
// SELECCIÓN DE TEXTO — índices, ajuste por palabra/carácter, frases y manejadores
//
// ¿Por qué solían sentirse rígidos los manejadores?
//  1. detectDragGestures espera a superar el «touch slop» (~8 dp) antes de empezar: el primer movimiento se pierde.
//  2. Las posiciones del puntero son LOCALES al manejador; como el manejador se recoloca mientras se arrastra
//     (sigue a la selección), cada evento mezcla el movimiento del dedo con el del propio manejador → saltos.
//  3. Zona táctil pequeña (30 dp con la «gota» de 14 dp) y competencia con el texto/enlaces de debajo.
//  4. Un manejador no podía cruzar al otro (el rango se «atascaba») y solo había precisión de carácter.
//  5. Al soltar no se volvía a mostrar el menú contextual.
// ══════════════════════════════════════════════════════════════════════════════

/** Rango [start, end) dentro del texto del capítulo. */
internal data class SelRange(val start: Int, val end: Int) {
    val isEmpty: Boolean get() = end <= start
}

/**
 * Herramientas de índices para un capítulo. Los BreakIterator se crean UNA vez por capítulo
 * (crearlos en cada micro-movimiento del dedo era lo más caro del arrastre). Solo se usa en el hilo principal.
 */
internal class SelectionTools(private val plain: String) {
    private val words: BreakIterator = BreakIterator.getWordInstance(Locale("es")).also { if (plain.isNotEmpty()) it.setText(plain) }
    private val sentences: BreakIterator = BreakIterator.getSentenceInstance(Locale("es")).also { if (plain.isNotEmpty()) it.setText(plain) }
    private val len = plain.length

    private fun isWordChar(i: Int) = i in 0 until len && plain[i].isLetterOrDigit()

    /** Palabra bajo [off] (sin espacios ni puntuación), o null si el punto no cae en una palabra. */
    fun wordAt(off: Int): SelRange? {
        if (len == 0) return null
        val o = off.coerceIn(0, len - 1)
        var end = words.following(o)
        if (end == BreakIterator.DONE) end = len
        var start = words.preceding(end)
        if (start == BreakIterator.DONE) start = 0
        if (plain.substring(start, end).none { it.isLetterOrDigit() }) return null
        return SelRange(start, end)
    }

    /** Ajusta un extremo INICIAL al comienzo de palabra más cercano hacia atrás (saltando espacios y signos). */
    fun snapStart(off: Int): Int {
        if (len == 0) return 0
        val o = off.coerceIn(0, len)
        var s = if (words.isBoundary(o)) o else words.preceding(o).let { if (it == BreakIterator.DONE) 0 else it }
        // si el tramo es espacio/puntuación, se avanza hasta la siguiente palabra
        while (s < len && !isWordChar(s)) {
            val n = words.following(s)
            if (n == BreakIterator.DONE) break
            s = n
        }
        return s.coerceIn(0, len)
    }

    /** Ajusta un extremo FINAL al fin de palabra más cercano hacia delante (sin arrastrar espacios finales). */
    fun snapEnd(off: Int): Int {
        if (len == 0) return 0
        val o = off.coerceIn(0, len)
        var e = if (words.isBoundary(o)) o else words.following(o).let { if (it == BreakIterator.DONE) len else it }
        while (e > 0 && plain[e - 1].isWhitespace()) e--
        return e.coerceIn(0, len)
    }

    /**
     * Expande [s, e) a las frases completas que lo contienen, sin salir de [lo, hi] (la página visible).
     * Si ya es exactamente una o varias frases completas, la siguiente pulsación suma la frase siguiente.
     */
    fun expandToSentences(s: Int, e: Int, lo: Int, hi: Int): SelRange? {
        if (len == 0) return null
        val a = s.coerceIn(0, len)
        val b = e.coerceIn(a, len)
        var start = if (sentences.isBoundary(a)) a else sentences.preceding(a).let { if (it == BreakIterator.DONE) 0 else it }
        while (start < len && plain[start].isWhitespace()) start++
        var end = if (sentences.isBoundary(b)) b else sentences.following(b).let { if (it == BreakIterator.DONE) len else it }
        while (end > start && plain[end - 1].isWhitespace()) end--
        val already = start == a && end == b
        if (already && end < len) {                                   // ya eran frases completas → añade la siguiente
            var next = sentences.following(end).let { if (it == BreakIterator.DONE) len else it }
            while (next > end && plain[next - 1].isWhitespace()) next--
            if (next > end) end = next
        }
        val r = SelRange(max(start, lo), min(end, hi))
        return if (r.isEmpty) null else r
    }

    /** Texto seleccionado con espacios normalizados; seguro ante índices fuera de rango. */
    fun textOf(s: Int, e: Int): String {
        if (len == 0) return ""
        val a = s.coerceIn(0, len)
        val b = e.coerceIn(a, len)
        return plain.substring(a, b).replace(Regex("\\s+"), " ").trim()
    }
}

/** Precisión del arrastre de un manejador. */
internal enum class SelGranularity { CHAR, WORD }

/**
 * Calcula el nuevo rango al mover un manejador.
 *  · [fixed] = extremo contrario, que NO se mueve (permite cruzar: si el dedo pasa al otro lado, los roles se intercambian).
 *  · [target] = carácter bajo el dedo (ya dentro de la página).
 *  · Con [SelGranularity.WORD] el extremo móvil salta a límites de palabra; con CHAR sigue carácter a carácter.
 * Devuelve null si el resultado no es válido (se mantiene la selección anterior).
 */
internal fun SelectionTools.moveEnd(
    fixed: Int, target: Int, gran: SelGranularity, lo: Int, hi: Int
): SelRange? {
    val t = target.coerceIn(lo, hi)
    val r = when {
        t < fixed -> SelRange(if (gran == SelGranularity.WORD) snapStart(t) else t, fixed)
        t > fixed -> SelRange(fixed, if (gran == SelGranularity.WORD) snapEnd(t) else t)
        else -> return null
    }
    val clamped = SelRange(r.start.coerceIn(lo, hi), r.end.coerceIn(lo, hi))
    return if (clamped.isEmpty) null else clamped
}

/**
 * Manejador («coma») de la selección.
 *  · Empieza a seguir al dedo en cuanto lo toca (sin esperar al touch slop).
 *  · Zona táctil grande (64×72 dp) con la gota dibujada arriba; consume el gesto, así que nada del texto,
 *    enlaces o el pasa-página de debajo lo interrumpe.
 *  · Usa coordenadas ABSOLUTAS de la página (origen del manejador + posición local) para que el movimiento del
 *    propio manejador, que sigue a la selección, no distorsione el arrastre.
 *  · [onMove] recibe el punto objetivo (ya referido al ancla del manejador) y si el dedo va «rápido»
 *    (histéresis 70/140 dp/s): rápido → ajuste por palabra · lento → por carácter.
 */
@Composable
internal fun SelectionHandle(
    x: Float,
    y: Float,
    color: Color,
    onStart: () -> Unit,
    onMove: (target: Offset, fast: Boolean) -> Unit,
    onEnd: () -> Unit
) {
    val xs by rememberUpdatedState(x)
    val ys by rememberUpdatedState(y)
    val startCb by rememberUpdatedState(onStart)
    val moveCb by rememberUpdatedState(onMove)
    val endCb by rememberUpdatedState(onEnd)
    val density = LocalDensity.current
    val hitW = 64.dp
    val hitH = 72.dp
    val hitWpx = with(density) { hitW.toPx() }
    val topInsetPx = with(density) { 10.dp.toPx() }          // el área empieza algo por encima de la línea
    val dens = density.density

    Box(
        Modifier
            .offset { IntOffset((x - hitWpx / 2f).roundToInt(), (y - topInsetPx).roundToInt()) }
            .size(hitW, hitH)
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    down.consume()
                    // origen del manejador en coordenadas de la página (se relee en cada evento)
                    fun abs(local: Offset) = Offset(xs - hitWpx / 2f, ys - topInsetPx) + local
                    val anchor = Offset(xs, ys)
                    val grab = abs(down.position)
                    var lastAbs = grab
                    var lastT = down.uptimeMillis
                    var speed = 0f
                    var fast = false
                    startCb()
                    drag(down.id) { ch ->
                        ch.consume()
                        val now = abs(ch.position)
                        val dt = (ch.uptimeMillis - lastT).coerceAtLeast(1L)
                        val inst = (now - lastAbs).getDistance() / dt * 1000f / dens         // dp/s
                        speed = speed * 0.6f + inst * 0.4f
                        fast = if (fast) speed > 70f else speed > 140f
                        lastAbs = now
                        lastT = ch.uptimeMillis
                        moveCb(anchor + (now - grab), fast)                              // anclado: sin salto al agarrar
                    }
                    endCb()
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = this.size.width / 2f
            drawRect(color, Offset(cx - 1.5.dp.toPx(), topInsetPx), Size(3.dp.toPx(), 9.dp.toPx()))
            drawCircle(color, radius = 8.dp.toPx(), center = Offset(cx, topInsetPx + 17.dp.toPx()))
        }
    }
}
