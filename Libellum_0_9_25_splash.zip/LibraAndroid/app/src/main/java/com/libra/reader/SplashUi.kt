package com.libra.reader

import android.provider.Settings
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// ══════════════════════════════════════════════════════════════════════════════
// SPLASH / CARGA — «El libro que despierta, en papel»
//
// Secuencia (ms):   0–450   el libro aparece (abierto, inclinado en 3D)
//                 300–1200  «Libellum» se revela como tinta que se expande
//                1000–1450  aparece el texto bajo el nombre
//                 450–1600  6 páginas, una a una, cada vez más rápidas (látigo + rebote)
//                1700–2300  10 páginas casi de golpe
//                2300–2700  el libro se disuelve en motas doradas que forman una pluma
//                2350–2750  la pluma baja y se posa con un balanceo amortiguado
//                2700–3500  dos ondas (ripple) doradas desde la punta de la pluma
//                3220–3600  fundido hacia la interfaz principal
//
// • Toda la animación depende de UN reloj (`clock`), así que es determinista y barata.
// • Un toque en cualquier punto la salta (fundido corto).
// • Con «escala de duración de animación = 0» (movimiento reducido) se muestra solo
//   nombre + versión + pluma con un fundido simple (~1,8 s), sin 3D ni partículas.
// • Solo se muestra en arranque en frío (ver `LibraAppWithSplash`).
// ══════════════════════════════════════════════════════════════════════════════

/** Texto bajo el nombre. Fijo por petición del usuario (no depende de versionName). */
internal const val SPLASH_VERSION_TEXT = "28:12"

private const val TOTAL_MS = 3600f
private const val TOTAL_REDUCED_MS = 1800f

private val SplPaper = Color(0xFFFFFAF1)      // cara de las páginas
private val SplEdge = Color(0xFFEADFC6)       // canto de páginas
private val SplEdgeDark = Color(0xFFD9CCAE)   // canto lateral (en sombra)
private val SplCover = Color(0xFF292D3B)      // tapa (azul tinta)
private val SplCoverDark = Color(0xFF1B1E29)  // grosor de la tapa

/** Punto de entrada: app + splash encima. `showSplashOnStart` = arranque en frío. */
@Composable
fun LibraAppWithSplash(openRequest: MutableState<String?>, showSplashOnStart: Boolean) {
    var showSplash by remember { mutableStateOf(showSplashOnStart) }
    Box(Modifier.fillMaxSize()) {
        LibraApp(openRequest)           // carga debajo mientras suena la animación
        if (showSplash) SplashOverlay(onFinished = { showSplash = false })
    }
}

@Composable
private fun rememberLoraFamily(): FontFamily {
    val context = LocalContext.current
    return remember {
        runCatching { FontFamily(Font("fonts/lora.ttf", context.assets, FontWeight.SemiBold)) }
            .getOrDefault(LibellumSerif)
    }
}

@Composable
internal fun SplashOverlay(onFinished: () -> Unit) {
    val context = LocalContext.current
    val reduced = remember {
        runCatching {
            Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
        }.getOrDefault(false)
    }
    val total = if (reduced) TOTAL_REDUCED_MS else TOTAL_MS
    val clock = remember { Animatable(0f) }
    val skip = remember { Animatable(1f) }          // 1 = visible; baja a 0 si se toca para saltar
    val scope = rememberCoroutineScope()
    var finished by remember { mutableStateOf(false) }
    val lora = rememberLoraFamily()
    val finish: () -> Unit = { if (!finished) { finished = true; onFinished() } }

    LaunchedEffect(Unit) {
        clock.animateTo(total, tween(total.toInt(), easing = LinearEasing))
        finish()
    }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = (1f - smooth(seg(clock.value, total - 380f, total))) * skip.value }
            .background(Ink)
            .pointerInput(Unit) {
                detectTapGestures {
                    scope.launch { skip.animateTo(0f, tween(180)); finish() }
                }
            }
    ) {
        val u = min(maxWidth.value, maxHeight.value * 0.62f)     // unidad de tamaño (dp)
        val textTop = maxHeight * 0.40f + (u * 0.30f).dp

        // Fondo: papel con viñeta cálida
        Canvas(Modifier.fillMaxSize()) {
            drawRect(
                Brush.radialGradient(
                    listOf(Ink, SplEdge),
                    center = Offset(size.width / 2f, size.height * 0.42f),
                    radius = max(size.width, size.height) * 0.78f
                )
            )
        }

        // Libro 3D
        if (!reduced) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val t = clock.value
                        val fadeOut = smooth(seg(t, 2300f, 2800f))
                        alpha = smooth(seg(t, 0f, 450f)) * (1f - 0.85f * fadeOut)
                        val s = (0.92f + 0.08f * smooth(seg(t, 0f, 500f))) * (1f - 0.04f * fadeOut)
                        scaleX = s; scaleY = s
                        transformOrigin = TransformOrigin(0.5f, 0.40f)
                    }
            ) {
                drawBook(clock.value, min(size.width, size.height * 0.62f), Offset(size.width / 2f, size.height * 0.40f))
            }
        }

        // Motas, pluma y ondas
        Canvas(Modifier.fillMaxSize()) {
            drawFx(clock.value, min(size.width, size.height * 0.62f), Offset(size.width / 2f, size.height * 0.40f), reduced)
        }

        // Texto
        Column(
            Modifier.align(Alignment.TopCenter).padding(top = textTop),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "Libellum",
                fontFamily = lora,
                fontSize = 46.sp,
                letterSpacing = 1.sp,
                color = Cream,
                modifier = Modifier
                    .graphicsLayer {
                        compositingStrategy = CompositingStrategy.Offscreen
                        alpha = if (reduced) smooth(seg(clock.value, 0f, 600f)) else 1f
                    }
                    .drawWithContent {
                        drawContent()
                        val r = if (reduced) 1f else smooth(seg(clock.value, 300f, 1200f))
                        drawRect(inkMask(r), blendMode = BlendMode.DstIn)
                    }
            )
            Spacer(Modifier.height(10.dp))
            Box(
                Modifier
                    .width(64.dp)
                    .height(1.dp)
                    .graphicsLayer {
                        val r = if (reduced) 1f else smooth(seg(clock.value, 500f, 1300f))
                        scaleX = r; alpha = r
                    }
                    .background(GoldBright)
            )
            Spacer(Modifier.height(12.dp))
            Text(
                SPLASH_VERSION_TEXT,
                fontFamily = LibellumSans,
                fontSize = 14.sp,
                letterSpacing = 5.sp,
                color = Muted,
                modifier = Modifier.graphicsLayer {
                    val t = clock.value
                    val a = if (reduced) smooth(seg(t, 300f, 800f)) else smooth(seg(t, 1000f, 1450f))
                    alpha = a
                    translationY = (1f - a) * 6.dp.toPx()
                }
            )
        }
    }
}

// ───────────────────────────── utilidades de tiempo ─────────────────────────────

private fun clamp01(x: Float) = if (x < 0f) 0f else if (x > 1f) 1f else x
private fun seg(t: Float, a: Float, b: Float) = clamp01((t - a) / (b - a))
private fun smooth(x: Float): Float { val c = clamp01(x); return c * c * (3f - 2f * c) }
private fun easeOutCubic(x: Float): Float { val c = 1f - clamp01(x); return 1f - c * c * c }
private fun fl(a: Float, b: Float, f: Float) = a + (b - a) * f
private fun frac(x: Float) = x - floor(x)

/** Máscara «tinta que se expande» desde el centro del texto (r: 0..1). */
private fun inkMask(r: Float): Brush {
    val hw = r * 0.62f
    val soft = 0.12f
    val a = (0.5f - hw - soft).coerceIn(0f, 1f)
    val b = (0.5f - hw).coerceIn(0f, 1f)
    val c = (0.5f + hw).coerceIn(0f, 1f)
    val d = (0.5f + hw + soft).coerceIn(0f, 1f)
    return Brush.horizontalGradient(
        0f to Color.Transparent, a to Color.Transparent, b to Color.Black,
        c to Color.Black, d to Color.Transparent, 1f to Color.Transparent
    )
}

// ───────────────────────────── calendario de páginas ─────────────────────────────

private class PageTurn(val start: Float, val dur: Float)

private const val SLOW_COUNT = 6

private val TURNS: List<PageTurn> = buildList {
    val starts = floatArrayOf(450f, 680f, 880f, 1050f, 1200f, 1330f)
    val durs = floatArrayOf(460f, 420f, 380f, 340f, 300f, 280f)
    for (i in starts.indices) add(PageTurn(starts[i], durs[i]))
    for (i in 0 until 10) add(PageTurn(1700f + i * 38f, 260f))     // ráfaga final
}

/** Ángulo de la hoja respecto al lado derecho: 0 = tumbada a la derecha, π = a la izquierda. */
private fun pageAngle(tp: PageTurn, t: Float): Float {
    val p = clamp01((t - tp.start) / tp.dur)
    val e = if (p < 0.5f) 4f * p * p * p else 1f - (-2f * p + 2f).let { it * it * it } / 2f
    return PI.toFloat() * e
}

// ───────────────────────────── cámara 3D mínima ─────────────────────────────

/** Mesa = plano XY (x derecha, y a lo largo del lomo), z hacia arriba. Cámara delante y arriba. */
private class Cam(
    val cx: Float, val cy: Float,
    val se: Float, val ce: Float,       // sen/cos de la elevación
    val yc: Float, val ys: Float,       // cos/sen del giro (ligera inclinación del libro)
    val d: Float                        // distancia de la cámara (perspectiva)
) {
    fun proj(x: Float, y: Float, z: Float): Offset {
        val xr = x * yc - y * ys
        val yr = x * ys + y * yc
        val y1 = yr * se + z * ce
        val z1 = -yr * ce + z * se
        val k = d / (d - z1)
        return Offset(cx + xr * k, cy - y1 * k)
    }
}

private fun DrawScope.fillPoly(pts: Array<Offset>, color: Color, seam: Boolean = true) {
    val p = Path()
    p.moveTo(pts[0].x, pts[0].y)
    for (i in 1 until pts.size) p.lineTo(pts[i].x, pts[i].y)
    p.close()
    drawPath(p, color)
    if (seam) drawPath(p, color, style = Stroke(width = 0.9f))
}

private fun DrawScope.textLines(cam: Cam, x0: Float, x1: Float, z: Float, h2: Float) {
    val col = Line.copy(alpha = 0.85f)
    for (j in 0..6) {
        val v = -h2 * 0.70f + j * (h2 * 1.40f / 6f)
        drawLine(col, cam.proj(x0, v, z), cam.proj(x1, v, z), strokeWidth = 1.2f)
    }
}

// ───────────────────────────── el libro ─────────────────────────────

private fun DrawScope.drawBook(t: Float, u: Float, c: Offset) {
    val pw = u * 0.36f                    // ancho de página
    val h2 = pw * 0.65f                   // mitad del alto de página
    val thick = pw * 0.075f               // grosor total del bloque de páginas
    val elev = Math.toRadians(55.0).toFloat()
    val yaw = Math.toRadians(-5.0).toFloat()
    val cam = Cam(c.x, c.y, sin(elev), cos(elev), cos(yaw), sin(yaw), pw * 3.6f)

    val n = TURNS.size
    val unit = thick / (n + 6f)
    val turned = TURNS.count { t >= it.start + it.dur }
    val remaining = TURNS.count { t < it.start }
    val zR = unit * (remaining + 3f)      // altura del bloque derecho
    val zL = unit * (turned + 3f)         // altura del bloque izquierdo
    val coverT = pw * 0.03f
    val m = pw * 0.035f

    // Sombra bajo el libro
    val sc = cam.proj(0f, -h2 * 0.2f, -coverT)
    withTransform({ scale(1f, 0.38f, sc) }) {
        drawCircle(
            Brush.radialGradient(listOf(Color(0x40000000), Color.Transparent), center = sc, radius = pw * 1.35f),
            radius = pw * 1.35f, center = sc
        )
    }

    // Tapa
    val cL = -pw - m; val cR = pw + m; val cF = -h2 - m; val cB = h2 + m
    fillPoly(arrayOf(cam.proj(cL, cF, 0f), cam.proj(cR, cF, 0f), cam.proj(cR, cF, -coverT), cam.proj(cL, cF, -coverT)), SplCoverDark)
    fillPoly(arrayOf(cam.proj(cR, cF, 0f), cam.proj(cR, cB, 0f), cam.proj(cR, cB, -coverT), cam.proj(cR, cF, -coverT)), SplCoverDark)
    fillPoly(arrayOf(cam.proj(cL, cF, 0f), cam.proj(cR, cF, 0f), cam.proj(cR, cB, 0f), cam.proj(cL, cB, 0f)), SplCover)
    val gi = m * 0.45f
    val gold = Path().apply {
        val g = arrayOf(
            cam.proj(cL + gi, cF + gi, 0f), cam.proj(cR - gi, cF + gi, 0f),
            cam.proj(cR - gi, cB - gi, 0f), cam.proj(cL + gi, cB - gi, 0f)
        )
        moveTo(g[0].x, g[0].y); for (i in 1..3) lineTo(g[i].x, g[i].y); close()
    }
    drawPath(gold, GoldBright.copy(alpha = 0.85f), style = Stroke(width = 1.3f))

    // Bloque derecho (páginas aún sin pasar)
    fillPoly(arrayOf(cam.proj(0f, -h2, 0f), cam.proj(pw, -h2, 0f), cam.proj(pw, -h2, zR), cam.proj(0f, -h2, zR)), SplEdge)
    fillPoly(arrayOf(cam.proj(pw, -h2, 0f), cam.proj(pw, h2, 0f), cam.proj(pw, h2, zR), cam.proj(pw, -h2, zR)), SplEdgeDark)
    fillPoly(arrayOf(cam.proj(0f, -h2, zR), cam.proj(pw, -h2, zR), cam.proj(pw, h2, zR), cam.proj(0f, h2, zR)), SplPaper)
    textLines(cam, 0.14f * pw, 0.86f * pw, zR, h2)

    // Bloque izquierdo (páginas ya pasadas)
    fillPoly(arrayOf(cam.proj(-pw, -h2, 0f), cam.proj(0f, -h2, 0f), cam.proj(0f, -h2, zL), cam.proj(-pw, -h2, zL)), SplEdge)
    fillPoly(arrayOf(cam.proj(-pw, -h2, zL), cam.proj(0f, -h2, zL), cam.proj(0f, h2, zL), cam.proj(-pw, h2, zL)), SplPaper)
    textLines(cam, -0.86f * pw, -0.14f * pw, zL, h2)

    // Sombra del lomo (centro)
    fillPoly(arrayOf(cam.proj(0f, -h2, zR), cam.proj(0.07f * pw, -h2, zR), cam.proj(0.07f * pw, h2, zR), cam.proj(0f, h2, zR)), Color(0x1A000000), seam = false)
    fillPoly(arrayOf(cam.proj(-0.07f * pw, -h2, zL), cam.proj(0f, -h2, zL), cam.proj(0f, h2, zL), cam.proj(-0.07f * pw, h2, zL)), Color(0x1A000000), seam = false)

    // Hojas en vuelo (y rebote tras aterrizar las lentas)
    for (i in TURNS.indices) {
        val tp = TURNS[i]
        val slow = i < SLOW_COUNT
        val endT = tp.start + tp.dur
        if (t < tp.start || t >= endT + (if (slow) 450f else 0f)) continue
        val th = pageAngle(tp, t)
        val vel = (th - pageAngle(tp, t - 14f)) / 14f * 1000f            // rad/s
        val tau = (t - endT) / 1000f
        val bounce = if (slow && tau > 0f && tau < 0.45f) 0.32f * exp(-9f * tau) * max(0f, sin(22f * tau)) else 0f
        val lag = min(abs(vel) * 0.05f, 0.95f) + bounce                 // la punta se retrasa: látigo
        val landed = t >= endT
        val z0 = if (landed) zL else fl(zR + unit, zL + unit, th / PI.toFloat())

        val N = 12
        val ds = pw / N
        val xs = FloatArray(N + 1)
        val zs = FloatArray(N + 1)
        val ph = FloatArray(N + 1)
        xs[0] = 0f; zs[0] = z0
        for (s in 1..N) {
            val f = (s - 0.5f) / N
            val phi = th - lag * f * f * 1.2f
            ph[s] = phi
            xs[s] = xs[s - 1] + ds * cos(phi)
            zs[s] = max(zs[s - 1] + ds * sin(phi), 0f)
        }
        for (s in 1..N) {
            val shade = lerp(SplEdge, SplPaper, abs(cos(ph[s])) * 0.7f + 0.3f)
            fillPoly(
                arrayOf(
                    cam.proj(xs[s - 1], -h2, zs[s - 1]), cam.proj(xs[s], -h2, zs[s]),
                    cam.proj(xs[s], h2, zs[s]), cam.proj(xs[s - 1], h2, zs[s - 1])
                ),
                shade
            )
        }
        val lc = Line.copy(alpha = 0.8f)
        for (j in 0..5) {
            val v = -h2 * 0.68f + j * (h2 * 1.36f / 5f)
            for (s in 2 until N - 1) {
                drawLine(lc, cam.proj(xs[s], v, zs[s]), cam.proj(xs[s + 1], v, zs[s + 1]), strokeWidth = 1.1f)
            }
        }
        drawLine(Line, cam.proj(xs[N], -h2, zs[N]), cam.proj(xs[N], h2, zs[N]), strokeWidth = 1.5f)
    }
}

// ───────────────────────────── pluma, motas y ondas ─────────────────────────────

// Pluma en coordenadas unitarias: punta arriba (0,-1), cálamo abajo (0,1).
private val FEATHER_VANE = Path().apply {
    moveTo(0.02f, -1f)
    cubicTo(-0.26f, -0.82f, -0.42f, -0.20f, -0.05f, 0.60f)
    lineTo(0.04f, 0.60f)
    cubicTo(0.34f, -0.12f, 0.30f, -0.78f, 0.02f, -1f)
    close()
}
private val FEATHER_SHAFT = Path().apply {
    moveTo(0f, 1.0f)
    cubicTo(0.08f, 0.5f, 0.07f, -0.4f, 0.02f, -0.96f)
}

private fun DrawScope.drawFeatherShape(alpha: Float) {
    drawPath(
        FEATHER_VANE,
        Brush.linearGradient(listOf(GoldLight, GoldBright, GoldDeep), start = Offset(-0.5f, -1f), end = Offset(0.45f, 0.6f)),
        alpha = alpha
    )
    clipPath(FEATHER_VANE) {
        for (i in 0..21) {
            val y = -0.92f + i * 0.08f
            drawLine(Color(0xFFFFF3D6).copy(alpha = 0.55f * alpha), Offset(0.02f, y + 0.04f), Offset(-0.60f, y - 0.30f), strokeWidth = 0.006f)
            drawLine(GoldDeep.copy(alpha = 0.40f * alpha), Offset(0.02f, y + 0.04f), Offset(0.60f, y - 0.30f), strokeWidth = 0.006f)
        }
    }
    drawPath(FEATHER_SHAFT, GoldDeep.copy(alpha = alpha), style = Stroke(width = 0.032f, cap = StrokeCap.Round))
    drawPath(FEATHER_SHAFT, GoldLight.copy(alpha = 0.8f * alpha), style = Stroke(width = 0.010f, cap = StrokeCap.Round))
}

private fun DrawScope.drawFx(t: Float, u: Float, c: Offset, reduced: Boolean) {
    val dp = 1.dp.toPx()
    val s0 = u * 0.25f                                        // medio largo de la pluma
    val a0 = Math.toRadians(30.0).toFloat()                   // inclinación final
    val nib = Offset(c.x - u * 0.04f, c.y + u * 0.03f)        // punta de escribir: centro del libro

    // Pluma: aparece, baja y se posa con balanceo amortiguado
    val fa = if (reduced) smooth(seg(t, 0f, 800f)) else smooth(seg(t, 2350f, 2650f))
    val e = if (reduced) 1f else easeOutCubic(seg(t, 2350f, 2750f))
    val tau = if (reduced) 0f else max(0f, t - 2700f) / 1000f
    val ang = a0 + (1f - e) * 0.22f + 0.10f * exp(-5f * tau) * sin(15f * tau)
    val sc = 0.85f + 0.15f * e
    val dir = Offset(sin(ang), -cos(ang))
    val yoff = -u * 0.16f * (1f - e)
    val center = Offset(nib.x + dir.x * s0 * sc, nib.y + dir.y * s0 * sc + yoff)

    // Ondas (ripple) desde la punta
    if (!reduced) {
        for (k in 0..1) {
            val st = 2700f + k * 200f
            val p = seg(t, st, st + 700f)
            if (p > 0f && p < 1f) {
                val ep = easeOutCubic(p)
                val rx = u * 0.36f * ep
                val ry = rx * 0.36f
                val a = (1f - p) * (1f - p) * 0.75f
                val sw = fl(4.5f, 1f, ep) * dp
                drawOval(GoldBright.copy(alpha = a), Offset(nib.x - rx, nib.y - ry), Size(2f * rx, 2f * ry), style = Stroke(sw))
                drawOval(GoldLight.copy(alpha = a * 0.5f), Offset(nib.x - rx * 0.8f, nib.y - ry * 0.8f), Size(1.6f * rx, 1.6f * ry), style = Stroke(sw * 2.2f))
            }
        }
    }

    // Resplandor y pluma
    if (fa > 0f) {
        val gc = Offset(nib.x + dir.x * s0 * 0.6f, nib.y + dir.y * s0 * 0.6f)
        drawCircle(
            Brush.radialGradient(listOf(GoldLight.copy(alpha = 0.35f * fa), Color.Transparent), center = gc, radius = s0 * 1.1f),
            radius = s0 * 1.1f, center = gc
        )
        withTransform({
            translate(center.x, center.y)
            rotate(Math.toDegrees(ang.toDouble()).toFloat(), Offset.Zero)
            scale(s0 * sc, s0 * sc, Offset.Zero)
        }) { drawFeatherShape(fa) }
    }

    // Motas doradas que viajan del libro a la silueta de la pluma
    if (!reduced) {
        val fc = Offset(nib.x + sin(a0) * s0, nib.y - cos(a0) * s0)       // centro final de la pluma
        for (i in 0 until 36) {
            val r1 = frac(i * 0.61803f)
            val r2 = frac(i * 0.38197f + 0.3f)
            val r3 = frac(i * 0.7548f + 0.1f)
            val st = 2300f + r1 * 160f
            val p = seg(t, st, st + 380f)
            if (p <= 0f || p >= 1f) continue
            val ep = smooth(p)
            val start = Offset(c.x + (r1 * 2f - 1f) * u * 0.34f, c.y + (r2 - 0.5f) * u * 0.30f)
            val ly = -0.95f + 1.7f * r3
            val lx = (r2 * 2f - 1f) * 0.38f * (1f - abs(ly) * 0.5f)
            val tx = (lx * cos(a0) - ly * sin(a0)) * s0 + fc.x
            val ty = (lx * sin(a0) + ly * cos(a0)) * s0 + fc.y
            val bow = -sin(p * PI.toFloat()) * u * 0.05f * (r3 * 2f - 1f)
            val pos = Offset(fl(start.x, tx, ep), fl(start.y, ty, ep) + bow)
            val a = sin(p * PI.toFloat()) * 0.95f
            drawCircle(GoldLight.copy(alpha = a * 0.25f), radius = (3f + 4f * r3) * dp, center = pos)
            drawCircle(GoldLight.copy(alpha = a), radius = (1.2f + 2.2f * r3) * dp, center = pos)
        }
    }
}
