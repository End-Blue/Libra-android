package com.libra.reader

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import androidx.core.content.FileProvider
import java.io.File
import kotlin.math.max
import kotlin.math.min

/**
 * «Compartir como imagen»: dibuja la tarjeta del detalle (fondo pergamino, portada, tipografía serif,
 * texto completo con tamaño automático, ramitas y marca) en un PNG de 1080 px de ancho, lo guarda en la
 * caché y lo envía con ACTION_SEND (image/png) mediante FileProvider.
 */
internal object NoteShareImage {
    private const val W = 1080
    private const val MARGIN = 48f
    private const val PAD = 54f
    private const val MAX_H = 2400f

    private fun col(hex: Long) = hex.toInt()
    private val SERIF: Typeface = Typeface.SERIF
    private val SERIF_ITALIC: Typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC)
    private val SERIF_BOLD: Typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)

    private fun tp(size: Float, color: Long, face: Typeface) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = size; this.color = col(color); typeface = face
    }

    private fun layout(text: CharSequence, p: TextPaint, width: Int, maxLines: Int = Int.MAX_VALUE, spacing: Float = 1.2f) =
        StaticLayout.Builder.obtain(text, 0, text.length, p, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(0f, spacing)
            .setIncludePad(false)
            .setMaxLines(maxLines)
            .setEllipsize(TextUtils.TruncateAt.END)
            .build()

    fun render(entry: NoteEntry, bookTitle: String, coverPath: String?, dateText: String): Bitmap {
        val isHl = entry.kind == NoteKind.HIGHLIGHT
        val cardW = W - 2 * MARGIN
        val coverW = 190f
        val coverH = 274f
        val textLeft = PAD + coverW + 40f
        val textW = (cardW - textLeft - PAD).toInt()

        // ── Cabecera ──
        val labelPaint = tp(30f, 0xFFA3610B, SERIF_BOLD).apply { letterSpacing = 0.08f }
        val labelRaw = when {
            isHl && entry.chapterTitle.isNotBlank() -> "SUBRAYADO · ${entry.chapterTitle}"
            isHl -> "SUBRAYADO"
            else -> "NOTA O CITA"
        }
        val dotSpace = if (isHl) 30f else 0f
        val label = TextUtils.ellipsize(labelRaw, labelPaint, textW - dotSpace, TextUtils.TruncateAt.END).toString()
        val titleLayout = layout(bookTitle.ifBlank { "Sin libro asociado" }, tp(56f, 0xFF2A1503, SERIF), textW, maxLines = 2, spacing = 1.1f)
        val datePaint = tp(40f, 0xFF45301B, SERIF)
        val textBlockH = 30f + 16f + titleLayout.height + 14f + 44f
        val headerH = PAD + max(coverH, textBlockH) + PAD

        // ── Cuerpo: cita completa, tamaño automático ──
        val quote = "“${entry.text.trim().trim('“', '”', '"')}”"
        val bodyW = (cardW - 2 * PAD - 8f).toInt()
        val comment = entry.comment.trim()
        val commentLayout = if (comment.isNotEmpty()) layout(comment, tp(40f, 0xFF45301B, SERIF), bodyW, maxLines = 5) else null
        val commentBlockH = if (commentLayout != null) 36f + 2f + 24f + 30f + 8f + commentLayout.height else 0f
        val footerH = 130f
        val bodyPadV = 62f
        val maxQuoteH = MAX_H - 2 * MARGIN - headerH - 3f - 2 * bodyPadV - commentBlockH - footerH
        var quoteLayout = layout(quote, tp(66f, 0xFF2A1503, SERIF_ITALIC), bodyW, spacing = 1.3f)
        var size = 66f
        while (quoteLayout.height > maxQuoteH && size > 38f) {
            size -= 2f
            quoteLayout = layout(quote, tp(size, 0xFF2A1503, SERIF_ITALIC), bodyW, spacing = 1.3f)
        }
        if (quoteLayout.height > maxQuoteH) {                       // texto descomunal: último recurso, se corta con «…»
            val lineH = quoteLayout.height / quoteLayout.lineCount.toFloat()
            val lines = max(1, (maxQuoteH / lineH).toInt())
            quoteLayout = layout(quote, tp(size, 0xFF2A1503, SERIF_ITALIC), bodyW, maxLines = lines, spacing = 1.3f)
        }
        val bodyH = bodyPadV + quoteLayout.height + commentBlockH + bodyPadV

        val cardH = headerH + 3f + bodyH + footerH
        val totalH = cardH + 2 * MARGIN
        val bmp = Bitmap.createBitmap(W, totalH.toInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)

        // Fondo (como el «pantallazo» del modal sobre la pantalla)
        val bg = Paint().apply { shader = LinearGradient(0f, 0f, 0f, totalH, col(0xFFF7E8D1), col(0xFFEAD3A8), Shader.TileMode.CLAMP) }
        c.drawRect(0f, 0f, W.toFloat(), totalH, bg)

        val card = RectF(MARGIN, MARGIN, MARGIN + cardW, MARGIN + cardH)
        val radius = 72f
        val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = col(0xFFFFF8EA); setShadowLayer(44f, 0f, 18f, col(0x55402808))
        }
        c.drawRoundRect(card, radius, radius, shadowPaint)

        val clip = Path().apply { addRoundRect(card, radius, radius, Path.Direction.CW) }
        c.save()
        c.clipPath(clip)
        // banda de cabecera
        val headRect = RectF(card.left, card.top, card.right, card.top + headerH)
        c.drawRect(headRect, Paint().apply {
            shader = LinearGradient(0f, headRect.top, 0f, headRect.bottom, col(0xFFFFF1D6), col(0xFFFBEBCF), Shader.TileMode.CLAMP)
        })
        val line = Paint().apply { color = col(0xFFEAD7B5); strokeWidth = 3f }
        c.drawLine(card.left, headRect.bottom, card.right, headRect.bottom, line)
        // ramitas decorativas
        drawSprig(c, card.right - 300f, card.top + 8f, 300f, 220f, flip = false)
        drawSprig(c, card.left - 10f, card.bottom - 210f, 250f, 210f, flip = true)
        c.restore()
        c.drawRoundRect(card, radius, radius, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 3f; color = col(0xFFEAD7B5)
        })

        // Portada
        val coverRect = RectF(card.left + PAD, card.top + PAD, card.left + PAD + coverW, card.top + PAD + coverH)
        drawCover(c, coverRect, coverPath, bookTitle)

        // Etiqueta, título y fecha
        var y = card.top + PAD
        val tx = card.left + textLeft
        if (isHl) {
            c.drawCircle(tx + 11f, y + 19f, 11f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = entry.colorArgb.toInt() })
            c.drawCircle(tx + 11f, y + 19f, 11f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = 2f; color = col(0xFFD9B787)
            })
        }
        c.drawText(label, tx + dotSpace, y + 28f, labelPaint)
        y += 30f + 16f
        c.save(); c.translate(tx, y); titleLayout.draw(c); c.restore()
        y += titleLayout.height + 14f
        c.drawText(dateText, tx, y + 36f, datePaint)

        // Cuerpo
        val bx = card.left + PAD + 4f
        var by = headRect.bottom + 3f + bodyPadV
        c.save(); c.translate(bx, by); quoteLayout.draw(c); c.restore()
        by += quoteLayout.height
        if (commentLayout != null) {
            by += 36f
            c.drawLine(card.left + PAD, by, card.right - PAD, by, line)
            by += 2f + 24f
            c.drawText("NOTA", bx, by + 22f, tp(26f, 0xFFA3610B, SERIF_BOLD).apply { letterSpacing = 0.1f })
            by += 30f + 8f
            c.save(); c.translate(bx, by); commentLayout.draw(c); c.restore()
        }

        // Pie: marca
        val brand = tp(30f, 0xFFC9964A, SERIF_BOLD).apply { letterSpacing = 0.35f }
        val bw = brand.measureText("LIBELLUM")
        val fy = card.bottom - footerH / 2f + 10f
        c.drawText("LIBELLUM", (W - bw) / 2f, fy + 10f, brand)
        val gold = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col(0xFFC9964A); strokeWidth = 3f }
        c.drawLine(card.left + PAD + 40f, fy, (W - bw) / 2f - 36f, fy, gold)
        c.drawLine((W + bw) / 2f + 36f, fy, card.right - PAD - 40f, fy, gold)
        return bmp
    }

    private fun drawCover(c: Canvas, r: RectF, path: String?, title: String) {
        val rad = 30f
        val clip = Path().apply { addRoundRect(r, rad, rad, Path.Direction.CW) }
        c.save()
        c.clipPath(clip)
        val bitmap = path?.let { p -> runCatching {
            val f = File(p); if (!f.exists()) null else {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(p, o)
                var s = 1
                while (o.outWidth / (s * 2) >= r.width() && o.outHeight / (s * 2) >= r.height()) s *= 2
                BitmapFactory.decodeFile(p, BitmapFactory.Options().apply { inSampleSize = s })
            }
        }.getOrNull() }
        if (bitmap != null) {
            // recorte centrado (equivale a ContentScale.Crop)
            val sc = max(r.width() / bitmap.width, r.height() / bitmap.height)
            val sw = r.width() / sc
            val sh = r.height() / sc
            val sx = (bitmap.width - sw) / 2f
            val sy = (bitmap.height - sh) / 2f
            c.drawBitmap(
                bitmap, android.graphics.Rect(sx.toInt(), sy.toInt(), (sx + sw).toInt(), (sy + sh).toInt()), r,
                Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
            )
        } else {
            c.drawRect(r, Paint().apply {
                shader = LinearGradient(0f, r.top, 0f, r.bottom, col(0xFFF4DFB8), col(0xFFE9C98F), Shader.TileMode.CLAMP)
            })
            if (title.isNotBlank()) {
                val l = layout(title, tp(26f, 0xFF834906, SERIF_BOLD), (r.width() - 28f).toInt(), maxLines = 6)
                c.save(); c.translate(r.left + 14f, r.centerY() - l.height / 2f); l.draw(c); c.restore()
            }
        }
        c.restore()
        c.drawRoundRect(r, rad, rad, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 3f; color = col(0xFFEAD7B5)
        })
    }

    /** Ramita botánica discreta (misma idea que LeafSprig de la interfaz). */
    private fun drawSprig(c: Canvas, left: Float, top: Float, w: Float, h: Float, flip: Boolean) {
        c.save()
        c.translate(left, top)
        if (flip) c.scale(-1f, 1f, w / 2f, h / 2f)
        val cx = w * 0.35f
        val cy = h * 0.55f
        val stemPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 3.5f; strokeCap = Paint.Cap.ROUND; color = col(0xCCC9964A)
        }
        c.drawPath(Path().apply { moveTo(0f, h); quadTo(cx, cy, w * 0.96f, h * 0.04f) }, stemPaint)
        val leafPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col(0x8CC9964A) }
        for (i in 1..5) {
            val t = i / 6f
            val x = 2f * (1f - t) * t * cx + t * t * w * 0.96f
            val y = (1f - t) * (1f - t) * h + 2f * (1f - t) * t * cy + t * t * h * 0.04f
            for (a in floatArrayOf(-92f, -8f)) {
                c.save(); c.rotate(a, x, y)
                val len = w * 0.27f
                val wid = len * 0.34f
                c.drawPath(Path().apply {
                    moveTo(x, y); quadTo(x + len / 2, y - wid, x + len, y); quadTo(x + len / 2, y + wid, x, y); close()
                }, leafPaint)
                c.restore()
            }
        }
        c.restore()
    }

    /** Genera el PNG en caché (llamar fuera del hilo principal). */
    fun createFile(ctx: Context, entry: NoteEntry, bookTitle: String, coverPath: String?, dateText: String): File {
        val dir = File(ctx.cacheDir, "shared_notes").apply { mkdirs() }
        // limpieza: imágenes de más de un día
        dir.listFiles()?.filter { System.currentTimeMillis() - it.lastModified() > 24L * 3600_000L }?.forEach { it.delete() }
        val bmp = render(entry, bookTitle, coverPath, dateText)
        val file = File(dir, "nota_${entry.id.take(12)}_${System.currentTimeMillis()}.png")
        file.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
        return file
    }

    /** Abre el selector de Android con la imagen (image/png). */
    fun send(ctx: Context, file: File) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri("Nota", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, "Compartir imagen").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
