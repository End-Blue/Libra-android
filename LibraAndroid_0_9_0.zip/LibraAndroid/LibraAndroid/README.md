# Libellum — Android 0.8.4

Proyecto Android nativo con Kotlin, Jetpack Compose, Room y Media3.

## Novedades 0.8.4
- **Estantería realista** (como imagen de referencia): posturas Portada, De pie, Acostado, **Pila** (torre horizontal de libros tumbados) e **Inclinado**.
- Botón **Mezcla**: reparte verticales + pilas + inclinados en la misma balda.
- Botón **Pila**: selector de libros → torre centrada automática, sin solapes.
- Lector EPUB: texto multilínea vertical tipo Kindle (no una sola línea horizontal).

## Novedades 0.8.2
- **Imágenes en EPUB**: rutas reescritas en HTML y en CSS (`url(...)`), visibilidad forzada y re-medida de páginas al cargar cada imagen.
- Paginación reflowable de EPUB: columnas del ancho de pantalla, continuidad real del texto entre hojas.

## Novedades 0.8.1
- **Adornos arrastrables** en la estantería «Libre»: botón «+ Añadir» (16 adornos), tócalos para editarlos, mantén pulsado para moverlos (ya seleccionados se arrastran directamente).
- Edición del adorno: **tamaño** (×0,5 a ×3), **color** (14 colores u «Original»), **cambiar de adorno**, **duplicar** y **eliminar**.
- Al soltarlos se **apoyan solos** sobre una balda o sobre el canto superior de un libro (también libros acostados y apilados); si mueves el libro, el adorno que tiene encima se mueve con él.
- «Los del tema» devuelve los adornos del tema elegido. Posiciones, tamaños y colores se guardan en el teléfono.
- **Lector EPUB corregido**: ya no se reparte cada título en una hoja casi vacía («HOMERO», «POR»…). Se neutralizan los saltos de página forzados, alturas fijas, posiciones absolutas y márgenes enormes del propio libro, y se vuelve a medir el número de hojas cuando cargan imágenes.

## Novedades 0.8.0 — Taller de estantería
- Botón «🎨 Personalizar» en Estanterías, con vista previa en vivo y 7 pestañas: Temas, Madera, Pared, Lomos, Letra, Decoración y Luz.
- 17 maderas y acabados, 3 grosores de balda y 3 estructuras (solo balda, laterales, escuadras).
- 12 paredes (rayas, ladrillo, rombos, paneles, corcho, lino, cielo estrellado…).
- 10 paletas de lomos, 6 materiales (cuero cosido, tela, relieve, brillante, rústico…), 5 adornos de lámina y 6 colores de lámina.
- 10 tipos de letra, mayúsculas, 3 tamaños y color del título; marca de progreso en el lomo.
- 16 objetos decorativos dibujados a mano (planta, vela, globo, gato, búho…) y 6 luces (cálida, fría, atardecer, lámpara, guirnalda).
- 8 temas listos para aplicar. Color del lomo libro por libro (Ajustar lomos).
- Los ajustes se guardan en el teléfono y valen para las vistas Lomos, Portadas y Libre.

## Novedades 0.7.0
- Texto de TXT/FB2 y EPUB visible (arreglado color del texto y etiquetas autocerradas del EPUB).
- Interfaz nueva «papel»: Panel con racha, Biblioteca con filtros y detalle del libro, Favoritos, Racha, menú «Más».
- Estanterías por categoría (portadas o lomos, tamaños S/M/L, ajustar lomos) y modo libre.
- Reto de lectura, Resumen y exportar CSV.
- Widget «Mi estantería» para la pantalla de inicio.

## Novedades 0.9.0
- Lector EPUB rehecho al estilo Play Libros / ReadEra: hojas con medidas exactas (corrige las palabras salteadas), tocar el centro muestra u oculta los controles, párrafos justificados y número de hoja discreto.
- Los ajustes (letra, margen, interlineado, color, tipografía) se aplican en vivo sin recargar el capítulo: las imágenes no se cargan dos veces y no pierdes el sitio.
- Imágenes ajustadas a la hoja (portadas e ilustraciones a pantalla completa). Tipografías incluidas: Lora, Caladea y Carlito.
- Estantería: se quita «Inclinado»; la pila (torre) nace apoyada sobre una balda.

## Funciones
- Biblioteca local (Room): importación múltiple de EPUB, PDF, TXT, FB2, CBZ y CBR, y de audiolibros MP3, M4A, M4B, AAC, OGG, OPUS, WAV y FLAC. Cada archivo se copia al almacenamiento privado de la app.
- Escáner automático: con el permiso «Acceso a todos los archivos» (documentos y libros), Libellum busca EPUB, PDF, TXT, FB2 y CBZ en todo el teléfono y la SD, con filtro por tipo. Se abre solo la primera vez.
- Portadas y metadatos automáticos (EPUB, PDF, CBZ, FB2 y audio).
- Lector: EPUB, PDF, TXT, FB2 y CBZ, con modo de scroll vertical o pasar hoja, tamaño de letra y temas. Guarda por dónde ibas. CBR se importa pero aún no se lee.
- Subrayados y notas por libro, con colores pastel y vista global en la pestaña «Notas».
- Al seleccionar texto en un EPUB aparece «Copiar · Diccionario · Subrayar»; los subrayados se ven pintados en la página.
- EPUB con hojas reales (columnas): se pasa de hoja deslizando, tocando los bordes o con las flechas; los enlaces del índice funcionan.
- Iconos propios dibujados a mano (sin librerías de iconos).
- Estantería con posturas: de frente, de pie, acostado, pila horizontal e inclinado; botón Mezcla para layout realista; se mueven manteniendo pulsado.
- Audiolibros con reproducción en segundo plano, ±15/30 s, velocidad y posición guardada.
- Favoritos, búsqueda por título o autor y separador de página.
- Biblioteca en lista, cuadrícula o estantería con movimiento libre de los libros.
- Copias de seguridad exportables (.zip) con libros, audios, portadas, progreso, favoritos, orden de la estantería y notas.

## Limitaciones conocidas
- CBR (RAR) no se lee todavía.
- En EPUB se guarda el capítulo, no la posición exacta dentro del capítulo.
- Los EPUB con DRM no se abren.
- Android no permite elegir la carpeta «Descargas» completa en el escáner; para esos archivos usa «Importar».

## Compilar
- Android Studio Ladybug o posterior, JDK 17, Android SDK 35.
- Sin Android Studio: sube `LibellumAndroid.zip` y el workflow `.github/workflows/build.yml` a GitHub; el APK sale en Actions → artefacto `app-debug`.
