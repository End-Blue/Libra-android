@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.libra.reader

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.File
import java.util.UUID
import java.util.zip.ZipFile
import kotlin.math.absoluteValue

// ══════════════════════════════════════════════════════════════════════════════
// PANTALLA PRINCIPAL DEL LECTOR
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun ReaderScreen(
    item: LibraryItem,
    onClose: () -> Unit,
    onSave: (Long, Int) -> Unit,
    highlightDao: HighlightDao,
    onUpdateItem: (LibraryItem) -> Unit   // para guardar readingMode, bookmarkStyle
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    BackHandler(onBack = onClose)

    var showMenu by remember { mutableStateOf(false) }
    var showHighlights by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var readingPrefs by remember {
        mutableStateOf(
            ReadingPrefs(
                themeMode = when (item.readingMode) { // reuse nothing; default white
                    else -> 2
                }
            )
        )
    }

    val highlights by highlightDao.observeByBook(item.id).collectAsState(initial = emptyList())
    var editingHighlight by remember { mutableStateOf<Highlight?>(null) }

    Column(
        Modifier
            .fillMaxSize()
            .background(Ink)
            .systemBarsPadding()
    ) {
        // ── Barra superior ────────────────────────────────────────────────────
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onClose) { Text("‹ Volver", color = Gold) }
            Text(
                item.title, color = Cream, fontSize = 13.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            // Botón notas del libro
            TextButton(onClick = { showHighlights = true }) {
                Text("📝", fontSize = 18.sp)
            }
            // Botón ajustes del lector
            TextButton(onClick = { showSettings = true }) {
                Text("⚙", color = Muted, fontSize = 18.sp)
            }
        }

        // ── Contenido del lector (con brillo de página) ───────────────────────
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (item.format.lowercase()) {
                "epub" -> EpubReader(item, onSave, highlightDao, onUpdateItem, readingPrefs, { readingPrefs = it })
                "pdf"  -> PdfReader(item, onSave, item.readingMode, highlightDao, onUpdateItem)
                "txt"  -> TextFileReader(item, onSave, fb2 = false, highlightDao, onUpdateItem, readingPrefs)
                "fb2"  -> TextFileReader(item, onSave, fb2 = true,  highlightDao, onUpdateItem, readingPrefs)
                "cbz"  -> CbzReader(item, onSave, item.readingMode)
                else   -> Message(
                    "Los archivos CBR (RAR) todavía no se pueden leer dentro de Libellum. " +
                    "Conviértelo a CBZ y vuelve a importarlo."
                )
            }
        }

        // ── Separador de página (bookmark visual) ─────────────────────────────
        if (item.bookmarkStyle.isNotBlank()) {
            BookmarkDivider(item)
        }
    }

    // ── Hoja de notas del libro ───────────────────────────────────────────────
    if (showHighlights) {
        ModalBottomSheet(
            onDismissRequest = { showHighlights = false },
            containerColor = Panel
        ) {
            Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 32.dp)) {
                Text(
                    "NOTAS DE ESTE LIBRO",
                    color = Gold, fontSize = 13.sp,
                    fontWeight = FontWeight.Bold, letterSpacing = 1.sp
                )
                Spacer(Modifier.height(12.dp))
                BookHighlightsScreen(
                    highlights = highlights,
                    onEdit = { editingHighlight = it },
                    onDelete = { h -> scope.launch { highlightDao.deleteById(h.id) } }
                )
            }
        }
    }

    // ── Hoja de ajustes del lector ────────────────────────────────────────────
    if (showSettings) {
        ReaderSettingsSheet(
            item = item,
            prefs = readingPrefs,
            onPrefsChange = { readingPrefs = it },
            onDismiss = { showSettings = false },
            onUpdateItem = onUpdateItem
        )
    }

    // ── Diálogo de edición de nota ────────────────────────────────────────────
    editingHighlight?.let { h ->
        HighlightEditDialog(
            highlight = h,
            onSave = { updated ->
                scope.launch { highlightDao.update(updated) }
                editingHighlight = null
            },
            onDismiss = { editingHighlight = null }
        )
    }
}

// ── Ajustes del lector ────────────────────────────────────────────────────────

@Composable
fun ReaderSettingsSheet(
    item: LibraryItem,
    prefs: ReadingPrefs,
    onPrefsChange: (ReadingPrefs) -> Unit,
    onDismiss: () -> Unit,
    onUpdateItem: (LibraryItem) -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Panel
    ) {
        Column(
            Modifier
                .padding(horizontal = 16.dp)
                .padding(bottom = 36.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                "AJUSTES DE LECTURA",
                color = Gold, fontSize = 13.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 1.sp
            )

            // Temas de color (blanco / sepia / oscuro / negro)
            Text("Fondo", color = Cream, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                listOf(
                    2 to Color(0xFFFFFFFF),
                    1 to Color(0xFFF4ECD8),
                    0 to Color(0xFF0B1426),
                    3 to Color(0xFF000000)
                ).forEach { (mode, c) ->
                    Box(
                        Modifier
                            .size(42.dp)
                            .background(c, RoundedCornerShape(21.dp))
                            .border(
                                width = if (prefs.themeMode == mode) 2.dp else 1.dp,
                                color = if (prefs.themeMode == mode) Gold else Muted.copy(alpha = 0.4f),
                                shape = RoundedCornerShape(21.dp)
                            )
                            .clickable { onPrefsChange(prefs.copy(themeMode = mode)) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (prefs.themeMode == mode) {
                            Text("✓", color = if (mode == 2 || mode == 1) Color.Black else Gold, fontSize = 16.sp)
                        }
                    }
                }
            }

            // Tamaño de letra
            Text("Tamaño de letra: ${prefs.fontSizeSp}", color = Cream, fontSize = 14.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = {
                    onPrefsChange(prefs.copy(fontSizeSp = (prefs.fontSizeSp - 1).coerceAtLeast(12)))
                }) { Text("A−", color = Gold, fontSize = 16.sp) }
                Slider(
                    value = prefs.fontSizeSp.toFloat(),
                    onValueChange = { onPrefsChange(prefs.copy(fontSizeSp = it.toInt())) },
                    valueRange = 12f..32f,
                    modifier = Modifier.weight(1f),
                    colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold)
                )
                TextButton(onClick = {
                    onPrefsChange(prefs.copy(fontSizeSp = (prefs.fontSizeSp + 1).coerceAtMost(32)))
                }) { Text("A+", color = Gold, fontSize = 16.sp) }
            }

            // Margen
            Text("Margen: ${prefs.marginDp} dp", color = Cream, fontSize = 14.sp)
            Slider(
                value = prefs.marginDp.toFloat(),
                onValueChange = { onPrefsChange(prefs.copy(marginDp = it.toInt())) },
                valueRange = 8f..40f,
                colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold)
            )

            // Interlineado
            Text("Interlineado: ${"%.2f".format(prefs.lineHeight)}", color = Cream, fontSize = 14.sp)
            Slider(
                value = prefs.lineHeight,
                onValueChange = { onPrefsChange(prefs.copy(lineHeight = it)) },
                valueRange = 1.2f..2.2f,
                colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold)
            )

            // Brillo de la página
            Text("Brillo de página", color = Cream, fontSize = 14.sp)
            Slider(
                value = prefs.brightness,
                onValueChange = { onPrefsChange(prefs.copy(brightness = it)) },
                valueRange = 0.35f..1f,
                colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold)
            )

            HorizontalDivider(color = Ink)

            Text(
                "Pasar página: desliza o usa ‹ ›. El texto se adapta al tamaño de pantalla (sin scroll dentro de la hoja).",
                color = Muted, fontSize = 12.sp, lineHeight = 18.sp
            )

            // Separador visual
            Text("Separador de página", color = Cream, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(
                    "" to "Ninguno",
                    "COVER" to "Portada",
                    "RIBBON" to "Cinta"
                ).forEach { (style, label) ->
                    FilterChip(
                        selected = item.bookmarkStyle == style,
                        onClick = { onUpdateItem(item.copy(bookmarkStyle = style)) },
                        label = { Text(label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Gold,
                            selectedLabelColor = Ink,
                            labelColor = Cream
                        )
                    )
                }
            }
        }
    }
}

// ── Separador visual de página ─────────────────────────────────────────────────

@Composable
fun BookmarkDivider(item: LibraryItem) {
    when (item.bookmarkStyle) {
        "COVER" -> {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .background(Panel)
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BookCover(item, Modifier.size(width = 25.dp, height = 36.dp))
                Spacer(Modifier.width(10.dp))
                Text("Continuarás aquí", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                Text("🔖", fontSize = 18.sp)
            }
        }
        "RIBBON" -> {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .background(Gold)
            )
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// HELPERS COMUNES
// ══════════════════════════════════════════════════════════════════════════════

@Composable
private fun Message(text: String) {
    Box(Modifier.fillMaxSize().padding(28.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Cream, fontSize = 15.sp, lineHeight = 22.sp, textAlign = TextAlign.Center)
    }
}

/** Animación de paso de página horizontal (efecto slide + fade) */
@Composable
private fun <T> PagedContent(
    state: T,
    goingForward: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable (T) -> Unit
) {
    AnimatedContent(
        targetState = state,
        transitionSpec = {
            if (goingForward) {
                (slideInHorizontally { it } + fadeIn(tween(220))).togetherWith(
                    slideOutHorizontally { -it } + fadeOut(tween(220))
                )
            } else {
                (slideInHorizontally { -it } + fadeIn(tween(220))).togetherWith(
                    slideOutHorizontally { it } + fadeOut(tween(220))
                )
            }
        },
        label = "page_anim",
        modifier = modifier
    ) { s -> content(s) }
}

// ══════════════════════════════════════════════════════════════════════════════
// EPUB
// ══════════════════════════════════════════════════════════════════════════════

private const val EPUB_HOST = "libra.local"

private class EpubTheme {
    @Volatile var mode: Int = 2          // 0 dark, 1 sepia, 2 white, 3 black
    @Volatile var fontSizePx: Int = 18
    @Volatile var lineHeight: Float = 1.55f
    @Volatile var marginPx: Int = 20
}

/** Preferencias de lectura en memoria (se aplican a EPUB/TXT) */
data class ReadingPrefs(
    val themeMode: Int = 2,       // 0 oscuro, 1 sepia, 2 blanco, 3 negro
    val fontSizeSp: Int = 18,
    val lineHeight: Float = 1.55f,
    val marginDp: Int = 20,
    val brightness: Float = 1f    // 0.3 .. 1.0
)

private fun chapterUrl(path: String): String =
    Uri.Builder().scheme("https").authority(EPUB_HOST)
        .encodedPath("/" + Uri.encode(path, "/")).build().toString()

private fun styleFor(prefs: ReadingPrefs): String {
    val (bg, fg, link) = when (prefs.themeMode) {
        0 -> Triple("#0B1426", "#F3E6C8", "#D4AF37") // oscuro Libellum
        1 -> Triple("#F4ECD8", "#3B2F1E", "#8A5A1F") // sepia
        3 -> Triple("#000000", "#CCCCCC", "#88AAFF") // negro
        else -> Triple("#FFFFFF", "#111111", "#1A5FB4") // blanco
    }
    val pad = prefs.marginDp
    val fs = prefs.fontSizeSp
    val lh = prefs.lineHeight
    // Página adaptada a pantalla: sin scroll vertical del body; el volteo de hoja
    // se hace por capítulos / páginas lógicas desde Compose.
    return (
        "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1\">" +
        "<style>" +
        "html,body{background:" + bg + " !important;color:" + fg + " !important;" +
        "margin:0 !important;padding:0 !important;}" +
        "body{padding:" + pad + "px !important;line-height:" + lh + " !important;" +
        "font-size:" + fs + "px !important;font-family:sans-serif !important;" +
        "overflow-x:hidden !important;}" +
        "p,div,span,li,td,th,h1,h2,h3,h4,h5,h6{color:" + fg + " !important;" +
        "font-size:inherit !important;line-height:inherit !important;}" +
        "a{color:" + link + " !important;}" +
        "img,svg{max-width:100% !important;height:auto !important;}" +
        "*{-webkit-user-select:text !important;user-select:text !important;}" +
        "html{height:100% !important;overflow:hidden !important;}" +
        "body{min-height:100% !important;}" +
        "</style>"
    )
}

private fun injectStyle(html: String, prefs: ReadingPrefs): String {
    val style = styleFor(prefs)
    val index = html.indexOf("</head>", ignoreCase = true)
    return if (index >= 0) html.substring(0, index) + style + html.substring(index) else style + html
}

private fun emptyResponse(status: Int, reason: String) =
    WebResourceResponse("text/plain", "utf-8", status, reason, emptyMap(),
        ByteArrayInputStream(ByteArray(0)))

private fun serveEpub(pkg: EpubPackage, theme: EpubTheme, uri: Uri, prefs: ReadingPrefs): WebResourceResponse {
    if (uri.host != EPUB_HOST) return emptyResponse(403, "Blocked")
    return try {
        val path = uri.path?.removePrefix("/") ?: return emptyResponse(404, "Not found")
        val bytes = pkg.readBytes(path) ?: return emptyResponse(404, "Not found")
        val mime = pkg.mimeOf(path)
        if (mime.contains("html")) {
            val styled = injectStyle(String(bytes, Charsets.UTF_8), prefs.copy(
                themeMode = theme.mode,
                fontSizeSp = theme.fontSizePx,
                lineHeight = theme.lineHeight,
                marginDp = theme.marginPx
            ))
            WebResourceResponse("text/html", "utf-8",
                ByteArrayInputStream(styled.toByteArray(Charsets.UTF_8)))
        } else {
            WebResourceResponse(mime, null, ByteArrayInputStream(bytes))
        }
    } catch (_: Exception) {
        emptyResponse(404, "Not found")
    }
}

@Composable
private fun EpubReader(
    item: LibraryItem,
    onSave: (Long, Int) -> Unit,
    highlightDao: HighlightDao,
    onUpdateItem: (LibraryItem) -> Unit,
    prefs: ReadingPrefs,
    onPrefsChange: (ReadingPrefs) -> Unit
) {
    val pkg = remember(item.id) { runCatching { EpubPackage(File(item.localPath)) }.getOrNull() }
    DisposableEffect(pkg) { onDispose { pkg?.close() } }
    if (pkg == null || pkg.spine.isEmpty()) {
        Message("No se pudo abrir este EPUB. Puede estar dañado o protegido con DRM.")
        return
    }

    val theme = remember { EpubTheme() }
    val chapterHighlights by highlightDao.observeByBook(item.id).collectAsState(initial = emptyList())
    LaunchedEffect(prefs) {
        theme.mode = prefs.themeMode
        theme.fontSizePx = prefs.fontSizeSp
        theme.lineHeight = prefs.lineHeight
        theme.marginPx = prefs.marginDp
    }

    var spineIndex by remember(item.id) {
        mutableIntStateOf(item.lastPosition.toInt().coerceIn(0, pkg.spine.lastIndex))
    }
    // Página interna dentro del capítulo (0-based)
    var subPage by remember { mutableIntStateOf(0) }
    var subPageCount by remember { mutableIntStateOf(1) }
    var goingForward by remember { mutableStateOf(true) }
    val webViewRef = remember { mutableStateOf<WebView?>(null) }
    val scope = rememberCoroutineScope()

    var dictWord by remember { mutableStateOf<String?>(null) }
    var pendingHighlight by remember { mutableStateOf<String?>(null) }

    // Guardar progreso: capítulo actual
    LaunchedEffect(spineIndex) {
        onSave(spineIndex.toLong(), (spineIndex + 1) * 100 / pkg.spine.size)
        subPage = 0
    }

    fun goSubPage(target: Int) {
        val wv = webViewRef.value ?: return
        val p = target.coerceIn(0, (subPageCount - 1).coerceAtLeast(0))
        subPage = p
        // scroll programático a la hoja
        val y = p * wv.height
        wv.scrollTo(0, y)
    }

    fun nextPage() {
        if (subPage < subPageCount - 1) {
            goingForward = true
            goSubPage(subPage + 1)
        } else if (spineIndex < pkg.spine.lastIndex) {
            goingForward = true
            spineIndex++
        }
    }

    fun prevPage() {
        if (subPage > 0) {
            goingForward = false
            goSubPage(subPage - 1)
        } else if (spineIndex > 0) {
            goingForward = false
            spineIndex--
        }
    }

    Column(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .pointerInput(spineIndex, subPage, subPageCount) {
                    detectHorizontalDragGestures { _, dragAmount ->
                        if (dragAmount < -50) nextPage()
                        else if (dragAmount > 50) prevPage()
                    }
                }
        ) {
            PagedContent(
                state = spineIndex to subPage,
                goingForward = goingForward,
                modifier = Modifier.fillMaxSize()
            ) {
                EpubWebView(
                    pkg = pkg,
                    theme = theme,
                    index = spineIndex,
                    themeMode = prefs.themeMode,
                    zoom = 100,
                    prefs = prefs,
                    chapterHighlights = chapterHighlights.filter { h -> h.chapterIndex == spineIndex },
                    onWordSelected = { w -> dictWord = w },
                    onTextSelected = { t -> pendingHighlight = t },
                    onWebViewReady = { wv -> webViewRef.value = wv },
                    onPageMetrics = { total ->
                        subPageCount = total.coerceAtLeast(1)
                        if (subPage >= subPageCount) subPage = subPageCount - 1
                    }
                )
            }
            // Veladura de brillo
            if (prefs.brightness < 0.99f) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = (1f - prefs.brightness).coerceIn(0f, 0.65f)))
                )
            }
        }

        Row(
            Modifier.fillMaxWidth().background(Panel).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { prevPage() }) {
                Text("‹", color = Gold, fontSize = 24.sp)
            }
            Text(
                "Cap. ${spineIndex + 1}/${pkg.spine.size} · Hoja ${subPage + 1}/$subPageCount",
                color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f),
                textAlign = TextAlign.Center
            )
            TextButton(onClick = { nextPage() }) {
                Text("›", color = Gold, fontSize = 24.sp)
            }
            TextButton(onClick = {
                val next = (prefs.themeMode + 1) % 4
                onPrefsChange(prefs.copy(themeMode = next))
            }) {
                Text("◐", color = Gold, fontSize = 18.sp)
            }
        }
    }

    dictWord?.let { w ->
        DictionaryDialog(word = w, onDismiss = { dictWord = null })
    }
    pendingHighlight?.let { text ->
        HighlightColorPicker(
            selectedText = text,
            onConfirm = { colorArgb, note ->
                scope.launch {
                    highlightDao.insert(
                        Highlight(
                            id = UUID.randomUUID().toString(),
                            bookId = item.id,
                            bookTitle = item.title,
                            chapterIndex = spineIndex,
                            chapterTitle = "Capítulo ${spineIndex + 1}",
                            selectedText = text,
                            note = note,
                            colorArgb = colorArgb
                        )
                    )
                }
                pendingHighlight = null
            },
            onDismiss = { pendingHighlight = null }
        )
    }
}

@Composable
private fun EpubWebView(
    pkg: EpubPackage,
    theme: EpubTheme,
    index: Int,
    themeMode: Int,
    zoom: Int,
    prefs: ReadingPrefs,
    modifier: Modifier = Modifier,
    chapterHighlights: List<Highlight> = emptyList(),
    onWordSelected: (String) -> Unit,
    onTextSelected: (String) -> Unit,
    onWebViewReady: (WebView) -> Unit = {},
    onPageMetrics: (Int) -> Unit = {}
) {
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            WebView(ctx).apply {
                setBackgroundColor(0xFF0B1426.toInt())
                settings.javaScriptEnabled = true
                settings.allowFileAccess = false
                settings.allowContentAccess = false
                isVerticalScrollBarEnabled = false
                isHorizontalScrollBarEnabled = false
                overScrollMode = android.view.View.OVER_SCROLL_NEVER
                addJavascriptInterface(object {
                    @android.webkit.JavascriptInterface
                    fun onTextSelected(text: String) {
                        if (text.split(" ").size == 1) onWordSelected(text)
                        else onTextSelected(text)
                    }
                    @android.webkit.JavascriptInterface
                    fun onMetrics(totalPages: Int) {
                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                            onPageMetrics(totalPages.coerceAtLeast(1))
                        }
                    }
                }, "LibraAndroid")
                onWebViewReady(this)
            }
        },
        update = { wv ->
            theme.mode = themeMode
            theme.fontSizePx = prefs.fontSizeSp
            theme.lineHeight = prefs.lineHeight
            theme.marginPx = prefs.marginDp
            wv.settings.textZoom = zoom
            val url = chapterUrl(pkg.spine[index])
            val key = "$url|$themeMode|${prefs.fontSizeSp}|${prefs.marginDp}|${prefs.lineHeight}"
            if (wv.tag != key) {
                wv.tag = key
                wv.webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(
                        view: WebView?, request: WebResourceRequest?
                    ): WebResourceResponse? {
                        val uri = request?.url ?: return null
                        return serveEpub(pkg, theme, uri, prefs)
                    }
                    override fun shouldOverrideUrlLoading(
                        view: WebView?, request: WebResourceRequest?
                    ): Boolean {
                        val uri = request?.url ?: return true
                        return uri.host != EPUB_HOST
                    }
                    override fun onPageFinished(view: WebView?, url2: String?) {
                        // Paginación por altura de pantalla + captura de selección
                        val js = (
                            "(function(){"
                            + "document.documentElement.style.overflow='hidden';"
                            + "var h=window.innerHeight||document.documentElement.clientHeight;"
                            + "var total=Math.max(1, Math.ceil(document.body.scrollHeight/h));"
                            + "window.__libraPageH=h;window.__libraPages=total;"
                            + "if(window.LibraAndroid&&LibraAndroid.onMetrics)LibraAndroid.onMetrics(total);"
                            + "if(!window.__libraSel){window.__libraSel=true;"
                            + "document.addEventListener('selectionchange',function(){"
                            + "var t=window.getSelection().toString().trim();"
                            + "if(t.length>1)LibraAndroid.onTextSelected(t);"
                            + "});}"
                            + "window.scrollTo(0,0);"
                            + "})();"
                        )
                        wv.evaluateJavascript(js, null)
                        // Fallback métricas por altura nativa
                        wv.post {
                            val contentH = wv.contentHeight
                            val viewH = wv.height.coerceAtLeast(1)
                            // contentHeight está en CSS px aprox
                            val total = ((contentH.toFloat() / viewH) + 0.3f).toInt().coerceAtLeast(1)
                            onPageMetrics(total)
                            wv.scrollTo(0, 0)
                        }
                    }
                }
                wv.loadUrl(url)
            }
            onWebViewReady(wv)
        }
    )
}

// ══════════════════════════════════════════════════════════════════════════════
// PDF
// ══════════════════════════════════════════════════════════════════════════════

private class PdfHolder(file: File) {
    private val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(pfd)
    private val mutex = Mutex()
    val pageCount: Int = renderer.pageCount

    suspend fun render(index: Int, width: Int): Bitmap = mutex.withLock {
        withContext(Dispatchers.IO) {
            val page = renderer.openPage(index)
            try {
                val height = (width.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(android.graphics.Color.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                bmp
            } finally { page.close() }
        }
    }

    fun close() {
        runCatching { renderer.close() }
        runCatching { pfd.close() }
    }
}

@Composable
private fun PdfReader(
    item: LibraryItem,
    onSave: (Long, Int) -> Unit,
    readingMode: String,
    highlightDao: HighlightDao,
    onUpdateItem: (LibraryItem) -> Unit
) {
    val holder = remember(item.id) { runCatching { PdfHolder(File(item.localPath)) }.getOrNull() }
    DisposableEffect(holder) { onDispose { holder?.close() } }
    if (holder == null || holder.pageCount == 0) {
        Message("No se pudo abrir este PDF.")
        return
    }

    var index by remember(item.id) {
        mutableIntStateOf(item.lastPosition.toInt().coerceIn(0, holder.pageCount - 1))
    }
    var goingForward by remember { mutableStateOf(true) }
    LaunchedEffect(index) { onSave(index.toLong(), (index + 1) * 100 / holder.pageCount) }

    Column(Modifier.fillMaxSize()) {
        BoxWithConstraints(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .pointerInput(index) {
                    detectHorizontalDragGestures { _, dragAmount ->
                        if (dragAmount < -50 && index < holder.pageCount - 1) {
                            goingForward = true; index++
                        } else if (dragAmount > 50 && index > 0) {
                            goingForward = false; index--
                        }
                    }
                }
        ) {
            val widthPx = constraints.maxWidth.coerceAtLeast(1)
            PagedContent(state = index, goingForward = goingForward, modifier = Modifier.fillMaxSize()) { pg ->
                val bitmap by produceState<Bitmap?>(null, pg, widthPx) {
                    value = try { holder.render(pg, widthPx) } catch (_: Exception) { null }
                }
                bitmap?.let {
                    Image(
                        bitmap = it.asImageBitmap(),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                } ?: Box(Modifier.fillMaxSize().background(Panel))
            }
        }
        Row(
            Modifier.fillMaxWidth().background(Panel).padding(4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            TextButton(onClick = { if (index > 0) { goingForward = false; index-- } }) {
                Text("‹", color = Gold, fontSize = 24.sp)
            }
            Text("${index + 1} / ${holder.pageCount}", color = Muted, fontSize = 12.sp)
            TextButton(onClick = { if (index < holder.pageCount - 1) { goingForward = true; index++ } }) {
                Text("›", color = Gold, fontSize = 24.sp)
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// TXT / FB2
// ══════════════════════════════════════════════════════════════════════════════

@Composable
private fun TextFileReader(
    item: LibraryItem,
    onSave: (Long, Int) -> Unit,
    fb2: Boolean,
    highlightDao: HighlightDao,
    onUpdateItem: (LibraryItem) -> Unit,
    prefs: ReadingPrefs = ReadingPrefs()
) {
    val loaded by produceState<List<String>?>(null, item.id) {
        value = withContext(Dispatchers.IO) {
            try {
                val file = File(item.localPath)
                if (fb2) Fb2Parser.parse(file).paragraphs
                else file.readText().split(Regex("\\r?\\n"))
            } catch (_: Exception) { emptyList() }
        }
    }
    when {
        loaded == null -> Message("Abriendo…")
        loaded!!.isEmpty() -> Message("No se pudo leer el contenido de este archivo.")
        else -> ParagraphList(loaded!!, item, onSave, highlightDao, prefs)
    }
}

@Composable
private fun ParagraphList(
    paragraphs: List<String>,
    item: LibraryItem,
    onSave: (Long, Int) -> Unit,
    highlightDao: HighlightDao,
    prefs: ReadingPrefs = ReadingPrefs()
) {
    val highlights by highlightDao.observeByBook(item.id).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var fontSize by remember(prefs.fontSizeSp) { mutableIntStateOf(prefs.fontSizeSp) }
    LaunchedEffect(prefs.fontSizeSp) { fontSize = prefs.fontSizeSp }
    val pageBg = when (prefs.themeMode) {
        0 -> Color(0xFF0B1426)
        1 -> Color(0xFFF4ECD8)
        3 -> Color(0xFF000000)
        else -> Color(0xFFFFFFFF)
    }
    val pageFg = when (prefs.themeMode) {
        0 -> Color(0xFFF3E6C8)
        1 -> Color(0xFF3B2F1E)
        3 -> Color(0xFFCCCCCC)
        else -> Color(0xFF111111)
    }

    var dictWord by remember { mutableStateOf<String?>(null) }
    var pendingText by remember { mutableStateOf<Pair<String, Int>?>(null) }

// Páginas adaptadas a pantalla: agrupa párrafos en "hojas" sin scroll interno
    val pages = remember(paragraphs, prefs.fontSizeSp, prefs.marginDp, prefs.lineHeight) {
        // ~1800 caracteres por hoja a tamaño 18; se ajusta con el tamaño de fuente
        val charsPerPage = (2200.0 * (18.0 / prefs.fontSizeSp) * (1.55 / prefs.lineHeight)).toInt().coerceIn(800, 4000)
        val result = mutableListOf<List<Pair<Int, String>>>()
        var bucket = mutableListOf<Pair<Int, String>>()
        var count = 0
        paragraphs.forEachIndexed { i, p ->
            if (p.isBlank()) return@forEachIndexed
            bucket.add(i to p)
            count += p.length
            if (count >= charsPerPage) {
                result.add(bucket.toList())
                bucket = mutableListOf()
                count = 0
            }
        }
        if (bucket.isNotEmpty()) result.add(bucket.toList())
        if (result.isEmpty()) listOf(listOf(0 to "")) else result.toList()
    }
    var pageIndex by remember(item.id) {
        mutableIntStateOf(
            item.lastPosition.toInt().coerceIn(0, (pages.size - 1).coerceAtLeast(0))
        )
    }
    LaunchedEffect(pageIndex, pages.size) {
        onSave(pageIndex.toLong(), ((pageIndex + 1) * 100 / pages.size.coerceAtLeast(1)))
    }
    var goingForward by remember { mutableStateOf(true) }

    Column(
        Modifier
            .fillMaxSize()
            .background(pageBg)
    ) {
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = prefs.marginDp.dp, vertical = 12.dp)
                .pointerInput(pageIndex, pages.size) {
                    detectHorizontalDragGestures { _, dragAmount ->
                        if (dragAmount < -50 && pageIndex < pages.lastIndex) {
                            goingForward = true; pageIndex++
                        } else if (dragAmount > 50 && pageIndex > 0) {
                            goingForward = false; pageIndex--
                        }
                    }
                }
        ) {
            PagedContent(state = pageIndex, goingForward = goingForward, modifier = Modifier.fillMaxSize()) { pi ->
                val leaf = pages.getOrNull(pi).orEmpty()
                Column(Modifier.fillMaxSize()) {
                    leaf.forEach { (i, p) ->
                        val match = highlights.firstOrNull { h ->
                            h.chapterIndex == i || p.contains(h.selectedText)
                        }
                        val bg = match?.let { Color(it.colorArgb).copy(alpha = 0.35f) }
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .then(if (bg != null) Modifier.background(bg, RoundedCornerShape(6.dp)) else Modifier)
                                .padding(vertical = 4.dp)
                        ) {
                            SelectableText(
                                text = p,
                                fontSize = fontSize,
                                onWordLongPress = { word -> dictWord = word },
                                onTextSelected = { text -> pendingText = text to i }
                            )
                        }
                    }
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().background(Panel).padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            TextButton(onClick = { if (pageIndex > 0) { goingForward = false; pageIndex-- } }) {
                Text("‹", color = Gold, fontSize = 22.sp)
            }
            Text("${pageIndex + 1} / ${pages.size}", color = Muted, fontSize = 12.sp)
            TextButton(onClick = { if (pageIndex < pages.lastIndex) { goingForward = true; pageIndex++ } }) {
                Text("›", color = Gold, fontSize = 22.sp)
            }
        }
    }

    dictWord?.let { DictionaryDialog(word = it, onDismiss = { dictWord = null }) }

    pendingText?.let { (text, parIdx) ->
        HighlightColorPicker(
            selectedText = text,
            onConfirm = { colorArgb, note ->
                scope.launch {
                    highlightDao.insert(
                        Highlight(
                            id = UUID.randomUUID().toString(),
                            bookId = item.id,
                            bookTitle = item.title,
                            chapterIndex = parIdx,
                            chapterTitle = "Párrafo ${parIdx + 1}",
                            selectedText = text,
                            note = note,
                            colorArgb = colorArgb
                        )
                    )
                }
                pendingText = null
            },
            onDismiss = { pendingText = null }
        )
    }
}

/** Texto seleccionable con callback al mantener pulsado */
@Composable
private fun SelectableText(
    text: String,
    fontSize: Int,
    onWordLongPress: (String) -> Unit,
    onTextSelected: (String) -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }
    var lastSelected by remember { mutableStateOf("") }

    Box(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .pointerInput(Unit) {
                detectTapGestures(
                    onLongPress = {
                        // En texto plano, abrimos el picker con todo el párrafo
                        lastSelected = text
                        showMenu = true
                    }
                )
            }
    ) {
        Text(
            text, color = Cream,
            fontSize = fontSize.sp,
            lineHeight = (fontSize * 1.55f).sp
        )
    }

    if (showMenu) {
        AlertDialog(
            onDismissRequest = { showMenu = false },
            containerColor = Panel,
            title = { Text("Opciones de texto", color = Cream) },
            text = {
                Column {
                    TextButton(onClick = {
                        showMenu = false
                        onWordLongPress(text.split(" ").firstOrNull() ?: "")
                    }) { Text("🔍 Buscar en diccionario", color = Gold) }
                    TextButton(onClick = {
                        showMenu = false
                        onTextSelected(text)
                    }) { Text("🖍️ Subrayar párrafo", color = Gold) }
                }
            },
            confirmButton = {
                TextButton(onClick = { showMenu = false }) { Text("Cancelar", color = Muted) }
            }
        )
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// CBZ
// ══════════════════════════════════════════════════════════════════════════════

@Composable
private fun CbzReader(
    item: LibraryItem,
    onSave: (Long, Int) -> Unit,
    readingMode: String
) {
    val zip = remember(item.id) { runCatching { ZipFile(File(item.localPath)) }.getOrNull() }
    DisposableEffect(zip) { onDispose { runCatching { zip?.close() } } }
    if (zip == null) { Message("No se pudo abrir este CBZ."); return }

    val pages = remember(zip) {
        zip.entries().toList()
            .filter { !it.isDirectory && it.name.substringAfterLast('.').lowercase() in IMAGE_EXTENSIONS }
            .sortedBy { naturalKey(it.name) }
            .map { it.name }
    }
    if (pages.isEmpty()) { Message("Este CBZ no contiene imágenes."); return }

    var index by remember(item.id) {
        mutableIntStateOf(item.lastPosition.toInt().coerceIn(0, pages.lastIndex))
    }
    var goingForward by remember { mutableStateOf(true) }
    LaunchedEffect(index) { onSave(index.toLong(), (index + 1) * 100 / pages.size) }

    Column(Modifier.fillMaxSize()) {
        BoxWithConstraints(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .pointerInput(index) {
                    detectHorizontalDragGestures { _, dragAmount ->
                        if (dragAmount < -50 && index < pages.lastIndex) { goingForward = true; index++ }
                        else if (dragAmount > 50 && index > 0) { goingForward = false; index-- }
                    }
                }
        ) {
            val widthPx = constraints.maxWidth.coerceAtLeast(1)
            PagedContent(state = index, goingForward = goingForward, modifier = Modifier.fillMaxSize()) { pg ->
                val bitmap by produceState<Bitmap?>(null, pages[pg], widthPx) {
                    value = withContext(Dispatchers.IO) {
                        try {
                            val entry = zip.getEntry(pages[pg])
                            val bytes = zip.getInputStream(entry).use { it.readBytes() }
                            decodeSampled(bytes, widthPx)
                        } catch (_: Exception) { null }
                    }
                }
                bitmap?.let {
                    Image(
                        bitmap = it.asImageBitmap(),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                } ?: Box(Modifier.fillMaxSize().background(Panel))
            }
        }
        Row(
            Modifier.fillMaxWidth().background(Panel).padding(4.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { if (index > 0) { goingForward = false; index-- } }) {
                Text("‹", color = Gold, fontSize = 24.sp)
            }
            Text("${index + 1} / ${pages.size}", color = Muted, fontSize = 12.sp)
            TextButton(onClick = { if (index < pages.lastIndex) { goingForward = true; index++ } }) {
                Text("›", color = Gold, fontSize = 24.sp)
            }
        }
    }
}

