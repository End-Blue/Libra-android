package com.libra.reader

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import java.text.Normalizer
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipFile

/** BOOK = parece un libro con seguridad · MAYBE = dudoso (se muestra aparte y sin marcar). */
enum class BookConfidence { BOOK, MAYBE }

data class FoundBook(
    val uri: Uri,
    val name: String,
    val extension: String,
    val sizeKb: Long,
    val folder: String = "",
    val modified: Long = 0L,
    val confidence: BookConfidence = BookConfidence.BOOK,
    val pages: Int = 0,
    val reason: String = ""          // por qué es dudoso (solo MAYBE)
)

private val SCAN_EXTENSIONS = setOf("epub", "pdf", "txt", "fb2", "cbz")
// Carpetas que nunca contienen libros: del sistema, cachés, fotos, capturas, tonos y grabaciones
private val SKIP_DIRS = setOf(
    "android", "cache", "thumbnails", "lost.dir", "obb",
    "dcim", "screenshots", "capturas de pantalla", "ringtones", "alarms", "notifications", "recordings"
)
private const val MAX_FILES = 5000
private const val MAX_DEPTH = 12
private const val MIN_BYTES = 20L * 1024          // se ignoran archivos de menos de 20 KB (notas, logs…)
private const val TXT_MIN_BYTES = 100L * 1024     // un TXT solo cuenta como posible libro si pesa ≥ 100 KB
private const val VALIDATION_PARALLELISM = 4

// ── Permiso de almacenamiento ─────────────────────────────────────────────────

/** Android 11+: «Acceso a todos los archivos». Android 10 o menos: permiso de lectura. */
fun hasStorageAccess(context: Context): Boolean =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Environment.isExternalStorageManager()
    } else {
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED
    }

private fun openAllFilesSettings(context: Context) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
    try {
        context.startActivity(
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                .setData(Uri.parse("package:${context.packageName}"))
        )
    } catch (_: Exception) {
        context.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
    }
}

// ── Clasificación: ¿es un libro? ──────────────────────────────────────────────

/** Minúsculas, sin tildes y con separadores convertidos en espacios: «Factura_Marzo-2024» → «factura marzo 2024». */
internal fun plainName(s: String): String =
    Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .replace(Regex("[_.\\-]+"), " ")

// Documentos que NO son libros (por el nombre del archivo)
private val JUNK_NAME = Regex(
    "\\b(factura|invoice|recibo|receipt|boleto|boleta|ticket|comprobante|boarding pass|extracto|estado de cuenta|" +
        "statement|contrato|contract|certificad\\w*|certificate|formulario|curriculum|resume|cv|presupuesto|" +
        "cotizacion\\w*|quote|declaracion|impuestos?|tax|nomina|payslip|solicitud|diploma|receta|prescription|" +
        "datasheet|ficha tecnica|manual de usuario|user manual|guia rapida|quick start|screenshot|captura de pantalla)\\b" +
        "|^(scan|img|doc|camscanner|whatsapp|image|document|documento|scanned)\\s?\\d"
)
// Carpetas típicas de libros / de documentos sueltos
private val BOOK_FOLDER = Regex("\\b(libros?|books?|ebooks?|biblioteca|library|lectura|reading|novelas?|calibre|kindle|literatura|comics?|manga)\\b")
private val JUNK_FOLDER = Regex("\\b(whatsapp|telegram|facturas?|invoices?|recibos?|receipts?|scans?|escaneos?|tickets?|formularios?|tramites?)\\b")
// Autores «genéricos» que dejan los programas de oficina o los escáneres en los metadatos del PDF
private val GENERIC_AUTHOR = Regex("\\b(admin\\w*|user|usuario|microsoft|windows|word|scanner|canon|hp|epson|xerox|ricoh|konica|brother|sharp|samsung|android|camscanner|adobe|libreoffice|writer|pc|desktop|unknown)\\b")

/**
 * Puntúa un PDF. ≥ 2 → libro · de −1 a 1 → dudoso · ≤ −2 → se descarta.
 * Devuelve la puntuación y, si es dudoso, el motivo en lenguaje llano.
 */
internal fun scorePdf(fileName: String, folderPath: String, pages: Int, hasBookMetadata: Boolean): Pair<Int, String> {
    var score = 0
    val why = ArrayList<String>()
    when {
        pages >= 80 -> score += 3
        pages >= 40 -> score += 1
        pages >= 25 -> score += 0
        pages >= 10 -> { score -= 1; why.add("pocas páginas ($pages)") }
        else -> { score -= 4; why.add("solo $pages páginas") }
    }
    if (JUNK_NAME.containsMatchIn(plainName(fileName.substringBeforeLast('.')))) { score -= 5; why.add("el nombre parece de un documento") }
    val folder = plainName(folderPath)
    if (BOOK_FOLDER.containsMatchIn(folder)) score += 2
    if (JUNK_FOLDER.containsMatchIn(folder)) { score -= 1; why.add("está en una carpeta de chats o documentos") }
    if (hasBookMetadata) score += 1
    return score to (if (why.isEmpty()) "sin pistas claras" else why.joinToString(", "))
}

/** ¿Los metadatos del PDF traen título y un autor «de verdad»? Solo se lee el final del archivo (donde suele ir). */
private fun pdfHasBookMetadata(f: File): Boolean = try {
    RandomAccessFile(f, "r").use { raf ->
        val n = minOf(raf.length(), 65536L).toInt()
        raf.seek(raf.length() - n)
        val buf = ByteArray(n)
        raf.readFully(buf)
        val txt = String(buf, Charsets.ISO_8859_1)
        val title = Regex("/Title\\s*\\(([^)]{2,})\\)").find(txt)?.groupValues?.get(1)
        val author = Regex("/Author\\s*\\(([^)]{2,})\\)").find(txt)?.groupValues?.get(1)
        title != null && author != null && !GENERIC_AUTHOR.containsMatchIn(plainName(author))
    }
} catch (_: Throwable) {
    false
}

/** Número de páginas, o null si el PDF está dañado o protegido con contraseña (la app tampoco podría abrirlo). */
private fun pdfPageCount(f: File): Int? = try {
    val pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
    try {
        val r = PdfRenderer(pfd)
        try { r.pageCount } finally { r.close() }
    } finally {
        pfd.close()
    }
} catch (_: Throwable) {
    null
}

/** EPUB de verdad: un ZIP con META-INF/container.xml (no cualquier ZIP renombrado). */
private fun isRealEpub(f: File): Boolean = try {
    ZipFile(f).use { it.getEntry("META-INF/container.xml") != null }
} catch (_: Throwable) {
    false
}

/** FB2 de verdad: XML cuyo contenido empieza con <FictionBook>. */
private fun isRealFb2(f: File): Boolean = try {
    f.inputStream().use { ins ->
        val buf = ByteArray(2048)
        val n = ins.read(buf).coerceAtLeast(0)
        String(buf, 0, n, Charsets.ISO_8859_1).contains("<FictionBook", ignoreCase = true)
    }
} catch (_: Throwable) {
    false
}

/** CBZ de verdad: un ZIP formado casi solo por imágenes (≥ 5 y ≥ 80 %). */
private fun isRealCbz(f: File): Boolean = try {
    ZipFile(f).use { zip ->
        var total = 0
        var images = 0
        val en = zip.entries()
        while (en.hasMoreElements()) {
            val e = en.nextElement()
            if (e.isDirectory) continue
            total++
            if (e.name.substringAfterLast('.', "").lowercase() in IMAGE_EXTENSIONS) images++
        }
        images >= 5 && images * 5 >= total * 4
    }
} catch (_: Throwable) {
    false
}

/** Devuelve el libro encontrado, o null si el archivo no es un libro (se descarta del resultado). */
private fun classify(f: File): FoundBook? {
    val name = f.name
    val ext = name.substringAfterLast('.', "").lowercase()
    val sizeKb = f.length() / 1024
    val folder = f.parentFile?.name ?: ""
    val folderPath = (f.parentFile?.parentFile?.name ?: "") + " " + folder
    fun make(conf: BookConfidence, pages: Int = 0, reason: String = "") =
        FoundBook(Uri.fromFile(f), name, ext, sizeKb, folder, f.lastModified(), conf, pages, reason)
    return when (ext) {
        "epub" -> if (isRealEpub(f)) make(BookConfidence.BOOK) else null
        "fb2" -> if (isRealFb2(f)) make(BookConfidence.BOOK) else null
        "cbz" -> if (isRealCbz(f)) make(BookConfidence.BOOK) else null
        "txt" -> if (f.length() >= TXT_MIN_BYTES) make(BookConfidence.MAYBE, reason = "texto plano") else null
        "pdf" -> {
            val pages = pdfPageCount(f) ?: return null
            val (score, why) = scorePdf(name, folderPath, pages, pdfHasBookMetadata(f))
            when {
                score >= 2 -> make(BookConfidence.BOOK, pages)
                score >= -1 -> make(BookConfidence.MAYBE, pages, why)
                else -> null
            }
        }
        else -> null
    }
}

// ── Escaneo automático de todo el almacenamiento ──────────────────────────────

/**
 * Dos fases: (1) recorrido rápido por nombre, extensión y tamaño; (2) validación del contenido de cada candidato
 * (EPUB/FB2/CBZ bien formados; PDF puntuado por páginas, nombre, carpeta y metadatos). Solo se devuelven los libros
 * y los dudosos; lo que claramente no es un libro se descarta. [onProgress] informa (hechos, total) de la fase 2.
 */
suspend fun scanDeviceForBooks(
    context: Context,
    onProgress: (done: Int, total: Int) -> Unit = { _, _ -> }
): List<FoundBook> = withContext(Dispatchers.IO) {
    val roots = LinkedHashSet<File>()
    roots.add(Environment.getExternalStorageDirectory())
    // Tarjeta SD u otros volúmenes: se deduce su raíz a partir de la carpeta privada de la app
    context.getExternalFilesDirs(null).forEach { dir ->
        dir?.absolutePath?.substringBefore("/Android/")?.let { roots.add(File(it)) }
    }

    // Fase 1: candidatos por extensión y tamaño
    val candidates = ArrayList<File>()
    val seen = HashSet<String>()
    val stack = ArrayDeque<Pair<File, Int>>()
    roots.forEach { stack.addLast(it to 0) }
    while (stack.isNotEmpty() && candidates.size < MAX_FILES) {
        val (dir, depth) = stack.removeLast()
        val children = try {
            dir.listFiles()
        } catch (_: Exception) {
            null
        } ?: continue
        for (f in children) {
            val name = f.name
            if (f.isDirectory) {
                if (depth < MAX_DEPTH && !name.startsWith(".") && name.lowercase() !in SKIP_DIRS) {
                    stack.addLast(f to depth + 1)
                }
            } else {
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext in SCAN_EXTENSIONS && f.length() >= MIN_BYTES && seen.add(f.absolutePath)) candidates.add(f)
            }
        }
    }

    // Fase 2: validar el contenido (en paralelo, de 4 en 4)
    val total = candidates.size
    val done = AtomicInteger(0)
    val gate = Semaphore(VALIDATION_PARALLELISM)
    onProgress(0, total)
    val classified = coroutineScope {
        candidates.map { f ->
            async {
                gate.withPermit {
                    val r = runCatching { classify(f) }.getOrNull()
                    onProgress(done.incrementAndGet(), total)
                    r
                }
            }
        }.awaitAll()
    }.filterNotNull()

    // Mismo nombre y tamaño en dos carpetas = el mismo libro: se queda uno (primero los seguros, luego el más reciente)
    val dup = HashSet<String>()
    classified
        .sortedWith(compareBy<FoundBook> { it.confidence }.thenByDescending { it.modified })
        .filter { dup.add(it.name.lowercase() + "|" + it.sizeKb) }
}

private fun formatSize(kb: Long): String =
    if (kb >= 1024) String.format(java.util.Locale.getDefault(), "%.1f MB", kb / 1024f) else "$kb KB"

// ── Diálogo del escáner ───────────────────────────────────────────────────────

@Composable
fun ScannerDialog(
    onImport: (List<Uri>) -> Unit,
    onDismiss: () -> Unit,
    context: Context
) {
    val appContext = LocalContext.current
    var hasAccess by remember { mutableStateOf(hasStorageAccess(context)) }
    var scanning by remember { mutableStateOf(false) }
    var scanned by remember { mutableStateOf(false) }
    var found by remember { mutableStateOf<List<FoundBook>>(emptyList()) }
    var selected by remember { mutableStateOf<Set<Uri>>(emptySet()) }
    var typeFilter by remember { mutableStateOf("TODOS") }
    var group by remember { mutableStateOf(BookConfidence.BOOK) }
    var progress by remember { mutableStateOf(0 to 0) }

    // Android 10 o menos: permiso de lectura normal
    val readPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasAccess = granted
    }

    // Al volver de Ajustes se vuelve a comprobar el permiso (y el escaneo arranca solo)
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) hasAccess = hasStorageAccess(context)
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(Unit) {
        if (!hasAccess && Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            readPermission.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    // En cuanto hay permiso se escanea todo el almacenamiento, sin elegir carpetas
    LaunchedEffect(hasAccess) {
        if (hasAccess) {
            scanning = true
            found = scanDeviceForBooks(context) { d, t -> progress = d to t }
            // Solo vienen marcados los libros seguros; los dudosos quedan aparte y sin marcar
            selected = found.filter { it.confidence == BookConfidence.BOOK }.map { it.uri }.toSet()
            group = if (found.any { it.confidence == BookConfidence.BOOK }) BookConfidence.BOOK else BookConfidence.MAYBE
            scanning = false
            scanned = true
        }
    }

    val inGroup = found.filter { it.confidence == group }
    val visible = if (typeFilter == "TODOS") inGroup else inGroup.filter { it.extension.uppercase() == typeFilter }
    val types = listOf("TODOS") + SCAN_EXTENSIONS.map { it.uppercase() }.filter { t -> inGroup.any { it.extension.uppercase() == t } }
    val nBooks = found.count { it.confidence == BookConfidence.BOOK }
    val nMaybe = found.size - nBooks

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Panel,
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.88f)
        ) {
            Column(Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LibIcon(LibIconKind.SCAN, tint = Cream, size = 24.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Libros en tu dispositivo",
                        color = Cream,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    "Busca en todas las carpetas y deja marcados solo los libros reales. Los PDF que parecen facturas, manuales cortos o documentos sueltos se descartan.",
                    color = Muted,
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(12.dp))

                when {
                    !hasAccess -> {
                        Box(
                            Modifier.fillMaxWidth().weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                LibIcon(LibIconKind.LOCK, tint = Gold, size = 44.dp)
                                Spacer(Modifier.height(10.dp))
                                Text(
                                    "Para encontrar tus libros, Libra necesita permiso de almacenamiento.",
                                    color = Cream, fontSize = 14.sp, textAlign = TextAlign.Center,
                                    lineHeight = 20.sp
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
                                        "Se abrirán los Ajustes de Android: activa «Permitir acceso para administrar todos los archivos» y vuelve a Libra."
                                    else "Acepta el permiso de lectura que te va a pedir Android.",
                                    color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center,
                                    lineHeight = 18.sp
                                )
                                Spacer(Modifier.height(14.dp))
                                Button(
                                    onClick = {
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) openAllFilesSettings(appContext)
                                        else readPermission.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)
                                ) { Text("Dar permiso") }
                            }
                        }
                    }
                    scanning || !scanned -> {
                        Box(
                            Modifier.fillMaxWidth().weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CircularProgressIndicator(color = Gold)
                                Spacer(Modifier.height(12.dp))
                                Text(
                                    if (progress.second > 0) "Revisando archivos… ${progress.first}/${progress.second}"
                                    else "Buscando libros…",
                                    color = Muted
                                )
                            }
                        }
                    }
                    found.isEmpty() -> {
                        Box(
                            Modifier.fillMaxWidth().weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "No se encontraron libros (EPUB, PDF, FB2 o CBZ) en el dispositivo. Los PDF que no parecen libros se ignoran.",
                                color = Muted,
                                fontSize = 14.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                    else -> {
                        // Libros seguros / dudosos
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(BookConfidence.BOOK to "Libros $nBooks", BookConfidence.MAYBE to "Dudosos $nMaybe").forEach { (g, label) ->
                                FilterChip(
                                    selected = group == g,
                                    onClick = { group = g; typeFilter = "TODOS" },
                                    label = { Text(label, fontSize = 12.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Gold,
                                        selectedLabelColor = Ink,
                                        labelColor = Cream
                                    )
                                )
                            }
                        }
                        // Filtro por tipo de libro
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            types.forEach { t ->
                                val count = if (t == "TODOS") inGroup.size else inGroup.count { it.extension.uppercase() == t }
                                FilterChip(
                                    selected = typeFilter == t,
                                    onClick = { typeFilter = t },
                                    label = { Text("$t $count", fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Gold,
                                        selectedLabelColor = Ink,
                                        labelColor = Cream
                                    )
                                )
                            }
                        }
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${visible.size} archivos", color = Muted, fontSize = 12.sp)
                            val allSelected = visible.isNotEmpty() && visible.all { it.uri in selected }
                            TextButton(onClick = {
                                selected = if (allSelected) selected - visible.map { it.uri }.toSet()
                                else selected + visible.map { it.uri }
                            }) {
                                Text(
                                    if (allSelected) "Quitar selección" else "Seleccionar todo",
                                    color = Gold, fontSize = 12.sp
                                )
                            }
                        }

                        LazyColumn(
                            Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            items(visible, key = { it.uri.toString() }) { book ->
                                val isSelected = book.uri in selected
                                // Un solo hijo por item: fila + separador dentro de una Column
                                Column {
                                    Row(
                                        Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                selected = if (isSelected) selected - book.uri
                                                else selected + book.uri
                                            }
                                            .padding(vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Checkbox(
                                            checked = isSelected,
                                            onCheckedChange = {
                                                selected = if (it) selected + book.uri else selected - book.uri
                                            },
                                            colors = CheckboxDefaults.colors(checkedColor = Gold)
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(
                                                book.name,
                                                color = Cream,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                buildString {
                                                    append(book.extension.uppercase())
                                                    if (book.pages > 0) append(" · ${book.pages} págs")
                                                    append(" · ${formatSize(book.sizeKb)} · ${book.folder}")
                                                },
                                                color = Muted,
                                                fontSize = 11.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            if (book.confidence == BookConfidence.MAYBE && book.reason.isNotEmpty()) {
                                                Text(
                                                    "Dudoso: ${book.reason}",
                                                    color = Gold,
                                                    fontSize = 11.sp,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }
                                    }
                                    HorizontalDivider(color = Ink, thickness = 0.5.dp)
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Muted)
                    ) { Text("Cancelar") }

                    Button(
                        onClick = {
                            if (selected.isNotEmpty()) onImport(selected.toList())
                            onDismiss()
                        },
                        enabled = selected.isNotEmpty(),
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)
                    ) {
                        Text(
                            if (selected.isEmpty()) "Importar"
                            else "Importar (${selected.size})"
                        )
                    }
                }
            }
        }
    }
}
