# Selección y resaltado de texto a nivel de carácter

## Qué cambia
- **Signos sueltos:** mantener pulsado sobre un «.», «,», «;», símbolo o espacio selecciona ESE carácter
  (antes solo se podían seleccionar palabras). Sobre una letra o dígito se sigue seleccionando la palabra.
- **Arrastre tras la pulsación larga:** lento → carácter a carácter (incluye espacios y puntuación);
  rápido → por palabras. Nunca encoge por debajo de la unidad inicial.
- **Manejadores:** el ajuste ya era carácter/palabra según la velocidad; ahora el extremo contrario puede estar en otra hoja.
  En selecciones cortas de una línea los manejadores se separan hacia fuera para que sus zonas táctiles no se pisen.
- **Auto-giro (equivale al auto-scroll):** arrastrar el manejador final por debajo de la última línea (o el inicial por encima
  de la primera) ~0,45 s gira la hoja sin perder la selección; se repite cada ~1,2 s dentro del capítulo.
  Se desactiva con `SELECTION_AUTO_TURN = false` en `TextSelection.kt`.
- **Barra de acciones inferior** (`SelectionActionBar.kt`): solo los 6 colores (un toque resalta) y un botón de tres puntos
  horizontales con el resto: Copiar, Añadir nota, Buscar, Compartir, Definir, Expandir a frase, Quitar resaltado (solo si la
  selección toca un resaltado) y Limpiar selección. Pasa arriba si la selección queda abajo.
- **Barra de navegación:** la 4.ª pestaña es ahora «Biblioteca» (antes «Racha»); Racha pasa al menú «Más» en el lugar de Biblioteca.
- **Resaltados cortos:** un signo suelto se pinta con un ancho mínimo (rectángulo redondeado) para que se vea claro;
  los extremos de espacio se recortan al resaltar; resaltar de nuevo el mismo rango solo cambia el color.
- **Toque sobre un resaltado** usa el carácter BAJO el dedo (`glyphAt`), también para signos sueltos.

## Archivos
Nuevo: `SelectionActionBar.kt` · Modificados: `PageLayout.kt`, `TextSelection.kt`, `NativeReader.kt`
Sin cambios en base de datos ni en el formato de los resaltados guardados.

# Escáner de libros: solo libros reales

- **Dos fases:** (1) recorrido rápido por extensión y tamaño; (2) validación del contenido de cada candidato, en paralelo (de 4 en 4) y con progreso «Revisando archivos… n/total».
- **EPUB** (ZIP con META-INF/container.xml), **FB2** (contiene `<FictionBook`) y **CBZ** (≥ 5 imágenes y ≥ 80 % del contenido): se descarta lo que sea otra cosa con esa extensión.
- **PDF:** se puntúa por páginas (≥ 80 suma, < 10 descarta), nombre de archivo (factura, recibo, CV, boleto, manual de usuario, scan/IMG…), carpeta (Libros/Books/Calibre suman; WhatsApp/Facturas/Scans restan) y metadatos (título + autor no genérico).
  ≥ 2 → **Libro** (marcado) · de −1 a 1 → **Dudoso** (aparte y sin marcar, con el motivo) · ≤ −2 → se descarta. PDF dañados o con contraseña también se descartan.
- **TXT:** solo si pesa ≥ 100 KB y siempre como dudoso.
- **Carpetas ignoradas** además de las de antes: DCIM, Screenshots/Capturas, Ringtones, Alarms, Notifications, Recordings.
- **Duplicados:** mismo nombre y tamaño en dos carpetas = un solo libro.
- **Diálogo:** chips «Libros n» / «Dudosos n», filtro por tipo dentro de cada grupo, páginas y tamaño legible en cada fila.
- Permisos: sin cambios (sigue «Acceso a todos los archivos» en Android 11+ y lectura en Android 10 o menos).
