@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.libra.reader

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.LruCache
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import java.io.File
import java.text.BreakIterator
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max
import kotlin.math.min

// ══════════════════════════════════════════════════════════════════════════════
// LECTOR NATIVO (EPUB · TXT · FB2)
//   motor (carga y paginación) → bitmaps de página → paso de hoja tipo cilindro
// ══════════════════════════════════════════════════════════════════════════════

internal class ChapterPages(val doc: ChapterDoc, val pages: List<PageSpec>)

/** Carga capítulos y los pagina en segundo plano; guarda los resultados para no repetir trabajo. */
internal class ReaderEngine(val source: BookSource) {
    val images = ImageStore { source.readImage(it) }
    private val docs = ConcurrentHashMap<Int, ChapterDoc>()
    private val paged = ConcurrentHashMap<String, ChapterPages>()
    val lens = IntArray(source.chapterCount) { -1 }
    private val weights = DoubleArray(source.chapterCount) { -1.0 }

    fun doc(i: Int): ChapterDoc {
        docs[i]?.let { return it }
        val d = runCatching { source.loadChapter(i) }.getOrElse { e ->
            readerLog("capítulo $i no se pudo cargar: ${e.message}")
            ChapterDoc(i, "", emptyList(), "", emptyMap())
        }
        docs[i] = d
        lens[i] = d.plain.length
        weights[i] = ProgressModel.weightOf(d)
        return d
    }

    /** Avance 0..1 de TODO el libro en (capítulo, carácter). Única fuente del % que se muestra y se guarda. */
    fun fraction(ch: Int, off: Int): Float {
        val n = weights.size
        if (n == 0) return 0f
        val c = ch.coerceIn(0, n - 1)
        var known = 0.0
        var k = 0
        for (w in weights) if (w >= 0) { known += w; k++ }
        val avg = if (k > 0) known / k else ProgressModel.DEFAULT_WEIGHT
        fun w(i: Int) = if (weights[i] >= 0) weights[i] else avg
        var before = 0.0
        for (i in 0 until c) before += w(i)
        val cur = w(c)
        var total = before + cur
        for (i in c + 1 until n) total += w(i)
        if (total <= 0.0) return 0f
        val len = lens[c]
        val inside = if (len > 0) (off.toDouble() / len).coerceIn(0.0, 1.0) else 0.0
        return ((before + inside * cur) / total).toFloat().coerceIn(0f, 1f)
    }

    /** Índice en orden real de lectura, con cada entrada resuelta a su posición exacta. */
    fun buildToc(): List<TocTarget> {
        val n = source.chapterCount
        val entries = source.toc
        if (entries.isNotEmpty()) {
            val t = TocResolver.resolve(entries, n) { ci -> runCatching { doc(ci) }.getOrNull() }
            if (t.isNotEmpty()) return t
            readerLog("índice vacío tras resolver; se usa el orden del spine")
        }
        return TocResolver.fromSpine(n, { i -> runCatching { doc(i) }.getOrNull() }, { i -> source.chapterTitle(i) })
    }

    fun pages(cfg: LayoutConfig, i: Int): ChapterPages {
        val k = cfg.key + "#" + i
        paged[k]?.let { return it }
        val d = doc(i)
        val cp = ChapterPages(d, Paginator(cfg, images).paginate(d))
        paged[k] = cp
        return cp
    }

    fun pagesIfReady(cfg: LayoutConfig, i: Int): ChapterPages? = paged[cfg.key + "#" + i]

    fun prune(cfgKey: String) {
        paged.keys.filter { !it.startsWith("$cfgKey#") }.forEach { paged.remove(it) }
    }
}

private class BitmapCache(maxBytes: Int) : LruCache<String, Bitmap>(maxBytes) {
    override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
}

internal fun createBookSource(item: LibraryItem): BookSource? {
    val file = File(item.localPath)
    return when (item.format.lowercase()) {
        "epub" -> EpubSource(EpubPackage(file))
        "txt" -> TextSource.open(file, fb2 = false)
        "fb2" -> TextSource.open(file, fb2 = true)
        else -> null
    }
}

/** Punto de entrada: abre el libro en segundo plano y muestra el lector cuando está listo. */
@Composable
fun NativeBookReader(
    item: LibraryItem,
    onSave: (Long, Int) -> Unit,
    highlightDao: HighlightDao,
    prefs: ReadingPrefs,
    showContents: Boolean = false,
    onContentsDismiss: () -> Unit = {},
    onChapterLabel: (String) -> Unit = {},
    onToggleChrome: () -> Unit = {},
    jumpChapter: Int? = null,
    onJumpConsumed: () -> Unit = {},
    jumpOffset: Int = -1,
    jumpText: String? = null,
    jumpTextK: Int = 0,
    initialOffset: Int = -1,
    initialSnippet: String = "",
    onOffsetSave: (Int, Int, String) -> Unit = { _, _, _ -> },
    bookmarkOffsets: List<Pair<Int, Int>> = emptyList(),
    bookmarkRequest: Int = 0,
    onBookmarkToggle: (Int, Int, Int, String, Int) -> Unit = { _, _, _, _, _ -> },
    ribbonEnabled: Boolean = true,
    onChapterNames: (List<String>) -> Unit = {},
    onPageBookmarked: (Boolean) -> Unit = {}
) {
    val ctx = LocalContext.current
    var engine by remember(item.id) { mutableStateOf<ReaderEngine?>(null) }
    var failed by remember(item.id) { mutableStateOf(false) }
    val pal = readerPalette(prefs.themeMode)

    LaunchedEffect(item.id) {
        DictionaryContext.app = ctx.applicationContext
        val src = withContext(Dispatchers.IO) { runCatching { createBookSource(item) }.getOrNull() }
        if (src == null || src.chapterCount == 0) failed = true else engine = ReaderEngine(src)
        launch { DictionaryEngine.warm(ctx.applicationContext) }
    }
    DisposableEffect(item.id) { onDispose { runCatching { engine?.source?.close() } } }

    val eng = engine
    Box(Modifier.fillMaxSize().background(Color(pal.bg))) {
        when {
            failed -> Text(
                "No se pudo abrir este libro. Puede estar dañado o protegido con DRM.",
                color = Color(pal.fg), fontSize = 14.sp, modifier = Modifier.align(Alignment.Center).padding(32.dp)
            )
            eng == null -> CircularProgressIndicator(
                color = Color(pal.link), modifier = Modifier.align(Alignment.Center).size(30.dp)
            )
            else -> BoxWithConstraints(Modifier.fillMaxSize()) {
                ReaderBody(
                    eng, item, onSave, highlightDao, prefs, showContents, onContentsDismiss, onChapterLabel,
                    onToggleChrome, jumpChapter, onJumpConsumed, jumpOffset, jumpText, jumpTextK,
                    initialOffset, initialSnippet, onOffsetSave, bookmarkOffsets, bookmarkRequest,
                    onBookmarkToggle, ribbonEnabled, onChapterNames, onPageBookmarked,
                    constraints.maxWidth, constraints.maxHeight
                )
            }
        }
    }
}

@Composable
private fun ReaderBody(
    eng: ReaderEngine,
    item: LibraryItem,
    onSave: (Long, Int) -> Unit,
    highlightDao: HighlightDao,
    prefs: ReadingPrefs,
    showContents: Boolean,
    onContentsDismiss: () -> Unit,
    onChapterLabel: (String) -> Unit,
    onToggleChrome: () -> Unit,
    jumpChapter: Int?,
    onJumpConsumed: () -> Unit,
    jumpOffset: Int,
    jumpText: String?,
    jumpTextK: Int,
    initialOffset: Int,
    initialSnippet: String,
    onOffsetSave: (Int, Int, String) -> Unit,
    bookmarkOffsets: List<Pair<Int, Int>>,
    bookmarkRequest: Int,
    onBookmarkToggle: (Int, Int, Int, String, Int) -> Unit,
    ribbonEnabled: Boolean,
    onChapterNames: (List<String>) -> Unit,
    onPageBookmarked: (Boolean) -> Unit,
    wPx: Int,
    hPx: Int
) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val haptic = LocalHapticFeedback.current
    val d = density.density
    val count = eng.source.chapterCount
    val lastCh = count - 1
    val hlPrefs = remember { ctx.getSharedPreferences("libra_reading_prefs", 0) }

    // ── Composición: cualquier ajuste tipográfico crea una configuración nueva y se vuelve a paginar ──
    val pal = readerPalette(prefs.themeMode)
    val typeface = remember(prefs.fontFamily) { readerTypeface(ctx, prefs.fontFamily) }
    val textPx = with(density) { prefs.fontSizeSp.sp.toPx() }
    val cfg = remember(wPx, hPx, prefs.themeMode, prefs.fontSizeSp, prefs.lineHeight, prefs.marginDp, prefs.fontFamily, prefs.justify, prefs.indent, d) {
        LayoutConfig(
            widthPx = wPx, heightPx = hPx, marginPx = min(prefs.marginDp * d, wPx * 0.22f).toInt(),
            topPx = (40f * d).toInt(), bottomPx = (34f * d).toInt(),
            textSizePx = textPx, lineMult = prefs.lineHeight, typeface = typeface, familyKey = prefs.fontFamily,
            justify = prefs.justify, indent = prefs.indent, fg = pal.fg, bg = pal.bg, link = pal.link, density = d
        )
    }
    val bmpCache = remember(wPx, hPx) { BitmapCache(max(4 * wPx * hPx * 4, 8 * 1024 * 1024)) }

    // ── Posición actual ──
    val savedValid = item.lastPosition in 0L..lastCh.toLong()
    val st = remember(eng) {
        ReaderStateHolder(
            startChapter = if (savedValid) item.lastPosition.toInt() else 0,
            startOffset = if (savedValid) initialOffset.coerceAtLeast(0) else 0
        )
    }
    var chapter by st::chapter
    var anchor by st::anchor
    var curPages by st::pages
    var pageNo by st::pageNo
    var curBmp by st::bitmap
    var pagesKey by st::pagesKey
    var snippetPending by remember(eng) { mutableStateOf(initialSnippet) }
    var toc by remember(eng) { mutableStateOf<List<TocTarget>>(emptyList()) }
    var decoVersion by remember { mutableIntStateOf(0) }
    var turning by remember { mutableStateOf(false) }
    val pager = remember { PagerController() }

    // ── Subrayados ──
    val highlightsFlow = remember(item.id) { highlightDao.observeByBook(item.id) }
    val allHighlights by highlightsFlow.collectAsState(initial = emptyList())
    val hlNow by rememberUpdatedState(allHighlights)
    LaunchedEffect(allHighlights) { decoVersion++ }

    // ── Nombres de capítulo (índice del libro; si falta, el encabezado del capítulo) ──
    val labels = remember(eng) {
        mutableStateListOf<String>().apply { for (i in 0 until count) add(eng.source.chapterTitle(i)) }
    }
    fun labelOf(i: Int): String = labels.getOrNull(i)?.takeIf { it.isNotBlank() } ?: "Capítulo ${i + 1}"
    LaunchedEffect(eng) {
        val built = withContext(Dispatchers.Default) {
            for (i in 0 until count) {
                val doc = runCatching { eng.doc(i) }.getOrNull() ?: continue
                if (labels[i].isBlank()) {
                    val head = doc.blocks.firstOrNull { it is TextBlock && (it.kind == BlockKind.H1 || it.kind == BlockKind.H2 || it.kind == BlockKind.H3) } as? TextBlock
                    val t = doc.title.ifBlank { head?.text?.toString().orEmpty() }
                    if (t.isNotBlank()) labels[i] = t.replace('\n', ' ').take(80)
                }
                yield()
            }
            // Ya con todos los capítulos cargados: índice en orden real de lectura
            eng.buildToc()
        }
        toc = built
        // los capítulos sin nombre toman el de su primera entrada del índice
        built.groupBy { it.chapter }.forEach { (c, l) ->
            if (c in 0 until count && labels[c].isBlank()) labels[c] = l.first().title.take(80)
        }
    }
    LaunchedEffect(labels.toList()) { onChapterNames(List(count) { labelOf(it) }) }

    // ── Avance global del libro (por caracteres: no depende de la paginación) ──
    fun fractionOf(ch: Int, off: Int): Float = eng.fraction(ch, off)

    // ── Subrayados → rangos de texto (por desplazamiento exacto; si no, buscando el texto) ──
    fun rangesFor(ch: Int, list: List<Highlight>): List<HlRange> {
        val plain = runCatching { eng.doc(ch).plain }.getOrNull() ?: return emptyList()
        val out = ArrayList<HlRange>()
        for (h in list) {
            if (h.chapterIndex != ch) continue
            var s = -1
            var e = -1
            val raw = hlPrefs.getString("hlo_${h.id}", null)
            if (raw != null) {
                val a = raw.substringBefore('|').toIntOrNull()
                val b = raw.substringAfter('|', "").toIntOrNull()
                if (a != null && b != null && a >= 0 && b <= plain.length && a < b &&
                    plain.substring(a, b).replace(Regex("\\s+"), " ").trim() == h.selectedText.replace(Regex("\\s+"), " ").trim()
                ) { s = a; e = b }
            }
            if (s < 0) {
                val r = findOccurrence(plain, h.selectedText, hlPrefs.getInt("hlk_${h.id}", 0))
                if (r != null) { s = r.first; e = r.last + 1 }
            }
            if (s >= 0) out.add(HlRange(s, e, (h.colorArgb.toInt() and 0x00FFFFFF) or 0x66000000))
        }
        return out
    }

    fun renderPage(cp: ChapterPages, pg: Int, list: List<Highlight>, version: Int): Bitmap? {
        val spec = cp.pages.getOrNull(pg) ?: return null
        val ch = cp.doc.index
        val key = "${cfg.key}#$ch#$pg#$version"
        bmpCache.get(key)?.let { return it }
        val pct = fractionOf(ch, spec.start) * 100f
        val bmp = PageRenderer.render(
            spec, cfg, eng.images, rangesFor(ch, list), null,
            labelOf(ch), String.format(Locale.US, "%.1f %%", pct)
        )
        bmpCache.put(key, bmp)
        return bmp
    }

    // ── Paginación asíncrona del capítulo actual (conserva el punto de lectura al cambiar ajustes) ──
    LaunchedEffect(cfg.key, chapter) {
        val cp = withContext(Dispatchers.Default) {
            eng.prune(cfg.key)
            eng.pages(cfg, chapter)
        }
        if (snippetPending.isNotBlank()) {
            val s = snippetPending
            snippetPending = ""
            val plain = cp.doc.plain
            val ok = anchor + s.length <= plain.length && plain.regionMatches(anchor, s, 0, s.length)
            if (!ok) {
                val idx = plain.indexOf(s)
                if (idx >= 0) anchor = idx
            }
        }
        curPages = cp
        pagesKey = cfg.key
        pageNo = cp.pages.indexForOffset(anchor)
        anchor = cp.pages.getOrNull(pageNo)?.start ?: anchor
    }

    // ── Dibujo de la página actual + precarga de las vecinas (sin bloquear la interfaz) ──
    LaunchedEffect(curPages, pageNo, decoVersion, cfg.key) {
        val cp = curPages ?: return@LaunchedEffect
        if (pagesKey != cfg.key) return@LaunchedEffect      // repaginando: no dibujar páginas viejas con medidas nuevas
        val list = hlNow
        val ver = decoVersion
        val bmp = withContext(Dispatchers.Default) { renderPage(cp, pageNo, list, ver) }
        if (bmp != null) curBmp = bmp
        withContext(Dispatchers.Default) {
            val ch = cp.doc.index
            if (pageNo < cp.pages.lastIndex) renderPage(cp, pageNo + 1, list, ver)
            else if (ch < lastCh) eng.pages(cfg, ch + 1).let { renderPage(it, 0, list, ver) }
            if (pageNo > 0) renderPage(cp, pageNo - 1, list, ver)
            else if (ch > 0) eng.pages(cfg, ch - 1).let { renderPage(it, it.pages.lastIndex, list, ver) }
        }
    }

    // ── Leer en segundo plano el tamaño de cada capítulo para que el % de avance sea exacto ──
    val page: PageSpec? = curPages?.pages?.getOrNull(pageNo)
    val fresh = st.isFresh(cfg.key)
    val canNext = fresh && (curPages?.let { pageNo < it.pages.lastIndex || chapter < lastCh } ?: false)
    val canPrev = fresh && (pageNo > 0 || chapter > 0)

    // ── Selección ──
    var selS by remember { mutableIntStateOf(-1) }
    var selE by remember { mutableIntStateOf(-1) }
    var anchS by remember { mutableIntStateOf(-1) }
    var anchE by remember { mutableIntStateOf(-1) }
    var toolbar by remember { mutableStateOf(false) }
    var selKeep by remember { mutableStateOf(false) }          // true mientras la selección cruza de hoja (auto-giro)
    val edgeTurn = remember { EdgeAutoTurn() }
    val longSpeed = remember { DragSpeedTracker() }
    fun clearSelection() { selS = -1; selE = -1; anchS = -1; anchE = -1; toolbar = false }
    // BreakIterators y utilidades de índices: una instancia por capítulo (no por cada movimiento del dedo)
    val tools = remember(curPages?.doc) { curPages?.let { SelectionTools(it.doc.plain) } }
    fun selectionText(): String {
        if (selS < 0 || selE <= selS) return ""
        return tools?.textOf(selS, selE).orEmpty()
    }

    // ── Cuadros de diálogo ──
    var viewerBytes by remember { mutableStateOf<ByteArray?>(null) }
    var dictWord by remember { mutableStateOf<String?>(null) }
    var pendingHighlight by remember { mutableStateOf<Triple<Int, Int, String>?>(null) }
    var menuHighlight by remember { mutableStateOf<Highlight?>(null) }
    var editHighlight by remember { mutableStateOf<Highlight?>(null) }

    fun highlightAt(ch: Int, off: Int): Highlight? {
        val list = hlNow
        for (h in list) {
            if (h.chapterIndex != ch) continue
            val r = rangesFor(ch, listOf(h)).firstOrNull() ?: continue
            if (off >= r.start && off < r.end) return h
        }
        return null
    }

    // ── Navegación ──
    fun syncBitmap() {
        val cp = curPages ?: return
        renderPage(cp, pageNo, hlNow, decoVersion)?.let { curBmp = it }
    }

    fun commitTurn(forward: Boolean) {
        if (!st.isFresh(cfg.key)) return
        val cp = curPages ?: return
        if (forward) {
            if (pageNo < cp.pages.lastIndex) {
                pageNo += 1
            } else if (chapter < lastCh) {
                val np = eng.pages(cfg, chapter + 1)
                chapter += 1
                curPages = np
                pageNo = 0
            }
        } else {
            if (pageNo > 0) {
                pageNo -= 1
            } else if (chapter > 0) {
                val pp = eng.pages(cfg, chapter - 1)
                chapter -= 1
                curPages = pp
                pageNo = pp.pages.lastIndex
            }
        }
        val now = curPages
        anchor = now?.pages?.getOrNull(pageNo)?.start ?: anchor
        if (!selKeep) clearSelection()
        syncBitmap()
    }

    suspend fun goTo(ch: Int, off: Int) {
        val c = ch.coerceIn(0, lastCh)
        val cp = withContext(Dispatchers.Default) { eng.pages(cfg, c) }
        chapter = c
        curPages = cp
        pagesKey = cfg.key
        pageNo = cp.pages.indexForOffset(off)
        anchor = cp.pages.getOrNull(pageNo)?.start ?: off
        clearSelection()
        syncBitmap()
    }

    // Saltos pedidos desde fuera: capítulo, marcador, subrayado
    LaunchedEffect(jumpChapter, jumpOffset, jumpText, jumpTextK) {
        val jc = jumpChapter ?: return@LaunchedEffect
        val c = jc.coerceIn(0, lastCh)
        val cp = withContext(Dispatchers.Default) { eng.pages(cfg, c) }
        val off = when {
            jumpText != null -> {
                val same = hlNow.filter { it.chapterIndex == c && it.selectedText == jumpText }
                val pick = same.firstOrNull { hlPrefs.getInt("hlk_${it.id}", 0) == jumpTextK } ?: same.firstOrNull()
                val byId = pick?.let { rangesFor(c, listOf(it)).firstOrNull()?.start }
                byId ?: findOccurrence(cp.doc.plain, jumpText, jumpTextK)?.first ?: 0
            }
            jumpOffset >= 0 -> jumpOffset
            else -> 0
        }
        goTo(c, off)
        onJumpConsumed()
    }

    fun openLink(href: String) {
        val res = eng.source.resolveHref(chapter, href)
        if (res != null) {
            scope.launch {
                val cp = withContext(Dispatchers.Default) { eng.pages(cfg, res.first.coerceIn(0, lastCh)) }
                val off = res.second?.let { cp.doc.anchors[it] } ?: 0
                goTo(res.first, off)
            }
        } else if (!href.startsWith("http", ignoreCase = true) && !href.startsWith("mailto:", true) && !href.startsWith("tel:", true)) {
            readerLog("enlace interno sin destino: $href")
        } else if (href.startsWith("http", ignoreCase = true)) {
            runCatching {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(href)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }

    fun handleTap(pos: Offset) {
        val pg = page ?: return
        if (selS >= 0) { clearSelection(); return }
        pg.linkAt(pos.x, pos.y)?.let { openLink(it); return }
        pg.imageAt(pos.x, pos.y)?.let { img ->
            scope.launch {
                val bytes = withContext(Dispatchers.IO) { runCatching { eng.source.readImage(img.path) }.getOrNull() }
                if (bytes == null) readerLog("visor: no se pudo abrir la imagen ${img.path}") else viewerBytes = bytes
            }
            return
        }
        val w = wPx.toFloat()
        val zone = w * 0.30f
        if (pos.x >= zone && pos.x <= w - zone) {
            val off = pg.glyphAt(pos.x, pos.y)
            if (off != null) {
                val h = highlightAt(chapter, off)
                if (h != null) { menuHighlight = h; return }
            }
            onToggleChrome()
        } else if (pos.x < zone) {
            pager.turn(prefs.leftHanded)
        } else {
            pager.turn(!prefs.leftHanded)
        }
    }

    // Pulsación larga: palabra bajo el dedo; si cae en un signo de puntuación, símbolo o espacio, ESE carácter
    fun startSelection(pos: Offset) {
        val pg = page ?: return
        val t = tools ?: return
        val g = pg.glyphAt(pos.x, pos.y) ?: return
        val wr = t.unitAt(g) ?: return
        selS = wr.start; selE = wr.end
        anchS = selS; anchE = selE
        toolbar = false
        longSpeed.start(pos.x, pos.y, System.nanoTime())
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    }

    // Arrastre tras la pulsación larga: lento → carácter a carácter · rápido → por palabras
    fun dragSelection(pos: Offset) {
        val pg = page ?: return
        val t = tools ?: return
        if (anchS < 0) return
        val fast = longSpeed.update(pos.x, pos.y, System.nanoTime(), d)
        val raw = pg.charAt(pos.x, pos.y) ?: return
        val gran = if (fast) SelGranularity.WORD else SelGranularity.CHAR
        val r = t.growFromAnchor(anchS, anchE, raw, gran, pg.start, pg.end, curPages?.doc?.plain?.length ?: 0)
        if (r.start != selS || r.end != selE) { selS = r.start; selE = r.end }
    }

    // ── Manejadores: arrastre fluido con ajuste por palabra (rápido) o por carácter (lento) ──
    var dragFixed by remember { mutableIntStateOf(-1) }       // extremo contrario, inmóvil durante el gesto
    var dragGran by remember { mutableStateOf(SelGranularity.CHAR) }
    var handleActive by remember { mutableStateOf(false) }
    var dragIsStartInstance by remember { mutableStateOf(false) }   // qué manejador físico tiene el dedo
    var handleY by remember { mutableFloatStateOf(0f) }
    var handlePos by remember { mutableStateOf(Offset.Zero) }
    var dragCorrX by remember { mutableFloatStateOf(0f) }     // compensa la separación hacia fuera de manejadores juntos
    fun beginHandleDrag(isStart: Boolean, spread: Float) {
        dragCorrX = if (isStart) spread else -spread
        dragFixed = if (isStart) selE else selS
        dragIsStartInstance = isStart
        handleActive = true
        edgeTurn.reset()
        toolbar = false                                       // el menú se oculta UNA vez al empezar…
    }
    fun moveHandle(target: Offset, lineHeight: Float, fast: Boolean) {
        val t = tools ?: return
        val pg = curPages?.pages?.getOrNull(pageNo) ?: return
        if (dragFixed < 0) return
        handlePos = target
        handleY = target.y
        dragGran = if (fast) SelGranularity.WORD else SelGranularity.CHAR
        // punto objetivo = centro de la línea bajo el manejador; charAt acepta cualquier punto (márgenes incluidos)
        val raw = pg.charAt(target.x + dragCorrX, target.y - lineHeight / 2f) ?: return
        val r = t.moveEnd(dragFixed, raw, dragGran, pg.start, pg.end, curPages?.doc?.plain?.length ?: 0) ?: return
        if (r.start != selS || r.end != selE) { selS = r.start; selE = r.end }   // solo si cambia: sin recomposiciones inútiles
    }
    fun endHandleDrag() {
        dragFixed = -1
        handleActive = false
        edgeTurn.reset()
        if (selS >= 0) toolbar = true                          // …y reaparece al soltar
    }

    // Auto-giro (equivale al auto-scroll en un lector por hojas): arrastrar un manejador por debajo de la última línea
    // (final) o por encima de la primera (inicio) y mantenerlo ~0,45 s gira la hoja SIN perder la selección.
    LaunchedEffect(handleActive) {
        if (!handleActive) return@LaunchedEffect
        while (true) {
            delay(60)
            if (!SELECTION_AUTO_TURN || turning || dragFixed < 0 || selS < 0) continue
            val cp = curPages ?: continue
            val cur = cp.pages.getOrNull(pageNo) ?: continue
            val movingEnd = dragFixed == selS
            val firstTop = cur.items.firstOrNull { it is TextItem }?.top
            val lastBottom = cur.items.lastOrNull { it is TextItem }?.bottom
            val margin = 6f * d
            val want = when {
                movingEnd && lastBottom != null && handleY > lastBottom + margin && pageNo < cp.pages.lastIndex -> 1
                !movingEnd && firstTop != null && handleY < firstTop - margin && pageNo > 0 -> -1
                else -> 0
            }
            val dir = edgeTurn.poll(System.nanoTime() / 1_000_000L, want)
            if (dir != 0) {
                selKeep = true
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                pager.turn(dir > 0)
                delay(900)
                selKeep = false                                // por si el giro no llegó a producirse
            }
        }
    }

    // ── Resaltado: aplicar, quitar, buscar y compartir ──
    /** Rango seleccionado sin espacios sobrantes en los extremos (el resaltado queda limpio). */
    fun trimmedSelection(): SelRange? {
        val plain = curPages?.doc?.plain ?: return null
        var a = selS.coerceIn(0, plain.length)
        var b = selE.coerceIn(0, plain.length)
        while (a < b && plain[a].isWhitespace()) a++
        while (b > a && plain[b - 1].isWhitespace()) b--
        return if (b > a) SelRange(a, b) else null
    }
    fun commitHighlight(sStart: Int, sEnd: Int, text: String, colorArgb: Long, note: String) {
        val ch = chapter
        val plain = curPages?.doc?.plain ?: ""
        // misma selección ya resaltada → solo cambia el color (no se duplica)
        val same = hlNow.firstOrNull { h ->
            h.chapterIndex == ch && rangesFor(ch, listOf(h)).any { it.start == sStart && it.end == sEnd }
        }
        if (same != null) {
            scope.launch {
                highlightDao.update(same.copy(colorArgb = colorArgb, note = if (note.isNotBlank()) note else same.note))
            }
            return
        }
        val newId = UUID.randomUUID().toString()
        hlPrefs.edit()
            .putString("hlo_$newId", "$sStart|$sEnd")
            .putInt("hlk_$newId", occurrenceIndexBefore(plain, text, sStart))
            .apply()
        scope.launch {
            highlightDao.insert(
                Highlight(
                    id = newId, bookId = item.id, bookTitle = item.title, chapterIndex = ch,
                    chapterTitle = labelOf(ch), selectedText = text, note = note, colorArgb = colorArgb
                )
            )
        }
    }
    fun applyHighlight(colorArgb: Long) {
        val r = trimmedSelection() ?: return
        val text = tools?.textOf(r.start, r.end).orEmpty()
        if (text.isEmpty()) return
        commitHighlight(r.start, r.end, text, colorArgb, "")
        clearSelection()
    }
    fun overlappingHighlights(): List<Highlight> {
        if (selS < 0) return emptyList()
        val ch = chapter
        return hlNow.filter { h ->
            h.chapterIndex == ch && rangesFor(ch, listOf(h)).any { it.start < selE && it.end > selS }
        }
    }
    fun removeSelectedHighlights() {
        for (h in overlappingHighlights()) {
            scope.launch { highlightDao.deleteById(h.id) }
            hlPrefs.edit().remove("hlo_${h.id}").remove("hlk_${h.id}").apply()
        }
        clearSelection()
    }
    fun searchSelection() {
        val q = selectionText()
        if (q.isBlank()) return
        val ok = runCatching {
            ctx.startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra(android.app.SearchManager.QUERY, q))
        }.isSuccess
        if (!ok) runCatching {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
        }
    }
    fun shareSelection() {
        val q = selectionText()
        if (q.isBlank()) return
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "“$q”\n— ${item.title}")
        }
        runCatching { ctx.startActivity(Intent.createChooser(send, null)) }
    }

    // ── Última posición, avance y etiqueta del capítulo ──
    fun saveNow() {
        val cp = curPages ?: return
        val pg = cp.pages.getOrNull(pageNo) ?: return
        val ch = cp.doc.index
        val pct = (fractionOf(ch, pg.start) * 100f).toInt().coerceIn(0, 100)
        onSave(ch.toLong(), pct)
        val plain = cp.doc.plain
        val snippet = plain.substring(min(pg.start, plain.length), min(pg.start + 40, plain.length)).replace('\n', ' ')
        onOffsetSave(ch, pg.start, snippet)
    }
    LaunchedEffect(curPages, pageNo, toc) {
        val cp = curPages ?: return@LaunchedEffect
        val pg = cp.pages.getOrNull(pageNo) ?: return@LaunchedEffect
        val ch = cp.doc.index
        val u = st.snapshot(eng, toc, count)
        val where = if (u.tocNumber > 0) "Cap. ${u.tocNumber}/${u.tocCount} · ${u.tocTitle}" else "Cap. ${ch + 1}/$count · ${labelOf(ch)}"
        onChapterLabel("$where · Hoja ${pg.number + 1}/${cp.pages.size}")
        delay(200)
        saveNow()
    }
    DisposableEffect(Unit) { onDispose { saveNow() } }

    // ── Marcadores ──
    val bmHere: Int = remember(bookmarkOffsets, chapter, pageNo, curPages) {
        val pg = page
        if (pg == null) -1 else bookmarkOffsets.firstOrNull {
            it.first == chapter && it.second >= pg.start && it.second < max(pg.end, pg.start + 1)
        }?.second ?: -1
    }
    val pageBookmarked = bmHere >= 0
    LaunchedEffect(pageBookmarked) { onPageBookmarked(pageBookmarked) }
    fun toggleBookmark() {
        val pg = page ?: return
        val pct = (fractionOf(chapter, pg.start) * 100f).toInt().coerceIn(0, 100)
        onBookmarkToggle(chapter, pg.start, pct, labelOf(chapter), bmHere)
    }
    var bmHandled by remember { mutableIntStateOf(bookmarkRequest) }
    LaunchedEffect(bookmarkRequest) {
        if (bookmarkRequest != bmHandled) {
            bmHandled = bookmarkRequest
            toggleBookmark()
        }
    }

    // ══════════════════════════════ Interfaz ══════════════════════════════
    Box(Modifier.fillMaxSize()) {
        BookPager(
            current = curBmp?.takeIf { fresh && it.width == wPx && it.height == hPx },
            canNext = canNext,
            canPrev = canPrev,
            nextBitmap = {
                val cp = curPages
                if (cp == null || !fresh) null
                else if (pageNo < cp.pages.lastIndex) renderPage(cp, pageNo + 1, hlNow, decoVersion)
                else if (chapter < lastCh) eng.pages(cfg, chapter + 1).let { renderPage(it, 0, hlNow, decoVersion) }
                else null
            },
            prevBitmap = {
                val cp = curPages
                if (cp == null || !fresh) null
                else if (pageNo > 0) renderPage(cp, pageNo - 1, hlNow, decoVersion)
                else if (chapter > 0) eng.pages(cfg, chapter - 1).let { renderPage(it, it.pages.lastIndex, hlNow, decoVersion) }
                else null
            },
            paperColor = pal.bg,
            controller = pager,
            onTurnStart = { turning = true; if (!selKeep) clearSelection() },
            onTurnEnd = { turning = false; selKeep = false },
            onCommit = { commitTurn(it) },
            onTap = { handleTap(it) },
            onLongPress = { startSelection(it) },
            onLongDrag = { dragSelection(it) },
            onLongRelease = { if (selS >= 0) toolbar = true }
        )

        // Selección: pintada por encima de la página (instantánea, sin volver a dibujar el bitmap)
        val pg = page
        if (pg != null && selS >= 0 && (!turning || selKeep)) {
            val rects = remember(pg, selS, selE) { pg.selectionRects(selS, selE, 9f * d) }
            if (!turning) {
                Canvas(Modifier.fillMaxSize()) {
                    rects.forEach { r ->
                        drawRoundRect(
                            Color(0x664A90E2), Offset(r.left, r.top), Size(r.width(), r.height()), CornerRadius(4f)
                        )
                    }
                }
            }
            val first = rects.firstOrNull()
            val last = rects.lastOrNull()
            val lineH = (first ?: last)?.height() ?: (20f * d)
            // Selección corta de una línea (p. ej. un solo «.»): los manejadores se separan hacia fuera para que sus
            // zonas táctiles no se solapen y se pueda ajustar cualquiera de los dos
            val spread = if (rects.size == 1 && first != null) ((56f * d - first.width()) / 2f).coerceIn(0f, 28f * d) else 0f
            val startHere = first != null && selS >= pg.start && selS <= pg.end   // el inicio está en esta hoja
            val endHere = last != null && selE >= pg.start && selE <= pg.end       // el final está en esta hoja
            // Un manejador se mantiene mientras tiene el dedo encima, aunque su extremo haya quedado en otra hoja
            if (startHere || (handleActive && dragIsStartInstance)) {
                SelectionHandle(
                    if (startHere && first != null) first.left - spread else handlePos.x,
                    if (startHere && first != null) first.bottom else handlePos.y,
                    Color(pal.link), visible = !turning,
                    onStart = { beginHandleDrag(isStart = true, spread = spread) },
                    onMove = { p, fast -> moveHandle(p, lineH, fast) },
                    onEnd = { endHandleDrag() }
                )
            }
            if (endHere || (handleActive && !dragIsStartInstance)) {
                SelectionHandle(
                    if (endHere && last != null) last.right + spread else handlePos.x,
                    if (endHere && last != null) last.bottom else handlePos.y,
                    Color(pal.link), visible = !turning,
                    onStart = { beginHandleDrag(isStart = false, spread = spread) },
                    onMove = { p, fast -> moveHandle(p, lineH, fast) },
                    onEnd = { endHandleDrag() }
                )
            }
            if (toolbar && !turning) {
                val atTop = last != null && last.bottom + 36f * d > hPx - 120f * d   // selección abajo → la barra pasa arriba
                val hasHl = overlappingHighlights().isNotEmpty()
                SelectionActionBar(
                    modifier = Modifier.align(if (atTop) Alignment.TopCenter else Alignment.BottomCenter),
                    atTop = atTop,
                    preview = selectionText(),
                    hasHighlight = hasHl,
                    onColor = { argb -> applyHighlight(argb) },
                    onNote = {
                        trimmedSelection()?.let { r ->
                            val text = tools?.textOf(r.start, r.end).orEmpty()
                            if (text.isNotEmpty()) pendingHighlight = Triple(r.start, r.end, text)
                        }
                        toolbar = false
                    },
                    onCopy = {
                        clipboard.setText(AnnotatedString(selectionText()))
                        clearSelection()
                    },
                    onSearch = { searchSelection() },
                    onShare = { shareSelection() },
                    onDefine = {
                        val text = selectionText()
                        if (text.isNotEmpty()) dictWord = text
                        clearSelection()
                    },
                    onSentence = {
                        // Expande a frase(s) completa(s); pulsar otra vez suma la siguiente. Los manejadores siguen libres.
                        val t = tools
                        if (t != null && selS >= 0) {
                            t.expandToSentences(selS, selE, pg.start, pg.end)?.let { r -> selS = r.start; selE = r.end }
                        }
                    },
                    onRemove = { removeSelectedHighlights() },
                    onClear = { clearSelection() }
                )
            }
        }

        // Listón de marcador (se oculta mientras la hoja gira)
        if (!turning) {
            PageRibbon(
                visible = pageBookmarked && ribbonEnabled,
                onLongPress = { toggleBookmark() },
                modifier = Modifier.align(Alignment.TopStart)
            )
        }

        // Botones ◀ ▶ opcionales
        if (prefs.showNavButtons) {
            NavButton("‹", Modifier.align(Alignment.BottomStart).padding(16.dp)) { pager.turn(false) }
            NavButton("›", Modifier.align(Alignment.BottomEnd).padding(16.dp)) { pager.turn(true) }
        }

        // Velo de brillo
        if (prefs.brightness < 0.99f) {
            Box(
                Modifier.fillMaxSize()
                    .background(Color.Black.copy(alpha = (1f - prefs.brightness).coerceIn(0f, 0.65f)))
            )
        }
    }

    // ── Panel de capítulos y avance ──
    if (showContents) {
        ModalBottomSheet(onDismissRequest = onContentsDismiss, containerColor = Panel) {
            Column(
                Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp).padding(bottom = 24.dp)
            ) {
                Text("CONTENIDO", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(Modifier.height(8.dp))
                Text("Avance del libro", color = Cream, fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                val ui = st.snapshot(eng, toc, count)
                val pct = ui.progressPct
                GoldProgressBar(pct / 100f, height = 10.dp)
                val capText = if (ui.tocNumber > 0) "Cap. ${ui.tocNumber} de ${ui.tocCount}" else "Cap. ${ui.chapter + 1} de $count"
                Text(
                    "$pct% · $capText · Hoja ${ui.page + 1}/${ui.pageCount}",
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)
                )
                Spacer(Modifier.height(14.dp))
                Text("CAPÍTULOS", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(Modifier.height(6.dp))
                val tocNow = toc
                if (tocNow.isNotEmpty()) {
                    val activeToc = st.snapshot(eng, tocNow, count).tocIndex
                    val listState = rememberLazyListState(initialFirstVisibleItemIndex = (activeToc - 3).coerceAtLeast(0))
                    LazyColumn(Modifier.heightIn(max = 360.dp), state = listState) {
                        itemsIndexed(tocNow) { i, t ->
                            val selected = i == activeToc
                            Row(
                                Modifier.fillMaxWidth()
                                    .clickable {
                                        onContentsDismiss()
                                        scope.launch { goTo(t.chapter, t.offset) }
                                    }
                                    .background(if (selected) Gold.copy(alpha = 0.15f) else Color.Transparent)
                                    .padding(vertical = 10.dp, horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "${i + 1}.", color = if (selected) Gold else Muted, fontSize = 12.sp,
                                    modifier = Modifier.width(28.dp)
                                )
                                Spacer(Modifier.width((t.level.coerceAtMost(3) * 12).dp))
                                Text(
                                    t.title, color = if (selected) Cream else Cream.copy(alpha = 0.85f), fontSize = 14.sp,
                                    maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                                )
                                if (selected) Text("●", color = Gold, fontSize = 10.sp)
                            }
                        }
                    }
                } else {
                LazyColumn(Modifier.heightIn(max = 360.dp)) {
                        items(count) { i ->
                            val selected = i == chapter
                            Row(
                                Modifier.fillMaxWidth()
                                    .clickable {
                                        onContentsDismiss()
                                        scope.launch { goTo(i, 0) }
                                    }
                                    .background(if (selected) Gold.copy(alpha = 0.15f) else Color.Transparent)
                                    .padding(vertical = 10.dp, horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "${i + 1}.", color = if (selected) Gold else Muted, fontSize = 12.sp,
                                    modifier = Modifier.width(28.dp)
                                )
                                Text(
                                    labelOf(i), color = if (selected) Cream else Cream.copy(alpha = 0.85f), fontSize = 14.sp,
                                    maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                                )
                                if (selected) Text("●", color = Gold, fontSize = 10.sp)
                            }
                        }
                    }
                    }
            }
        }
    }

    viewerBytes?.let { data -> ImageGalleryDialog(bytes = data, onDismiss = { viewerBytes = null }) }
    dictWord?.let { w -> DictionaryDialog(word = w, onDismiss = { dictWord = null }) }

    pendingHighlight?.let { (hs, he, text) ->
        HighlightColorPicker(
            selectedText = text,
            onConfirm = { colorArgb, note ->
                commitHighlight(hs, he, text, colorArgb, note)
                pendingHighlight = null
                clearSelection()
            },
            onDismiss = { pendingHighlight = null }
        )
    }

    menuHighlight?.let { h ->
        AlertDialog(
            onDismissRequest = { menuHighlight = null },
            containerColor = Panel,
            title = { Text("Subrayado", color = Cream, fontWeight = FontWeight.SemiBold, fontSize = 16.sp) },
            text = {
                Column {
                    Text("“${h.selectedText.take(160)}”", color = Cream, fontSize = 13.sp, lineHeight = 18.sp)
                    if (h.note.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Text(h.note, color = Muted, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { editHighlight = h; menuHighlight = null }) { Text("Editar nota", color = Gold) }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        scope.launch { highlightDao.deleteById(h.id) }
                        hlPrefs.edit().remove("hlo_${h.id}").remove("hlk_${h.id}").apply()
                        menuHighlight = null
                    }) { Text("Quitar", color = Muted) }
                    TextButton(onClick = { menuHighlight = null }) { Text("Cerrar", color = Muted) }
                }
            }
        )
    }
    editHighlight?.let { h ->
        HighlightEditDialog(
            highlight = h,
            onSave = { updated -> scope.launch { highlightDao.update(updated) }; editHighlight = null },
            onDismiss = { editHighlight = null }
        )
    }
}

// ── Piezas de interfaz ───────────────────────────────────────────────────────

@Composable
private fun NavButton(label: String, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.size(44.dp).clip(CircleShape).background(Color(0x66000000)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 24.sp) }
}

/** Imagen a pantalla completa tipo galería: pellizco, doble toque, arrastre y botón de cerrar. */
@Composable
private fun ImageGalleryDialog(bytes: ByteArray, onDismiss: () -> Unit) {
    val bmp = remember(bytes) {
        runCatching {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (bounds.outWidth / sample > 3000 || bounds.outHeight / sample > 3000) sample *= 2
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
        }.getOrNull()
    }
    if (bmp == null) {
        LaunchedEffect(bytes) { onDismiss() }
        return
    }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(IntSize.Zero) }

    fun clamp(o: Offset, s: Float): Offset {
        val mx = box.width * (s - 1f) / 2f
        val my = box.height * (s - 1f) / 2f
        return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            Modifier.fillMaxSize().background(Color.Black).onSizeChanged { box = it }
                .pointerInput(Unit) {
                    detectTransformGestures { centroid, pan, zoom, _ ->
                        val ns = (scale * zoom).coerceIn(1f, 8f)
                        val c = Offset(box.width / 2f, box.height / 2f)
                        val moved = (centroid - c) - ((centroid - c) - offset) * (ns / scale) + pan
                        scale = ns
                        offset = if (ns <= 1f) Offset.Zero else clamp(moved, ns)
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures(onDoubleTap = { p ->
                        if (scale > 1f) { scale = 1f; offset = Offset.Zero }
                        else {
                            val ns = 2.5f
                            val c = Offset(box.width / 2f, box.height / 2f)
                            scale = ns
                            offset = clamp((p - c) - (p - c) * ns, ns)
                        }
                    })
                }
        ) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().graphicsLayer {
                    scaleX = scale; scaleY = scale
                    translationX = offset.x; translationY = offset.y
                }
            )
            Box(
                Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(12.dp)
                    .size(42.dp).clip(CircleShape).background(Color(0x66000000)).clickable(onClick = onDismiss),
                contentAlignment = Alignment.Center
            ) { Text("✕", color = Color.White, fontSize = 18.sp) }
        }
    }
}
