package com.libra.reader

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Barra de acciones de la selección de texto del lector (versión limpia).
 *
 *  · Siempre visible: la vista previa de lo seleccionado y los 6 colores (un toque resalta con ese color).
 *  · Botón de tres puntos horizontales (⋯): menú con el resto de acciones — Copiar, Nota, Buscar, Compartir,
 *    Definir, Frase, Quitar resaltado (solo si la selección toca un resaltado) y Limpiar selección.
 *  · [atTop] la coloca arriba cuando la selección está en la parte baja de la hoja (para no taparla).
 */
@Composable
internal fun SelectionActionBar(
    modifier: Modifier,
    atTop: Boolean,
    preview: String,
    hasHighlight: Boolean,
    onColor: (Long) -> Unit,
    onNote: () -> Unit,
    onCopy: () -> Unit,
    onSearch: () -> Unit,
    onShare: () -> Unit,
    onDefine: () -> Unit,
    onSentence: () -> Unit,
    onRemove: () -> Unit,
    onClear: () -> Unit
) {
    val shape = if (atTop) RoundedCornerShape(bottomStart = 18.dp, bottomEnd = 18.dp)
    else RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp)
    var menuOpen by remember { mutableStateOf(false) }

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = shape,
        color = Panel,
        shadowElevation = 12.dp
    ) {
        Column(
            Modifier
                .then(if (atTop) Modifier.statusBarsPadding() else Modifier.navigationBarsPadding())
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(
                "“${preview.ifBlank { "espacio" }}”",
                color = Muted,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                HIGHLIGHT_COLORS.forEach { (argb, name) ->
                    Box(
                        Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color(argb))
                            .border(1.dp, Muted, CircleShape)
                            .clickable { onColor(argb) }
                            .semantics { contentDescription = "Resaltar en $name" }
                    )
                    Spacer(Modifier.width(6.dp))
                }
                Spacer(Modifier.weight(1f))

                // Menú de tres puntos horizontales
                Box {
                    Box(
                        Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .clickable { menuOpen = true }
                            .semantics { contentDescription = "Más acciones" },
                        contentAlignment = Alignment.Center
                    ) { ThreeDots(Cream) }
                    DropdownMenu(
                        expanded = menuOpen,
                        onDismissRequest = { menuOpen = false },
                        modifier = Modifier.background(Panel)
                    ) {
                        MenuRow("Copiar") { menuOpen = false; onCopy() }
                        MenuRow("Añadir nota…") { menuOpen = false; onNote() }
                        MenuRow("Buscar en la web") { menuOpen = false; onSearch() }
                        MenuRow("Compartir") { menuOpen = false; onShare() }
                        MenuRow("Definir") { menuOpen = false; onDefine() }
                        MenuRow("Expandir a frase") { menuOpen = false; onSentence() }
                        HorizontalDivider(color = Line)
                        if (hasHighlight) MenuRow("Quitar resaltado", Gold) { menuOpen = false; onRemove() }
                        MenuRow("Limpiar selección", Muted) { menuOpen = false; onClear() }
                    }
                }
            }
        }
    }
}

@Composable
private fun MenuRow(label: String, tint: Color = Cream, onClick: () -> Unit) {
    DropdownMenuItem(
        text = { Text(label, color = tint, fontSize = 14.sp) },
        onClick = onClick
    )
}

/** Tres puntos en horizontal (⋯), dibujados con Canvas para no depender de la fuente. */
@Composable
private fun ThreeDots(color: Color) {
    Canvas(Modifier.size(width = 22.dp, height = 6.dp)) {
        val r = 2.2.dp.toPx()
        val step = (size.width - 2f * r) / 2f
        for (k in 0..2) drawCircle(color, radius = r, center = Offset(r + k * step, size.height / 2f))
    }
}
