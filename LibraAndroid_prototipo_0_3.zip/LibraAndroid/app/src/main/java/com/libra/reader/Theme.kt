package com.libra.reader

import androidx.compose.ui.graphics.Color

internal val Ink = Color(0xFF171716)
internal val Panel = Color(0xFF242320)
internal val Cream = Color(0xFFF1E8D8)
internal val Gold = Color(0xFFC5A46D)
internal val Muted = Color(0xFFB9B0A2)
