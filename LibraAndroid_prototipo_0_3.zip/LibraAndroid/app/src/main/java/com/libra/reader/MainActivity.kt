package com.libra.reader

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LibraApp() }
    }
}

@Composable
fun LibraApp() {
    val context = LocalContext.current
    val dao = remember { LibraryDatabase.get(context).libraryDao() }
    val allItems = remember { dao.observeAll() }
    val items by allItems.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    val controller by rememberMediaController()
    PlaybackPersistence(controller, dao)

    var selectedTab by remember { mutableStateOf("Inicio") }
    var listMode by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf("Tu biblioteca está guardada en este dispositivo.") }
    var busy by remember { mutableStateOf(false) }
    var opened by remember { mutableStateOf<LibraryItem?>(null) }

    val bookPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            scope.launch {
                busy = true
                status = "Importando…"
                status = withContext(Dispatchers.IO) {
                    importUris(context.contentResolver, context.filesDir, uris, "BOOK", dao)
                }
                busy = false
            }
        }
    }
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            scope.launch {
                busy = true
                status = "Importando…"
                status = withContext(Dispatchers.IO) {
                    importUris(context.contentResolver, context.filesDir, uris, "AUDIO", dao)
                }
                busy = false
            }
        }
    }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                status = "Creando copia de seguridad…"
                status = Backup.export(context, dao, uri)
                busy = false
            }
        }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                status = "Restaurando copia de seguridad…"
                status = Backup.restore(context, dao, uri)
                busy = false
            }
        }
    }

    val onDelete: (LibraryItem) -> Unit = { item -> scope.launch { removeItem(dao, item) } }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Ink, surface = Panel, primary = Gold,
            onBackground = Cream, onSurface = Cream, onPrimary = Ink
        )
    ) {
        val current = opened
        if (current != null) {
            if (current.mediaType == "AUDIO") {
                AudioPlayerScreen(current, controller, onClose = { opened = null })
            } else {
                ReaderScreen(
                    current,
                    onClose = { opened = null },
                    onSave = { position, progress ->
                        scope.launch { dao.updateProgress(current.id, position, progress) }
                    }
                )
            }
        } else {
            Scaffold(
                containerColor = Ink,
                bottomBar = {
                    NavigationBar(containerColor = Panel, contentColor = Cream) {
                        listOf("Inicio", "Biblioteca", "Estantería", "Audio", "Ajustes").forEach { tab ->
                            NavigationBarItem(
                                selected = selectedTab == tab,
                                onClick = { selectedTab = tab },
                                icon = {
                                    Text(
                                        when (tab) {
                                            "Inicio" -> "⌂"; "Biblioteca" -> "▤"; "Estantería" -> "▥"
                                            "Audio" -> "♫"; else -> "⚙"
                                        }, fontSize = 20.sp
                                    )
                                },
                                label = { Text(tab, fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Gold, selectedTextColor = Gold,
                                    indicatorColor = Ink, unselectedIconColor = Muted,
                                    unselectedTextColor = Muted
                                )
                            )
                        }
                    }
                }
            ) { padding ->
                Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp)) {
                    Spacer(Modifier.height(18.dp))
                    Text("LIBRA", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                    Text(
                        when (selectedTab) {
                            "Inicio" -> "Tu biblioteca, a tu manera."
                            "Biblioteca" -> "Todos tus libros"
                            "Estantería" -> "Tu rincón de lectura"
                            "Audio" -> "Escucha tus historias"
                            else -> "Personaliza tu experiencia"
                        },
                        color = Cream, fontSize = 26.sp, fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { bookPicker.launch(arrayOf("*/*")) },
                            enabled = !busy,
                            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink),
                            modifier = Modifier.weight(1f)
                        ) { Text("＋ Importar libros", fontSize = 12.sp) }
                        OutlinedButton(
                            onClick = { audioPicker.launch(arrayOf("audio/*")) },
                            enabled = !busy,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
                        ) { Text("♫ Audiolibros", fontSize = 12.sp) }
                    }
                    Text(status, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp))
                    val books = items.filter { it.mediaType == "BOOK" }
                    when (selectedTab) {
                        "Inicio" -> HomeScreen(books, onOpen = { opened = it }, onDelete = onDelete)
                        "Biblioteca" -> LibraryScreen(
                            books, listMode, onModeChange = { listMode = it },
                            onOpen = { opened = it }, onDelete = onDelete
                        )
                        "Estantería" -> ShelfScreen(
                            books,
                            onOpen = { opened = it },
                            onToggle = { item ->
                                scope.launch {
                                    dao.update(
                                        item.copy(
                                            shelfOrientation = if (item.shelfOrientation == "VERTICAL") "HORIZONTAL" else "VERTICAL"
                                        )
                                    )
                                }
                            },
                            onMove = { id, x, y -> scope.launch { dao.updateShelfPosition(id, x, y) } },
                            onReset = { scope.launch { dao.resetShelfPositions() } }
                        )
                        "Audio" -> AudioScreen(
                            items.filter { it.mediaType == "AUDIO" },
                            onOpen = { opened = it }, onDelete = onDelete
                        )
                        else -> SettingsScreen(
                            items.size, busy,
                            onExport = {
                                val stamp = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
                                exportLauncher.launch("libra-copia-$stamp.zip")
                            },
                            onImport = { restoreLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(books: List<LibraryItem>, onOpen: (LibraryItem) -> Unit, onDelete: (LibraryItem) -> Unit) {
    if (books.isEmpty()) {
        EmptyFeature(
            "TU BIBLIOTECA COMIENZA AQUÍ",
            "Importa tus archivos EPUB, PDF, TXT, FB2, CBZ o CBR. Libra guardará una copia privada dentro de la aplicación para que puedas acceder sin conexión."
        )
    } else {
        Text("LIBROS EN TU DISPOSITIVO · ${books.size}", color = Gold, fontSize = 11.sp, letterSpacing = 1.sp)
        Spacer(Modifier.height(8.dp))
        LazyColumn { items(books, key = { it.id }) { BookRow(it, onOpen, onDelete) } }
    }
}

@Composable
fun LibraryScreen(
    books: List<LibraryItem>, listMode: Boolean, onModeChange: (Boolean) -> Unit,
    onOpen: (LibraryItem) -> Unit, onDelete: (LibraryItem) -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("${books.size} libros importados", color = Muted, modifier = Modifier.weight(1f))
        TextButton(onClick = { onModeChange(!listMode) }) {
            Text(if (listMode) "Vista cuadrícula" else "Vista lista", color = Gold)
        }
    }
    if (books.isEmpty()) {
        EmptyFeature("AÚN NO HAY LIBROS", "Pulsa «Importar libros» para añadir tu colección.")
    } else if (listMode) {
        LazyColumn { items(books, key = { it.id }) { BookRow(it, onOpen, onDelete) } }
    } else {
        LazyColumn {
            items(books.chunked(2)) { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    row.forEach { book ->
                        Column(Modifier.weight(1f).padding(vertical = 8.dp).clickable { onOpen(book) }) {
                            BookCover(book, Modifier.fillMaxWidth().height(190.dp))
                            Spacer(Modifier.height(6.dp))
                            Text(book.title, color = Cream, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text("${book.author} · ${book.format}", color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

private fun shelfSize(horizontal: Boolean): Pair<Dp, Dp> =
    if (horizontal) 118.dp to 40.dp else 52.dp to 124.dp

private val PLANK_LEVELS = listOf(0.30f, 0.62f, 0.94f)

/** Colocación inicial: los libros se apoyan sobre las baldas, fila a fila. */
private fun autoSlots(books: List<LibraryItem>, areaW: Int, areaH: Int, density: Density): Map<String, IntOffset> {
    val gap = with(density) { 4.dp.roundToPx() }
    val result = HashMap<String, IntOffset>()
    var row = 0
    var cursor = 0
    books.forEach { b ->
        val (w, h) = shelfSize(b.shelfOrientation == "HORIZONTAL")
        val bw = with(density) { w.roundToPx() }
        val bh = with(density) { h.roundToPx() }
        if (cursor + bw > areaW && cursor > 0) {
            row++
            cursor = 0
        }
        val plankY = (areaH * PLANK_LEVELS[row % PLANK_LEVELS.size]).toInt()
        result[b.id] = IntOffset(cursor, (plankY - bh).coerceAtLeast(0))
        cursor += bw + gap
    }
    return result
}

@Composable
fun ShelfScreen(
    books: List<LibraryItem>,
    onOpen: (LibraryItem) -> Unit,
    onToggle: (LibraryItem) -> Unit,
    onMove: (String, Float, Float) -> Unit,
    onReset: () -> Unit
) {
    if (books.isEmpty()) {
        EmptyFeature("ESTANTERÍA VACÍA", "Cuando importes libros, aparecerán aquí. Podrás moverlos libremente y alternar su orientación vertical u horizontal.")
        return
    }
    LazyColumn {
        item {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "ARRASTRA LOS LIBROS DONDE QUIERAS · TOCA PARA ABRIR",
                        color = Muted, fontSize = 10.sp, letterSpacing = 1.sp, modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = onReset) { Text("Ordenar", color = Gold, fontSize = 11.sp) }
                }
                Spacer(Modifier.height(8.dp))
                BoxWithConstraints(
                    Modifier.fillMaxWidth().height(400.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF4A3022))
                ) {
                    val areaW = constraints.maxWidth
                    val areaH = constraints.maxHeight
                    val density = LocalDensity.current
                    val slots = remember(books.map { it.id to it.shelfOrientation }, areaW, areaH) {
                        autoSlots(books, areaW, areaH, density)
                    }
                    PLANK_LEVELS.forEach { level ->
                        Box(
                            Modifier.offset(y = maxHeight * level).fillMaxWidth().height(10.dp)
                                .background(Color(0xFFB18A5C))
                        )
                    }
                    books.forEach { book ->
                        key(book.id) {
                            ShelfBook(book, slots[book.id] ?: IntOffset.Zero, areaW, areaH, onOpen, onMove)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
        }
        items(books, key = { it.id }) { book ->
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Column(Modifier.weight(1f)) {
                    Text(book.title, color = Cream, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(book.format, color = Muted, fontSize = 10.sp)
                }
                TextButton(onClick = { onToggle(book) }) {
                    Text(if (book.shelfOrientation == "VERTICAL") "Acostar" else "Levantar", color = Gold)
                }
            }
        }
    }
}

@Composable
private fun ShelfBook(
    book: LibraryItem,
    slot: IntOffset,
    areaW: Int,
    areaH: Int,
    onOpen: (LibraryItem) -> Unit,
    onMove: (String, Float, Float) -> Unit
) {
    val density = LocalDensity.current
    val horizontal = book.shelfOrientation == "HORIZONTAL"
    val dims = shelfSize(horizontal)
    val bw = with(density) { dims.first.roundToPx() }
    val bh = with(density) { dims.second.roundToPx() }
    val maxX = (areaW - bw).coerceAtLeast(1)
    val maxY = (areaH - bh).coerceAtLeast(1)
    var x by remember(book.id, book.shelfX, areaW, bw, slot.x) {
        mutableFloatStateOf(if (book.shelfX >= 0f) book.shelfX * maxX else slot.x.toFloat().coerceIn(0f, maxX.toFloat()))
    }
    var y by remember(book.id, book.shelfY, areaH, bh, slot.y) {
        mutableFloatStateOf(if (book.shelfY >= 0f) book.shelfY * maxY else slot.y.toFloat().coerceIn(0f, maxY.toFloat()))
    }
    var dragging by remember { mutableStateOf(false) }

    Box(
        Modifier
            .offset { IntOffset(x.roundToInt(), y.roundToInt()) }
            .zIndex(if (dragging) 10f else 0f)
            .size(dims.first, dims.second)
            .pointerInput(book.id, maxX, maxY) {
                detectDragGestures(
                    onDragStart = { dragging = true },
                    onDragEnd = {
                        dragging = false
                        onMove(book.id, (x / maxX).coerceIn(0f, 1f), (y / maxY).coerceIn(0f, 1f))
                    },
                    onDragCancel = { dragging = false }
                ) { change, drag ->
                    change.consume()
                    x = (x + drag.x).coerceIn(0f, maxX.toFloat())
                    y = (y + drag.y).coerceIn(0f, maxY.toFloat())
                }
            }
            .clickable { onOpen(book) }
    ) {
        if (horizontal) {
            Box(
                Modifier.fillMaxSize().clip(RoundedCornerShape(4.dp)).background(coverColor(book.title)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    book.title, color = Cream, fontSize = 9.sp, fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 6.dp)
                )
            }
        } else {
            BookCover(book, Modifier.fillMaxSize(), textSize = 8.sp)
        }
    }
}

@Composable
fun AudioScreen(audio: List<LibraryItem>, onOpen: (LibraryItem) -> Unit, onDelete: (LibraryItem) -> Unit) {
    if (audio.isEmpty()) {
        EmptyFeature(
            "TUS AUDIOLIBROS",
            "Importa MP3, M4A, M4B, AAC, OGG, OPUS, WAV o FLAC. Libra recuerda por dónde ibas y sigue sonando con la pantalla apagada."
        )
    } else {
        Text("${audio.size} archivos de audio importados", color = Gold, fontSize = 11.sp)
        LazyColumn { items(audio, key = { it.id }) { BookRow(it, onOpen, onDelete) } }
    }
}

@Composable
fun SettingsScreen(itemCount: Int, busy: Boolean, onExport: () -> Unit, onImport: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        EmptyFeature(
            "ALMACENAMIENTO LOCAL",
            "Libra mantiene $itemCount elementos en el almacenamiento privado de la aplicación."
        )
        Button(
            onClick = onExport, enabled = !busy, modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)
        ) { Text("Exportar copia de seguridad") }
        OutlinedButton(
            onClick = onImport, enabled = !busy, modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
        ) { Text("Restaurar desde una copia") }
        Text(
            "La copia es un archivo .zip con tus libros, audiolibros, portadas, progreso y orden de la estantería. " +
                "Guárdalo en Drive o en la tarjeta y restáuralo en otro teléfono.",
            color = Muted, fontSize = 12.sp, lineHeight = 18.sp
        )
    }
}

@Composable
fun EmptyFeature(title: String, description: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text(title, color = Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Text(description, color = Cream, fontSize = 14.sp, lineHeight = 21.sp)
        }
    }
}

@Composable
fun BookRow(item: LibraryItem, onOpen: (LibraryItem) -> Unit, onDelete: (LibraryItem) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onOpen(item) }.padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BookCover(item, Modifier.size(width = 48.dp, height = 66.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(item.title, color = Cream, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text("${item.author} · ${item.format}", color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (item.progress > 0) {
                Spacer(Modifier.height(5.dp))
                LinearProgressIndicator(
                    progress = { item.progress / 100f },
                    color = Gold, trackColor = Panel,
                    modifier = Modifier.fillMaxWidth().height(3.dp)
                )
            }
        }
        TextButton(onClick = { onDelete(item) }) { Text("Quitar", color = Muted, fontSize = 11.sp) }
    }
}

private fun coverColor(title: String): Color {
    val palette = listOf(Color(0xFF6B3540), Color(0xFF35564D), Color(0xFF43506D), Color(0xFF7A5C3A), Color(0xFF3B3430))
    return palette[abs(title.hashCode()) % palette.size]
}

/** Portada real si existe; si no, un bloque de color con el título. */
@Composable
fun BookCover(item: LibraryItem, modifier: Modifier = Modifier, textSize: androidx.compose.ui.unit.TextUnit = 10.sp) {
    val cover = remember(item.coverPath) { item.coverPath?.let { File(it) }?.takeIf { it.exists() } }
    Box(
        modifier.clip(RoundedCornerShape(7.dp)).background(coverColor(item.title)),
        contentAlignment = Alignment.Center
    ) {
        if (cover != null) {
            AsyncImage(
                model = cover, contentDescription = item.title,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
            )
        } else {
            Text(
                item.title, color = Cream, fontSize = textSize, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, maxLines = 6, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(5.dp)
            )
        }
    }
}
