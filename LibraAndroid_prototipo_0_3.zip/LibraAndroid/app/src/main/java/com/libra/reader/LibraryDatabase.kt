package com.libra.reader

import android.content.Context
import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "library_items")
data class LibraryItem(
    @PrimaryKey val id: String,
    val title: String,
    val author: String,
    val format: String,
    val localPath: String,
    val mediaType: String,
    val progress: Int = 0,
    val shelfOrientation: String = "VERTICAL",
    val sortOrder: Int = 0,
    val addedAt: Long = System.currentTimeMillis(),
    val coverPath: String? = null,
    // Posición de lectura: capítulo (EPUB), página (PDF/CBZ), párrafo (TXT/FB2) o milisegundos (audio).
    @ColumnInfo(defaultValue = "0") val lastPosition: Long = 0,
    @ColumnInfo(defaultValue = "0") val durationMs: Long = 0,
    // Posición libre en la estantería como fracción 0..1 del área; -1 = colocación automática.
    @ColumnInfo(defaultValue = "-1") val shelfX: Float = -1f,
    @ColumnInfo(defaultValue = "-1") val shelfY: Float = -1f
)

@Dao
interface LibraryDao {
    @Query("SELECT * FROM library_items ORDER BY sortOrder ASC, addedAt DESC")
    fun observeAll(): Flow<List<LibraryItem>>

    @Query("SELECT * FROM library_items ORDER BY addedAt ASC")
    suspend fun getAll(): List<LibraryItem>

    @Query("SELECT * FROM library_items WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): LibraryItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: LibraryItem)

    @Update
    suspend fun update(item: LibraryItem)

    @Query("DELETE FROM library_items WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("SELECT COUNT(*) FROM library_items")
    suspend fun count(): Int

    @Query("UPDATE library_items SET lastPosition = :position, progress = :progress WHERE id = :id")
    suspend fun updateProgress(id: String, position: Long, progress: Int)

    @Query("UPDATE library_items SET lastPosition = :position, progress = :progress, durationMs = :durationMs WHERE id = :id")
    suspend fun updatePlayback(id: String, position: Long, progress: Int, durationMs: Long)

    @Query("UPDATE library_items SET shelfX = :x, shelfY = :y WHERE id = :id")
    suspend fun updateShelfPosition(id: String, x: Float, y: Float)

    @Query("UPDATE library_items SET shelfX = -1, shelfY = -1")
    suspend fun resetShelfPositions()
}

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE library_items ADD COLUMN coverPath TEXT")
        db.execSQL("ALTER TABLE library_items ADD COLUMN lastPosition INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE library_items ADD COLUMN durationMs INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE library_items ADD COLUMN shelfX REAL NOT NULL DEFAULT -1")
        db.execSQL("ALTER TABLE library_items ADD COLUMN shelfY REAL NOT NULL DEFAULT -1")
    }
}

@Database(entities = [LibraryItem::class], version = 2, exportSchema = false)
abstract class LibraryDatabase : RoomDatabase() {
    abstract fun libraryDao(): LibraryDao

    companion object {
        @Volatile private var INSTANCE: LibraryDatabase? = null

        fun get(context: Context): LibraryDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    LibraryDatabase::class.java,
                    "libra-library.db"
                ).addMigrations(MIGRATION_1_2).build().also { INSTANCE = it }
            }
    }
}
