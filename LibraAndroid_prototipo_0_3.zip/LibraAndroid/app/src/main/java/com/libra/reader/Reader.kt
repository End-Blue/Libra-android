package com.libra.reader

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.File
import java.util.zip.ZipFile

/**
 * Lector a pantalla completa. onSave(posición, porcentaje) se llama al cambiar de capítulo/página.
 */
@Composable
fun ReaderScreen(item: LibraryItem, onClose: () -> Unit, onSave: (Long, Int) -> Unit) {
    BackHandler(onBack = onClose)
    Column(Modifier.fillMaxSize().background(Ink).systemBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onClose) { Text("‹ Volver", color = Gold) }
            Text(
                item.title, color = Cream, fontSize = 13.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
            )
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (item.format.lowercase()) {
                "epub" -> EpubReader(item, onSave)
                "pdf" -> PdfReader(item, onSave)
                "txt" -> TextFileReader(item, onSave, fb2 = false)
                "fb2" -> TextFileReader(item, onSave, fb2 = true)
                "cbz" -> CbzReader(item, onSave)
                else -> Message(
                    "Los archivos CBR (RAR) todavía no se pueden leer dentro de Libra. " +
                        "Conviértelo a CBZ y vuelve a importarlo."
                )
            }
        }
    }
}

@Composable
private fun Message(text: String) {
    Box(Modifier.fillMaxSize().padding(28.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Cream, fontSize = 15.sp, lineHeight = 22.sp, textAlign = TextAlign.Center)
    }
}

// ───────────────────────────── EPUB ─────────────────────────────

private const val EPUB_HOST = "libra.local"

private class EpubTheme {
    @Volatile var mode: Int = 0
}

private fun chapterUrl(path: String): String =
    Uri.Builder().scheme("https").authority(EPUB_HOST).encodedPath("/" + Uri.encode(path, "/")).build().toString()

private fun styleFor(mode: Int): String {
    val (bg, fg, link) = when (mode) {
        1 -> Triple("#F4ECD8", "#3B2F1E", "#8A5A1F")
        2 -> Triple("#FFFFFF", "#111111", "#1A5FB4")
        else -> Triple("#171716", "#F1E8D8", "#C5A46D")
    }
    return "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">" +
        "<style>html,body{background:$bg !important;color:$fg !important;}" +
        "body{padding:14px 18px !important;line-height:1.6 !important;margin:0 !important;}" +
        "a{color:$link !important;}img,svg{max-width:100% !important;height:auto !important;}" +
        "p,div,span,li,h1,h2,h3,h4{color:$fg !important;}</style>"
}

private fun injectStyle(html: String, mode: Int): String {
    val style = styleFor(mode)
    val index = html.indexOf("</head>", ignoreCase = true)
    return if (index >= 0) html.substring(0, index) + style + html.substring(index) else style + html
}

private fun emptyResponse(status: Int, reason: String) =
    WebResourceResponse("text/plain", "utf-8", status, reason, emptyMap(), ByteArrayInputStream(ByteArray(0)))

private fun serveEpub(pkg: EpubPackage, theme: EpubTheme, uri: Uri): WebResourceResponse {
    // Todo lo que no sea del propio libro se bloquea: el lector funciona sin conexión.
    if (uri.host != EPUB_HOST) return emptyResponse(403, "Blocked")
    return try {
        val path = uri.path?.removePrefix("/") ?: return emptyResponse(404, "Not found")
        val bytes = pkg.readBytes(path) ?: return emptyResponse(404, "Not found")
        val mime = pkg.mimeOf(path)
        if (mime.contains("html")) {
            val styled = injectStyle(String(bytes, Charsets.UTF_8), theme.mode)
            WebResourceResponse("text/html", "utf-8", ByteArrayInputStream(styled.toByteArray(Charsets.UTF_8)))
        } else {
            WebResourceResponse(mime, null, ByteArrayInputStream(bytes))
        }
    } catch (_: Exception) {
        emptyResponse(404, "Not found")
    }
}

@Composable
private fun EpubReader(item: LibraryItem, onSave: (Long, Int) -> Unit) {
    val pkg = remember(item.id) { runCatching { EpubPackage(File(item.localPath)) }.getOrNull() }
    DisposableEffect(pkg) { onDispose { pkg?.close() } }
    if (pkg == null || pkg.spine.isEmpty()) {
        Message("No se pudo abrir este EPUB. Puede estar dañado o protegido con DRM.")
        return
    }
    val theme = remember { EpubTheme() }
    var themeMode by remember { mutableIntStateOf(0) }
    var zoom by remember { mutableIntStateOf(100) }
    var index by remember(item.id) {
        mutableIntStateOf(item.lastPosition.toInt().coerceIn(0, pkg.spine.lastIndex))
    }
    LaunchedEffect(index) { onSave(index.toLong(), (index + 1) * 100 / pkg.spine.size) }

    Column(Modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            factory = { ctx ->
                WebView(ctx).apply {
                    setBackgroundColor(0xFF171716.toInt())
                    settings.javaScriptEnabled = false
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    webViewClient = object : WebViewClient() {
                        override fun shouldInterceptRequest(
                            view: WebView?, request: WebResourceRequest?
                        ): WebResourceResponse? {
                            val uri = request?.url ?: return null
                            return serveEpub(pkg, theme, uri)
                        }

                        override fun shouldOverrideUrlLoading(
                            view: WebView?, request: WebResourceRequest?
                        ): Boolean {
                            val uri = request?.url ?: return true
                            if (uri.host != EPUB_HOST) return true
                            val path = uri.path?.removePrefix("/")
                            val target = if (path != null) pkg.spine.indexOf(path) else -1
                            if (target >= 0) {
                                view?.tag = chapterUrl(pkg.spine[target]) + "|" + theme.mode
                                index = target
                            }
                            return false
                        }
                    }
                }
            },
            update = { wv ->
                theme.mode = themeMode
                wv.settings.textZoom = zoom
                val url = chapterUrl(pkg.spine[index])
                val key = url + "|" + themeMode
                if (wv.tag != key) {
                    wv.tag = key
                    wv.loadUrl(url)
                }
            }
        )
        Row(
            Modifier.fillMaxWidth().background(Panel).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { if (index > 0) index-- }) { Text("‹", color = Gold, fontSize = 24.sp) }
            Text("${index + 1} / ${pkg.spine.size}", color = Muted, fontSize = 12.sp)
            TextButton(onClick = { if (index < pkg.spine.lastIndex) index++ }) {
                Text("›", color = Gold, fontSize = 24.sp)
            }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { zoom = (zoom - 10).coerceAtLeast(70) }) { Text("A−", color = Gold) }
            TextButton(onClick = { zoom = (zoom + 10).coerceAtMost(220) }) { Text("A+", color = Gold) }
            TextButton(onClick = { themeMode = (themeMode + 1) % 3 }) { Text("◐", color = Gold, fontSize = 18.sp) }
        }
    }
}

// ───────────────────────────── PDF ─────────────────────────────

private class PdfHolder(file: File) {
    private val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(pfd)
    private val mutex = Mutex()
    val pageCount: Int = renderer.pageCount

    suspend fun render(index: Int, width: Int): Bitmap = mutex.withLock {
        withContext(Dispatchers.IO) {
            val page = renderer.openPage(index)
            try {
                val height = (width.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(android.graphics.Color.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                bmp
            } finally {
                page.close()
            }
        }
    }

    fun close() {
        runCatching { renderer.close() }
        runCatching { pfd.close() }
    }
}

@Composable
private fun PdfReader(item: LibraryItem, onSave: (Long, Int) -> Unit) {
    val holder = remember(item.id) { runCatching { PdfHolder(File(item.localPath)) }.getOrNull() }
    DisposableEffect(holder) { onDispose { holder?.close() } }
    if (holder == null || holder.pageCount == 0) {
        Message("No se pudo abrir este PDF. Puede estar protegido con contraseña.")
        return
    }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val widthPx = constraints.maxWidth
        val state = rememberLazyListState(
            initialFirstVisibleItemIndex = item.lastPosition.toInt().coerceIn(0, holder.pageCount - 1)
        )
        LaunchedEffect(state) {
            snapshotFlow { state.firstVisibleItemIndex }.collect {
                onSave(it.toLong(), (it + 1) * 100 / holder.pageCount)
            }
        }
        LazyColumn(state = state, modifier = Modifier.fillMaxSize()) {
            items(holder.pageCount) { i ->
                val bitmap by produceState<Bitmap?>(null, i, widthPx) {
                    value = try {
                        holder.render(i, widthPx)
                    } catch (_: Exception) {
                        null
                    }
                }
                val b = bitmap
                Column(Modifier.fillMaxWidth()) {
                    if (b != null) {
                        Image(
                            bitmap = b.asImageBitmap(), contentDescription = null,
                            modifier = Modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth
                        )
                    } else {
                        Box(Modifier.fillMaxWidth().aspectRatio(0.707f).background(Panel))
                    }
                    Spacer(Modifier.height(6.dp))
                }
            }
        }
    }
}

// ───────────────────────────── TXT / FB2 ─────────────────────────────

@Composable
private fun TextFileReader(item: LibraryItem, onSave: (Long, Int) -> Unit, fb2: Boolean) {
    val loaded by produceState<List<String>?>(null, item.id) {
        value = withContext(Dispatchers.IO) {
            try {
                val file = File(item.localPath)
                if (fb2) Fb2Parser.parse(file).paragraphs
                else file.readText().split(Regex("\\r?\\n"))
            } catch (_: Exception) {
                emptyList()
            }
        }
    }
    val paragraphs = loaded
    when {
        paragraphs == null -> Message("Abriendo…")
        paragraphs.isEmpty() -> Message("No se pudo leer el contenido de este archivo.")
        else -> ParagraphList(paragraphs, item.lastPosition.toInt(), onSave)
    }
}

@Composable
private fun ParagraphList(paragraphs: List<String>, start: Int, onSave: (Long, Int) -> Unit) {
    var fontSize by remember { mutableIntStateOf(17) }
    val state = rememberLazyListState(initialFirstVisibleItemIndex = start.coerceIn(0, paragraphs.lastIndex))
    LaunchedEffect(state) {
        snapshotFlow { state.firstVisibleItemIndex }.collect {
            onSave(it.toLong(), (it + 1) * 100 / paragraphs.size)
        }
    }
    Column(Modifier.fillMaxSize()) {
        LazyColumn(state = state, modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 20.dp)) {
            items(paragraphs.size) { i ->
                val p = paragraphs[i]
                if (p.isBlank()) {
                    Spacer(Modifier.height(10.dp))
                } else {
                    Text(
                        p, color = Cream, fontSize = fontSize.sp, lineHeight = (fontSize * 1.55f).sp,
                        modifier = Modifier.padding(vertical = 5.dp)
                    )
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().background(Panel).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Párrafo ${state.firstVisibleItemIndex + 1} / ${paragraphs.size}", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { fontSize = (fontSize - 1).coerceAtLeast(12) }) { Text("A−", color = Gold) }
            TextButton(onClick = { fontSize = (fontSize + 1).coerceAtMost(34) }) { Text("A+", color = Gold) }
        }
    }
}

// ───────────────────────────── CBZ ─────────────────────────────

@Composable
private fun CbzReader(item: LibraryItem, onSave: (Long, Int) -> Unit) {
    val zip = remember(item.id) { runCatching { ZipFile(File(item.localPath)) }.getOrNull() }
    DisposableEffect(zip) { onDispose { runCatching { zip?.close() } } }
    if (zip == null) {
        Message("No se pudo abrir este CBZ.")
        return
    }
    val pages = remember(zip) {
        zip.entries().toList()
            .filter { !it.isDirectory && it.name.substringAfterLast('.').lowercase() in IMAGE_EXTENSIONS }
            .sortedBy { naturalKey(it.name) }
            .map { it.name }
    }
    if (pages.isEmpty()) {
        Message("Este CBZ no contiene imágenes.")
        return
    }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val widthPx = constraints.maxWidth
        val state = rememberLazyListState(
            initialFirstVisibleItemIndex = item.lastPosition.toInt().coerceIn(0, pages.lastIndex)
        )
        LaunchedEffect(state) {
            snapshotFlow { state.firstVisibleItemIndex }.collect {
                onSave(it.toLong(), (it + 1) * 100 / pages.size)
            }
        }
        LazyColumn(state = state, modifier = Modifier.fillMaxSize()) {
            items(pages, key = { it }) { name ->
                val bitmap by produceState<Bitmap?>(null, name, widthPx) {
                    value = withContext(Dispatchers.IO) {
                        try {
                            val entry = zip.getEntry(name)
                            val bytes = zip.getInputStream(entry).use { it.readBytes() }
                            decodeSampled(bytes, widthPx)
                        } catch (_: Exception) {
                            null
                        }
                    }
                }
                val b = bitmap
                if (b != null) {
                    Image(
                        bitmap = b.asImageBitmap(), contentDescription = null,
                        modifier = Modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth
                    )
                } else {
                    Box(Modifier.fillMaxWidth().aspectRatio(0.7f).background(Panel))
                }
            }
        }
    }
}
