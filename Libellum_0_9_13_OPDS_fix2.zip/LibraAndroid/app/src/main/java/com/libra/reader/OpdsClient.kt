package com.libra.reader

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.UUID
import org.json.JSONArray
import org.json.JSONObject

// ══════════════════════════════════════════════════════════════════════════════
// OPDS — modelos, catálogos curados, cliente y descargas
// ══════════════════════════════════════════════════════════════════════════════

data class OpdsCatalog(
    val id: String,
    val name: String,
    val url: String,
    val description: String = "",
    val language: String = "",
    val curated: Boolean = false
)

data class OpdsLink(
    val href: String,
    val rel: String = "",
    val type: String = "",
    val title: String = ""
)

data class OpdsEntry(
    val id: String,
    val title: String,
    val authors: List<String> = emptyList(),
    val summary: String = "",
    val published: String = "",
    val language: String = "",
    val coverUrl: String? = null,
    val links: List<OpdsLink> = emptyList(),
    val categories: List<String> = emptyList()
) {
    val authorText: String get() = authors.joinToString(", ").ifBlank { "Autor desconocido" }

    /** Mejor enlace de descarga (prioriza EPUB). Ignora enlaces de navegación y páginas web. */
    fun bestDownload(): OpdsLink? {
        val downloads = links.filter {
            val r = it.rel.lowercase()
            val t = it.type.lowercase()
            val esNavegacion = t.contains("atom+xml") || t.contains("opds-catalog") ||
                t.contains("opds+json") || t.startsWith("text/html")
            !esNavegacion && (r.contains("acquisition") || t.contains("epub") ||
                t.contains("pdf") || t.contains("octet-stream"))
        }
        return downloads.firstOrNull { it.type.contains("epub", true) }
            ?: downloads.firstOrNull { it.href.contains(".epub", true) }
            ?: downloads.firstOrNull { it.type.contains("pdf", true) }
            ?: downloads.firstOrNull()
    }

    /** Enlace a la ficha completa del libro (ej. Gutenberg: /ebooks/1342.opds). */
    fun detailLink(): OpdsLink? = links.firstOrNull {
        it.type.contains("type=entry", true) ||
            Regex("/ebooks/\\d+\\.opds").containsMatchIn(it.href)
    }

    /** Enlace para abrir una carpeta (sub-catálogo). */
    fun navigationLink(): OpdsLink? {
        links.firstOrNull { it.rel.contains("subsection", true) && detailLink() != it }?.let { return it }
        return links.firstOrNull {
            val r = it.rel.lowercase()
            val t = it.type.lowercase()
            (t.contains("atom+xml") || t.contains("opds-catalog")) &&
                !r.contains("acquisition") && r != "self" && r != "search" &&
                !t.contains("type=entry")
        }
    }
}

data class OpdsFeed(
    val title: String = "",
    val entries: List<OpdsEntry> = emptyList(),
    val nextUrl: String? = null,
    val searchUrl: String? = null
)

/** Catálogos de dominio público de alta calidad, listos para usar. */
object OpdsCatalogs {
    val CURATED = listOf(
        OpdsCatalog(
            id = "gutenberg",
            name = "Project Gutenberg",
            url = "https://www.gutenberg.org/ebooks/search.opds/",
            description = "El mayor archivo de libros de dominio público. Explora por categorías o busca por título o autor.",
            language = "multi",
            curated = true
        ),
        OpdsCatalog(
            id = "gutenberg_es",
            name = "Gutenberg en español",
            url = "https://www.gutenberg.org/ebooks/search.opds/?query=l.es&sort_order=downloads",
            description = "Libros en español de dominio público, los más descargados primero.",
            language = "es",
            curated = true
        ),
        OpdsCatalog(
            id = "standard_ebooks_new",
            name = "Standard Ebooks (novedades)",
            url = "https://standardebooks.org/feeds/opds/new-releases",
            description = "Últimas novedades de Standard Ebooks (clásicos en inglés muy bien cuidados). El resto de sus feeds exige cuenta de mecenas.",
            language = "en",
            curated = true
        )
    )

    private const val PREFS = "libra_opds"
    private const val KEY_CUSTOM = "custom_catalogs"
    private const val KEY_RECENT = "recent_downloads"
    private const val KEY_LAST_CATALOG = "last_catalog_id"

    private fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(PREFS, 0)

    fun custom(ctx: Context): List<OpdsCatalog> {
        val raw = prefs(ctx).getString(KEY_CUSTOM, "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                OpdsCatalog(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    url = o.getString("url"),
                    description = o.optString("description", ""),
                    language = o.optString("language", ""),
                    curated = false
                )
            }
        }.getOrDefault(emptyList())
    }

    fun all(ctx: Context): List<OpdsCatalog> = CURATED + custom(ctx)

    fun saveCustom(ctx: Context, list: List<OpdsCatalog>) {
        val arr = JSONArray()
        list.forEach { c ->
            arr.put(JSONObject().apply {
                put("id", c.id)
                put("name", c.name)
                put("url", c.url)
                put("description", c.description)
                put("language", c.language)
            })
        }
        prefs(ctx).edit().putString(KEY_CUSTOM, arr.toString()).apply()
    }

    fun addCustom(ctx: Context, name: String, url: String, description: String = ""): OpdsCatalog {
        val cleanUrl = url.trim().let { if (it.startsWith("http")) it else "https://$it" }
        val cat = OpdsCatalog(
            id = "custom_${UUID.randomUUID().toString().take(8)}",
            name = name.trim().ifBlank { "Catálogo personalizado" },
            url = cleanUrl,
            description = description.trim(),
            curated = false
        )
        val list = custom(ctx).toMutableList()
        list.add(0, cat)
        saveCustom(ctx, list)
        return cat
    }

    fun removeCustom(ctx: Context, id: String) {
        saveCustom(ctx, custom(ctx).filter { it.id != id })
    }

    fun lastCatalogId(ctx: Context): String? =
        prefs(ctx).getString(KEY_LAST_CATALOG, null)

    fun setLastCatalogId(ctx: Context, id: String) {
        prefs(ctx).edit().putString(KEY_LAST_CATALOG, id).apply()
    }

    data class RecentDownload(
        val title: String,
        val author: String,
        val catalogName: String,
        val at: Long,
        val coverUrl: String? = null
    )

    fun recentDownloads(ctx: Context): List<RecentDownload> {
        val raw = prefs(ctx).getString(KEY_RECENT, "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                RecentDownload(
                    title = o.getString("title"),
                    author = o.optString("author", ""),
                    catalogName = o.optString("catalog", ""),
                    at = o.optLong("at", 0L),
                    coverUrl = o.optString("cover", null)
                )
            }
        }.getOrDefault(emptyList())
    }

    fun pushRecent(ctx: Context, entry: OpdsEntry, catalogName: String) {
        val list = recentDownloads(ctx).toMutableList()
        list.removeAll { it.title == entry.title && it.author == entry.authorText }
        list.add(0, RecentDownload(
            title = entry.title,
            author = entry.authorText,
            catalogName = catalogName,
            at = System.currentTimeMillis(),
            coverUrl = entry.coverUrl
        ))
        val trimmed = list.take(30)
        val arr = JSONArray()
        trimmed.forEach { r ->
            arr.put(JSONObject().apply {
                put("title", r.title)
                put("author", r.author)
                put("catalog", r.catalogName)
                put("at", r.at)
                if (r.coverUrl != null) put("cover", r.coverUrl)
            })
        }
        prefs(ctx).edit().putString(KEY_RECENT, arr.toString()).apply()
    }
}

object OpdsClient {

    private const val UA = "Libellum/0.9.13 (Android; OPDS)"
    private const val UA_BROWSER = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
    private const val TIMEOUT = 20_000
    private const val MAX_REDIRECTS = 8

    suspend fun fetchFeed(url: String): Result<OpdsFeed> = withContext(Dispatchers.IO) {
        runCatching {
            var last: Throwable? = null
            for (candidate in alternatives(url)) {
                try {
                    return@runCatching parseFeed(openUrl(candidate), candidate)
                } catch (e: Exception) {
                    last = e
                }
            }
            throw last ?: IllegalStateException("No se pudo cargar el catálogo")
        }
    }

    /** Direcciones equivalentes que se prueban en orden si la principal da 404/5xx. */
    private fun alternatives(url: String): List<String> {
        val u = url.trim()
        val list = mutableListOf(u)
        val isGutRoot = Regex("^https?://(www|m)\\.gutenberg\\.org/ebooks(\\.opds|/search\\.opds)/?$")
            .matches(u)
        if (isGutRoot) {
            listOf(
                "https://www.gutenberg.org/ebooks/search.opds/",
                "https://m.gutenberg.org/ebooks.opds/",
                "https://www.gutenberg.org/ebooks.opds/",
                "https://gutenberg.org/ebooks/search.opds/"
            ).forEach { if (it !in list) list.add(it) }
        } else if (u.startsWith("http://")) {
            list.add("https://" + u.removePrefix("http://"))
        }
        return list
    }

    /**
     * Busca en un catálogo. [searchLink] es el enlace "search" que declara el propio feed
     * (plantilla con {searchTerms} o descripción OpenSearch).
     */
    suspend fun search(
        catalogUrl: String,
        query: String,
        searchLink: String? = null
    ): Result<OpdsFeed> = withContext(Dispatchers.IO) {
        runCatching {
            val q = query.trim()
            if (q.isEmpty()) error("Consulta vacía")
            // Catálogos de Gutenberg filtrados por idioma (l.es): conservar el filtro
            val lang = if (catalogUrl.contains("gutenberg.org")) {
                Regex("(?:^|[=+ &])l\\.([a-z]{2})(?:$|[+ &])")
                    .find(runCatching { URLDecoder.decode(catalogUrl, "UTF-8") }.getOrDefault(catalogUrl))
                    ?.groupValues?.get(1)
            } else null
            val term = if (lang != null) "$q l.$lang" else q
            val encoded = URLEncoder.encode(term, "UTF-8")
            val target = searchTarget(catalogUrl, encoded, searchLink)
            parseFeed(openUrl(target), target)
        }
    }

    private fun searchTarget(catalogUrl: String, encoded: String, searchLink: String?): String {
        if (!searchLink.isNullOrBlank()) {
            if (searchLink.contains("{searchTerms}")) {
                return cleanTemplate(searchLink).replace("{searchTerms}", encoded)
            }
            val tpl = runCatching { openSearchTemplate(searchLink) }.getOrNull()
            if (tpl != null) return tpl.replace("{searchTerms}", encoded)
        }
        val host = runCatching { URL(catalogUrl).host }.getOrDefault("")
        return when {
            host.contains("gutenberg.org") ->
                "https://www.gutenberg.org/ebooks/search.opds/?query=$encoded"
            host.contains("standardebooks.org") ->
                "https://standardebooks.org/feeds/opds/all?query=$encoded"
            else -> error("Este catálogo no declara búsqueda. Explóralo por sus carpetas.")
        }
    }

    private fun cleanTemplate(t: String): String {
        var r = t.replace(Regex("[&?][^=&?{}]+=\\{[^}]*\\?\\}"), "")
        r = r.replace(Regex("\\{[^}]*\\?\\}"), "")
        if (!r.contains("?") && r.contains("&")) r = r.replaceFirst("&", "?")
        return r
    }

    /** Lee una descripción OpenSearch y devuelve la plantilla Atom/OPDS. */
    private fun openSearchTemplate(descUrl: String): String? {
        val xml = openUrl(descUrl)
        val parser = XmlPullParserFactory.newInstance().apply { isNamespaceAware = true }.newPullParser()
        parser.setInput(xml.trimStart('\uFEFF', ' ', '\n', '\r', '\t').reader())
        var first: String? = null
        var best: String? = null
        var ev = parser.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG && parser.name.equals("Url", true)) {
                val tpl = parser.attr("template")
                val type = parser.attr("type").lowercase()
                if (tpl.isNotBlank() && tpl.contains("{searchTerms")) {
                    val abs = resolve(tpl, descUrl)
                    if (first == null && !type.contains("html")) first = abs
                    if (best == null && (type.contains("atom") || type.contains("opds"))) best = abs
                }
            }
            ev = parser.next()
        }
        val chosen = best ?: first ?: return null
        return cleanTemplate(chosen).replace("{searchTerms?}", "{searchTerms}")
    }

    /**
     * Descarga el mejor archivo del entry y lo deja en [destDir].
     * Devuelve el File resultante o lanza.
     */
    suspend fun downloadEntry(
        entry: OpdsEntry,
        destDir: File,
        onProgress: ((Float) -> Unit)? = null
    ): File = withContext(Dispatchers.IO) {
        val link = entry.bestDownload() ?: error("Este libro no tiene enlace de descarga")
        val href = absoluteUrl(link.href, entry.id)
        val safeName = entry.title
            .replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .take(80)
            .ifBlank { "libro" }
        val tmp = File(destDir, "${safeName}_${System.currentTimeMillis()}.part")
        downloadFile(href, tmp, onProgress)
        // El formato real se decide por el contenido del archivo, no por lo que dice el catálogo
        val head = ByteArray(5)
        val n = tmp.inputStream().use { it.read(head) }
        val ext = when {
            n >= 4 && head[0] == '%'.code.toByte() && head[1] == 'P'.code.toByte() &&
                head[2] == 'D'.code.toByte() && head[3] == 'F'.code.toByte() -> "pdf"
            n >= 2 && head[0] == 'P'.code.toByte() && head[1] == 'K'.code.toByte() -> "epub"
            link.type.contains("pdf", true) || href.contains(".pdf", true) -> "pdf"
            link.type.contains("fb2", true) -> "fb2"
            else -> "epub"
        }
        val out = File(destDir, "${safeName}_${System.currentTimeMillis()}.$ext")
        if (!tmp.renameTo(out)) {
            tmp.copyTo(out, overwrite = true)
            tmp.delete()
        }
        out
    }

    /** Abre la conexión siguiendo redirecciones a mano (incluye http → https) y falla con mensajes claros. */
    private fun connect(urlStr: String, accept: String, readTimeoutMs: Int): HttpURLConnection {
        var lastError: Exception? = null
        // Intento 1: UA de Libellum. Intento 2 y 3: tras una pausa, UA de navegador (503/429/403 suelen ser temporales o por UA)
        val agents = listOf(UA, UA_BROWSER, UA_BROWSER)
        for ((i, agent) in agents.withIndex()) {
            try {
                return connectOnce(urlStr, accept, readTimeoutMs, agent)
            } catch (e: RetryableHttp) {
                lastError = e
                if (i < agents.lastIndex) Thread.sleep(1500L * (i + 1))
            }
        }
        throw IllegalStateException(lastError?.message ?: "No se pudo conectar")
    }

    private class RetryableHttp(msg: String) : Exception(msg)

    private fun connectOnce(urlStr: String, accept: String, readTimeoutMs: Int, agent: String): HttpURLConnection {
        var current = urlStr.trim()
        var hops = 0
        while (true) {
            val conn = (URL(current).openConnection() as HttpURLConnection).apply {
                connectTimeout = TIMEOUT
                readTimeout = readTimeoutMs
                instanceFollowRedirects = false
                setRequestProperty("User-Agent", agent)
                setRequestProperty("Accept", accept)
                setRequestProperty("Accept-Language", "es,en;q=0.8")
            }
            val code = conn.responseCode
            if (code in 300..399 && code != 304) {
                val loc = conn.getHeaderField("Location")
                conn.disconnect()
                if (loc.isNullOrBlank() || ++hops > MAX_REDIRECTS) error("Demasiadas redirecciones")
                current = URL(URL(current), loc).toString()
                continue
            }
            if (code !in 200..299) {
                conn.disconnect()
                val host = runCatching { URL(current).host }.getOrDefault("")
                val msg = when (code) {
                    401 -> "El catálogo exige cuenta (HTTP 401, $host)."
                    403 -> "Acceso denegado por el servidor (HTTP 403, $host)."
                    404 -> "No se encontró esa dirección (HTTP 404, $host)."
                    429, 503 -> "El servidor está saturado o limita las peticiones (HTTP $code, $host). Inténtalo en unos minutos."
                    else -> "El servidor respondió con error (HTTP $code, $host)."
                }
                if (code == 403 || code == 429 || code in 500..599) throw RetryableHttp(msg)
                error(msg)
            }
            return conn
        }
    }

    private fun openUrl(urlStr: String): String {
        val conn = connect(
            urlStr,
            "application/atom+xml, application/opds+xml, application/xml, text/xml;q=0.9, */*;q=0.5",
            TIMEOUT
        )
        return try {
            conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun downloadFile(urlStr: String, dest: File, onProgress: ((Float) -> Unit)?) {
        val conn = connect(urlStr, "application/epub+zip, application/pdf, */*", 60_000)
        try {
            val ctype = (conn.contentType ?: "").lowercase()
            if (ctype.startsWith("text/html")) {
                error("El servidor devolvió una página web en lugar del libro.")
            }
            val total = conn.contentLengthLong.coerceAtLeast(0L)
            BufferedInputStream(conn.inputStream).use { input ->
                FileOutputStream(dest).use { output ->
                    val buf = ByteArray(16 * 1024)
                    var read = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        if (n == 0) continue
                        output.write(buf, 0, n)
                        read += n
                        if (total > 0 && onProgress != null) {
                            onProgress((read.toFloat() / total).coerceIn(0f, 1f))
                        }
                    }
                }
            }
            if (dest.length() < 100) error("La descarga llegó vacía.")
            onProgress?.invoke(1f)
        } finally {
            conn.disconnect()
        }
    }

    private fun absoluteUrl(href: String, baseHint: String): String {
        if (href.startsWith("http://") || href.startsWith("https://")) return href
        return try {
            URL(URL(baseHint), href).toString()
        } catch (_: Exception) {
            href
        }
    }

    // ── Parser Atom / OPDS ────────────────────────────────────────────────────

    /** Lee todo el texto de un elemento (aunque tenga hijos XHTML) y termina en su etiqueta de cierre. */
    private fun XmlPullParser.readAllText(): String {
        val sb = StringBuilder()
        var depth = 1
        while (depth > 0) {
            when (next()) {
                XmlPullParser.TEXT, XmlPullParser.CDSECT, XmlPullParser.ENTITY_REF ->
                    sb.append(text ?: "")
                XmlPullParser.START_TAG -> {
                    depth++
                    sb.append(' ')
                }
                XmlPullParser.END_TAG -> depth--
                XmlPullParser.END_DOCUMENT -> return sb.toString()
            }
        }
        return sb.toString()
    }

    private fun parseFeed(rawXml: String, baseUrl: String): OpdsFeed {
        val xml = rawXml.trimStart('\uFEFF', ' ', '\n', '\r', '\t')
        if (xml.startsWith("{") || xml.startsWith("[")) {
            error("Este catálogo usa OPDS 2.0 (JSON), que aún no es compatible.")
        }
        val head = xml.take(400).lowercase()
        if (!head.startsWith("<") || (head.contains("<html") && !head.contains("<feed"))) {
            error("La dirección no es un catálogo OPDS (devolvió una página web).")
        }

        val factory = XmlPullParserFactory.newInstance().apply { isNamespaceAware = true }
        val parser = factory.newPullParser()
        parser.setInput(xml.reader())

        var feedTitle = ""
        var nextUrl: String? = null
        var searchUrl: String? = null
        val entries = mutableListOf<OpdsEntry>()

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                when (parser.name.lowercase()) {
                    "title" -> {
                        if (entries.isEmpty() && feedTitle.isEmpty()) {
                            feedTitle = parser.readAllText().trim()
                        }
                    }
                    "link" -> {
                        val rel = parser.attr("rel").lowercase()
                        val href = parser.attr("href")
                        val type = parser.attr("type").lowercase()
                        if (href.isNotBlank()) {
                            when {
                                rel == "next" -> nextUrl = resolve(href, baseUrl)
                                rel == "search" || type.contains("opensearch") -> {
                                    val abs = resolve(href, baseUrl)
                                    // Preferir la plantilla directa a la descripción OpenSearch
                                    if (searchUrl == null || abs.contains("{searchTerms}")) searchUrl = abs
                                }
                            }
                        }
                    }
                    "entry" -> {
                        entries.add(parseEntry(parser, baseUrl))
                    }
                }
            }
            event = parser.next()
        }
        return OpdsFeed(
            title = feedTitle.ifBlank { "Catálogo" },
            entries = entries,
            nextUrl = nextUrl,
            searchUrl = searchUrl
        )
    }

    private fun parseEntry(parser: XmlPullParser, baseUrl: String): OpdsEntry {
        var id = ""
        var title = ""
        var summary = ""
        var published = ""
        var language = ""
        val authors = mutableListOf<String>()
        val links = mutableListOf<OpdsLink>()
        val categories = mutableListOf<String>()
        var cover: String? = null

        var event = parser.next()
        while (event != XmlPullParser.END_DOCUMENT &&
            !(event == XmlPullParser.END_TAG && parser.name.equals("entry", true))
        ) {
            if (event == XmlPullParser.START_TAG) {
                when (parser.name.lowercase()) {
                    "id" -> id = parser.readAllText().trim()
                    "title" -> title = parser.readAllText().trim()
                    "summary", "content" -> {
                        val t = parser.readAllText().trim()
                        if (t.isNotBlank() && summary.isBlank()) summary = stripHtml(t)
                    }
                    "published", "updated", "date", "issued" -> {
                        val t = parser.readAllText().trim().take(10)
                        if (published.isBlank()) published = t
                    }
                    "language" -> language = parser.readAllText().trim()
                    "name" -> {
                        val n = parser.readAllText().trim()
                        if (n.isNotBlank()) authors.add(n)
                    }
                    "category" -> {
                        val term = parser.attr("label").ifBlank { parser.attr("term") }
                        if (term.isNotBlank()) categories.add(term)
                    }
                    "link" -> {
                        val href = parser.attr("href")
                        val rel = parser.attr("rel")
                        val type = parser.attr("type")
                        val linkTitle = parser.attr("title")
                        if (href.isNotBlank()) {
                            val abs = resolve(href, baseUrl)
                            links.add(OpdsLink(abs, rel, type, linkTitle))
                            val isImage = rel.contains("image", true) || rel.contains("thumbnail", true) ||
                                type.startsWith("image/", true)
                            if (isImage) {
                                val isThumb = rel.contains("thumbnail", true)
                                if (cover == null || !isThumb) cover = abs
                            }
                        }
                    }
                }
            }
            event = parser.next()
        }

        // Gutenberg: en los resultados el autor viene en <content> y el libro es un enlace a su ficha
        val hasAcq = links.any { it.rel.contains("acquisition", true) }
        val esFichaGutenberg = links.any { Regex("/ebooks/\\d+\\.opds").containsMatchIn(it.href) }
        if (authors.isEmpty() && !hasAcq && esFichaGutenberg && summary.isNotBlank() && summary.length <= 120) {
            authors.add(summary)
            summary = ""
        }

        if (id.isBlank()) id = title.ifBlank { UUID.randomUUID().toString() }
        return OpdsEntry(
            id = id,
            title = title.ifBlank { "Sin título" },
            authors = authors.distinct(),
            summary = summary,
            published = published,
            language = language,
            coverUrl = cover,
            links = links,
            categories = categories.distinct()
        )
    }

    private fun XmlPullParser.attr(name: String): String {
        for (i in 0 until attributeCount) {
            if (getAttributeName(i).equals(name, true)) return getAttributeValue(i) ?: ""
        }
        for (i in 0 until attributeCount) {
            if (getAttributeName(i).substringAfter(':').equals(name, true))
                return getAttributeValue(i) ?: ""
        }
        return ""
    }

    private fun resolve(href: String, base: String): String {
        if (href.startsWith("http://") || href.startsWith("https://")) return href
        return try { URL(URL(base), href).toString() } catch (_: Exception) { href }
    }

    private fun stripHtml(s: String): String =
        s.replace(Regex("<[^>]+>"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(600)
}
