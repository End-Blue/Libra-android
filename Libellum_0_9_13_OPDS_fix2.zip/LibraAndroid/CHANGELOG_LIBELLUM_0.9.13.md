# Libellum 0.9.13 — OPDS: errores 404 / 503

- Gutenberg: la raíz ahora usa la dirección oficial vigente (/ebooks/search.opds/) y, si falla, prueba automáticamente m.gutenberg.org y otras equivalentes.
- Si una dirección http falla, se prueba su versión https.
- Errores 503/429/403 y 5xx: hasta 3 intentos con pausa y cambio de User-Agent; el mensaje indica el servidor y el código.
- No se necesita iniciar sesión en Gutenberg ni en Standard Ebooks (novedades).
