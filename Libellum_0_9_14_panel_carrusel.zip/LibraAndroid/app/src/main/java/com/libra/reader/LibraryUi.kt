@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.libra.reader

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

// ══════════════════════════════════════════════════════════════════════════════
// MI BIBLIOTECA — diseño «papel dorado»
// ══════════════════════════════════════════════════════════════════════════════

private val LIB_SORTS = listOf(
    "RECENT" to "Recientes", "TITLE" to "Título", "AUTHOR" to "Autor",
    "RATING" to "Valoración", "PROGRESS" to "Progreso"
)

@Composable
fun LibraryScreen2(
    books: List<LibraryItem>,
    totalCount: Int,
    searchQuery: String,
    onSearch: (String) -> Unit,
    onDetail: (LibraryItem) -> Unit,
    onOpen: (LibraryItem) -> Unit,
    onToggleFavorite: (LibraryItem) -> Unit,
    onImport: () -> Unit,
    onScan: () -> Unit
) {
    val ctx = LocalContext.current
    var statusFilter by rememberPrefString("ui_lib_status", "")
    var author by rememberPrefString("ui_lib_author", "")
    var genre by rememberPrefString("ui_lib_genre", "")
    var format by rememberPrefString("ui_lib_format", "")
    var minRating by rememberPrefString("ui_lib_rating", "")
    var sort by rememberPrefString("ui_lib_sort", "RECENT")
    var grid by rememberPrefBool("ui_lib_grid", true)
    var showFilters by remember { mutableStateOf(false) }
    var sortMenu by remember { mutableStateOf(false) }

    val filtered = books.filter { b ->
        (statusFilter.isEmpty() || b.statusKey() == statusFilter) &&
            (author.isEmpty() || b.author == author) &&
            (genre.isEmpty() || b.genreLabel() == genre) &&
            (format.isEmpty() || b.format == format) &&
            (minRating.isEmpty() || b.rating >= minRating.first().digitToInt())
    }
    val sorted = when (sort) {
        "TITLE" -> filtered.sortedBy { it.title.lowercase() }
        "AUTHOR" -> filtered.sortedBy { it.author.lowercase() }
        "RATING" -> filtered.sortedByDescending { it.rating }
        "PROGRESS" -> filtered.sortedByDescending { it.progress }
        else -> filtered.sortedByDescending { it.addedAt }
    }
    val activeFilters = listOf(author, genre, format, minRating).count { it.isNotEmpty() }
    val readingBook = books.filter { it.statusKey() == "READING" }.maxByOrNull { it.startedAt }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 18.dp)
    ) {
        item {
            HeroHeader(
                art = R.drawable.hero_library,
                title = "Mi Biblioteca",
                sub = when (totalCount) {
                    0 -> "Tu colección empieza aquí."
                    1 -> "1 historia espera ser descubierta."
                    else -> "$totalCount historias esperan ser descubiertas."
                },
                quote = "",
                titleSize = 38,
                subSize = 16,
                subItalic = true,
                subWidth = 0.96f
            )
        }

        // ── Buscar y filtrar ──
        item {
            Row(
                Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val shape = RoundedCornerShape(26.dp)
                Row(
                    Modifier.weight(1f).height(52.dp)
                        .shadow(2.dp, shape, ambientColor = Color(0x22805020), spotColor = Color(0x22805020))
                        .clip(shape).background(Color(0xFFFBF2E0)).border(1.dp, LbCardEdge, shape)
                        .padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LibIcon(LibIconKind.SEARCH, tint = LbBrown, accent = LbBrown, size = 22.dp)
                    Spacer(Modifier.width(10.dp))
                    BasicTextField(
                        value = searchQuery,
                        onValueChange = onSearch,
                        singleLine = true,
                        textStyle = TextStyle(color = LbTitle, fontSize = 15.sp, fontFamily = LibellumSerif),
                        cursorBrush = SolidColor(LbBrown),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = {}),
                        modifier = Modifier.weight(1f),
                        decorationBox = { inner ->
                            Box(contentAlignment = Alignment.CenterStart) {
                                if (searchQuery.isEmpty()) {
                                    Text(
                                        "Buscar libros, autores o sagas…", color = LbMuted, fontSize = 15.sp,
                                        fontFamily = LibellumSerif, fontStyle = FontStyle.Italic, maxLines = 1
                                    )
                                }
                                inner()
                            }
                        }
                    )
                    if (searchQuery.isNotEmpty()) {
                        Box(Modifier.size(28.dp).clip(CircleShape).clickable { onSearch("") }, contentAlignment = Alignment.Center) {
                            LibIcon(LibIconKind.CLOSE, tint = LbMuted, accent = LbMuted, size = 16.dp)
                        }
                    }
                }
                Spacer(Modifier.width(10.dp))
                Row(
                    Modifier.height(52.dp)
                        .shadow(2.dp, shape, ambientColor = Color(0x22805020), spotColor = Color(0x22805020))
                        .clip(shape)
                        .background(if (activeFilters > 0) Color(0xFFF2D8B0) else Color(0xFFF6E9D2))
                        .border(1.dp, LbCardEdge, shape)
                        .clickable { showFilters = true }
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LbIcon(LbIconKind.FILTER, tint = LbBrown, size = 22.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (activeFilters > 0) "Filtrar · $activeFilters" else "Filtrar",
                        color = LbTitle, fontSize = 15.sp, fontFamily = LibellumSerif
                    )
                }
            }
        }

        // ── Continuar leyendo ──
        if (readingBook != null) {
            item {
                LbSectionHeader(
                    "Continuar leyendo",
                    icon = { LbIcon(LbIconKind.BOOK_OPEN, size = 28.dp) },
                    trailing = { LbLink("Ver todos") { statusFilter = "READING" } },
                    modifier = Modifier.padding(horizontal = 18.dp)
                )
            }
            item {
                val prefs = remember(ctx) { ctx.getSharedPreferences("libra_reading_stats", 0) }
                val totalMs = prefs.getLong("book_total_${readingBook.id}", 0L)
                val p = readingBook.progress.coerceIn(0, 100)
                val remainingMs = if (p in 1..99 && totalMs > 0L) totalMs * (100 - p) / p else 0L
                Box(Modifier.padding(horizontal = 18.dp).fillMaxWidth()) {
                    LbCard(Modifier.fillMaxWidth(), padding = 12.dp, onClick = { onOpen(readingBook) }) {
                        Box(Modifier.fillMaxWidth()) {
                            Image(
                                painter = painterResource(R.drawable.card_continue),
                                contentDescription = null,
                                contentScale = ContentScale.FillWidth,
                                alignment = Alignment.TopEnd,
                                modifier = Modifier.align(Alignment.TopEnd).fillMaxWidth(0.62f)
                            )
                            Row {
                                BookCover(
                                    readingBook,
                                    Modifier.size(width = 82.dp, height = 118.dp)
                                        .shadow(4.dp, RoundedCornerShape(8.dp)).clip(RoundedCornerShape(8.dp))
                                )
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        readingBook.title, color = LbTitle, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                                        fontFamily = LibellumSerif, maxLines = 2, overflow = TextOverflow.Ellipsis,
                                        lineHeight = 21.sp, modifier = Modifier.padding(end = 30.dp)
                                    )
                                    Text(
                                        readingBook.author, color = LbMuted, fontSize = 13.sp, fontFamily = LibellumSerif,
                                        fontStyle = FontStyle.Italic, maxLines = 1, overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(Modifier.height(6.dp))
                                    Box(
                                        Modifier.clip(RoundedCornerShape(50)).background(LbBrown)
                                            .padding(horizontal = 14.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            "LEYENDO", color = Color(0xFFFDF1DC), fontSize = 11.sp,
                                            letterSpacing = 1.5.sp, fontFamily = LibellumSerif
                                        )
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        LbProgress(p / 100f, Modifier.weight(1f), height = 9.dp)
                                        Spacer(Modifier.width(8.dp))
                                        Text("$p%", color = LbTitle, fontSize = 14.sp, fontFamily = LibellumSerif)
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        LbIcon(LbIconKind.DOC, size = 18.dp)
                                        Spacer(Modifier.width(4.dp))
                                        Text(
                                            readingBook.format, color = LbText, fontSize = 12.sp,
                                            fontFamily = LibellumSerif, fontStyle = FontStyle.Italic, maxLines = 1
                                        )
                                        Spacer(Modifier.width(10.dp))
                                        LbIcon(LbIconKind.CLOCK, size = 18.dp)
                                        Spacer(Modifier.width(4.dp))
                                        Text(
                                            if (remainingMs > 0L) "${formatReadingTime(remainingMs)} restantes" else "Sin estimar",
                                            color = LbText, fontSize = 12.sp, fontFamily = LibellumSerif,
                                            fontStyle = FontStyle.Italic, maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(
                            Modifier.fillMaxWidth().height(50.dp)
                                .shadow(3.dp, RoundedCornerShape(50), ambientColor = Color(0x33805020), spotColor = Color(0x55805020))
                                .clip(RoundedCornerShape(50))
                                .background(Brush.verticalGradient(listOf(Color(0xFF9A5A0C), LbBrown)))
                                .clickable { onOpen(readingBook) },
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            LibIcon(LibIconKind.PLAY, tint = Color(0xFFFDF1DC), size = 22.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(
                                "Continuar leyendo", color = Color(0xFFFDF1DC), fontSize = 17.sp,
                                fontFamily = LibellumSerif, fontStyle = FontStyle.Italic, fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                    RibbonMark(
                        Modifier.align(Alignment.TopEnd).padding(end = 26.dp),
                        on = readingBook.isFavorite == 1,
                        onClick = { onToggleFavorite(readingBook) }
                    )
                }
            }
        }

        // ── Estados ──
        item {
            Row(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("" to "Todos", "TBR" to "Por leer", "READING" to "Leyendo", "FINISHED" to "Terminados")
                    .forEach { (k, label) ->
                        val n = if (k.isEmpty()) books.size else books.count { it.statusKey() == k }
                        val sel = statusFilter == k
                        val shape = RoundedCornerShape(16.dp)
                        Box(
                            Modifier.weight(1f).height(46.dp)
                                .shadow(if (sel) 3.dp else 1.dp, shape, ambientColor = Color(0x22805020), spotColor = Color(0x33805020))
                                .clip(shape)
                                .background(if (sel) LbBrown else Color(0xFFFBF2E0))
                                .border(1.dp, if (sel) LbBrown else LbCardEdge, shape)
                                .clickable { statusFilter = k },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "$label · $n", color = if (sel) Color(0xFFFDF1DC) else LbTitle, fontSize = 11.5.sp,
                                fontFamily = LibellumSerif, fontStyle = FontStyle.Italic, maxLines = 1, softWrap = false
                            )
                        }
                    }
            }
        }

        // ── Contador, orden y vista ──
        item {
            Row(
                Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "${sorted.size} ${if (sorted.size == 1) "libro" else "libros"}", color = LbTitle, fontSize = 22.sp,
                    fontFamily = LibellumSerif, fontStyle = FontStyle.Italic, maxLines = 1,
                    modifier = Modifier.weight(1f)
                )
                Box {
                    Row(
                        Modifier.clip(RoundedCornerShape(8.dp)).clickable { sortMenu = true }.padding(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Ordenar por ", color = LbMuted, fontSize = 12.sp, fontFamily = LibellumSerif, fontStyle = FontStyle.Italic)
                        Text(
                            LIB_SORTS.firstOrNull { it.first == sort }?.second ?: "Recientes",
                            color = LbTitle, fontSize = 14.sp, fontFamily = LibellumSerif, maxLines = 1
                        )
                        Spacer(Modifier.width(2.dp))
                        LbIcon(LbIconKind.CHEVRON_DOWN, tint = LbBrown, size = 16.dp)
                    }
                    DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                        LIB_SORTS.forEach { (key, label) ->
                            DropdownMenuItem(
                                text = { Text((if (sort == key) "✓  " else "     ") + label) },
                                onClick = { sort = key; sortMenu = false }
                            )
                        }
                    }
                }
                Spacer(Modifier.width(8.dp))
                ViewToggle(grid) { grid = true }
                Spacer(Modifier.width(6.dp))
                ViewToggle(!grid, isList = true) { grid = false }
            }
        }

        // ── Libros ──
        if (totalCount == 0) {
            item {
                LbCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), padding = 16.dp) {
                    Text(
                        "Aún no hay libros", color = LbTitle, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                        fontFamily = LibellumSerif, fontStyle = FontStyle.Italic
                    )
                    Spacer(Modifier.height(4.dp))
                    Text("Importa tus archivos o usa el escáner para añadir tu colección.", color = LbText, fontSize = 13.sp, lineHeight = 19.sp)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = onImport, modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = LbBrown, contentColor = Color(0xFFFDF1DC))
                        ) { Text("Importar") }
                        OutlinedButton(onClick = onScan, modifier = Modifier.weight(1f)) {
                            Text("Escanear", color = LbBrown)
                        }
                    }
                }
            }
        } else if (sorted.isEmpty()) {
            item {
                Text(
                    "Ningún libro coincide con la búsqueda o los filtros.", color = LbMuted, fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)
                )
            }
        } else if (grid) {
            items(sorted.chunked(3), key = { it.first().id }) { row ->
                Row(
                    Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    row.forEach { b -> LibBookTile(b, Modifier.weight(1f), onDetail, onOpen, onToggleFavorite) }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        } else {
            items(sorted, key = { it.id }) { b ->
                LibBookRow(b, Modifier.padding(horizontal = 18.dp), onDetail, onOpen, onToggleFavorite)
            }
        }
    }

    // ── Hoja de filtros ──
    if (showFilters) {
        ModalBottomSheet(onDismissRequest = { showFilters = false }, containerColor = LbBg) {
            Column(
                Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp).padding(bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Filtrar biblioteca", color = LbTitle, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                        fontFamily = LibellumSerif, fontStyle = FontStyle.Italic, modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = { author = ""; genre = ""; format = ""; minRating = "" }) {
                        Text("Limpiar", color = LbBrown)
                    }
                }
                LbSelect("Autor", author, books.map { it.author }.distinct().sorted(), { author = it })
                LbSelect("Género", genre, books.map { it.genreLabel() }.distinct().sorted(), { genre = it })
                LbSelect("Formato", format, books.map { it.format }.distinct().sorted(), { format = it })
                LbSelect("Valoración", minRating, listOf("1+", "2+", "3+", "4+", "5"), { minRating = it })
                Button(
                    onClick = { showFilters = false }, modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = LbBrown, contentColor = Color(0xFFFDF1DC))
                ) { Text("Ver ${sorted.size} libros") }
            }
        }
    }
}

@Composable
private fun LbSelect(label: String, value: String, options: List<String>, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(16.dp)
    Box(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().clip(shape).background(Color(0xFFFBF2E0)).border(1.dp, LbCardEdge, shape)
                .clickable { open = true }.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, color = LbMuted, fontSize = 14.sp, fontFamily = LibellumSerif, modifier = Modifier.weight(1f))
            Text(
                value.ifEmpty { "Todos" }, color = if (value.isEmpty()) LbMuted else LbBrown, fontSize = 14.sp,
                fontFamily = LibellumSerif, fontWeight = if (value.isEmpty()) FontWeight.Normal else FontWeight.Bold
            )
            Spacer(Modifier.width(6.dp))
            LbIcon(LbIconKind.CHEVRON_DOWN, tint = LbBrown, size = 16.dp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(text = { Text("Todos") }, onClick = { onPick(""); open = false })
            options.forEach { o ->
                DropdownMenuItem(text = { Text(o) }, onClick = { onPick(o); open = false })
            }
        }
    }
}

@Composable
private fun ViewToggle(selected: Boolean, isList: Boolean = false, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier.size(38.dp).clip(shape)
            .background(if (selected) LbBrown else Color.Transparent)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        LibIcon(
            if (isList) LibIconKind.LIST else LibIconKind.GRID,
            tint = if (selected) Color(0xFFFDF1DC) else LbText,
            accent = if (selected) Color(0xFFFDF1DC) else LbText,
            size = 22.dp, filled = selected
        )
    }
}

@Composable
private fun StatusPill(b: LibraryItem, modifier: Modifier = Modifier) {
    val (text, bg) = when (b.statusKey()) {
        "READING" -> "LEYENDO" to Color(0xFFB87A1F)
        "FINISHED" -> "TERMINADO" to Color(0xFF3F7A45)
        else -> "PENDIENTE" to Color(0xCC6B655E)
    }
    Box(modifier.clip(RoundedCornerShape(8.dp)).background(bg).padding(horizontal = 7.dp, vertical = 2.dp)) {
        Text(text, color = Color(0xFFFDF1DC), fontSize = 9.sp, letterSpacing = 0.6.sp, fontFamily = LibellumSerif, maxLines = 1)
    }
}

@Composable
private fun BookMenu(
    b: LibraryItem,
    onDetail: (LibraryItem) -> Unit,
    onOpen: (LibraryItem) -> Unit,
    onToggleFavorite: (LibraryItem) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Box {
        Box(Modifier.size(26.dp).clip(CircleShape).clickable { open = true }, contentAlignment = Alignment.Center) {
            LbIcon(LbIconKind.DOTS_V, tint = LbText, size = 18.dp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(text = { Text("Abrir") }, onClick = { open = false; onOpen(b) })
            DropdownMenuItem(text = { Text("Ver ficha") }, onClick = { open = false; onDetail(b) })
            DropdownMenuItem(
                text = { Text(if (b.isFavorite == 1) "Quitar de favoritos" else "Añadir a favoritos") },
                onClick = { open = false; onToggleFavorite(b) }
            )
        }
    }
}

@Composable
private fun RatingLabel(b: LibraryItem) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        LibIcon(
            LibIconKind.STAR, tint = if (b.rating > 0) Color(0xFFC8912F) else LbLine,
            accent = Color(0xFFD9A441), size = 14.dp, filled = b.rating > 0
        )
        Spacer(Modifier.width(3.dp))
        Text(
            if (b.rating > 0) String.format(Locale.US, "%.1f", b.rating.toFloat()) else "—",
            color = LbTitle, fontSize = 12.sp, fontFamily = LibellumSerif
        )
    }
}

@Composable
private fun LibBookTile(
    b: LibraryItem,
    modifier: Modifier,
    onDetail: (LibraryItem) -> Unit,
    onOpen: (LibraryItem) -> Unit,
    onToggleFavorite: (LibraryItem) -> Unit
) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier
            .shadow(2.dp, shape, ambientColor = Color(0x22805020), spotColor = Color(0x22805020))
            .clip(shape)
            .background(Brush.verticalGradient(listOf(LbCardTop, LbCardBottom)))
            .border(1.dp, LbCardEdge, shape)
            .clickable { onDetail(b) }
            .padding(5.dp)
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(1.28f).clip(RoundedCornerShape(10.dp))) {
            BookCover(b, Modifier.fillMaxSize())
            StatusPill(b, Modifier.align(Alignment.BottomStart).padding(5.dp))
        }
        Spacer(Modifier.height(5.dp))
        Text(
            b.title, color = LbTitle, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = LibellumSerif,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 2.dp)
        )
        Text(
            b.author, color = LbMuted, fontSize = 10.5.sp, fontFamily = LibellumSerif,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 2.dp)
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) { RatingLabel(b) }
            BookMenu(b, onDetail, onOpen, onToggleFavorite)
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            LbIcon(LbIconKind.DOC, size = 13.dp)
            Spacer(Modifier.width(3.dp))
            Text(
                b.genreLabel(), color = LbMuted, fontSize = 10.5.sp, fontFamily = LibellumSerif,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
            )
        }
        if (b.statusKey() == "READING") {
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                LbProgress(b.progress.coerceIn(0, 100) / 100f, Modifier.weight(1f), height = 5.dp)
                Spacer(Modifier.width(4.dp))
                Text("${b.progress}%", color = LbTitle, fontSize = 10.sp, fontFamily = LibellumSerif)
            }
        }
        Spacer(Modifier.height(3.dp))
    }
}

@Composable
private fun LibBookRow(
    b: LibraryItem,
    modifier: Modifier,
    onDetail: (LibraryItem) -> Unit,
    onOpen: (LibraryItem) -> Unit,
    onToggleFavorite: (LibraryItem) -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier.fillMaxWidth()
            .shadow(2.dp, shape, ambientColor = Color(0x22805020), spotColor = Color(0x22805020))
            .clip(shape)
            .background(Brush.verticalGradient(listOf(LbCardTop, LbCardBottom)))
            .border(1.dp, LbCardEdge, shape)
            .clickable { onDetail(b) }
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BookCover(b, Modifier.size(width = 58.dp, height = 82.dp).clip(RoundedCornerShape(8.dp)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                b.title, color = LbTitle, fontSize = 15.sp, fontWeight = FontWeight.Bold, fontFamily = LibellumSerif,
                maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            Text(
                b.author, color = LbMuted, fontSize = 12.sp, fontFamily = LibellumSerif,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(5.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatusPill(b)
                RatingLabel(b)
                Text(
                    b.genreLabel(), color = LbMuted, fontSize = 11.sp, fontFamily = LibellumSerif,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            if (b.statusKey() == "READING") {
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LbProgress(b.progress.coerceIn(0, 100) / 100f, Modifier.weight(1f), height = 5.dp)
                    Spacer(Modifier.width(6.dp))
                    Text("${b.progress}%", color = LbTitle, fontSize = 11.sp, fontFamily = LibellumSerif)
                }
            }
        }
        BookMenu(b, onDetail, onOpen, onToggleFavorite)
    }
}
