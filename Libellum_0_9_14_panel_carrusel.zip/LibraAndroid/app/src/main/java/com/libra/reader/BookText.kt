package com.libra.reader

import android.graphics.Typeface
import android.text.Html
import android.text.Spanned
import android.text.SpannableStringBuilder
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.text.style.UnderlineSpan
import android.text.style.RelativeSizeSpan
import android.text.style.SuperscriptSpan
import java.io.File

// ══════════════════════════════════════════════════════════════════════════════
// MODELO DE TEXTO DEL LECTOR NATIVO
//   Cada capítulo = lista de bloques + un texto plano ESTABLE (`plain`).
//   Toda posición del lector (última página, marcadores, subrayados) es un
//   desplazamiento de caracteres dentro de ese texto: no depende de la tipografía.
// ══════════════════════════════════════════════════════════════════════════════

internal class LinkSpan(val href: String)

internal enum class BlockKind { PARAGRAPH, H1, H2, H3, QUOTE, LIST, PRE, SCENE }

internal sealed class Block {
    abstract val start: Int
    abstract val length: Int
}

internal class TextBlock(
    override val start: Int,
    val text: CharSequence,
    val kind: BlockKind,
    val centered: Boolean
) : Block() {
    override val length: Int get() = text.length
}

internal class ImageBlock(override val start: Int, val path: String, val alt: String) : Block() {
    override val length: Int get() = 1
}

internal class RuleBlock(override val start: Int) : Block() {
    override val length: Int get() = 1
}

internal class ChapterDoc(
    val index: Int,
    val title: String,
    val blocks: List<Block>,
    val plain: String,
    val anchors: Map<String, Int>
)

/** Un libro abierto: EPUB, TXT o FB2. Todas las funciones son bloqueantes (llamar desde un hilo de fondo). */
internal interface BookSource {
    val chapterCount: Int
    fun chapterTitle(i: Int): String
    fun loadChapter(i: Int): ChapterDoc
    fun readImage(path: String): ByteArray?
    /** Enlace interno → (capítulo, ancla) o null si no es un enlace dentro del libro. */
    fun resolveHref(chapter: Int, href: String): Pair<Int, String?>?
    fun close()
}

// ── Utilidades de búsqueda ────────────────────────────────────────────────────

/** Expresión que encuentra [text] ignorando diferencias de espacios y saltos de línea. */
private fun looseRegex(text: String): Regex? {
    val words = text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
    if (words.isEmpty()) return null
    return Regex(words.joinToString("\\s+") { Regex.escape(it) })
}

/** Posición de la aparición número [k] de [text] en [plain] (si no hay tantas, la primera). */
internal fun findOccurrence(plain: String, text: String, k: Int): IntRange? {
    val re = looseRegex(text) ?: return null
    val all = re.findAll(plain).map { it.range }.toList()
    if (all.isEmpty()) return null
    return all.getOrNull(k) ?: all.first()
}

/** Cuántas veces aparece [text] en [plain] antes de [start] (para recordar «cuál» aparición se subrayó). */
internal fun occurrenceIndexBefore(plain: String, text: String, start: Int): Int {
    val re = looseRegex(text) ?: return 0
    return re.findAll(plain).count { it.range.first < start }
}

// ══════════════════════════════════════════════════════════════════════════════
// Conversor de HTML/XHTML a bloques (tolerante: no exige XML válido)
// ══════════════════════════════════════════════════════════════════════════════

internal object HtmlBlocks {
    private val OPT = setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
    // Cabeceras XML/XHTML que no deben convertirse en texto visible
    private val XML_DECL = Regex("""<\?xml\b[^>]*\?>""", OPT)
    private val DOCTYPE  = Regex("""<!DOCTYPE\b.*?>""", OPT)          // multilínea gracias a DOT_MATCHES_ALL
    private val PI       = Regex("""<\?.*?\?>""", OPT)                // cualquier processing instruction residual
    private val COMMENT = Regex("<!--.*?-->", OPT)
    private val CDATA = Regex("<!\\[CDATA\\[.*?]]>", OPT)
    private val HEAD = Regex("<head\\b.*?</head\\s*>", OPT)
    private val SCRIPT = Regex("<script\\b.*?</script\\s*>", OPT)
    private val STYLE = Regex("<style\\b.*?</style\\s*>", OPT)
    private val TAG = Regex("<(/?)([a-zA-Z][a-zA-Z0-9:_-]*)((?:\"[^\"]*\"|'[^']*'|[^>\"'])*)>")
    private val ATTR = Regex("([a-zA-Z_:][-a-zA-Z0-9_:.]*)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s\"'>]+))")
    private val VOID = setOf("br", "img", "hr", "meta", "link", "input", "image", "col", "wbr", "source", "area", "base")
    private val BLOCKISH = setOf(
        "p", "div", "section", "article", "aside", "header", "footer", "main", "nav", "figure",
        "figcaption", "blockquote", "dd", "dt", "tr", "table", "ul", "ol", "dl", "body", "center",
        "address", "details", "summary", "tbody", "thead", "li", "h1", "h2", "h3", "h4", "h5", "h6", "pre"
    )

    private const val F_BOLD = 1
    private const val F_ITALIC = 2
    private const val F_UNDER = 4
    private const val F_SMALL = 8
    private const val F_SUP = 16
    private const val F_MONO = 32
    private const val F_SKIP = 64
    private const val F_PRE = 128
    private const val F_QUOTE = 256

    private fun attrs(raw: String): Map<String, String> {
        val out = HashMap<String, String>()
        ATTR.findAll(raw).forEach { m ->
            val v = m.groupValues[2].ifEmpty { m.groupValues[3].ifEmpty { m.groupValues[4] } }
            out[m.groupValues[1].lowercase()] = v
        }
        return out
    }

    private fun decode(s: String): String =
        if (s.indexOf('&') < 0) s else Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString()

    fun parse(
        index: Int,
        html: String,
        fallbackTitle: String,
        resolveImage: (String) -> String
    ): ChapterDoc {
        var src = html.removePrefix("\uFEFF")

        // Eliminar cabeceras XML/DOCTYPE para que no aparezcan como texto legible
        // (fallo típico al cambiar de capítulo/portada en EPUBs XHTML)
        src = XML_DECL.replace(src, "")
        src = DOCTYPE.replace(src, "")
        src = PI.replace(src, "")

        src = COMMENT.replace(src, "")
        src = CDATA.replace(src, "")
        src = HEAD.replace(src, "")
        src = SCRIPT.replace(src, "")
        src = STYLE.replace(src, "")
        src = src.trimStart()

        val b = Builder(resolveImage)
        var pos = 0
        for (m in TAG.findAll(src)) {
            if (m.range.first > pos) b.text(src.substring(pos, m.range.first))
            pos = m.range.last + 1
            val closing = m.groupValues[1] == "/"
            val name = m.groupValues[2].lowercase().substringAfterLast(':')
            val rawAttrs = m.groupValues[3]
            val selfClose = rawAttrs.trimEnd().endsWith("/")
            if (closing) b.close(name) else b.open(name, attrs(rawAttrs), rawAttrs, selfClose)
        }
        if (pos < src.length) b.text(src.substring(pos))
        return b.finish(index, fallbackTitle)
    }

    /** Documento a partir de párrafos de texto plano (TXT / FB2). */
    fun fromParagraphs(index: Int, title: String, paras: List<String>, headingRegex: Regex?): ChapterDoc {
        val blocks = ArrayList<Block>()
        val plain = StringBuilder()
        for (p in paras) {
            val t = p.trim()
            if (t.isEmpty()) continue
            val kind = if (headingRegex != null && t.length < 80 && headingRegex.containsMatchIn(t)) BlockKind.H2
            else if (isSceneBreak(t)) BlockKind.SCENE else BlockKind.PARAGRAPH
            blocks.add(TextBlock(plain.length, t, kind, kind != BlockKind.PARAGRAPH))
            plain.append(t).append('\n')
        }
        return ChapterDoc(index, title, blocks, plain.toString(), emptyMap())
    }

    private fun isSceneBreak(t: String): Boolean =
        t.length <= 8 && t.all { it in "*·•—–-_~ \u00A0.#" } && t.any { it != ' ' }

    private class Builder(val resolveImage: (String) -> String) {
        val blocks = ArrayList<Block>()
        val anchors = LinkedHashMap<String, Int>()
        var plainOffset = 0
        var cur: SpannableStringBuilder? = null
        var curKind = BlockKind.PARAGRAPH
        var curCentered = false
        var nextKind = BlockKind.PARAGRAPH
        var nextCentered = false
        var title: String? = null
        var flags = 0
        val stack = ArrayList<Pair<String, Int>>()
        val listStack = ArrayList<IntArray>()   // [0] = ordenada (1) o no (0), [1] = contador
        var linkHref: String? = null
        var linkStart = -1
        var linkBlock: SpannableStringBuilder? = null
        var inTitle = false

        fun has(f: Int) = flags and f != 0

        fun kindFor(base: BlockKind): BlockKind =
            if (base == BlockKind.PARAGRAPH && has(F_QUOTE)) BlockKind.QUOTE
            else if (has(F_PRE)) BlockKind.PRE else base

        fun flush() {
            val c = cur ?: return
            var n = c.length
            while (n > 0 && (c[n - 1] == ' ' || c[n - 1] == '\n' || c[n - 1] == '\u00A0')) n--
            if (n < c.length) c.delete(n, c.length)
            if (c.isNotEmpty()) {
                var kind = curKind
                var centered = curCentered
                val s = c.toString()
                if (kind == BlockKind.PARAGRAPH && isSceneBreak(s)) { kind = BlockKind.SCENE; centered = true }
                blocks.add(TextBlock(plainOffset, c, kind, centered))
                plainOffset += c.length + 1
            }
            cur = null
        }

        fun ensure() {
            if (cur == null) {
                cur = SpannableStringBuilder()
                curKind = kindFor(nextKind)
                curCentered = nextCentered
            }
        }

        fun anchor(id: String) {
            if (id.isNotEmpty() && !anchors.containsKey(id)) anchors[id] = plainOffset + (cur?.length ?: 0)
        }

        fun text(raw: String) {
            if (inTitle) {
                if (title == null) title = decode(raw).trim()
                return
            }
            if (has(F_SKIP)) return
            val t = decode(raw)
            if (t.isEmpty()) return
            val pre = has(F_PRE)
            val start0 = cur?.length ?: 0
            for (ch in t) {
                if (!pre && (ch == ' ' || ch == '\n' || ch == '\r' || ch == '\t')) {
                    val c = cur
                    if (c == null || c.isEmpty()) continue
                    val last = c[c.length - 1]
                    if (last == ' ' || last == '\n') continue
                    c.append(' ')
                } else {
                    if (ch == '\r') continue
                    ensure()
                    cur!!.append(ch)
                }
            }
            val c = cur ?: return
            if (c.length > start0) {
                if (linkHref != null && linkStart < 0) { linkStart = start0; linkBlock = c }
                val end = c.length
                if (has(F_BOLD)) c.setSpan(StyleSpan(Typeface.BOLD), start0, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                if (has(F_ITALIC)) c.setSpan(StyleSpan(Typeface.ITALIC), start0, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                if (has(F_UNDER)) c.setSpan(UnderlineSpan(), start0, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                if (has(F_SMALL)) c.setSpan(RelativeSizeSpan(0.85f), start0, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                if (has(F_SUP)) {
                    c.setSpan(SuperscriptSpan(), start0, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    c.setSpan(RelativeSizeSpan(0.7f), start0, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                if (has(F_MONO)) c.setSpan(TypefaceSpan("monospace"), start0, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }

        fun addImage(src: String?, alt: String) {
            if (src.isNullOrBlank() || has(F_SKIP)) return
            flush()
            blocks.add(ImageBlock(plainOffset, resolveImage(src), alt))
            plainOffset += 2
        }

        fun open(name: String, a: Map<String, String>, rawAttrs: String, selfClose: Boolean) {
            val id = a["id"] ?: a["name"]
            if (name == "title") { inTitle = true; return }
            if (id != null) anchor(id)
            when (name) {
                "br" -> {
                    if (!has(F_SKIP)) {
                        ensure()
                        val c = cur!!
                        if (c.isNotEmpty() && c[c.length - 1] != '\n') c.append('\n')
                    }
                    return
                }
                "img" -> { addImage(a["src"], a["alt"] ?: ""); return }
                "image" -> { addImage(a["xlink:href"] ?: a["href"], a["alt"] ?: ""); return }
                "hr" -> {
                    if (!has(F_SKIP)) {
                        flush()
                        blocks.add(RuleBlock(plainOffset))
                        plainOffset += 2
                    }
                    return
                }
            }
            if (name in VOID) return

            var added = 0
            val low = rawAttrs.lowercase()
            val skipEl = low.contains("doc-pagebreak") || low.contains("\"pagebreak\"")
            if (skipEl) added = added or F_SKIP

            val centered = low.contains("text-align:center") || low.contains("text-align: center") ||
                low.contains("align=\"center\"") || Regex("class\\s*=\\s*\"[^\"]*(center|centro)[^\"]*\"").containsMatchIn(low)
            val styleItalic = low.contains("font-style:italic") || low.contains("font-style: italic")
            val styleBold = low.contains("font-weight:bold") || low.contains("font-weight: bold") ||
                low.contains("font-weight:700") || low.contains("font-weight: 700")

            when (name) {
                "b", "strong" -> added = added or F_BOLD
                "i", "em", "cite", "dfn", "var" -> added = added or F_ITALIC
                "u", "ins" -> added = added or F_UNDER
                "small" -> added = added or F_SMALL
                "sup" -> added = added or F_SUP
                "code", "tt", "kbd", "samp" -> added = added or F_MONO
                "span", "font" -> {
                    if (styleItalic) added = added or F_ITALIC
                    if (styleBold) added = added or F_BOLD
                }
                "a" -> {
                    val href = a["href"]
                    if (href != null && !has(F_SKIP)) { linkHref = href; linkStart = -1; linkBlock = null }
                }
                "td", "th" -> {
                    val c = cur
                    if (c != null && c.isNotEmpty() && c[c.length - 1] != ' ') c.append(' ')
                }
                "blockquote" -> { flush(); added = added or F_QUOTE }
                "pre" -> { flush(); added = added or F_PRE }
                "ul" -> { flush(); listStack.add(intArrayOf(0, 0)) }
                "ol" -> { flush(); listStack.add(intArrayOf(1, 0)) }
                "li" -> {
                    flush()
                    nextKind = BlockKind.LIST
                    nextCentered = false
                    ensure()
                    val ls = listStack.lastOrNull()
                    val bullet = if (ls != null && ls[0] == 1) { ls[1]++; "${ls[1]}.\u00A0" } else "•\u00A0"
                    cur!!.append(bullet)
                }
                "h1" -> { flush(); nextKind = BlockKind.H1; nextCentered = true }
                "h2" -> { flush(); nextKind = BlockKind.H2; nextCentered = true }
                "h3", "h4", "h5", "h6" -> { flush(); nextKind = BlockKind.H3; nextCentered = true }
                else -> if (name in BLOCKISH) {
                    flush()
                    nextKind = BlockKind.PARAGRAPH
                    nextCentered = centered
                }
            }
            if (name == "p" || name == "div" || name == "section") { nextKind = BlockKind.PARAGRAPH; nextCentered = centered }
            if (!selfClose) {
                stack.add(name to added)
                flags = flags or added
            }
        }

        fun close(name: String) {
            if (name == "title") { inTitle = false; return }
            if (name == "a") {
                val href = linkHref
                val c = cur
                if (href != null && c != null && linkBlock === c && linkStart >= 0 && c.length > linkStart) {
                    c.setSpan(LinkSpan(href), linkStart, c.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                linkHref = null; linkStart = -1; linkBlock = null
            }
            if (name == "ul" || name == "ol") { flush(); if (listStack.isNotEmpty()) listStack.removeAt(listStack.lastIndex) }
            if (name in BLOCKISH) {
                flush()
                nextKind = BlockKind.PARAGRAPH
                nextCentered = false
            }
            val i = stack.indexOfLast { it.first == name }
            if (i >= 0) {
                while (stack.size > i) stack.removeAt(stack.lastIndex)
                var f = 0
                for (e in stack) f = f or e.second
                flags = f
            }
        }

        fun finish(index: Int, fallbackTitle: String): ChapterDoc {
            flush()
            val plain = StringBuilder()
            for (bl in blocks) {
                when (bl) {
                    is TextBlock -> plain.append(bl.text)
                    is ImageBlock -> plain.append('\uFFFC')
                    is RuleBlock -> plain.append('\u2042')
                }
                plain.append('\n')
            }
            val t = title?.takeIf { it.isNotBlank() } ?: fallbackTitle
            return ChapterDoc(index, t, blocks, plain.toString(), anchors)
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// Fuentes de libro
// ══════════════════════════════════════════════════════════════════════════════

internal class EpubSource(private val pkg: EpubPackage) : BookSource {
    override val chapterCount: Int get() = pkg.spine.size

    override fun chapterTitle(i: Int): String = pkg.tocTitleFor(i) ?: ""

    override fun loadChapter(i: Int): ChapterDoc {
        val path = pkg.spine[i]
        val html = pkg.readText(path) ?: ""
        return HtmlBlocks.parse(i, html, "") { src -> pkg.resolveRelative(path, src) }
    }

    override fun readImage(path: String): ByteArray? = pkg.readBytes(path)

    override fun resolveHref(chapter: Int, href: String): Pair<Int, String?>? {
        val h = href.trim()
        if (h.isEmpty() || h.startsWith("http", true) || h.startsWith("mailto:", true) || h.startsWith("tel:", true)) return null
        val frag = if (h.contains('#')) h.substringAfter('#') else ""
        val pathPart = h.substringBefore('#')
        if (pathPart.isEmpty()) return chapter to frag.ifEmpty { null }
        val resolved = pkg.resolveRelative(pkg.spine[chapter], pathPart)
        var idx = pkg.spine.indexOf(resolved)
        if (idx < 0) idx = pkg.spine.indexOfFirst { it.equals(resolved, ignoreCase = true) }
        if (idx < 0) {
            val name = resolved.substringAfterLast('/')
            idx = pkg.spine.indexOfFirst { it.substringAfterLast('/').equals(name, ignoreCase = true) }
        }
        return if (idx >= 0) idx to frag.ifEmpty { null } else null
    }

    override fun close() { pkg.close() }
}

/** TXT y FB2: se parten en «partes» de ~25 000 caracteres (o en cada encabezado tipo «Capítulo N»). */
internal class TextSource(paragraphs: List<String>) : BookSource {
    private val headingRe = Regex("^(cap[ií]tulo|chapter|parte|part|libro|book|pr[oó]logo|ep[ií]logo|prologue|epilogue)\\b", RegexOption.IGNORE_CASE)
    private val parts = ArrayList<Pair<String, List<String>>>()

    init {
        var buf = ArrayList<String>()
        var size = 0
        var title = ""
        var n = 0
        fun close() {
            if (buf.isNotEmpty()) {
                n++
                parts.add((title.ifBlank { "Parte $n" }) to buf)
            }
            buf = ArrayList(); size = 0; title = ""
        }
        for (p in paragraphs) {
            val t = p.trim()
            if (t.isEmpty()) continue
            val isHeading = t.length < 80 && headingRe.containsMatchIn(t)
            if ((isHeading && size >= 3000) || size >= 25_000) close()
            if (isHeading && title.isBlank()) title = t
            buf.add(t)
            size += t.length
        }
        close()
        if (parts.isEmpty()) parts.add("Texto" to listOf(""))
    }

    override val chapterCount: Int get() = parts.size
    override fun chapterTitle(i: Int): String = parts.getOrNull(i)?.first ?: ""
    override fun loadChapter(i: Int): ChapterDoc {
        val p = parts[i.coerceIn(0, parts.lastIndex)]
        return HtmlBlocks.fromParagraphs(i, p.first, p.second, headingRe)
    }
    override fun readImage(path: String): ByteArray? = null
    override fun resolveHref(chapter: Int, href: String): Pair<Int, String?>? = null
    override fun close() {}

    companion object {
        /** Convierte el texto de un TXT en párrafos (una línea = un párrafo si no hay líneas en blanco). */
        fun paragraphsOfTxt(text: String): List<String> {
            val t = text.replace("\r\n", "\n").replace('\r', '\n')
            return if (t.contains("\n\n")) {
                t.split(Regex("\n\\s*\n")).map { it.replace('\n', ' ').replace(Regex("[ \\t]+"), " ").trim() }
            } else {
                t.split('\n').map { it.trim() }
            }
        }

        fun open(file: File, fb2: Boolean): TextSource =
            if (fb2) TextSource(Fb2Parser.parse(file).paragraphs)
            else TextSource(paragraphsOfTxt(readTextSmart(file)))
    }
}
