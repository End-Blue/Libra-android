package com.libra.reader

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

// ══════════════════════════════════════════════════════════════════════════════
// OPDS — interfaz «papel dorado»
// ══════════════════════════════════════════════════════════════════════════════

private sealed class OpdsView {
    data object Home : OpdsView()
    data class Browse(val catalog: OpdsCatalog, val feedUrl: String, val title: String) : OpdsView()
}

@Composable
fun OpdsScreen(
    onImported: (String) -> Unit = {},
    onBack: (() -> Unit)? = null
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var view by remember { mutableStateOf<OpdsView>(OpdsView.Home) }
    var catalogs by remember { mutableStateOf(OpdsCatalogs.all(ctx)) }
    var recent by remember { mutableStateOf(OpdsCatalogs.recentDownloads(ctx)) }
    var showAdd by remember { mutableStateOf(false) }
    var detail by remember { mutableStateOf<Pair<OpdsEntry, OpdsCatalog>?>(null) }
    var statusMsg by remember { mutableStateOf<String?>(null) }

    fun refreshLists() {
        catalogs = OpdsCatalogs.all(ctx)
        recent = OpdsCatalogs.recentDownloads(ctx)
    }

    Box(Modifier.fillMaxSize().background(LbBg)) {
        when (val v = view) {
            is OpdsView.Home -> OpdsHome(
                catalogs = catalogs,
                recent = recent,
                statusMsg = statusMsg,
                onOpenCatalog = { cat ->
                    OpdsCatalogs.setLastCatalogId(ctx, cat.id)
                    view = OpdsView.Browse(cat, cat.url, cat.name)
                },
                onAddCatalog = { showAdd = true },
                onRemoveCatalog = { id ->
                    OpdsCatalogs.removeCustom(ctx, id)
                    refreshLists()
                },
                onOpenRecent = { /* solo visual por ahora */ },
                onDismissStatus = { statusMsg = null }
            )
            is OpdsView.Browse -> OpdsBrowse(
                catalog = v.catalog,
                initialUrl = v.feedUrl,
                title = v.title,
                onBack = { view = OpdsView.Home },
                onEntry = { entry -> detail = entry to v.catalog },
                onStatus = { statusMsg = it }
            )
        }

        if (showAdd) {
            AddCatalogDialog(
                onDismiss = { showAdd = false },
                onAdd = { name, url ->
                    OpdsCatalogs.addCustom(ctx, name, url)
                    refreshLists()
                    showAdd = false
                    statusMsg = "Catálogo «$name» añadido."
                }
            )
        }

        detail?.let { (entry, catalog) ->
            OpdsBookSheet(
                entry = entry,
                catalogName = catalog.name,
                onDismiss = { detail = null },
                onDownloaded = { msg ->
                    detail = null
                    refreshLists()
                    statusMsg = msg
                    onImported(msg)
                }
            )
        }
    }
}

// ── Inicio OPDS ───────────────────────────────────────────────────────────────

@Composable
private fun OpdsHome(
    catalogs: List<OpdsCatalog>,
    recent: List<OpdsCatalogs.RecentDownload>,
    statusMsg: String?,
    onOpenCatalog: (OpdsCatalog) -> Unit,
    onAddCatalog: () -> Unit,
    onRemoveCatalog: (String) -> Unit,
    onOpenRecent: (OpdsCatalogs.RecentDownload) -> Unit,
    onDismissStatus: () -> Unit
) {
    val curated = catalogs.filter { it.curated }
    val custom = catalogs.filter { !it.curated }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            OpdsHeroHeader()
        }

        // Estado / mensaje
        item {
            AnimatedVisibility(visible = statusMsg != null, enter = fadeIn(), exit = fadeOut()) {
                if (statusMsg != null) {
                    LbCard(
                        Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
                        padding = 12.dp,
                        onClick = onDismissStatus
                    ) {
                        Text(statusMsg, color = LbTitle, fontSize = 14.sp, fontFamily = LibellumSerif)
                    }
                }
            }
        }

        // Qué es esto
        item {
            LbCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), padding = 14.dp) {
                Text(
                    "Descubre libros libres",
                    color = LbTitle, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                    fontFamily = LibellumSerif, fontStyle = FontStyle.Italic
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "OPDS conecta Libellum con catálogos de dominio público y bibliotecas abiertas. Elige un catálogo, busca y descarga EPUB directamente a tu biblioteca.",
                    color = LbText, fontSize = 13.sp, lineHeight = 19.sp
                )
            }
        }

        // Catálogos recomendados
        item {
            LbSectionHeader(
                "Catálogos recomendados",
                icon = { LbIcon(LbIconKind.SPARKLE, size = 26.dp) },
                modifier = Modifier.padding(horizontal = 18.dp)
            )
        }
        item {
            Column(
                Modifier.padding(horizontal = 18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                curated.forEach { cat ->
                    CatalogCard(cat, onClick = { onOpenCatalog(cat) })
                }
            }
        }

        // Mis catálogos
        item {
            LbSectionHeader(
                "Mis catálogos",
                icon = { LbIcon(LbIconKind.BOOK_OPEN, size = 26.dp) },
                modifier = Modifier.padding(horizontal = 18.dp),
                trailing = {
                    LbLink("Añadir") { onAddCatalog() }
                }
            )
        }
        item {
            if (custom.isEmpty()) {
                LbCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), padding = 14.dp) {
                    Text(
                        "Aún no has añadido catálogos propios.",
                        color = LbMuted, fontSize = 13.sp, lineHeight = 19.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = onAddCatalog,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = LbBrown,
                            contentColor = Color(0xFFFDF1DC)
                        )
                    ) {
                        Text("Añadir catálogo OPDS", fontSize = 14.sp, fontFamily = LibellumSerif)
                    }
                }
            } else {
                Column(
                    Modifier.padding(horizontal = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    custom.forEach { cat ->
                        CatalogCard(
                            cat,
                            onClick = { onOpenCatalog(cat) },
                            onRemove = { onRemoveCatalog(cat.id) }
                        )
                    }
                }
            }
        }

        // Descargas recientes
        if (recent.isNotEmpty()) {
            item {
                LbSectionHeader(
                    "Descargas recientes",
                    icon = { LbIcon(LbIconKind.CLOCK, size = 26.dp) },
                    modifier = Modifier.padding(horizontal = 18.dp)
                )
            }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(recent.take(12), key = { it.title + it.at }) { r ->
                        RecentCard(r, onClick = { onOpenRecent(r) })
                    }
                }
            }
        }

        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
private fun OpdsHeroHeader() {
    Box(
        Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFFF3DFC0), Color(0xFFF7E8D1))
                )
            )
            .padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 16.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LbIcon(LbIconKind.BOOK_OPEN, tint = LbBrown, size = 28.dp)
                Spacer(Modifier.width(10.dp))
                Box(Modifier.width(1.dp).height(22.dp).background(LbBrown.copy(alpha = 0.35f)))
                Spacer(Modifier.width(10.dp))
                Text(
                    "LIBELLUM", color = LbBrown, fontSize = 13.sp, letterSpacing = 3.sp,
                    fontFamily = LibellumSerif, maxLines = 1
                )
            }
            Spacer(Modifier.height(10.dp))
            Text(
                "Explorar",
                color = LbTitle, fontSize = 36.sp, fontWeight = FontWeight.Bold,
                fontFamily = LibellumSerif, fontStyle = FontStyle.Italic,
                lineHeight = 42.sp
            )
            Text(
                "Catálogos abiertos · OPDS",
                color = LbTitle, fontSize = 16.sp, fontFamily = LibellumSerif,
                fontStyle = FontStyle.Italic, modifier = Modifier.padding(top = 2.dp)
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "“Los mejores libros del mundo\nestán al alcance de un toque.”",
                color = LbText, fontSize = 13.sp, fontFamily = LibellumSerif,
                fontStyle = FontStyle.Italic, lineHeight = 18.sp
            )
            Spacer(Modifier.height(8.dp))
            Flourish()
        }
    }
}

@Composable
private fun CatalogCard(
    cat: OpdsCatalog,
    onClick: () -> Unit,
    onRemove: (() -> Unit)? = null
) {
    LbCard(Modifier.fillMaxWidth(), padding = 0.dp, onClick = onClick) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFF8E0BF)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    cat.name.take(1).uppercase(),
                    color = LbBrown, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                    fontFamily = LibellumSerif
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    cat.name, color = LbTitle, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                    fontFamily = LibellumSerif, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                if (cat.description.isNotBlank()) {
                    Text(
                        cat.description, color = LbMuted, fontSize = 12.sp, lineHeight = 16.sp,
                        maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                }
                if (cat.language.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        when (cat.language) {
                            "es" -> "Español"
                            "en" -> "Inglés"
                            "multi" -> "Varios idiomas"
                            else -> cat.language
                        },
                        color = LbBrownLight, fontSize = 11.sp, fontFamily = LibellumSerif,
                        fontStyle = FontStyle.Italic
                    )
                }
            }
            if (onRemove != null) {
                Box(
                    Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .clickable { onRemove() },
                    contentAlignment = Alignment.Center
                ) {
                    Text("×", color = LbMuted, fontSize = 20.sp)
                }
            } else {
                LbIcon(LbIconKind.CHEVRON_RIGHT, tint = LbBrownLight, size = 18.dp)
            }
        }
    }
}

@Composable
private fun RecentCard(r: OpdsCatalogs.RecentDownload, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        Modifier
            .width(120.dp)
            .shadow(2.dp, shape, ambientColor = Color(0x22805020), spotColor = Color(0x33805020))
            .clip(shape)
            .background(Brush.verticalGradient(listOf(LbCardTop, LbCardBottom)))
            .border(1.dp, LbCardEdge, shape)
            .clickable(onClick = onClick)
            .padding(10.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(90.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFFF0D9B0)),
            contentAlignment = Alignment.Center
        ) {
            if (r.coverUrl != null) {
                AsyncImage(
                    model = r.coverUrl,
                    contentDescription = r.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Text(
                    r.title.take(1).uppercase(),
                    color = LbBrown, fontSize = 28.sp, fontWeight = FontWeight.Bold,
                    fontFamily = LibellumSerif
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            r.title, color = LbTitle, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
            fontFamily = LibellumSerif, maxLines = 2, overflow = TextOverflow.Ellipsis,
            lineHeight = 15.sp
        )
        Text(
            r.author, color = LbMuted, fontSize = 11.sp, maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

// ── Navegación dentro de un catálogo ──────────────────────────────────────────

@Composable
private fun OpdsBrowse(
    catalog: OpdsCatalog,
    initialUrl: String,
    title: String,
    onBack: () -> Unit,
    onEntry: (OpdsEntry) -> Unit,
    onStatus: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current
    var url by remember(initialUrl) { mutableStateOf(initialUrl) }
    var headerTitle by remember(title) { mutableStateOf(title) }
    var feed by remember { mutableStateOf<OpdsFeed?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var searchLink by remember(initialUrl) { mutableStateOf<String?>(null) }
    // Pila de navegación para carpetas OPDS
    val navStack = remember { mutableStateListOf(initialUrl to title) }
    val listState = rememberLazyListState()

    fun load(
        target: String,
        isSearch: Boolean = false,
        pushTitle: String? = null,
        append: Boolean = false
    ) {
        scope.launch {
            loading = true
            error = null
            if (isSearch) searching = true
            val result = if (isSearch && query.isNotBlank()) {
                OpdsClient.search(catalog.url, query, searchLink)
            } else {
                OpdsClient.fetchFeed(target)
            }
            result.onSuccess { nuevo ->
                nuevo.searchUrl?.let { searchLink = it }
                val previo = feed
                if (append && previo != null) {
                    val vistos = previo.entries.map { it.id + it.title }.toSet()
                    feed = previo.copy(
                        entries = previo.entries + nuevo.entries.filter { (it.id + it.title) !in vistos },
                        nextUrl = nuevo.nextUrl,
                        searchUrl = nuevo.searchUrl ?: previo.searchUrl
                    )
                    url = target
                } else {
                    feed = nuevo
                    url = target
                    if (pushTitle != null) {
                        headerTitle = pushTitle
                        if (navStack.lastOrNull()?.first != target) {
                            navStack.add(target to pushTitle)
                        }
                    }
                    listState.scrollToItem(0)
                }
            }.onFailure {
                error = it.message ?: "No se pudo cargar el catálogo"
            }
            loading = false
            searching = false
        }
    }

    // Abre la ficha completa de un libro (p. ej. Gutenberg) y muestra directamente su descarga
    fun openDetail(entry: OpdsEntry, detailHref: String) {
        scope.launch {
            loading = true
            error = null
            OpdsClient.fetchFeed(detailHref).onSuccess { f ->
                val full = f.entries.firstOrNull { it.bestDownload() != null }
                if (full != null) {
                    onEntry(
                        full.copy(
                            title = full.title.ifBlank { entry.title },
                            authors = if (full.authors.isEmpty()) entry.authors else full.authors,
                            coverUrl = full.coverUrl ?: entry.coverUrl
                        )
                    )
                } else {
                    error = "Este libro no ofrece archivo descargable en el catálogo."
                }
            }.onFailure {
                error = it.message ?: "No se pudo abrir el libro"
            }
            loading = false
        }
    }

    fun goBackNav(): Boolean {
        if (navStack.size <= 1) return false
        navStack.removeLast()
        val (prevUrl, prevTitle) = navStack.last()
        headerTitle = prevTitle
        load(prevUrl)
        return true
    }

    LaunchedEffect(initialUrl) { load(initialUrl) }

    Column(Modifier.fillMaxSize()) {
        // Cabecera compacta
        Row(
            Modifier
                .fillMaxWidth()
                .background(Color(0xFFF3DFC0))
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFFF8EA))
                    .clickable {
                        if (!goBackNav()) onBack()
                    },
                contentAlignment = Alignment.Center
            ) {
                Text("‹", color = LbBrown, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    headerTitle, color = LbTitle, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                    fontFamily = LibellumSerif, fontStyle = FontStyle.Italic,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    feed?.title?.takeIf { it.isNotBlank() && it != headerTitle }
                        ?: catalog.description.take(48),
                    color = LbMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }

        // Buscador
        OpdsSearchBar(
            query = query,
            onQueryChange = { query = it },
            onSearch = {
                keyboard?.hide()
                if (query.isNotBlank()) load(catalog.url, isSearch = true)
            },
            onClear = {
                query = ""
                load(initialUrl)
            },
            loading = searching
        )

        when {
            loading && feed == null -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = LbBrown, modifier = Modifier.size(36.dp))
                        Spacer(Modifier.height(12.dp))
                        Text("Cargando catálogo…", color = LbMuted, fontSize = 14.sp, fontFamily = LibellumSerif)
                    }
                }
            }
            error != null && feed == null -> {
                Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    LbCard(Modifier.fillMaxWidth(), padding = 18.dp) {
                        Text(
                            "No se pudo abrir el catálogo",
                            color = LbTitle, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                            fontFamily = LibellumSerif, fontStyle = FontStyle.Italic
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(error ?: "", color = LbText, fontSize = 13.sp, lineHeight = 19.sp)
                        Spacer(Modifier.height(14.dp))
                        Button(
                            onClick = { load(url) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = LbBrown, contentColor = Color(0xFFFDF1DC)
                            )
                        ) { Text("Reintentar", fontFamily = LibellumSerif) }
                    }
                }
            }
            else -> {
                val entries = feed?.entries.orEmpty()
                LazyColumn(
                    state = listState,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp)
                ) {
                    if (error != null) {
                        item {
                            LbCard(Modifier.fillMaxWidth(), padding = 14.dp) {
                                Text(
                                    error ?: "",
                                    color = Color(0xFF9B2C1D), fontSize = 13.sp, lineHeight = 19.sp
                                )
                            }
                        }
                    }
                    if (entries.isEmpty()) {
                        item {
                            LbCard(Modifier.fillMaxWidth(), padding = 16.dp) {
                                Text(
                                    if (query.isNotBlank()) "No se encontraron resultados para «$query»."
                                    else "Este catálogo no devolvió entradas.",
                                    color = LbMuted, fontSize = 14.sp, lineHeight = 20.sp
                                )
                            }
                        }
                    }
                    items(entries, key = { it.id + it.title }) { entry ->
                        OpdsEntryCard(entry, onClick = {
                            val nav = entry.navigationLink()
                            val dl = entry.bestDownload()
                            val ficha = entry.detailLink()
                            when {
                                dl != null -> onEntry(entry)
                                ficha != null -> openDetail(entry, ficha.href)
                                nav != null -> load(nav.href, pushTitle = entry.title)
                                else -> onEntry(entry)
                            }
                        })
                    }
                    // Siguiente página
                    val next = feed?.nextUrl
                    if (next != null) {
                        item {
                            OutlinedButton(
                                onClick = { load(next, append = true) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = LbBrown)
                            ) {
                                Text("Cargar más", fontFamily = LibellumSerif)
                            }
                        }
                    }
                    if (loading) {
                        item {
                            Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = LbBrown, modifier = Modifier.size(28.dp))
                            }
                        }
                    }
                    item { Spacer(Modifier.height(12.dp)) }
                }
            }
        }
    }
}

@Composable
private fun OpdsSearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    onSearch: () -> Unit,
    onClear: () -> Unit,
    loading: Boolean
) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 10.dp)
            .shadow(2.dp, shape, ambientColor = Color(0x22805020), spotColor = Color(0x33805020))
            .clip(shape)
            .background(Color(0xFFFFF8EA))
            .border(1.dp, LbCardEdge, shape)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("⌕", color = LbBrown, fontSize = 18.sp)
        Spacer(Modifier.width(10.dp))
        BasicTextField(
            value = query,
            onValueChange = onQueryChange,
            singleLine = true,
            textStyle = TextStyle(
                color = LbTitle, fontSize = 15.sp, fontFamily = LibellumSerif
            ),
            cursorBrush = SolidColor(LbBrown),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { onSearch() }),
            modifier = Modifier.weight(1f),
            decorationBox = { inner ->
                Box {
                    if (query.isEmpty()) {
                        Text(
                            "Buscar título, autor…",
                            color = LbMuted, fontSize = 15.sp, fontFamily = LibellumSerif
                        )
                    }
                    inner()
                }
            }
        )
        if (loading) {
            CircularProgressIndicator(color = LbBrown, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
        } else if (query.isNotEmpty()) {
            Text(
                "✕", color = LbMuted, fontSize = 14.sp,
                modifier = Modifier
                    .clip(CircleShape)
                    .clickable(onClick = onClear)
                    .padding(6.dp)
            )
            Spacer(Modifier.width(4.dp))
            Text(
                "Buscar",
                color = LbBrown, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                fontFamily = LibellumSerif,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onSearch)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
private fun OpdsEntryCard(entry: OpdsEntry, onClick: () -> Unit) {
    val canDownload = entry.bestDownload() != null
    val isNav = entry.navigationLink() != null && !canDownload && entry.detailLink() == null

    LbCard(Modifier.fillMaxWidth(), padding = 0.dp, onClick = onClick) {
        Row(Modifier.padding(12.dp)) {
            // Portada
            Box(
                Modifier
                    .width(64.dp)
                    .height(92.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFF0D9B0)),
                contentAlignment = Alignment.Center
            ) {
                if (entry.coverUrl != null) {
                    AsyncImage(
                        model = entry.coverUrl,
                        contentDescription = entry.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Text(
                        entry.title.take(1).uppercase(),
                        color = LbBrown, fontSize = 24.sp, fontWeight = FontWeight.Bold,
                        fontFamily = LibellumSerif
                    )
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    entry.title, color = LbTitle, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                    fontFamily = LibellumSerif, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    lineHeight = 19.sp
                )
                Text(
                    entry.authorText, color = LbMuted, fontSize = 12.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                if (entry.summary.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        entry.summary, color = LbText, fontSize = 12.sp, lineHeight = 16.sp,
                        maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (canDownload) {
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(LbBrown.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                "Descargar", color = LbBrown, fontSize = 11.sp,
                                fontWeight = FontWeight.Bold, fontFamily = LibellumSerif
                            )
                        }
                    } else if (isNav) {
                        Text(
                            "Carpeta ›", color = LbBrownLight, fontSize = 12.sp,
                            fontFamily = LibellumSerif, fontStyle = FontStyle.Italic
                        )
                    }
                    if (entry.language.isNotBlank()) {
                        Spacer(Modifier.width(8.dp))
                        Text(entry.language.uppercase(), color = LbMuted, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

// ── Ficha del libro + descarga ────────────────────────────────────────────────

@Composable
private fun OpdsBookSheet(
    entry: OpdsEntry,
    catalogName: String,
    onDismiss: () -> Unit,
    onDownloaded: (String) -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var downloading by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var error by remember { mutableStateOf<String?>(null) }
    val link = entry.bestDownload()

    Dialog(onDismissRequest = { if (!downloading) onDismiss() }) {
        SurfacePaper {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Box(
                        Modifier
                            .width(88.dp)
                            .height(128.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFF0D9B0)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (entry.coverUrl != null) {
                            AsyncImage(
                                model = entry.coverUrl,
                                contentDescription = entry.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Text(
                                entry.title.take(1).uppercase(),
                                color = LbBrown, fontSize = 32.sp, fontWeight = FontWeight.Bold,
                                fontFamily = LibellumSerif
                            )
                        }
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            entry.title, color = LbTitle, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                            fontFamily = LibellumSerif, fontStyle = FontStyle.Italic, lineHeight = 22.sp
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(entry.authorText, color = LbMuted, fontSize = 13.sp)
                        if (entry.published.isNotBlank()) {
                            Text(entry.published, color = LbMuted, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            catalogName, color = LbBrownLight, fontSize = 12.sp,
                            fontFamily = LibellumSerif, fontStyle = FontStyle.Italic
                        )
                    }
                }

                if (entry.summary.isNotBlank()) {
                    Spacer(Modifier.height(14.dp))
                    Text(
                        entry.summary, color = LbText, fontSize = 13.sp, lineHeight = 19.sp,
                        maxLines = 8, overflow = TextOverflow.Ellipsis
                    )
                }

                if (entry.categories.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState())) {
                        entry.categories.take(6).forEach { cat ->
                            Box(
                                Modifier
                                    .padding(end = 6.dp)
                                    .clip(RoundedCornerShape(50))
                                    .background(Color(0xFFF8EEDB))
                                    .border(1.dp, LbCardEdge, RoundedCornerShape(50))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(cat, color = LbText, fontSize = 11.sp, fontFamily = LibellumSerif)
                            }
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))

                if (error != null) {
                    Text(error!!, color = Color(0xFF8B3A2A), fontSize = 13.sp, lineHeight = 18.sp)
                    Spacer(Modifier.height(10.dp))
                }

                if (downloading) {
                    Text(
                        "Descargando… ${(progress * 100).toInt()}%",
                        color = LbBrown, fontSize = 13.sp, fontFamily = LibellumSerif
                    )
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = LbBrown,
                        trackColor = LbTrack
                    )
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = LbBrown)
                        ) {
                            Text("Cerrar", fontFamily = LibellumSerif)
                        }
                        Button(
                            onClick = {
                                if (link == null) {
                                    error = "Este título no tiene archivo descargable."
                                    return@Button
                                }
                                downloading = true
                                error = null
                                progress = 0f
                                scope.launch {
                                    try {
                                        val dir = File(ctx.filesDir, "imports").apply { mkdirs() }
                                        val file = OpdsClient.downloadEntry(entry, dir) { progress = it }
                                        // Importar a la biblioteca usando el mismo flujo que el importador
                                        val msg = importDownloadedFile(ctx, file, entry)
                                        OpdsCatalogs.pushRecent(ctx, entry, catalogName)
                                        onDownloaded(msg)
                                    } catch (e: Exception) {
                                        error = e.message ?: "Error al descargar"
                                        downloading = false
                                    }
                                }
                            },
                            enabled = link != null,
                            modifier = Modifier.weight(1.2f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = LbBrown,
                                contentColor = Color(0xFFFDF1DC),
                                disabledContainerColor = LbTrack
                            )
                        ) {
                            Text(
                                if (link != null) "Descargar y añadir" else "No disponible",
                                fontSize = 14.sp, fontFamily = LibellumSerif
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SurfacePaper(content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .shadow(8.dp, shape, ambientColor = Color(0x33805020), spotColor = Color(0x44805020))
            .clip(shape)
            .background(Brush.verticalGradient(listOf(LbCardTop, LbCardBottom)))
            .border(1.dp, LbCardEdge, shape),
        content = content
    )
}

// ── Añadir catálogo ───────────────────────────────────────────────────────────

@Composable
private fun AddCatalogDialog(
    onDismiss: () -> Unit,
    onAdd: (name: String, url: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        SurfacePaper {
            Column(Modifier.padding(20.dp)) {
                Text(
                    "Añadir catálogo OPDS",
                    color = LbTitle, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                    fontFamily = LibellumSerif, fontStyle = FontStyle.Italic
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Pega la URL del feed Atom/OPDS de una biblioteca o catálogo abierto.",
                    color = LbMuted, fontSize = 13.sp, lineHeight = 18.sp
                )
                Spacer(Modifier.height(14.dp))
                FieldLabel("Nombre")
                PaperField(value = name, onValueChange = { name = it }, placeholder = "Mi biblioteca")
                Spacer(Modifier.height(10.dp))
                FieldLabel("URL del catálogo")
                PaperField(
                    value = url,
                    onValueChange = { url = it },
                    placeholder = "https://ejemplo.org/opds"
                )
                if (err != null) {
                    Spacer(Modifier.height(8.dp))
                    Text(err!!, color = Color(0xFF8B3A2A), fontSize = 12.sp)
                }
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = LbBrown)
                    ) { Text("Cancelar", fontFamily = LibellumSerif) }
                    Button(
                        onClick = {
                            when {
                                url.isBlank() -> err = "La URL es obligatoria"
                                !url.contains("http") && !url.contains(".") ->
                                    err = "Revisa la URL del catálogo"
                                else -> onAdd(name.ifBlank { "Catálogo" }, url.trim())
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = LbBrown, contentColor = Color(0xFFFDF1DC)
                        )
                    ) { Text("Añadir", fontFamily = LibellumSerif) }
                }
            }
        }
    }
}

@Composable
private fun FieldLabel(text: String) {
    Text(
        text, color = LbBrown, fontSize = 12.sp, fontWeight = FontWeight.Bold,
        fontFamily = LibellumSerif, letterSpacing = 0.5.sp,
        modifier = Modifier.padding(bottom = 4.dp)
    )
}

@Composable
private fun PaperField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String
) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Color(0xFFFFF8EA))
            .border(1.dp, LbCardEdge, shape)
            .padding(horizontal = 12.dp, vertical = 12.dp)
    ) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            textStyle = TextStyle(color = LbTitle, fontSize = 15.sp, fontFamily = LibellumSerif),
            cursorBrush = SolidColor(LbBrown),
            modifier = Modifier.fillMaxWidth(),
            decorationBox = { inner ->
                Box {
                    if (value.isEmpty()) {
                        Text(placeholder, color = LbMuted, fontSize = 15.sp, fontFamily = LibellumSerif)
                    }
                    inner()
                }
            }
        )
    }
}

// ── Importar archivo descargado a la biblioteca ───────────────────────────────

/**
 * Copia el archivo descargado al almacenamiento privado e inserta el registro
 * usando el mismo criterio que el importador local.
 */
private suspend fun importDownloadedFile(
    ctx: Context,
    file: File,
    entry: OpdsEntry
): String {
    return withContext(Dispatchers.IO) {
        try {
            val db = LibraryDatabase.get(ctx)
            val dao = db.libraryDao()
            val booksDir = File(ctx.filesDir, "books").apply { mkdirs() }
            val ext = file.extension.ifBlank { "epub" }.lowercase()
            val id = java.util.UUID.randomUUID().toString()
            val dest = File(booksDir, "$id.$ext")
            file.copyTo(dest, overwrite = true)
            runCatching { file.delete() }

            // Misma extracción de metadatos/portada que el importador local
            val meta = runCatching {
                MetadataExtractor.extract(dest, ext, "BOOK")
            }.getOrNull()
            val coverPath = meta?.cover?.let { CoverStore.save(ctx.filesDir, id, it) }

            val opdsAuthor = entry.authorText.let {
                if (it == "Autor desconocido") "" else it
            }
            val title = meta?.title?.takeIf { it.isNotBlank() }
                ?: entry.title.takeIf { it.isNotBlank() }
                ?: file.nameWithoutExtension
            val author = meta?.author?.takeIf { it.isNotBlank() }
                ?: opdsAuthor.takeIf { it.isNotBlank() }
                ?: "Autor no identificado"
            val count = dao.count()

            val item = LibraryItem(
                id = id,
                title = title,
                author = author,
                format = ext.uppercase(),
                localPath = dest.absolutePath,
                mediaType = "BOOK",
                sortOrder = count,
                coverPath = coverPath,
                genre = entry.categories.firstOrNull().orEmpty(),
                addedAt = System.currentTimeMillis()
            )
            dao.insert(item)
            "«${item.title}» añadido a tu biblioteca."
        } catch (e: Exception) {
            "Descargado, pero no se pudo registrar: ${e.message}"
        }
    }
}
