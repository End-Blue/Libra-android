package com.libra.reader

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ══════════════════════════════════════════════════════════════════════════════
// INICIO (PANEL) — diseño «papel dorado»
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun DashboardScreen(
    books: List<LibraryItem>,
    days: Set<String>,
    status: String,
    busy: Boolean,
    onMarkToday: () -> Unit,
    onOpen: (LibraryItem) -> Unit,
    onDetail: (LibraryItem) -> Unit,
    onImport: () -> Unit,
    onScan: () -> Unit,
    onSettings: () -> Unit = {},
    onAllBooks: () -> Unit = {},
    onToggleFavorite: (LibraryItem) -> Unit = {},
    statsVersion: Int = 0
) {
    val context = LocalContext.current
    val streak = remember(days) { Streak.current(days) }
    val reading = remember(books) {
        books.filter { it.statusKey() == "READING" }.sortedByDescending { it.startedAt }
    }
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val greeting = if (hour < 12) "Buenos días" else if (hour < 19) "Buenas tardes" else "Buenas noches"
    val dateText = SimpleDateFormat("EEEE, d 'de' MMMM", Locale("es"))
        .format(Date()).replaceFirstChar { it.uppercase() }
    val prefs = remember(context) { context.getSharedPreferences("libra_reading_stats", 0) }
    val active = reading.firstOrNull()
    val totalBookMs = active?.let { prefs.getLong("book_total_${it.id}", 0L) } ?: 0L
    val lastSessionAt = active?.let { prefs.getLong("book_last_at_${it.id}", 0L) } ?: 0L

    var weeksBack by remember { mutableIntStateOf(0) }
    val week = remember(weeksBack, statsVersion) { Streak.weekKeys(weeksBack) }
    val weekValues = week.map { (_, key) -> prefs.getLong("day_$key", 0L) }
    val todayIdx = week.indexOfFirst { it.second == Streak.key() }
    val bestIdx = weekValues.indices.maxByOrNull { weekValues[it] } ?: 0
    var selectedDay by remember(weeksBack) { mutableIntStateOf(if (weeksBack == 0 && todayIdx >= 0) todayIdx else bestIdx) }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 18.dp)
    ) {
        item {
            HeroHeader(
                art = R.drawable.hero_panel,
                title = greeting,
                sub = dateText,
                subItalic = true,
                subSize = 17,
                quote = "Un buen libro\nsiempre encuentra su momento.",
                titleSize = 36,
                onGear = onSettings
            )
        }

        // ── Racha ──
        item {
            LbCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), padding = 12.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(48.dp).clip(CircleShape).background(Color(0xFFF8E0BF)),
                        contentAlignment = Alignment.Center
                    ) { LbIcon(LbIconKind.FLAME, size = 30.dp, filled = true) }
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            "Tu racha de lectura", color = LbTitle, fontSize = 13.sp,
                            fontFamily = LibellumSerif, maxLines = 1
                        )
                        Text(
                            "$streak ${if (streak == 1) "día seguido" else "días seguidos"}",
                            color = LbTitle, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                            fontFamily = LibellumSerif, fontStyle = FontStyle.Italic, maxLines = 1
                        )
                        Text(
                            if (streak > 0) "¡Sigues construyendo tu hábito!" else "Lee unas páginas hoy y empieza tu racha",
                            color = LbMuted, fontSize = 10.sp, fontFamily = LibellumSerif,
                            fontStyle = FontStyle.Italic, lineHeight = 13.sp
                        )
                    }
                    Spacer(Modifier.width(6.dp))
                    Box(Modifier.width(1.dp).height(54.dp).background(LbCardEdge))
                    Spacer(Modifier.width(8.dp))
                    WeekDotsRow(days, Modifier.width(138.dp))
                }
            }
        }

        // ── Leyendo ahora ──
        item {
            LbSectionHeader(
                "Leyendo ahora",
                icon = { LbIcon(LbIconKind.BOOK_OPEN, size = 26.dp) },
                modifier = Modifier.padding(horizontal = 18.dp)
            )
        }
        item {
            if (active == null) {
                LbCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), padding = 16.dp) {
                    Text(
                        if (books.isEmpty()) "Tu biblioteca comienza aquí" else "Tu próxima lectura te está esperando",
                        color = LbTitle, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                        fontFamily = LibellumSerif, fontStyle = FontStyle.Italic
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (books.isEmpty())
                            "Importa tus libros EPUB, PDF, TXT, FB2 o CBZ, o búscalos en el teléfono."
                        else "Abre un libro de tu estantería o biblioteca para comenzar: aparecerá aquí.",
                        color = LbText, fontSize = 13.sp, lineHeight = 19.sp
                    )
                    if (books.isEmpty()) {
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = onImport, enabled = !busy, modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = LbBrown, contentColor = Color(0xFFFDF1DC))
                            ) { Text("Importar", fontSize = 13.sp) }
                            OutlinedButton(
                                onClick = onScan, enabled = !busy, modifier = Modifier.weight(1f)
                            ) { Text("Buscar en el teléfono", fontSize = 12.sp, color = LbBrown, maxLines = 1) }
                        }
                        if (busy || status.isNotBlank()) {
                            Text(status, color = LbMuted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                        }
                    }
                }
            } else {
                Box(Modifier.padding(horizontal = 18.dp).fillMaxWidth()) {
                    LbCard(Modifier.fillMaxWidth(), padding = 14.dp, onClick = { onOpen(active) }) {
                        Row {
                            BookCover(
                                active,
                                Modifier.size(width = 92.dp, height = 132.dp)
                                    .shadow(5.dp, RoundedCornerShape(6.dp))
                                    .clip(RoundedCornerShape(6.dp))
                            )
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    active.title, color = LbTitle, fontSize = 23.sp, fontWeight = FontWeight.Bold,
                                    fontFamily = LibellumSerif, fontStyle = FontStyle.Italic,
                                    maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 27.sp,
                                    modifier = Modifier.padding(end = 26.dp)
                                )
                                Text(
                                    active.author, color = LbText, fontSize = 15.sp, fontFamily = LibellumSerif,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                                Spacer(Modifier.height(18.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    LbProgress(active.progressFraction(), Modifier.weight(1f))
                                    Spacer(Modifier.width(10.dp))
                                    Text(
                                        active.progressText(" leído"), color = LbText, fontSize = 13.sp,
                                        fontFamily = LibellumSerif, maxLines = 1
                                    )
                                }
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Box(Modifier.fillMaxWidth().height(1.dp).background(LbCardEdge))
                        Spacer(Modifier.height(10.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            LbIcon(LbIconKind.CLOCK, size = 26.dp)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Tiempo total", color = LbMuted, fontSize = 11.sp, fontFamily = LibellumSerif)
                                Text(
                                    formatReadingTime(totalBookMs), color = LbTitle, fontSize = 16.sp,
                                    fontWeight = FontWeight.SemiBold, fontFamily = LibellumSerif, maxLines = 1
                                )
                            }
                            Box(Modifier.width(1.dp).height(34.dp).background(LbCardEdge))
                            Spacer(Modifier.width(10.dp))
                            LbIcon(LbIconKind.CALENDAR, size = 26.dp)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1.2f)) {
                                Text("Última sesión", color = LbMuted, fontSize = 11.sp, fontFamily = LibellumSerif)
                                Text(
                                    lastSessionLabel(lastSessionAt), color = LbTitle, fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold, fontFamily = LibellumSerif, maxLines = 1
                                )
                            }
                            Box(
                                Modifier.size(40.dp).clip(CircleShape).background(Color(0xFFF2DDB8))
                                    .clickable { onOpen(active) },
                                contentAlignment = Alignment.Center
                            ) { LbIcon(LbIconKind.CHEVRON_RIGHT, tint = LbBrown, size = 20.dp) }
                        }
                    }
                    RibbonMark(
                        Modifier.align(Alignment.TopEnd).padding(end = 30.dp),
                        on = active.isFavorite == 1,
                        onClick = { onToggleFavorite(active) }
                    )
                }
            }
        }

        // ── Tu actividad ──
        item {
            Column(Modifier.padding(horizontal = 18.dp)) {
                LbSectionHeader(
                    "Tu actividad",
                    icon = { LbIcon(LbIconKind.CHART, size = 26.dp) }
                )
                Spacer(Modifier.height(10.dp))
                LbCard(Modifier.fillMaxWidth(), padding = 8.dp) {
                    LbPeriodSelector(
                        options = listOf("0" to "Esta semana", "1" to "Semana pasada", "2" to "Hace 2 semanas"),
                        selected = weeksBack.toString(),
                        onSelect = { weeksBack = it.toInt() },
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                    WeekBarsChart(
                        labels = week.map { it.first },
                        values = weekValues,
                        selected = selectedDay.coerceIn(0, 6),
                        onSelect = { selectedDay = it },
                        valueText = { formatReadingTime(it) }
                    )
                    if (weekValues.sum() == 0L) {
                        Text(
                            "Tus minutos de lectura aparecerán aquí mientras lees.",
                            color = LbMuted, fontSize = 11.sp, fontFamily = LibellumSerif,
                            fontStyle = FontStyle.Italic,
                            modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        }

        // ── Libros en lectura ──
        readingBooksSection(books = reading, onOpenBook = onOpen, onAllBooks = onAllBooks)
    }
}

/** Los 7 días de la semana con ✓ en los que leíste; hoy lleva un aro marrón. */
@Composable
private fun WeekDotsRow(days: Set<String>, modifier: Modifier = Modifier) {
    val today = Streak.key()
    Row(modifier, horizontalArrangement = Arrangement.SpaceBetween) {
        Streak.weekKeys().forEach { (label, key) ->
            val done = key in days
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(label, color = LbText, fontSize = 11.sp, fontFamily = LibellumSerif)
                Spacer(Modifier.height(5.dp))
                Box(
                    Modifier.size(17.dp).clip(CircleShape)
                        .background(if (done) LbBrown else Color.Transparent)
                        .border(1.3.dp, if (done || key == today) LbBrown else LbLine, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (done) LbIcon(LbIconKind.CHECK, tint = Color(0xFFFDF1DC), size = 10.dp)
                }
            }
        }
    }
}

private fun lastSessionLabel(at: Long): String {
    if (at <= 0L) return "—"
    val t = Calendar.getInstance().apply { timeInMillis = at }
    val now = Calendar.getInstance()
    val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(at))
    fun same(a: Calendar, b: Calendar) =
        a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
    val yesterday = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
    return when {
        same(t, now) -> "Hoy · $time"
        same(t, yesterday) -> "Ayer · $time"
        else -> SimpleDateFormat("d MMM · HH:mm", Locale("es")).format(Date(at))
    }
}
