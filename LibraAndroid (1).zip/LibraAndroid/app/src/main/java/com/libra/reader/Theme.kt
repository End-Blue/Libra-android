package com.libra.reader

import androidx.compose.ui.graphics.Color

// ── Paleta Libellum (azul noche + dorado del logo) ───────────────────────────
internal val Ink    = Color(0xFF0B1426)  // azul noche profundo
internal val Panel  = Color(0xFF152238)  // panel azul oscuro
internal val Cream  = Color(0xFFF3E6C8)  // crema dorada (texto)
internal val Gold   = Color(0xFFD4AF37)  // dorado del logo
internal val Muted  = Color(0xFF8A9BB5)  // azul grisáceo suave

// ── Colores pastel para subrayado ───────────────────────────────────────────
internal val HighlightYellow  = Color(0xFFFFF176)
internal val HighlightGreen   = Color(0xFFB9F6CA)
internal val HighlightBlue    = Color(0xFFB3E5FC)
internal val HighlightPink    = Color(0xFFF8BBD0)
internal val HighlightLavender= Color(0xFFE1BEE7)
internal val HighlightPeach   = Color(0xFFFFCCBC)

val HIGHLIGHT_COLORS = listOf(
    0xFFFFF176L to "Amarillo",
    0xFFB9F6CAL to "Verde",
    0xFFB3E5FCL to "Azul",
    0xFFF8BBD0L to "Rosa",
    0xFFE1BEE7L to "Lavanda",
    0xFFFFCCBCL to "Melocotón"
)
