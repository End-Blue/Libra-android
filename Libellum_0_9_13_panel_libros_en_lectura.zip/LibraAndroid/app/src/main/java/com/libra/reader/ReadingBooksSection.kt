package com.libra.reader

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ══════════════════════════════════════════════════════════════════════════════
// PANEL — «Libros en lectura»
// Usa solo el kit existente de LibUi.kt (LbCard, LbProgress, LbSectionHeader, Lb* colores)
// y BookCover de MainActivity.kt, así que no añade dependencias.
// ══════════════════════════════════════════════════════════════════════════════

private val CoverWidth = 82.dp
private val CoverHeight = 118.dp

/**
 * Sección completa para un LazyColumn: cabecera + una tarjeta por libro.
 * No se dibuja nada si [books] está vacío (igual que antes con «Añadidos recientemente»).
 *
 * Uso dentro del LazyColumn de DashboardScreen:
 *     readingBooksSection(books = reading, onOpenBook = onOpen, onAllBooks = onAllBooks)
 */
internal fun LazyListScope.readingBooksSection(
    books: List<LibraryItem>,
    onOpenBook: (LibraryItem) -> Unit,
    onAllBooks: () -> Unit,
    maxVisible: Int = 6,
    horizontalPadding: Dp = 18.dp
) {
    if (books.isEmpty()) return
    item(key = "reading_books_header") {
        ReadingBooksHeader(
            onAllBooks = onAllBooks,
            modifier = Modifier.padding(horizontal = horizontalPadding)
        )
    }
    items(books.take(maxVisible), key = { "reading_book_${it.id}" }) { book ->
        ReadingBookCard(
            book = book,
            onClick = { onOpenBook(book) },
            modifier = Modifier.padding(horizontal = horizontalPadding)
        )
    }
}

/** Encabezado: icono decorativo + «Libros en lectura» + botón compacto hacia Biblioteca. */
@Composable
internal fun ReadingBooksHeader(onAllBooks: () -> Unit, modifier: Modifier = Modifier) {
    LbSectionHeader(
        title = "Libros en lectura",
        icon = { LbIcon(LbIconKind.SPARKLE, size = 26.dp) },
        trailing = { LibraryIconButton(onClick = onAllBooks) },
        modifier = modifier
    )
}

/** Botón circular de 36 dp con una estantería dibujada; no puede cortarse porque no lleva texto. */
@Composable
internal fun LibraryIconButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(Color(0xFFF2DDB8))
            .border(1.dp, LbLine, CircleShape)
            .semantics { contentDescription = "Ir a la Biblioteca" }
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        ShelfGlyph(tint = LbBrown, size = 20.dp)
    }
}

/** Tarjeta horizontal: portada a la izquierda; título, autor, píldora de estado y progreso a la derecha. */
@Composable
internal fun ReadingBookCard(
    book: LibraryItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pct = book.progress.coerceIn(0, 100)
    LbCard(modifier.fillMaxWidth(), padding = 12.dp, onClick = onClick) {
        Row(Modifier.fillMaxWidth()) {
            BookCover(
                book,
                Modifier
                    .size(width = CoverWidth, height = CoverHeight)
                    .shadow(4.dp, RoundedCornerShape(12.dp))
                    .clip(RoundedCornerShape(12.dp))
            )
            Spacer(Modifier.width(14.dp))
            Column(
                Modifier.weight(1f).height(CoverHeight),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        book.title, color = LbTitle, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                        fontFamily = LibellumSerif, fontStyle = FontStyle.Italic,
                        maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 22.sp
                    )
                    Text(
                        book.author, color = LbText, fontSize = 14.sp, fontFamily = LibellumSerif,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    StatusPill(statusLabel(book.statusKey()).uppercase())
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LbProgress(pct / 100f, Modifier.weight(1f))
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "$pct%", color = LbText, fontSize = 13.sp, fontFamily = LibellumSerif,
                        fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false,
                        textAlign = TextAlign.End, modifier = Modifier.widthIn(min = 38.dp)
                    )
                }
            }
        }
    }
}

/** Píldora dorada/ámbar («LEYENDO»). */
@Composable
internal fun StatusPill(text: String, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(50)
    Text(
        text,
        modifier = modifier
            .clip(shape)
            .background(Color(0xFFF2DDB8))
            .border(1.dp, LbLine, shape)
            .padding(horizontal = 10.dp, vertical = 3.dp),
        color = LbBrown, fontSize = 10.sp, fontWeight = FontWeight.Bold,
        letterSpacing = 0.8.sp, maxLines = 1, softWrap = false
    )
}

/** Icono de estantería (tres libros sobre una balda) en trazo fino, como el resto de iconos Lb*. */
@Composable
private fun ShelfGlyph(tint: Color, modifier: Modifier = Modifier, size: Dp = 20.dp) {
    Canvas(modifier.size(size)) {
        val u = this.size.minDimension / 24f
        val stroke = Stroke(width = 1.7f * u)
        fun book(l: Float, t: Float, r: Float, b: Float) = drawRoundRect(
            tint, Offset(l * u, t * u), Size((r - l) * u, (b - t) * u),
            CornerRadius(1.2f * u, 1.2f * u), style = stroke
        )
        book(3.5f, 5f, 8f, 18f)
        book(9.5f, 3f, 14f, 18f)
        rotate(-16f, Offset(19f * u, 18f * u)) { book(16.5f, 4.5f, 21f, 18f) }
        drawLine(
            tint, Offset(2f * u, 20.8f * u), Offset(22f * u, 20.8f * u),
            strokeWidth = 1.7f * u, cap = StrokeCap.Round
        )
    }
}
