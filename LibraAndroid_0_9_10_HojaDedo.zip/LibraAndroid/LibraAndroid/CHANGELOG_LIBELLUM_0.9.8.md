# Libellum 0.9.8

## Novedades 0.9.8 — Inicio, Favoritos y Audiolibros con el nuevo diseño «papel dorado»
- **Barra inferior nueva** con laureles y pestaña activa resaltada. La 4.ª pestaña es «Racha» y pasa a «Audiolibros» cuando estás en esa pantalla.
- **Inicio**: cabecera ilustrada (saludo, fecha, cita, ⚙ ajustes), racha con ✓ en los días leídos, «Leyendo ahora» (cinta de marcador = favorito, tiempo total, última sesión «Hoy · hh:mm», botón ›), «Tu actividad» con selector Esta semana / Semana pasada / Hace 2 semanas y burbuja al tocar una barra, y «Añadidos recientemente».
- **Favoritos** (sin icono de ajustes): colección con total, último añadido y autor favorito; filtros Todos / Leyendo / Terminados / Más valorados; «Ordenar» (recientes, título, autor, valoración, progreso); cuadrícula de 3 con estrella, valoración y progreso; «Recomendados para ti» (mismo autor o género que tus favoritos).
- **Audiolibros** (sin icono de ajustes): tarjeta «En reproducción» con barra de avance, −15 s / +15 s, play/pausa, velocidad y «al azar»; «Tiempo escuchado esta semana» (se mide de verdad mientras suena) con «Ver detalles»; «Continúa escuchando» con play directo; «Explora por categorías» (filtra por el género del audiolibro); «Tus logros de escucha» con «Ver todos».
- Los filtros, el orden y la categoría elegidos se recuerdan al cambiar de pestaña.
- Nuevo: `LibUi.kt` (kit visual), `HomeUi.kt`, `FavoritesUi.kt`, `AudioHome.kt`. Ilustraciones: `hero_panel`, `hero_favs`, `hero_audio` (res/drawable-nodpi, se pueden sustituir por versiones en alta resolución con el mismo nombre).

