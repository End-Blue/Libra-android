# Libellum 0.9.5 — Sistema tipográfico

- Se establece una jerarquía global de tipografía en `Theme.kt`.
- Encabezados, títulos editoriales y nombres destacados usan la familia serif.
- Texto funcional, controles, botones, metadatos y etiquetas usan sans-serif para mejorar la lectura.
- `SectionTitle` comparte el tratamiento editorial con el resto de secciones.
- Se conservan las tipografías elegibles del lector de libros.
- Se eliminan cursivas redundantes en estilos globales: la cursiva queda reservada para encabezados y elementos editoriales.

## Nota sobre Fraunces
Esta compilación usa la serif del sistema Android como fallback temporal. El archivo TTF oficial de Fraunces no estaba disponible para incorporarlo al paquete en este entorno, por lo que esta entrega **no afirma incluir la fuente Fraunces exacta**. Para conseguir fidelidad tipográfica exacta, falta integrar los archivos TTF de Fraunces (romana e itálica) en `app/src/main/res/font/` y sustituir `LibellumSerif` por la familia cargada desde esos recursos.
