package com.libra.reader

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Typeface
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.unit.coerceAtMost
import androidx.compose.ui.unit.coerceIn
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.roundToInt

// ══════════════════════════════════════════════════════════════════════════════
// Libellum 0.9.6 — Paneles flotantes del lector
//  · Abajo a la derecha: ajustes de lectura (4 pestañas con iconos, valores en vivo)
//  · Arriba a la izquierda: anotaciones (marcadores · notas · resaltados)
//    Al abrir «Resaltados» la tarjeta se EXPANDE y muestra cada oración completa.
// Colores propios (azul noche + dorado). Para igualar el tema «papel» de la app,
// cambia los valores de abajo por Panel / Cream / Gold / Muted / Line de Theme.kt.
// ══════════════════════════════════════════════════════════════════════════════

private val RpNavy = Color(0xFF0E1B33)
private val RpNavy2 = Color(0xFF17274A)
private val RpLine = Color(0xFF27375A)
private val RpGold = Color(0xFFC9A24B)
private val RpText = Color(0xFFF6F0E2)
private val RpMuted = Color(0xFFB9C1D6)
private val RpDim = Color(0xFF7F8BAA)

enum class ReaderPanel { NONE, SETTINGS, NOTES }

// ── Marcadores (se guardan en SharedPreferences por libro; la base de datos no cambia) ──

data class ReaderBookmark(
    val id: String,
    val pos: Long,        // posición guardada por el lector (EPUB: índice de capítulo)
    val off: Int,         // texto exacto de la hoja marcada (caracteres desde el inicio del capítulo); -1 = solo capítulo
    val pct: Int,         // % leído en ese momento
    val label: String,    // «Cap. 5/67 · Nombre · Hoja 1/3»
    val createdAt: Long
)

internal fun loadReaderBookmarks(sp: SharedPreferences, bookId: String): List<ReaderBookmark> {
    val raw = sp.getString("bm_$bookId", null) ?: return emptyList()
    return runCatching {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ReaderBookmark(
                id = o.getString("id"),
                pos = o.optLong("pos"),
                off = o.optInt("off", -1),
                pct = o.optInt("pct"),
                label = o.optString("label"),
                createdAt = o.optLong("at")
            )
        }
    }.getOrDefault(emptyList())
}

internal fun saveReaderBookmarks(sp: SharedPreferences, bookId: String, list: List<ReaderBookmark>) {
    val arr = JSONArray()
    list.forEach { b ->
        arr.put(
            JSONObject()
                .put("id", b.id)
                .put("pos", b.pos)
                .put("off", b.off)
                .put("pct", b.pct)
                .put("label", b.label)
                .put("at", b.createdAt)
        )
    }
    sp.edit().putString("bm_$bookId", arr.toString()).apply()
}

internal fun newReaderBookmark(pos: Long, off: Int, pct: Int, label: String) =
    ReaderBookmark(UUID.randomUUID().toString(), pos, off, pct, label, System.currentTimeMillis())

// Tipografía «Clásica» = Lora (assets/fonts). Se distingue de la «Serif» del sistema.
private var loraCache: FontFamily? = null
internal fun libraClassicFamily(ctx: Context): FontFamily =
    loraCache ?: runCatching { FontFamily(Typeface.createFromAsset(ctx.assets, "fonts/lora.ttf")) }
        .getOrDefault(FontFamily.Serif)
        .also { loraCache = it }

// ══════════════════════════════════════════════════════════════════════════════
// Contenedor: botones flotantes + tarjetas
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun ReaderFloatingPanels(
    item: LibraryItem,
    prefs: ReadingPrefs,
    onPrefsChange: (ReadingPrefs) -> Unit,
    onUpdateItem: (LibraryItem) -> Unit,
    highlights: List<Highlight>,
    onEditHighlight: (Highlight) -> Unit,
    onDeleteHighlight: (Highlight) -> Unit,
    bookmarks: List<ReaderBookmark>,
    pageBookmarked: Boolean,
    onToggleBookmark: () -> Unit,
    onDeleteBookmark: (ReaderBookmark) -> Unit,
    onJumpBookmark: (ReaderBookmark) -> Unit,
    chapters: List<String>,
    currentChapter: Int,
    onGoChapter: (Int) -> Unit,
    onJumpChapter: (Int) -> Unit,
    onJumpHighlight: (Highlight) -> Unit,
    canJump: Boolean,
    panel: ReaderPanel,
    onPanelChange: (ReaderPanel) -> Unit,
    buttonsVisible: Boolean,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier.fillMaxSize()) {
        val maxW = maxWidth
        val maxH = maxHeight
        // si el lector muestra los botones ◀ ▶ abajo, el botón de ajustes sube para no taparlos
        val navInset = if (prefs.showNavButtons) 54.dp else 0.dp

        // Toque fuera de las tarjetas: las cierra (sin mover la página)
        if (panel != ReaderPanel.NONE) {
            Box(
                Modifier
                    .fillMaxSize()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) { onPanelChange(ReaderPanel.NONE) }
            )
        }

        // Botón arriba a la derecha: anotaciones (la X para cerrar el libro queda a la izquierda)
        AnimatedVisibility(
            visible = buttonsVisible || panel != ReaderPanel.NONE,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopEnd).padding(end = 8.dp, top = 4.dp)
        ) {
            RpFab(
                size = 40.dp,
                label = "Anotaciones: marcadores, notas y resaltados",
                open = panel == ReaderPanel.NOTES,
                onClick = {
                    onPanelChange(if (panel == ReaderPanel.NOTES) ReaderPanel.NONE else ReaderPanel.NOTES)
                }
            ) { LibIcon(LibIconKind.BOOKMARK, tint = RpGold, size = 20.dp, accent = RpGold) }
        }

        // Botón abajo a la derecha: ajustes de lectura
        AnimatedVisibility(
            visible = buttonsVisible || panel != ReaderPanel.NONE,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 14.dp, bottom = 14.dp + navInset)
        ) {
            RpFab(
                size = 52.dp,
                label = "Ajustes de lectura",
                open = panel == ReaderPanel.SETTINGS,
                onClick = {
                    onPanelChange(if (panel == ReaderPanel.SETTINGS) ReaderPanel.NONE else ReaderPanel.SETTINGS)
                }
            ) { LibIcon(LibIconKind.TEXT_SIZE, tint = RpGold, size = 24.dp, accent = RpGold) }
        }

        // Tarjeta de anotaciones (arriba derecha)
        AnimatedVisibility(
            visible = panel == ReaderPanel.NOTES,
            enter = fadeIn(tween(160)) + slideInVertically(tween(200)) { -it / 8 },
            exit = fadeOut(tween(120)),
            modifier = Modifier.align(Alignment.TopEnd).padding(end = 14.dp, top = 56.dp)
        ) {
            NotesCard(
                showBookmarks = canJump,
                bookmarks = bookmarks,
                pageBookmarked = pageBookmarked,
                chapters = chapters,
                currentChapter = currentChapter,
                onGoChapter = onGoChapter,
                highlights = highlights,
                canJump = canJump,
                maxW = maxW,
                maxH = maxH,
                onToggleBookmark = onToggleBookmark,
                onDeleteBookmark = onDeleteBookmark,
                onJumpBookmark = onJumpBookmark,
                onEdit = onEditHighlight,
                onDelete = onDeleteHighlight,
                onJumpChapter = onJumpChapter,
                onJumpHighlight = onJumpHighlight
            )
        }

        // Tarjeta de ajustes (abajo derecha)
        AnimatedVisibility(
            visible = panel == ReaderPanel.SETTINGS,
            enter = fadeIn(tween(160)) + slideInVertically(tween(200)) { it / 8 },
            exit = fadeOut(tween(120)),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(start = 14.dp, end = 14.dp, bottom = 76.dp + navInset)
        ) {
            SettingsCard(
                item = item,
                prefs = prefs,
                onPrefsChange = onPrefsChange,
                onUpdateItem = onUpdateItem,
                maxH = maxH
            )
        }
    }
}

@Composable
private fun RpFab(
    size: Dp,
    label: String,
    open: Boolean,
    onClick: () -> Unit,
    icon: @Composable () -> Unit
) {
    Box(
        Modifier
            .size(size)
            .shadow(6.dp, CircleShape)
            .clip(CircleShape)
            .background(RpNavy)
            .border(1.dp, RpLine, CircleShape)
            .clickable(onClick = onClick)
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center
    ) {
        if (open) LibIcon(LibIconKind.CLOSE, tint = RpGold, size = 20.dp, accent = RpGold) else icon()
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// Piezas comunes
// ══════════════════════════════════════════════════════════════════════════════

@Composable
private fun RowScope.RpTab(
    selected: Boolean,
    label: String,
    onClick: () -> Unit,
    content: @Composable (Color) -> Unit
) {
    val col = if (selected) RpGold else RpDim
    Box(
        Modifier
            .weight(1f)
            .height(46.dp)
            .clickable(onClick = onClick)
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center
    ) {
        content(col)
        if (selected) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .width(28.dp)
                    .height(3.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(RpGold)
            )
        }
    }
}

@Composable
private fun RpDivider() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(RpLine))
}

@Composable
private fun RpIconBtn(label: String, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier
            .size(36.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun RowScope.RpOpt(
    selected: Boolean,
    label: String,
    onClick: () -> Unit,
    content: @Composable (Color) -> Unit
) {
    Box(
        Modifier
            .weight(1f)
            .height(52.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) RpGold else RpNavy2)
            .clickable(onClick = onClick)
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center
    ) { content(if (selected) RpNavy else RpMuted) }
}

@Composable
private fun RpOptRow(content: @Composable RowScope.() -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        content = content
    )
}

@Composable
private fun RpSliderRow(
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    label: String,
    onChange: (Float) -> Unit,
    start: @Composable () -> Unit,
    end: @Composable () -> Unit
) {
    Row(Modifier.fillMaxWidth().height(50.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(24.dp), contentAlignment = Alignment.Center) { start() }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = RpGold,
                activeTrackColor = RpGold,
                inactiveTrackColor = RpLine
            ),
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 6.dp)
                .semantics { contentDescription = label }
        )
        Box(Modifier.width(24.dp), contentAlignment = Alignment.Center) { end() }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// Tarjeta de AJUSTES (abajo a la derecha)
// ══════════════════════════════════════════════════════════════════════════════

@Composable
private fun SettingsCard(
    item: LibraryItem,
    prefs: ReadingPrefs,
    onPrefsChange: (ReadingPrefs) -> Unit,
    onUpdateItem: (LibraryItem) -> Unit,
    maxH: Dp
) {
    var tab by remember { mutableIntStateOf(0) }
    val classicFamily = libraClassicFamily(LocalContext.current)
    var capName by remember { mutableStateOf("Tamaño") }
    var capVal by remember { mutableStateOf("${prefs.fontSizeSp}") }
    fun say(n: String, v: String = "") { capName = n; capVal = v }

    val shape = RoundedCornerShape(24.dp)
    // En pantallas bajas (horizontal) el contenido se desplaza en vez de salirse
    val bodyH = minOf(172.dp, maxH - 240.dp).coerceAtLeast(96.dp)

    Column(
        Modifier
            .widthIn(max = 304.dp)
            .fillMaxWidth()
            .shadow(10.dp, shape)
            .clip(shape)
            .background(RpNavy)
            .border(1.dp, RpLine, shape)
            .padding(horizontal = 16.dp)
            .padding(top = 2.dp, bottom = 10.dp)
    ) {
        // Pestañas con iconos
        Row(Modifier.fillMaxWidth()) {
            RpTab(tab == 0, "Texto", { tab = 0; say("Texto") }) { c ->
                LibIcon(LibIconKind.TEXT_SIZE, tint = c, size = 24.dp, accent = c)
            }
            RpTab(tab == 1, "Página", { tab = 1; say("Página") }) { c ->
                RdGlyph(RdIcon.PAGE, tint = c, size = 24.dp)
            }
            RpTab(tab == 2, "Pasar hoja y pantalla", { tab = 2; say("Pasar hoja y pantalla") }) { c ->
                RdGlyph(RdIcon.SWAP, tint = c, size = 24.dp)
            }
            RpTab(tab == 3, "Tema y brillo", { tab = 3; say("Tema y brillo") }) { c ->
                LibIcon(LibIconKind.THEME, tint = c, size = 24.dp, accent = c)
            }
        }
        RpDivider()

        // Una sola línea de texto: nombre y valor de lo último que tocaste
        Row(Modifier.fillMaxWidth().height(40.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(capName, color = RpMuted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (capVal.isNotEmpty()) {
                Spacer(Modifier.width(8.dp))
                Text(capVal, color = RpGold, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
            Spacer(Modifier.weight(1f))
            RpIconBtn("Restablecer ajustes", {
                onPrefsChange(ReadingPrefs())
                say("Restablecido")
            }) { LibIcon(LibIconKind.REPLAY, tint = RpMuted, size = 20.dp, accent = RpMuted) }
        }

        Column(Modifier.fillMaxWidth().height(bodyH).verticalScroll(rememberScrollState())) {
            when (tab) {
                // ── Texto: tamaño · fuente · interlineado ───────────────────────────
                0 -> {
                    RpSliderRow(
                        value = prefs.fontSizeSp.toFloat(),
                        range = 12f..32f,
                        label = "Tamaño del texto",
                        onChange = { v ->
                            onPrefsChange(prefs.copy(fontSizeSp = v.roundToInt()))
                            say("Tamaño", "${v.roundToInt()}")
                        },
                        start = { Text("A", color = RpMuted, fontSize = 13.sp, fontFamily = FontFamily.Serif) },
                        end = { Text("A", color = RpText, fontSize = 24.sp, fontFamily = FontFamily.Serif) }
                    )
                    RpOptRow {
                        listOf("serif" to "Serif", "sans" to "Sans", "classic" to "Clásica").forEach { (id, name) ->
                            RpOpt(prefs.fontFamily == id, "Fuente $name", {
                                onPrefsChange(prefs.copy(fontFamily = id)); say("Fuente", name)
                            }) { c ->
                                Text(
                                    "Aa", color = c, fontSize = 22.sp,
                                    fontFamily = when (id) {
                                        "sans" -> FontFamily.SansSerif
                                        "classic" -> classicFamily
                                        else -> FontFamily.Serif
                                    }
                                )
                            }
                        }
                    }
                    RpSliderRow(
                        value = prefs.lineHeight,
                        range = 1.2f..2.2f,
                        label = "Interlineado",
                        onChange = { v ->
                            val r = (v * 20f).roundToInt() / 20f
                            onPrefsChange(prefs.copy(lineHeight = r))
                            say("Interlineado", "%.2f".format(r))
                        },
                        start = { RdGlyph(RdIcon.DENSITY_LOW, tint = RpMuted, size = 20.dp) },
                        end = { RdGlyph(RdIcon.DENSITY_HIGH, tint = RpMuted, size = 20.dp) }
                    )
                }

                // ── Página: márgenes · justificado · sangría · cinta ────────────────
                1 -> {
                    RpSliderRow(
                        value = prefs.marginDp.toFloat(),
                        range = 8f..40f,
                        label = "Márgenes",
                        onChange = { v ->
                            onPrefsChange(prefs.copy(marginDp = v.roundToInt()))
                            say("Márgenes", "${v.roundToInt()}")
                        },
                        start = { RdGlyph(RdIcon.MARGIN_WIDE, tint = RpMuted, size = 20.dp) },
                        end = { RdGlyph(RdIcon.MARGIN_NARROW, tint = RpMuted, size = 20.dp) }
                    )
                    val ribbon = item.bookmarkStyle != "NONE"
                    RpOptRow {
                        RpOpt(prefs.justify, "Justificado", {
                            onPrefsChange(prefs.copy(justify = !prefs.justify))
                            say("Justificado", if (!prefs.justify) "sí" else "no")
                        }) { c -> RdGlyph(RdIcon.JUSTIFY, tint = c, size = 24.dp) }
                        RpOpt(prefs.indent, "Sangría", {
                            onPrefsChange(prefs.copy(indent = !prefs.indent))
                            say("Sangría", if (!prefs.indent) "sí" else "no")
                        }) { c -> RdGlyph(RdIcon.INDENT, tint = c, size = 24.dp, accent = c) }
                        RpOpt(ribbon, "Listón rojo en las hojas marcadas", {
                            onUpdateItem(item.copy(bookmarkStyle = if (ribbon) "NONE" else "RIBBON"))
                            say("Listón", if (!ribbon) "sí" else "no")
                        }) { c -> LibIcon(LibIconKind.BOOKMARK, tint = c, size = 24.dp, filled = ribbon, accent = c) }
                    }
                }

                // ── Pasar hoja y pantalla ───────────────────────────────────────────
                2 -> {
                    RpOptRow {
                        RpOpt(prefs.orientation == "auto", "Pantalla automática", {
                            onPrefsChange(prefs.copy(orientation = "auto")); say("Pantalla", "Auto")
                        }) { c -> RdGlyph(RdIcon.ROTATE, tint = c, size = 24.dp) }
                        RpOpt(prefs.orientation == "portrait", "Vertical", {
                            onPrefsChange(prefs.copy(orientation = "portrait")); say("Pantalla", "Vertical")
                        }) { c -> RdGlyph(RdIcon.PHONE_V, tint = c, size = 24.dp) }
                        RpOpt(prefs.orientation == "landscape", "Horizontal", {
                            onPrefsChange(prefs.copy(orientation = "landscape")); say("Pantalla", "Horizontal")
                        }) { c -> RdGlyph(RdIcon.PHONE_H, tint = c, size = 24.dp) }
                        RpOpt(prefs.leftHanded, "Mano izquierda", {
                            onPrefsChange(prefs.copy(leftHanded = !prefs.leftHanded))
                            say("Mano izquierda", if (!prefs.leftHanded) "sí" else "no")
                        }) { c -> RdGlyph(RdIcon.HAND, tint = c, size = 24.dp) }
                        RpOpt(prefs.showNavButtons, "Botones anterior y siguiente", {
                            onPrefsChange(prefs.copy(showNavButtons = !prefs.showNavButtons))
                            say("Botones ◀ ▶", if (!prefs.showNavButtons) "sí" else "no")
                        }) { c -> RdGlyph(RdIcon.ARROWS_LR, tint = c, size = 24.dp) }
                    }
                }

                // ── Tema y brillo ───────────────────────────────────────────────────
                else -> {
                    Row(
                        Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 10.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf(
                            Triple(2, Color(0xFFFFFFFF), "Blanco"),
                            Triple(1, Color(0xFFF4ECD8), "Papel"),
                            Triple(0, Color(0xFF0B1426), "Noche"),
                            Triple(3, Color(0xFF000000), "Negro")
                        ).forEach { (mode, color, name) ->
                            val sel = prefs.themeMode == mode
                            Box(
                                Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .border(if (sel) 3.dp else 2.dp, if (sel) RpGold else RpLine, CircleShape)
                                    .clickable {
                                        onPrefsChange(prefs.copy(themeMode = mode)); say("Tema", name)
                                    }
                                    .semantics { contentDescription = "Tema $name" }
                            )
                        }
                    }
                    RpSliderRow(
                        value = prefs.brightness,
                        range = 0.35f..1f,
                        label = "Brillo",
                        onChange = { v ->
                            onPrefsChange(prefs.copy(brightness = v))
                            say("Brillo", "${(v * 100).roundToInt()}%")
                        },
                        start = { RdGlyph(RdIcon.SUN_LOW, tint = RpMuted, size = 20.dp) },
                        end = { RdGlyph(RdIcon.SUN_HIGH, tint = RpMuted, size = 20.dp) }
                    )
                }
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// Tarjeta de ANOTACIONES (arriba a la izquierda)
//   Marcadores · Notas · Resaltados  →  «Resaltados» se expande y muestra la oración completa
// ══════════════════════════════════════════════════════════════════════════════

private enum class NTab { BOOKMARKS, NOTES, HIGHLIGHTS }

@Composable
private fun NotesCard(
    showBookmarks: Boolean,
    bookmarks: List<ReaderBookmark>,
    pageBookmarked: Boolean,
    chapters: List<String>,
    currentChapter: Int,
    onGoChapter: (Int) -> Unit,
    highlights: List<Highlight>,
    canJump: Boolean,
    maxW: Dp,
    maxH: Dp,
    onToggleBookmark: () -> Unit,
    onDeleteBookmark: (ReaderBookmark) -> Unit,
    onJumpBookmark: (ReaderBookmark) -> Unit,
    onEdit: (Highlight) -> Unit,
    onDelete: (Highlight) -> Unit,
    onJumpChapter: (Int) -> Unit,
    onJumpHighlight: (Highlight) -> Unit
) {
    val tabs = if (showBookmarks) listOf(NTab.BOOKMARKS, NTab.NOTES, NTab.HIGHLIGHTS)
    else listOf(NTab.NOTES, NTab.HIGHLIGHTS)
    var tab by remember { mutableStateOf(tabs.first()) }
    var big by remember { mutableStateOf(true) }   // «Resaltados» expandido (se puede contraer)
    val notes = remember(highlights) { highlights.filter { it.note.isNotBlank() } }

    // La tarjeta crece al abrir «Resaltados» (oraciones completas) y «Marcadores» (con los capítulos)
    val wide = tab == NTab.HIGHLIGHTS && big
    val cardW by animateDpAsState(
        if (wide) (maxW - 28.dp).coerceAtMost(392.dp) else (maxW - 28.dp).coerceAtMost(292.dp),
        tween(260), label = "notesW"
    )
    val bodyH by animateDpAsState(
        when {
            wide -> (maxH - 210.dp).coerceIn(172.dp, 480.dp)
            tab == NTab.BOOKMARKS -> (maxH - 300.dp).coerceIn(172.dp, 340.dp)
            else -> 172.dp
        },
        tween(260), label = "notesH"
    )

    val shape = RoundedCornerShape(24.dp)
    Column(
        Modifier
            .width(cardW)
            .shadow(10.dp, shape)
            .clip(shape)
            .background(RpNavy)
            .border(1.dp, RpLine, shape)
            .padding(horizontal = 16.dp)
            .padding(top = 2.dp, bottom = 10.dp)
    ) {
        Row(Modifier.fillMaxWidth()) {
            tabs.forEach { t ->
                val count = when (t) {
                    NTab.BOOKMARKS -> bookmarks.size
                    NTab.NOTES -> notes.size
                    NTab.HIGHLIGHTS -> highlights.size
                }
                val name = when (t) {
                    NTab.BOOKMARKS -> "Marcadores y capítulos"
                    NTab.NOTES -> "Notas"
                    NTab.HIGHLIGHTS -> "Resaltados"
                }
                RpTab(tab == t, "$name, $count", { tab = t; if (t == NTab.HIGHLIGHTS) big = true }) { c ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        when (t) {
                            NTab.BOOKMARKS -> LibIcon(LibIconKind.BOOKMARK, tint = c, size = 23.dp, accent = c)
                            NTab.NOTES -> RdGlyph(RdIcon.NOTE, tint = c, size = 23.dp)
                            NTab.HIGHLIGHTS -> LibIcon(LibIconKind.NOTES, tint = c, size = 23.dp, accent = c)
                        }
                        Spacer(Modifier.width(4.dp))
                        Text("$count", color = c, fontSize = 11.sp)
                    }
                }
            }
        }
        RpDivider()

        Row(Modifier.fillMaxWidth().height(40.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                when (tab) {
                    NTab.BOOKMARKS -> "Marcadores"
                    NTab.NOTES -> "Notas"
                    NTab.HIGHLIGHTS -> "Resaltados"
                },
                color = RpMuted, fontSize = 13.sp
            )
            Spacer(Modifier.weight(1f))
            when (tab) {
                NTab.BOOKMARKS -> RpIconBtn(
                    if (pageBookmarked) "Quitar el marcador de esta hoja" else "Poner marcador en esta hoja",
                    onToggleBookmark
                ) {
                    if (pageBookmarked) LibIcon(LibIconKind.BOOKMARK, tint = Color(0xFFE23744), size = 22.dp, filled = true, accent = Color(0xFFE23744))
                    else LibIcon(LibIconKind.PLUS, tint = RpGold, size = 20.dp, accent = RpGold)
                }
                NTab.HIGHLIGHTS -> RpIconBtn(if (big) "Contraer" else "Expandir", { big = !big }) {
                    RdGlyph(if (big) RdIcon.CHEV_UP else RdIcon.CHEV_DOWN, tint = RpMuted, size = 20.dp)
                }
                NTab.NOTES -> {}
            }
        }

        Box(Modifier.fillMaxWidth().height(bodyH)) {
            when (tab) {
                NTab.BOOKMARKS -> {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        if (bookmarks.isEmpty()) {
                            item {
                                Text(
                                    "Toca el botón de arriba para poner un listón rojo en la hoja que estás leyendo.",
                                    color = RpDim, fontSize = 12.sp, lineHeight = 17.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                )
                            }
                        } else {
                            items(bookmarks, key = { it.id }) { b ->
                                BookmarkRow(b, canJump, { onJumpBookmark(b) }, { onDeleteBookmark(b) })
                            }
                        }
                        item {
                            Text(
                                "CAPÍTULOS", color = RpGold, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                modifier = Modifier.padding(start = 8.dp, top = 12.dp, bottom = 4.dp)
                            )
                        }
                        itemsIndexed(chapters) { i, name ->
                            ChapterRow(i, name, selected = i == currentChapter) { onGoChapter(i) }
                        }
                    }
                }
                NTab.NOTES -> {
                    if (notes.isEmpty()) RpEmpty("Aún no hay notas. Al resaltar un texto puedes añadir una.")
                    else LazyColumn(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        items(notes, key = { it.id }) { h ->
                            NoteRow(h, canJump, { onEdit(h) }, { onJumpHighlight(h) })
                        }
                    }
                }
                NTab.HIGHLIGHTS -> {
                    if (highlights.isEmpty()) RpEmpty("Mantén pulsado un texto mientras lees para resaltarlo.")
                    else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(highlights, key = { it.id }) { h ->
                            HighlightItem(
                                h = h,
                                canJump = canJump,
                                onJump = { onJumpHighlight(h) },
                                onEdit = { onEdit(h) },
                                onDelete = { onDelete(h) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChapterRow(index: Int, name: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) RpGold.copy(alpha = 0.16f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "${index + 1}", color = if (selected) RpGold else RpDim, fontSize = 11.sp,
            modifier = Modifier.width(26.dp)
        )
        Text(
            name, color = if (selected) RpText else RpMuted, fontSize = 13.sp,
            maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
        )
        if (selected) Text("●", color = RpGold, fontSize = 10.sp)
    }
}

@Composable
private fun RpEmpty(text: String) {
    Box(Modifier.fillMaxSize().padding(horizontal = 12.dp), contentAlignment = Alignment.Center) {
        Text(text, color = RpDim, fontSize = 13.sp, lineHeight = 19.sp)
    }
}

@Composable
private fun BookmarkRow(
    b: ReaderBookmark,
    canJump: Boolean,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    val fmt = remember { SimpleDateFormat("d MMM", Locale.getDefault()) }
    val parts = b.label.split(" · ")
    val title = parts.getOrNull(1)?.takeIf { it.isNotBlank() } ?: b.label.ifBlank { "Marcador" }
    val meta = listOfNotNull(parts.getOrNull(2), "${b.pct}%", fmt.format(Date(b.createdAt))).joinToString(" · ")
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(enabled = canJump, onClick = onClick)
            .padding(start = 8.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        LibIcon(LibIconKind.BOOKMARK, tint = RpGold, size = 20.dp, filled = true, accent = RpGold)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = RpText, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(meta, color = RpDim, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        RpIconBtn("Eliminar marcador", onDelete) {
            LibIcon(LibIconKind.TRASH, tint = RpDim, size = 18.dp, accent = RpDim)
        }
    }
}

@Composable
private fun NoteRow(
    h: Highlight,
    canJump: Boolean,
    onEdit: () -> Unit,
    onJump: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = if (canJump) onJump else onEdit)
            .padding(start = 8.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RdGlyph(RdIcon.NOTE, tint = RpGold, size = 20.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(h.note, color = RpText, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(
                h.chapterTitle.ifBlank { "Nota" },
                color = RpDim, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        if (canJump) {
            RpIconBtn("Ir al texto", onJump) { RdGlyph(RdIcon.GOTO, tint = RpMuted, size = 18.dp) }
        }
        RpIconBtn("Editar nota", onEdit) {
            LibIcon(LibIconKind.NOTES, tint = RpMuted, size = 18.dp, accent = RpMuted)
        }
    }
}

/**
 * Un resaltado con la ORACIÓN COMPLETA (no recortada con «…»).
 * Si es muy larga se muestran 8 líneas y «Ver toda la oración» la despliega entera.
 */
@Composable
private fun HighlightItem(
    h: Highlight,
    canJump: Boolean,
    onJump: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val color = Color(h.colorArgb)
    val fmt = remember { SimpleDateFormat("d MMM yyyy", Locale.getDefault()) }
    var open by remember(h.id) { mutableStateOf(false) }
    var overflow by remember(h.id) { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(enabled = canJump, onClick = onJump)
            .background(RpNavy2)
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(color))
            Spacer(Modifier.width(8.dp))
            Text(
                h.chapterTitle.ifBlank { "Resaltado" },
                color = RpMuted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Text(fmt.format(Date(h.createdAt)), color = RpDim, fontSize = 10.sp)
        }
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .height(IntrinsicSize.Min)
                .clip(RoundedCornerShape(10.dp))
                .background(color.copy(alpha = 0.14f))
        ) {
            Box(Modifier.width(3.dp).fillMaxHeight().background(color))
            Text(
                h.selectedText.trim(),
                color = RpText,
                fontSize = 15.sp,
                lineHeight = 22.sp,
                fontFamily = FontFamily.Serif,
                maxLines = if (open) Int.MAX_VALUE else 8,
                overflow = TextOverflow.Ellipsis,
                onTextLayout = { if (!open) overflow = it.hasVisualOverflow },
                modifier = Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 8.dp)
            )
        }
        if (overflow || open) {
            Text(
                if (open) "Ver menos" else "Ver toda la oración",
                color = RpGold, fontSize = 12.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .clickable { open = !open }
                    .padding(top = 8.dp, bottom = 2.dp)
            )
        }
        if (h.note.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.Top) {
                RdGlyph(RdIcon.NOTE, tint = RpGold, size = 16.dp)
                Spacer(Modifier.width(8.dp))
                Text(h.note, color = RpMuted, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.weight(1f))
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.End) {
            if (canJump) {
                RpIconBtn("Ir al texto", onJump) { RdGlyph(RdIcon.GOTO, tint = RpMuted, size = 18.dp) }
            }
            RpIconBtn("Editar nota o color", onEdit) {
                LibIcon(LibIconKind.NOTES, tint = RpMuted, size = 18.dp, accent = RpMuted)
            }
            RpIconBtn("Eliminar resaltado", onDelete) {
                LibIcon(LibIconKind.TRASH, tint = RpDim, size = 18.dp, accent = RpDim)
            }
        }
    }
}


// ══════════════════════════════════════════════════════════════════════════════
// Listón rojo de la hoja marcada — pegado al lateral izquierdo, como en un libro real.
// Cae desde arriba con un pequeño rebote al marcar; mantén pulsado para quitarlo.
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun PageRibbon(
    visible: Boolean,
    onLongPress: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ribbonH = 104.dp
    val ribbonW = 20.dp
    val drop by animateDpAsState(
        targetValue = if (visible) 0.dp else -(ribbonH + 16.dp),
        animationSpec = spring(dampingRatio = 0.52f, stiffness = Spring.StiffnessLow),
        label = "ribbonDrop"
    )
    if (!visible && drop <= -(ribbonH + 12.dp)) return   // ya subió del todo: no se dibuja

    Canvas(
        modifier
            .offset(x = 5.dp, y = drop)
            .size(ribbonW + 10.dp, ribbonH + 10.dp)
            .pointerInput(Unit) { detectTapGestures(onLongPress = { onLongPress() }) }
    ) {
        val w = ribbonW.toPx()
        val h = ribbonH.toPx()
        val notch = 15.dp.toPx()
        val ribbon = Path().apply {
            moveTo(0f, 0f); lineTo(w, 0f); lineTo(w, h)
            lineTo(w / 2f, h - notch)          // muesca en V (cola de golondrina)
            lineTo(0f, h); close()
        }
        // sombra suave que cae sobre la hoja
        translate(left = 4.dp.toPx(), top = 3.dp.toPx()) { drawPath(ribbon, Color.Black.copy(alpha = 0.16f)) }
        translate(left = 2.5.dp.toPx(), top = 1.8.dp.toPx()) { drawPath(ribbon, Color.Black.copy(alpha = 0.20f)) }
        // tela: franjas de brillo de izquierda a derecha
        drawPath(
            ribbon,
            Brush.horizontalGradient(
                0f to Color(0xFF7A0B13), 0.22f to Color(0xFFC8182A), 0.48f to Color(0xFFEA3A47),
                0.78f to Color(0xFFB5121F), 1f to Color(0xFF74090F),
                startX = 0f, endX = w
            )
        )
        clipPath(ribbon) {
            // pliegue y sombra donde nace el listón (borde superior de la hoja)
            drawRect(
                Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.45f), Color.Transparent), 0f, 26.dp.toPx()),
                size = androidx.compose.ui.geometry.Size(w, 26.dp.toPx())
            )
            // brillo satinado
            drawRect(
                Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = 0.0f), Color.White.copy(alpha = 0.16f), Color.White.copy(alpha = 0.0f)),
                    0f, h
                ),
                topLeft = Offset(w * 0.34f, 0f),
                size = androidx.compose.ui.geometry.Size(3.dp.toPx(), h)
            )
            // pespunte a ambos lados
            val dash = PathEffect.dashPathEffect(floatArrayOf(5.dp.toPx(), 4.dp.toPx()))
            drawLine(
                Color.White.copy(alpha = 0.28f), Offset(3.2.dp.toPx(), 3.dp.toPx()), Offset(3.2.dp.toPx(), h - 4.dp.toPx()),
                strokeWidth = 0.9.dp.toPx(), pathEffect = dash
            )
            drawLine(
                Color.White.copy(alpha = 0.28f), Offset(w - 3.2.dp.toPx(), 3.dp.toPx()), Offset(w - 3.2.dp.toPx(), h - 4.dp.toPx()),
                strokeWidth = 0.9.dp.toPx(), pathEffect = dash
            )
        }
        drawPath(ribbon, Color(0xFF4A060B).copy(alpha = 0.55f), style = Stroke(width = 0.8.dp.toPx()))
    }
}
