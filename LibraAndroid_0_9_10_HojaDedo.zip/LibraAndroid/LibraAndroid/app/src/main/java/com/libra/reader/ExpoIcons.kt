package com.libra.reader

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Iconos de la vitrina: trazo fino de puntas redondeadas sobre una rejilla de 24×24. */
internal enum class XIconKind {
    TRASH, LOCK, UNLOCK, MORE, UNDO, REDO, CHECK, COVER, SCALE, ROTATE, PLUS, SPARKLE, BACK,
    ZOOM_IN, ZOOM_OUT, SPINE, EDGE, PENCIL, PORTRAIT, LANDSCAPE, FLIP, CHEVRON_DOWN, RESIZE, CLOSE
}

@Composable
internal fun XIcon(kind: XIconKind, tint: Color, modifier: Modifier = Modifier, size: Dp = 20.dp) {
    Canvas(modifier.size(size)) { drawXIcon(kind, tint) }
}

private fun DrawScope.drawXIcon(kind: XIconKind, c: Color) {
    val u = size.minDimension / 24f
    val line = Stroke(width = 1.9f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)

    fun Path.m(x: Float, y: Float) = moveTo(x * u, y * u)
    fun Path.l(x: Float, y: Float) = lineTo(x * u, y * u)
    fun Path.cu(a: Float, b: Float, cc: Float, d: Float, e: Float, f: Float) =
        cubicTo(a * u, b * u, cc * u, d * u, e * u, f * u)
    fun path(block: Path.() -> Unit): Path = Path().apply(block)
    fun seg(x1: Float, y1: Float, x2: Float, y2: Float, w: Float = 1.9f) =
        drawLine(c, Offset(x1 * u, y1 * u), Offset(x2 * u, y2 * u), strokeWidth = w * u, cap = StrokeCap.Round)
    fun ring(cx: Float, cy: Float, r: Float, w: Float = 1.9f) =
        drawCircle(c, radius = r * u, center = Offset(cx * u, cy * u), style = Stroke(width = w * u))
    fun dot(cx: Float, cy: Float, r: Float) = drawCircle(c, radius = r * u, center = Offset(cx * u, cy * u))
    fun box(l: Float, t: Float, r: Float, b: Float, rad: Float) {
        val p = Path().apply {
            addRoundRect(RoundRect(l * u, t * u, r * u, b * u, CornerRadius(rad * u, rad * u)))
        }
        drawPath(p, c, style = line)
    }

    when (kind) {
        XIconKind.TRASH -> {
            seg(5f, 7f, 19f, 7f)
            drawPath(path { m(9f, 7f); l(9f, 4.8f); l(15f, 4.8f); l(15f, 7f) }, c, style = line)
            drawPath(path { m(7f, 7f); l(8f, 19f); l(16f, 19f); l(17f, 7f) }, c, style = line)
            seg(10.2f, 10.5f, 10.2f, 15.5f, 1.5f)
            seg(13.8f, 10.5f, 13.8f, 15.5f, 1.5f)
        }
        XIconKind.LOCK -> {
            box(6f, 11f, 18f, 20f, 2.2f)
            drawPath(path { m(8.6f, 11f); l(8.6f, 8.6f); cu(8.6f, 4.4f, 15.4f, 4.4f, 15.4f, 8.6f); l(15.4f, 11f) }, c, style = line)
            dot(12f, 15.5f, 1.2f)
        }
        XIconKind.UNLOCK -> {
            box(6f, 11f, 18f, 20f, 2.2f)
            drawPath(path { m(8.6f, 11f); l(8.6f, 8.6f); cu(8.6f, 4.4f, 15.4f, 4.4f, 15.4f, 7.2f) }, c, style = line)
            dot(12f, 15.5f, 1.2f)
        }
        XIconKind.MORE -> {
            dot(6f, 12f, 1.7f); dot(12f, 12f, 1.7f); dot(18f, 12f, 1.7f)
        }
        XIconKind.UNDO -> {
            drawPath(path { m(9f, 5.5f); l(5f, 9.5f); l(9f, 13.5f) }, c, style = line)
            drawPath(path { m(5f, 9.5f); l(14f, 9.5f); cu(18.8f, 9.5f, 18.8f, 18f, 14f, 18f); l(8.5f, 18f) }, c, style = line)
        }
        XIconKind.REDO -> {
            drawPath(path { m(15f, 5.5f); l(19f, 9.5f); l(15f, 13.5f) }, c, style = line)
            drawPath(path { m(19f, 9.5f); l(10f, 9.5f); cu(5.2f, 9.5f, 5.2f, 18f, 10f, 18f); l(15.5f, 18f) }, c, style = line)
        }
        XIconKind.CHECK -> {
            drawPath(path { m(5f, 12.5f); l(10f, 17.5f); l(19f, 7f) }, c, style = Stroke(width = 2.3f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        XIconKind.COVER -> {
            drawPath(
                path {
                    m(12f, 7f); cu(10f, 5.4f, 6.5f, 5.4f, 4f, 6.5f); l(4f, 18f)
                    cu(6.5f, 17f, 10f, 17f, 12f, 18.6f); cu(14f, 17f, 17.5f, 17f, 20f, 18f); l(20f, 6.5f)
                    cu(17.5f, 5.4f, 14f, 5.4f, 12f, 7f); close()
                },
                c, style = line
            )
            seg(12f, 7f, 12f, 18.6f, 1.5f)
        }
        XIconKind.SCALE -> {
            seg(6.5f, 17.5f, 17.5f, 6.5f)
            drawPath(path { m(12.5f, 6f); l(18f, 6f); l(18f, 11.5f) }, c, style = line)
            drawPath(path { m(11.5f, 18f); l(6f, 18f); l(6f, 12.5f) }, c, style = line)
        }
        XIconKind.ROTATE -> {
            drawArc(
                c, -50f, 280f, false, Offset(5f * u, 5f * u), Size(14f * u, 14f * u), style = line
            )
            drawPath(path { m(19.2f, 3.8f); l(18.6f, 8.4f); l(14.2f, 7.4f) }, c, style = line)
        }
        XIconKind.PLUS -> {
            seg(12f, 5f, 12f, 19f, 2.1f); seg(5f, 12f, 19f, 12f, 2.1f)
        }
        XIconKind.SPARKLE -> {
            val star = path {
                m(11f, 3.5f); cu(11.6f, 8.6f, 13.4f, 10.4f, 18.5f, 11f)
                cu(13.4f, 11.6f, 11.6f, 13.4f, 11f, 18.5f)
                cu(10.4f, 13.4f, 8.6f, 11.6f, 3.5f, 11f)
                cu(8.6f, 10.4f, 10.4f, 8.6f, 11f, 3.5f); close()
            }
            drawPath(star, c)
            val small = path {
                m(18f, 14.5f); cu(18.3f, 17f, 19.1f, 17.8f, 21.5f, 18f)
                cu(19.1f, 18.2f, 18.3f, 19f, 18f, 21.5f)
                cu(17.7f, 19f, 16.9f, 18.2f, 14.5f, 18f)
                cu(16.9f, 17.8f, 17.7f, 17f, 18f, 14.5f); close()
            }
            drawPath(small, c)
        }
        XIconKind.BACK -> {
            drawPath(path { m(15f, 5f); l(8f, 12f); l(15f, 19f) }, c, style = line)
        }
        XIconKind.ZOOM_IN -> {
            ring(10.5f, 10.5f, 6f); seg(15f, 15f, 20f, 20f); seg(8f, 10.5f, 13f, 10.5f, 1.6f); seg(10.5f, 8f, 10.5f, 13f, 1.6f)
        }
        XIconKind.ZOOM_OUT -> {
            ring(10.5f, 10.5f, 6f); seg(15f, 15f, 20f, 20f); seg(8f, 10.5f, 13f, 10.5f, 1.6f)
        }
        XIconKind.SPINE -> {
            box(4f, 5.5f, 20f, 18.5f, 2.2f)
            seg(4f, 10f, 20f, 10f, 1.5f); seg(4f, 14f, 20f, 14f, 1.5f)
        }
        XIconKind.EDGE -> {
            box(3.5f, 5f, 8f, 19f, 1.4f); box(9.8f, 5f, 14.3f, 19f, 1.4f); box(16f, 5f, 20.5f, 19f, 1.4f)
        }
        XIconKind.PENCIL -> {
            drawPath(path { m(4.5f, 19.5f); l(5.2f, 15.6f); l(15.8f, 5f); l(19f, 8.2f); l(8.4f, 18.8f); close() }, c, style = line)
            seg(13.4f, 7.4f, 16.6f, 10.6f, 1.5f)
        }
        XIconKind.PORTRAIT -> box(7f, 3.5f, 17f, 20.5f, 2.6f)
        XIconKind.LANDSCAPE -> box(3.5f, 7f, 20.5f, 17f, 2.6f)
        XIconKind.FLIP -> {
            seg(8f, 5f, 8f, 19f)
            drawPath(path { m(5f, 16f); l(8f, 19f); l(11f, 16f) }, c, style = line)
            seg(16f, 19f, 16f, 5f)
            drawPath(path { m(13f, 8f); l(16f, 5f); l(19f, 8f) }, c, style = line)
        }
        XIconKind.CHEVRON_DOWN -> {
            drawPath(path { m(7f, 10f); l(12f, 15f); l(17f, 10f) }, c, style = line)
        }
        XIconKind.RESIZE -> {
            seg(7f, 17f, 17f, 7f, 1.7f)
            drawPath(path { m(12f, 7f); l(17f, 7f); l(17f, 12f) }, c, style = Stroke(width = 1.7f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
            drawPath(path { m(12f, 17f); l(7f, 17f); l(7f, 12f) }, c, style = Stroke(width = 1.7f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        XIconKind.CLOSE -> {
            seg(6f, 6f, 18f, 18f); seg(18f, 6f, 6f, 18f)
        }
    }
}
