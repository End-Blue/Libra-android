package com.libra.reader

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp

// ══════════════════════════════════════════════════════════════════════════════
// Catálogo de objetos de la vitrina. Los 16 clásicos se dibujan con DecoView (ShelfDraw);
// los nuevos (monstera, helecho, bonsái…) se dibujan aquí con Canvas, sin imágenes.
// ══════════════════════════════════════════════════════════════════════════════

internal data class XDecoDef(val key: String, val label: String, val cat: String, val w: Int, val h: Int)

internal val X_DECO_CATS = listOf(
    "Todo", "Plantas", "Naturaleza", "Luz", "Rincón cálido", "Curiosidades", "Mascotas"
)

internal val X_DECOS = listOf(
    XDecoDef("monstera", "Monstera", "Plantas", 54, 64),
    XDecoDef("fern", "Helecho", "Plantas", 50, 58),
    XDecoDef("bonsai", "Bonsái", "Plantas", 54, 54),
    XDecoDef("orchid", "Orquídea", "Plantas", 36, 62),
    XDecoDef("succulents", "Suculentas", "Plantas", 54, 30),
    XDecoDef("cactus", "Cactus", "Plantas", 30, 46),
    XDecoDef("plant", "Maceta", "Plantas", 36, 52),
    XDecoDef("flowers", "Florero", "Plantas", 32, 50),
    XDecoDef("pampas", "Pampas", "Naturaleza", 42, 72),
    XDecoDef("dried", "Ramo seco", "Naturaleza", 38, 66),
    XDecoDef("terrarium", "Terrario", "Naturaleza", 46, 54),
    XDecoDef("stones", "Piedras", "Naturaleza", 46, 24),
    XDecoDef("candle", "Vela", "Luz", 24, 44),
    XDecoDef("lamp", "Lámpara", "Luz", 38, 60),
    XDecoDef("lantern", "Farol", "Luz", 34, 54),
    XDecoDef("coffee", "Taza de café", "Rincón cálido", 36, 32),
    XDecoDef("glasses", "Gafas", "Rincón cálido", 40, 18),
    XDecoDef("inkwell", "Tintero y pluma", "Rincón cálido", 32, 44),
    XDecoDef("frame", "Foto enmarcada", "Rincón cálido", 38, 46),
    XDecoDef("globe", "Globo terráqueo", "Curiosidades", 42, 56),
    XDecoDef("clock", "Reloj", "Curiosidades", 34, 40),
    XDecoDef("hourglass", "Reloj de arena", "Curiosidades", 26, 42),
    XDecoDef("trophy", "Trofeo", "Curiosidades", 30, 46),
    XDecoDef("stack", "Pila de libros", "Curiosidades", 50, 30),
    XDecoDef("cat", "Gato", "Mascotas", 40, 48),
    XDecoDef("owl", "Búho", "Mascotas", 34, 46)
)

internal fun xDecoDef(key: String): XDecoDef? = X_DECOS.firstOrNull { it.key == key }

/** Dibuja un objeto de la vitrina a su tamaño base (def.w × def.h dp). */
@Composable
internal fun XDecoView(key: String, modifier: Modifier = Modifier) {
    val def = xDecoDef(key) ?: return
    val classic = decoOf(key)
    if (classic != null) {
        DecoView(classic, modifier)
    } else {
        Canvas(modifier.size(def.w.dp, def.h.dp)) { drawXDeco(key, size.width, size.height) }
    }
}

// ── Pinceles ─────────────────────────────────────────────────────────────────

private fun xTone(c: Color, f: Float): Color = Color(
    (c.red * f).coerceIn(0f, 1f), (c.green * f).coerceIn(0f, 1f), (c.blue * f).coerceIn(0f, 1f), c.alpha
)

private val LEAF_A = Color(0xFF3F7D4A)
private val LEAF_B = Color(0xFF58A05E)
private val LEAF_C = Color(0xFF2F6B3C)
private val TERRA = Color(0xFFC77B4A)
private val CREAM_POT = Color(0xFFEADBC0)

/** Hoja ovalada que nace en (cx, cy) y apunta hacia arriba girada [deg] grados. */
private fun DrawScope.leaf(cx: Float, cy: Float, len: Float, wid: Float, deg: Float, color: Color) {
    rotate(deg, pivot = Offset(cx, cy)) {
        drawOval(color, topLeft = Offset(cx - wid / 2f, cy - len), size = Size(wid, len))
        drawLine(
            xTone(color, 0.72f), Offset(cx, cy), Offset(cx, cy - len * 0.9f),
            strokeWidth = maxOf(1f, wid * 0.07f)
        )
    }
}

/** Maceta trapezoidal con borde. l, r y top van en fracción del ancho/alto. */
private fun DrawScope.pot(w: Float, h: Float, l: Float, r: Float, top: Float, color: Color) {
    val path = Path().apply {
        moveTo(l * w, top * h)
        lineTo(r * w, top * h)
        lineTo((r - 0.08f) * w, h)
        lineTo((l + 0.08f) * w, h)
        close()
    }
    drawPath(path, color)
    drawRect(xTone(color, 1.15f), Offset((l - 0.02f) * w, top * h), Size((r - l + 0.04f) * w, 0.1f * h))
    drawRect(
        Color.Black.copy(alpha = 0.14f),
        Offset((l + 0.06f) * w, (top + 0.1f) * h),
        Size(0.07f * w, (1f - top - 0.1f) * h)
    )
}

private fun DrawScope.drawXDeco(key: String, w: Float, h: Float) {
    when (key) {
        "monstera" -> {
            pot(w, h, 0.32f, 0.68f, 0.74f, TERRA)
            val bx = 0.5f * w
            val by = 0.76f * h
            leaf(bx, by, 0.55f * h, 0.34f * w, -62f, LEAF_C)
            leaf(bx, by, 0.55f * h, 0.34f * w, 62f, LEAF_C)
            leaf(bx, by, 0.66f * h, 0.38f * w, -30f, LEAF_A)
            leaf(bx, by, 0.66f * h, 0.38f * w, 30f, LEAF_A)
            leaf(bx, by, 0.74f * h, 0.40f * w, 0f, LEAF_B)
            // cortes característicos de la monstera
            val cut = Color(0x55000000)
            drawCircle(cut, 0.035f * w, Offset(0.5f * w, 0.36f * h))
            drawCircle(cut, 0.03f * w, Offset(0.36f * w, 0.42f * h))
            drawCircle(cut, 0.03f * w, Offset(0.64f * w, 0.42f * h))
        }
        "fern" -> {
            pot(w, h, 0.3f, 0.7f, 0.76f, CREAM_POT)
            for (i in -4..4) {
                val len = (0.6f - kotlin.math.abs(i) * 0.04f) * h
                leaf(0.5f * w, 0.78f * h, len, 0.15f * w, i * 15f, if (i % 2 == 0) LEAF_B else LEAF_A)
            }
        }
        "bonsai" -> {
            pot(w, h, 0.2f, 0.8f, 0.8f, Color(0xFF7A5C3A))
            val trunk = Path().apply {
                moveTo(0.5f * w, 0.82f * h)
                cubicTo(0.42f * w, 0.7f * h, 0.58f * w, 0.58f * h, 0.48f * w, 0.4f * h)
            }
            drawPath(trunk, Color(0xFF5A3B22), style = Stroke(width = 0.07f * w, cap = StrokeCap.Round))
            drawLine(Color(0xFF5A3B22), Offset(0.5f * w, 0.6f * h), Offset(0.72f * w, 0.5f * h), 0.04f * w, StrokeCap.Round)
            drawCircle(LEAF_C, 0.2f * w, Offset(0.34f * w, 0.36f * h))
            drawCircle(LEAF_A, 0.24f * w, Offset(0.5f * w, 0.26f * h))
            drawCircle(LEAF_B, 0.2f * w, Offset(0.7f * w, 0.4f * h))
        }
        "orchid" -> {
            pot(w, h, 0.3f, 0.7f, 0.78f, Color(0xFFD9C9B0))
            leaf(0.5f * w, 0.8f * h, 0.3f * h, 0.26f * w, -50f, LEAF_B)
            leaf(0.5f * w, 0.8f * h, 0.3f * h, 0.26f * w, 50f, LEAF_B)
            val stem = Path().apply {
                moveTo(0.5f * w, 0.8f * h)
                cubicTo(0.5f * w, 0.5f * h, 0.7f * w, 0.4f * h, 0.66f * w, 0.14f * h)
            }
            drawPath(stem, Color(0xFF4E7A3E), style = Stroke(width = 0.04f * w, cap = StrokeCap.Round))
            val pts = listOf(0.62f to 0.2f, 0.68f to 0.32f, 0.6f to 0.44f, 0.54f to 0.56f)
            pts.forEachIndexed { i, p ->
                val r = (0.13f - i * 0.012f) * w
                drawCircle(Color(0xFFF2B6D3), r, Offset(p.first * w, p.second * h))
                drawCircle(Color(0xFFFFFFFF).copy(alpha = 0.5f), r * 0.55f, Offset(p.first * w, p.second * h))
                drawCircle(Color(0xFFE8B63D), r * 0.25f, Offset(p.first * w, p.second * h))
            }
        }
        "succulents" -> {
            pot(w, h, 0.08f, 0.92f, 0.56f, CREAM_POT)
            val spots = listOf(0.27f to 0.5f, 0.52f to 0.42f, 0.76f to 0.5f)
            spots.forEachIndexed { si, s ->
                for (k in 0 until 8) {
                    leaf(
                        s.first * w, s.second * h + 0.04f * h, 0.3f * h, 0.12f * w, k * 45f,
                        if ((k + si) % 2 == 0) Color(0xFF7FB08A) else Color(0xFF5E9970)
                    )
                }
            }
        }
        "pampas" -> {
            val vase = Path().apply {
                moveTo(0.4f * w, 0.62f * h); lineTo(0.6f * w, 0.62f * h)
                cubicTo(0.66f * w, 0.78f * h, 0.62f * w, 0.94f * h, 0.56f * w, h)
                lineTo(0.44f * w, h)
                cubicTo(0.38f * w, 0.94f * h, 0.34f * w, 0.78f * h, 0.4f * w, 0.62f * h)
                close()
            }
            drawPath(vase, Color(0xFFD9C3A0))
            val plume = Color(0xFFE9D8B6)
            leaf(0.5f * w, 0.64f * h, 0.62f * h, 0.2f * w, -26f, plume)
            leaf(0.5f * w, 0.64f * h, 0.66f * h, 0.2f * w, 0f, xTone(plume, 1.06f))
            leaf(0.5f * w, 0.64f * h, 0.62f * h, 0.2f * w, 26f, plume)
            leaf(0.5f * w, 0.64f * h, 0.5f * h, 0.16f * w, -48f, xTone(plume, 0.94f))
            leaf(0.5f * w, 0.64f * h, 0.5f * h, 0.16f * w, 48f, xTone(plume, 0.94f))
        }
        "dried" -> {
            val vase = Path().apply {
                moveTo(0.38f * w, 0.7f * h); lineTo(0.62f * w, 0.7f * h)
                lineTo(0.66f * w, h); lineTo(0.34f * w, h); close()
            }
            drawPath(vase, Color(0xFF8E6B4E))
            val tops = listOf(0.26f to 0.14f, 0.5f to 0.06f, 0.74f to 0.16f, 0.38f to 0.3f, 0.62f to 0.32f)
            tops.forEach { t ->
                drawLine(Color(0xFF9C7B4C), Offset(0.5f * w, 0.72f * h), Offset(t.first * w, t.second * h + 0.08f * h), 0.025f * w)
                drawOval(Color(0xFFD9A441), Offset((t.first - 0.06f) * w, t.second * h), Size(0.12f * w, 0.2f * h))
            }
        }
        "terrarium" -> {
            drawRect(Color(0xFF7A5C3A), Offset(0.08f * w, 0.88f * h), Size(0.84f * w, 0.12f * h))
            drawRoundRect(
                Color(0x33BFE3E8), Offset(0.12f * w, 0.14f * h), Size(0.76f * w, 0.76f * h),
                CornerRadius(0.3f * w)
            )
            drawRoundRect(
                Color(0xAAFFFFFF), Offset(0.12f * w, 0.14f * h), Size(0.76f * w, 0.76f * h),
                CornerRadius(0.3f * w), style = Stroke(width = 0.03f * w)
            )
            drawRect(Color(0xFF6B4A2B), Offset(0.14f * w, 0.8f * h), Size(0.72f * w, 0.08f * h))
            leaf(0.38f * w, 0.8f * h, 0.34f * h, 0.16f * w, -18f, LEAF_B)
            leaf(0.5f * w, 0.8f * h, 0.46f * h, 0.18f * w, 6f, LEAF_A)
            leaf(0.64f * w, 0.8f * h, 0.28f * h, 0.14f * w, 24f, LEAF_B)
            drawCircle(Color(0xFFE67E80), 0.05f * w, Offset(0.7f * w, 0.74f * h))
        }
        "stones" -> {
            drawOval(Color(0xFF8A8F98), Offset(0.04f * w, 0.4f * h), Size(0.56f * w, 0.6f * h))
            drawOval(Color(0xFFB4B8BF), Offset(0.36f * w, 0.5f * h), Size(0.54f * w, 0.5f * h))
            drawOval(Color(0xFF6E737C), Offset(0.2f * w, 0.0f), Size(0.4f * w, 0.55f * h))
            drawOval(Color.White.copy(alpha = 0.2f), Offset(0.26f * w, 0.06f * h), Size(0.16f * w, 0.14f * h))
        }
        "lantern" -> {
            drawArc(
                Color(0xFF2B2B33), 180f, 180f, false, Offset(0.3f * w, 0.0f), Size(0.4f * w, 0.2f * h),
                style = Stroke(width = 0.05f * w)
            )
            drawRect(Color(0xFF2B2B33), Offset(0.2f * w, 0.14f * h), Size(0.6f * w, 0.08f * h))
            drawRoundRect(
                Brush.verticalGradient(listOf(Color(0xFFFFE6A6), Color(0xFFFFB84D))),
                Offset(0.24f * w, 0.22f * h), Size(0.52f * w, 0.6f * h), CornerRadius(0.06f * w)
            )
            drawLine(Color(0xFF2B2B33), Offset(0.5f * w, 0.22f * h), Offset(0.5f * w, 0.82f * h), 0.03f * w)
            drawRoundRect(
                Color(0xFF2B2B33), Offset(0.24f * w, 0.22f * h), Size(0.52f * w, 0.6f * h),
                CornerRadius(0.06f * w), style = Stroke(width = 0.04f * w)
            )
            drawRect(Color(0xFF2B2B33), Offset(0.18f * w, 0.82f * h), Size(0.64f * w, 0.1f * h))
            drawOval(Color(0xFFFFFFFF).copy(alpha = 0.75f), Offset(0.42f * w, 0.5f * h), Size(0.16f * w, 0.18f * h))
        }
    }
}
