package com.libra.reader

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder

data class DictMeaning(
    val partOfSpeech: String,
    val definitions: List<String>,
    val synonyms: List<String>
)

data class DictResult(
    val word: String,
    val phonetic: String,
    val meanings: List<DictMeaning>,
    val lang: String,
    val translatedFrom: String = ""
)

private fun openUrl(urlStr: String): String {
    val conn = URL(urlStr).openConnection()
    conn.connectTimeout = 8000
    conn.readTimeout = 8000
    conn.setRequestProperty("User-Agent", "Libellum/1.0")
    return conn.getInputStream().bufferedReader(Charsets.UTF_8).use { it.readText() }
}

private fun translateToSpanish(text: String): String {
    if (text.isBlank()) return text
    return try {
        val enc = URLEncoder.encode(text, "UTF-8")
        val json = openUrl("https://api.mymemory.translated.net/get?q=$enc&langpair=en|es")
        val obj = JSONObject(json)
        obj.optJSONObject("responseData")?.optString("translatedText")?.takeIf { it.isNotBlank() } ?: text
    } catch (_: Exception) {
        text
    }
}

private fun parseDictionaryApi(json: String, lang: String): DictResult {
    val arr = JSONArray(json)
    val entry = arr.getJSONObject(0)
    val word = entry.optString("word", "")
    val phonetic = entry.optString("phonetic", "")
    val meaningsArr = entry.getJSONArray("meanings")
    val meanings = (0 until meaningsArr.length()).map { i ->
        val m = meaningsArr.getJSONObject(i)
        val pos = m.optString("partOfSpeech", "")
        val defs = m.getJSONArray("definitions")
        val defList = (0 until minOf(defs.length(), 3)).map { j ->
            defs.getJSONObject(j).optString("definition", "")
        }
        val syns = m.optJSONArray("synonyms")
        val synList = if (syns != null)
            (0 until minOf(syns.length(), 4)).map { j -> syns.getString(j) }
        else emptyList()
        DictMeaning(pos, defList, synList)
    }
    return DictResult(word, phonetic, meanings, lang)
}

private fun toSpanish(result: DictResult): DictResult {
    if (result.lang == "es") return result
    val mapped = result.meanings.map { m ->
        DictMeaning(
            partOfSpeech = when (m.partOfSpeech.lowercase()) {
                "noun" -> "sustantivo"
                "verb" -> "verbo"
                "adjective" -> "adjetivo"
                "adverb" -> "adverbio"
                "pronoun" -> "pronombre"
                "preposition" -> "preposición"
                "conjunction" -> "conjunción"
                "interjection" -> "interjección"
                else -> m.partOfSpeech
            },
            definitions = m.definitions.map { translateToSpanish(it) },
            synonyms = m.synonyms.map { translateToSpanish(it) }
        )
    }
    return result.copy(meanings = mapped, lang = "es", translatedFrom = result.lang)
}

suspend fun fetchDefinition(word: String): Result<DictResult> = withContext(Dispatchers.IO) {
    // Si llegan varias palabras se usa la primera; se quitan signos de puntuación de los extremos
    val clean = word.trim().lowercase().split(Regex("\\s+")).first().trim { !it.isLetter() }
    if (clean.isEmpty()) return@withContext Result.failure(Exception("Palabra vacía"))

    val es = runCatching {
        val enc = URLEncoder.encode(clean, "UTF-8")
        parseDictionaryApi(openUrl("https://api.dictionaryapi.dev/api/v2/entries/es/$enc"), "es")
    }
    if (es.isSuccess) return@withContext es

    val en = runCatching {
        val enc = URLEncoder.encode(clean, "UTF-8")
        toSpanish(parseDictionaryApi(openUrl("https://api.dictionaryapi.dev/api/v2/entries/en/$enc"), "en"))
    }
    if (en.isSuccess) return@withContext en

    val via = runCatching {
        val enc = URLEncoder.encode(clean, "UTF-8")
        val trJson = openUrl("https://api.mymemory.translated.net/get?q=$enc&langpair=es|en")
        val translated = JSONObject(trJson)
            .optJSONObject("responseData")
            ?.optString("translatedText")
            ?.trim()
            ?.lowercase()
            ?.split(" ")
            ?.firstOrNull()
            ?: error("sin traducción")
        val encEn = URLEncoder.encode(translated, "UTF-8")
        val base = parseDictionaryApi(
            openUrl("https://api.dictionaryapi.dev/api/v2/entries/en/$encEn"),
            "en"
        ).copy(word = "$clean → $translated")
        toSpanish(base)
    }
    if (via.isSuccess) return@withContext via

    Result.failure(Exception("No se encontró definición para «$clean»"))
}

@Composable
fun DictionaryDialog(word: String, onDismiss: () -> Unit) {
    var state by remember { mutableStateOf<Result<DictResult>?>(null) }

    LaunchedEffect(word) {
        state = null
        state = fetchDefinition(word)
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Panel,
            modifier = Modifier.fillMaxWidth().heightIn(max = 480.dp)
        ) {
            Column(Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LibIcon(LibIconKind.DICTIONARY, tint = Gold, size = 20.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("DICCIONARIO", color = Gold, fontSize = 13.sp, letterSpacing = 1.sp,
                        fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    LibIconButton(LibIconKind.CLOSE, onClick = onDismiss, tint = Muted, iconSize = 18.dp)
                }
                Spacer(Modifier.height(4.dp))
                when {
                    state == null -> Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Gold, modifier = Modifier.size(32.dp))
                    }
                    state!!.isFailure -> Text(
                        "No se encontró definición para «$word».\n\nPrueba con otra palabra o revisa la ortografía.",
                        color = Cream, fontSize = 14.sp, lineHeight = 20.sp
                    )
                    else -> {
                        val r = state!!.getOrNull()!!
                        Column(Modifier.verticalScroll(rememberScrollState())) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(r.word, color = Cream, fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                Box(Modifier.background(Gold.copy(alpha = .2f), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)) {
                                    Text(if (r.translatedFrom.isNotBlank()) "ES (trad.)" else "ES",
                                        color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            if (r.phonetic.isNotBlank())
                                Text(r.phonetic, color = Gold, fontSize = 14.sp, fontStyle = FontStyle.Italic)
                            Spacer(Modifier.height(12.dp))
                            r.meanings.forEach { m ->
                                if (m.partOfSpeech.isNotBlank())
                                    Text(m.partOfSpeech, color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                m.definitions.forEachIndexed { i, def ->
                                    Text("${i + 1}. $def", color = Cream, fontSize = 14.sp, lineHeight = 20.sp,
                                        modifier = Modifier.padding(start = 8.dp, top = 4.dp))
                                }
                                if (m.synonyms.isNotEmpty())
                                    Text("Sinónimos: ${m.synonyms.joinToString(", ")}",
                                        color = Muted, fontSize = 12.sp,
                                        modifier = Modifier.padding(start = 8.dp, top = 4.dp))
                                Spacer(Modifier.height(10.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
