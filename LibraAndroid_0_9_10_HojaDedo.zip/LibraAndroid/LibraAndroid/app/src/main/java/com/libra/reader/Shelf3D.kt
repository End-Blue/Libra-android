package com.libra.reader

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Paint
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ══════════════════════════════════════════════════════════════════════════════
// Libros en 3D para la estantería (proyección oblicua: cara frontal + lateral + superior).
// El tamaño total del libro NO cambia: la profundidad se dibuja dentro del mismo ancho
// y solo sobresale unos dp por ARRIBA, así que las colisiones, huecos, torres y adornos
// siguen funcionando exactamente igual que antes.
// ══════════════════════════════════════════════════════════════════════════════

private val coverBitmapCache = android.util.LruCache<String, Bitmap>(40)
private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

/** Carga la portada reducida (máx. ~220 px) para dibujarla deformada en las caras del libro. */
private fun loadCoverBitmap(path: String): Bitmap? {
    coverBitmapCache.get(path)?.let { return it }
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 220) sample *= 2
    val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
    coverBitmapCache.put(path, bmp)
    return bmp
}

@Composable
private fun rememberCoverBitmap(path: String?): Bitmap? {
    val state = produceState<Bitmap?>(path?.let { coverBitmapCache.get(it) }, path) {
        value = if (path == null) null
        else coverBitmapCache.get(path) ?: withContext(Dispatchers.IO) { loadCoverBitmap(path) }
    }
    return state.value
}

private class Depth(val dx: Dp, val dy: Dp)

/** Profundidad visible (dx hacia la derecha, dy hacia arriba) según la postura y el tamaño del libro. */
private fun depthFor(pose: String, w: Dp, h: Dp): Depth = when (pose) {
    "SPINE" -> {
        val dx = (w.value * 0.30f).coerceIn(6f, 13f).coerceAtMost(w.value * 0.45f)
        Depth(dx.dp, (dx * 0.45f).coerceIn(3f, 6f).dp)
    }
    "STACK", "FLAT" -> {
        val dx = (h.value * 0.40f).coerceIn(5f, 8f).coerceAtMost(w.value * 0.3f)
        Depth(dx.dp, (h.value * 0.30f).coerceIn(3f, 5.5f).dp)
    }
    else -> Depth((w.value * 0.06f).coerceIn(4f, 6.5f).dp, 3.5.dp)
}

private fun poly(vararg p: Float): Path = Path().apply {
    moveTo(p[0], p[1])
    var i = 2
    while (i + 1 < p.size) { lineTo(p[i], p[i + 1]); i += 2 }
    close()
}

/** Dibuja la portada deformada sobre un paralelogramo: [dst] = TL, TR, BR, BL (x,y de cada esquina). */
private fun DrawScope.drawSkewedBitmap(bmp: Bitmap, dst: FloatArray) {
    val bw = bmp.width.toFloat()
    val bh = bmp.height.toFloat()
    val src = floatArrayOf(0f, 0f, bw, 0f, bw, bh, 0f, bh)
    val m = Matrix()
    m.setPolyToPoly(src, 0, dst, 0, 4)
    drawIntoCanvas { it.nativeCanvas.drawBitmap(bmp, m, bmpPaint) }
}

private fun DrawScope.drawBook3D(pose: String, dxDp: Dp, dyDp: Dp, base: Color, bmp: Bitmap?) {
    val w = size.width
    val h = size.height
    val dx = dxDp.toPx()
    val dy = dyDp.toPx()
    val fw = w - dx                      // ancho de la cara frontal
    val lw = 0.6.dp.toPx()
    val pageLight = Color(0xFFF1E9D6)
    val pageMid = Color(0xFFE2D8BE)
    val line = Color.Black.copy(alpha = 0.12f)
    val edge = Color.Black.copy(alpha = 0.25f)

    // sombra proyectada sobre la balda / el libro de al lado
    translate(2.dp.toPx(), 1.dp.toPx()) {
        drawPath(poly(0f, h, 0f, 0f, dx, -dy, w, -dy, w, h - dy, fw, h), Color.Black.copy(alpha = 0.22f))
    }

    when (pose) {
        // Libro tumbado: lomo al frente, páginas a la derecha y la portada arriba
        "STACK", "FLAT" -> {
            val right = poly(fw, 0f, w, -dy, w, h - dy, fw, h)
            drawPath(right, pageMid)
            val bd = minOf(1.3.dp.toPx(), h * 0.14f)
            val board = base.shade(0.78f)
            drawPath(poly(fw, 0f, w, -dy, w, -dy + bd, fw, bd), board)
            drawPath(poly(fw, h - bd, w, h - dy - bd, w, h - dy, fw, h), board)
            for (f in listOf(0.38f, 0.62f)) drawLine(line, Offset(fw, h * f), Offset(w, h * f - dy), lw)
            drawPath(right, edge, style = Stroke(lw))

            val top = poly(0f, 0f, fw, 0f, w, -dy, dx, -dy)
            if (bmp != null) {
                drawSkewedBitmap(bmp, floatArrayOf(0f, 0f, dx, -dy, w, -dy, fw, 0f))
                drawPath(top, Color.White.copy(alpha = 0.08f))
            } else {
                drawPath(top, base.shade(1.18f))
            }
            drawPath(top, edge, style = Stroke(lw))
        }
        // Libro de pie: lomo al frente, portada girada a la derecha y páginas arriba
        "SPINE" -> {
            val cover = poly(fw, 0f, w, -dy, w, h - dy, fw, h)
            if (bmp != null) {
                drawSkewedBitmap(bmp, floatArrayOf(fw, 0f, w, -dy, w, h - dy, fw, h))
                drawPath(cover, Color.Black.copy(alpha = 0.22f))
            } else {
                drawPath(cover, base.shade(0.72f))
            }
            drawPath(cover, edge, style = Stroke(lw))
            val top = poly(0f, 0f, fw, 0f, w, -dy, dx, -dy)
            drawPath(top, pageMid)
            drawPath(top, edge, style = Stroke(lw))
        }
        // Portada de frente: cara frontal + canto de páginas a la derecha y arriba
        else -> {
            val right = poly(fw, 0f, w, -dy, w, h - dy, fw, h)
            drawPath(right, pageMid)
            for (f in listOf(0.35f, 0.65f)) {
                drawLine(line, Offset(fw + dx * f, -dy * f), Offset(fw + dx * f, h - dy * f), lw)
            }
            drawPath(right, edge, style = Stroke(lw))
            val top = poly(0f, 0f, fw, 0f, w, -dy, dx, -dy)
            drawPath(top, pageLight)
            drawPath(top, edge, style = Stroke(lw))
        }
    }
}

/**
 * Libro con volumen para la estantería: ocupa el mismo recuadro que antes.
 * Con [flat] = true se dibuja plano (sin cara superior ni canto en perspectiva): se usa en los libros que
 * tienen otro encima (pilas), para que solo el de más arriba luzca el 3D completo y la torre se vea limpia.
 */
@Composable
internal fun Book3D(book: LibraryItem, pose: String, colorOverride: Long? = null, flat: Boolean = false) {
    if (flat) {
        Box(Modifier.fillMaxSize()) {
            when (pose) {
                "SPINE" -> SpineFace(book, vertical = true, colorOverride = colorOverride)
                "STACK", "FLAT" -> SpineFace(book, vertical = false, colorOverride = colorOverride)
                else -> FrontFace(book)
            }
        }
        return
    }
    val autoColor = rememberSpineColor(book)
    val raw = colorOverride?.let { Color(it) } ?: autoColor
    val base = if (raw.luminance() > 0.8f) raw.shade(0.8f) else raw
    val bmp = if (pose == "FRONT") null else rememberCoverBitmap(book.coverPath)

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val w = maxWidth
        val g = depthFor(pose, w, maxHeight)
        Box(Modifier.fillMaxSize().drawBehind { drawBook3D(pose, g.dx, g.dy, base, bmp) })
        Box(Modifier.width(w - g.dx).fillMaxHeight()) {
            when (pose) {
                "SPINE" -> SpineFace(book, vertical = true, colorOverride = colorOverride, corner = 1.dp)
                "STACK", "FLAT" -> SpineFace(
                    book, vertical = false, colorOverride = colorOverride, corner = 1.dp, pages = false
                )
                else -> FrontFace(book, pagesEdge = false)
            }
        }
    }
}
