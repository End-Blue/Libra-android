@file:OptIn(ExperimentalMaterial3Api::class)

package com.libra.reader

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitTouchSlopOrCancellation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

// ══════════════════════════════════════════════════════════════════════════════
// MIS ESTANTERÍAS: el expositor libre de Libellum (varias estanterías, cada una con su propio tablero).
// Libros y objetos se colocan donde quieras: arrastrar, girar (con grados), escalar,
// cambiar de cara (lomo / portada / canto), apilar, bloquear, deshacer y rehacer.
// Los libros usan Book3D (volumen) de Shelf3D.kt. Todo se guarda en el teléfono.
// ══════════════════════════════════════════════════════════════════════════════

private val XPanelBg = Color(0xFF16213A)
private val XPanelBtn = Color(0xFF243452)
private val XPanelText = Color(0xFFF4EDDC)
private val XPanelMuted = Color(0xFF9AA8C2)
private val XAccent = Color(0xFFE2A93C)
private val XDanger = Color(0xFFE0766B)
private val XGoldLine = Color(0xFFE8B63D)

private enum class XPanel { MAIN, FACE, SCALE, ORIENT }

private class XPlacing(val bookIds: List<String> = emptyList(), val decoKey: String? = null)

private class XGhost(val cx: Float, val cy: Float, val hw: Float, val hh: Float)

// ── Botones del panel oscuro ─────────────────────────────────────────────────

@Composable
private fun XCircleBtn(
    kind: XIconKind, onClick: () -> Unit, bg: Color, tint: Color,
    enabled: Boolean = true, size: Dp = 38.dp
) {
    Box(
        Modifier.size(size).clip(CircleShape)
            .background(if (enabled) bg else bg.copy(alpha = 0.45f))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        XIcon(kind, if (enabled) tint else tint.copy(alpha = 0.35f), size = 19.dp)
    }
}

@Composable
private fun XBigBtn(
    kind: XIconKind, label: String, onClick: () -> Unit, modifier: Modifier = Modifier,
    selected: Boolean = false, enabled: Boolean = true
) {
    val bg = if (selected) XAccent else XPanelBtn
    val fg = if (selected) Color(0xFF1B1405) else XPanelText
    Column(
        modifier.height(58.dp).clip(RoundedCornerShape(16.dp)).background(bg)
            .clickable(enabled = enabled, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        XIcon(kind, if (enabled) fg else fg.copy(alpha = 0.4f), size = 21.dp)
        Spacer(Modifier.height(3.dp))
        Text(label, color = if (enabled) fg else fg.copy(alpha = 0.4f), fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun XMiniChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(36.dp).clip(CircleShape).background(if (selected) XAccent else XPanelBtn).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (selected) Color(0xFF1B1405) else XPanelText, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun xSliderColors() = SliderDefaults.colors(
    thumbColor = XAccent, activeTrackColor = XAccent, inactiveTrackColor = Color(0x33FFFFFF)
)

// ── Barra de edición del libro seleccionado ──────────────────────────────────

@Composable
private fun XEditBar(
    book: XBook,
    panel: XPanel,
    onPanel: (XPanel) -> Unit,
    canUndo: Boolean, canRedo: Boolean,
    onUndo: () -> Unit, onRedo: () -> Unit, onDone: () -> Unit,
    onTrash: () -> Unit, onLock: () -> Unit,
    onFace: (Int) -> Unit, onEditSpine: () -> Unit,
    onScaleLive: (Float) -> Unit, onLiveDone: () -> Unit,
    onRotLive: (Float) -> Unit, onRotSet: (Float) -> Unit,
    onMore: (String) -> Unit
) {
    var more by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(XPanelBg).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            XCircleBtn(XIconKind.TRASH, onTrash, XPanelBtn, XPanelText)
            Spacer(Modifier.width(8.dp))
            XCircleBtn(
                if (book.locked) XIconKind.LOCK else XIconKind.UNLOCK, onLock,
                if (book.locked) XAccent else XPanelBtn,
                if (book.locked) Color(0xFF1B1405) else XPanelText
            )
            Spacer(Modifier.width(8.dp))
            Box {
                XCircleBtn(XIconKind.MORE, { more = true }, XPanelBtn, XPanelText)
                DropdownMenu(expanded = more, onDismissRequest = { more = false }) {
                    DropdownMenuItem(text = { Text("Ver ficha del libro") }, onClick = { more = false; onMore("detail") })
                    DropdownMenuItem(text = { Text("Leer ahora") }, onClick = { more = false; onMore("read") })
                    DropdownMenuItem(text = { Text("Traer al frente") }, onClick = { more = false; onMore("front") })
                    DropdownMenuItem(text = { Text("Enviar al fondo") }, onClick = { more = false; onMore("back") })
                    DropdownMenuItem(text = { Text("Dejar como nuevo") }, onClick = { more = false; onMore("reset") })
                    DropdownMenuItem(text = { Text("Quitar de la estantería") }, onClick = { more = false; onMore("remove") })
                }
            }
            Spacer(Modifier.weight(1f))
            XCircleBtn(XIconKind.UNDO, onUndo, XPanelBtn, XAccent, enabled = canUndo)
            Spacer(Modifier.width(8.dp))
            XCircleBtn(XIconKind.REDO, onRedo, XPanelBtn, XAccent, enabled = canRedo)
            Spacer(Modifier.width(8.dp))
            XCircleBtn(XIconKind.CHECK, onDone, XAccent, Color(0xFF1B1405))
        }
        when (panel) {
            XPanel.MAIN -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                XBigBtn(
                    XIconKind.COVER,
                    when (book.face) { X_FACE_SPINE -> "Lomo"; X_FACE_EDGE -> "Canto"; else -> "Portada" },
                    { onPanel(XPanel.FACE) }, Modifier.weight(1f)
                )
                XBigBtn(XIconKind.SCALE, "Escala", { onPanel(XPanel.SCALE) }, Modifier.weight(1f))
                XBigBtn(XIconKind.ROTATE, "Orientación", { onPanel(XPanel.ORIENT) }, Modifier.weight(1f))
            }
            XPanel.FACE -> Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                XCircleBtn(XIconKind.BACK, { onPanel(XPanel.MAIN) }, XPanelBtn, XPanelText, size = 44.dp)
                XBigBtn(XIconKind.SPINE, "Lomo", { onFace(X_FACE_SPINE) }, Modifier.weight(1f), selected = book.face == X_FACE_SPINE)
                XBigBtn(XIconKind.COVER, "Portada", { onFace(X_FACE_COVER) }, Modifier.weight(1f), selected = book.face == X_FACE_COVER)
                XBigBtn(XIconKind.EDGE, "Canto", { onFace(X_FACE_EDGE) }, Modifier.weight(1f), selected = book.face == X_FACE_EDGE)
                Column(
                    Modifier.height(58.dp).width(64.dp).clip(RoundedCornerShape(16.dp))
                        .border(1.5.dp, if (book.face != X_FACE_COVER) XAccent else XAccent.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                        .clickable(enabled = book.face != X_FACE_COVER, onClick = onEditSpine),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    val c = if (book.face != X_FACE_COVER) XAccent else XAccent.copy(alpha = 0.35f)
                    XIcon(XIconKind.PENCIL, c, size = 19.dp)
                    Spacer(Modifier.height(3.dp))
                    Text("Editar", color = c, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }
            }
            XPanel.SCALE -> Row(verticalAlignment = Alignment.CenterVertically) {
                XCircleBtn(XIconKind.BACK, { onPanel(XPanel.MAIN) }, XPanelBtn, XPanelText, size = 44.dp)
                Spacer(Modifier.width(8.dp))
                XIcon(XIconKind.ZOOM_OUT, XPanelMuted, size = 20.dp)
                Slider(
                    value = book.scale.coerceIn(0.5f, 2f),
                    onValueChange = onScaleLive,
                    onValueChangeFinished = onLiveDone,
                    valueRange = 0.5f..2f,
                    colors = xSliderColors(),
                    modifier = Modifier.weight(1f)
                )
                XIcon(XIconKind.ZOOM_IN, XPanelMuted, size = 20.dp)
                Spacer(Modifier.width(6.dp))
                XMiniChip("S", abs(book.scale - 0.75f) < 0.05f) { onScaleLive(0.75f); onLiveDone() }
                Spacer(Modifier.width(4.dp))
                XMiniChip("M", abs(book.scale - 1f) < 0.05f) { onScaleLive(1f); onLiveDone() }
                Spacer(Modifier.width(4.dp))
                XMiniChip("L", abs(book.scale - 1.4f) < 0.05f) { onScaleLive(1.4f); onLiveDone() }
            }
            XPanel.ORIENT -> Row(verticalAlignment = Alignment.CenterVertically) {
                XCircleBtn(XIconKind.BACK, { onPanel(XPanel.MAIN) }, XPanelBtn, XPanelText, size = 44.dp)
                Spacer(Modifier.width(8.dp))
                XCircleBtn(XIconKind.PORTRAIT, { onRotSet(0f) }, if (abs(book.rot) < 0.5f) XAccent else XPanelBtn,
                    if (abs(book.rot) < 0.5f) Color(0xFF1B1405) else XPanelText, size = 42.dp)
                Spacer(Modifier.width(6.dp))
                XCircleBtn(XIconKind.LANDSCAPE, { onRotSet(-90f) }, if (abs(book.rot + 90f) < 0.5f) XAccent else XPanelBtn,
                    if (abs(book.rot + 90f) < 0.5f) Color(0xFF1B1405) else XPanelText, size = 42.dp)
                Spacer(Modifier.width(6.dp))
                XCircleBtn(XIconKind.ROTATE, {
                    var r = book.rot + 90f
                    if (r > 180f) r -= 360f
                    onRotSet(r)
                }, XPanelBtn, XPanelText, size = 42.dp)
                Slider(
                    value = book.rot.coerceIn(-180f, 180f),
                    onValueChange = onRotLive,
                    onValueChangeFinished = onLiveDone,
                    valueRange = -180f..180f,
                    colors = xSliderColors(),
                    modifier = Modifier.weight(1f).padding(horizontal = 4.dp)
                )
                Text("${book.rot.roundToInt()}°", color = XPanelText, fontSize = 12.sp, modifier = Modifier.width(38.dp), textAlign = TextAlign.End)
                Spacer(Modifier.width(4.dp))
                XCircleBtn(XIconKind.FLIP, { onRotSet(0f) }, XPanelBtn, XPanelText, size = 40.dp)
            }
        }
    }
}

// ── Barra de decoración ──────────────────────────────────────────────────────

@Composable
private fun XDecorBar(
    hasSel: Boolean, scale: Float, locked: Boolean,
    canUndo: Boolean, canRedo: Boolean,
    onUndo: () -> Unit, onRedo: () -> Unit, onDone: () -> Unit,
    onAdd: () -> Unit, onLock: () -> Unit, onTrash: () -> Unit,
    onScaleLive: (Float) -> Unit, onLiveDone: () -> Unit
) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(XPanelBg).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Decora tu estantería", color = XPanelText, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text("Arrastra el objeto o ajusta su tamaño", color = XPanelMuted, fontSize = 11.sp)
            }
            XCircleBtn(XIconKind.UNDO, onUndo, XPanelBtn, XAccent, enabled = canUndo, size = 34.dp)
            Spacer(Modifier.width(6.dp))
            XCircleBtn(XIconKind.REDO, onRedo, XPanelBtn, XAccent, enabled = canRedo, size = 34.dp)
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier.height(38.dp).clip(RoundedCornerShape(19.dp)).background(XAccent)
                    .clickable(onClick = onDone).padding(horizontal = 18.dp),
                contentAlignment = Alignment.Center
            ) { Text("Hecho", color = Color(0xFF1B1405), fontWeight = FontWeight.Bold, fontSize = 13.sp) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row(
                Modifier.height(38.dp).clip(RoundedCornerShape(19.dp)).background(XPanelBtn)
                    .clickable(onClick = onAdd).padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                XIcon(XIconKind.PLUS, XAccent, size = 16.dp)
                Spacer(Modifier.width(6.dp))
                Text("Añadir objeto", color = XAccent, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
            Spacer(Modifier.weight(1f))
            XCircleBtn(
                if (locked) XIconKind.LOCK else XIconKind.UNLOCK, onLock,
                if (locked) XAccent else XPanelBtn, if (locked) Color(0xFF1B1405) else XPanelText,
                enabled = hasSel, size = 36.dp
            )
            Spacer(Modifier.width(8.dp))
            XCircleBtn(XIconKind.TRASH, onTrash, Color(0xFF4A2A2E), XDanger, enabled = hasSel, size = 36.dp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            XIcon(XIconKind.RESIZE, XPanelMuted, size = 20.dp)
            Slider(
                value = scale.coerceIn(0.5f, 3f),
                onValueChange = onScaleLive,
                onValueChangeFinished = onLiveDone,
                valueRange = 0.5f..3f,
                enabled = hasSel,
                colors = xSliderColors(),
                modifier = Modifier.weight(1f).padding(start = 6.dp)
            )
        }
    }
}

// ── Dibujo de cada pieza ─────────────────────────────────────────────────────

@Composable
private fun XOutline(color: Color = XGoldLine) {
    Canvas(Modifier.fillMaxSize()) {
        drawRoundRect(
            color, Offset(-2.dp.toPx(), -2.dp.toPx()),
            Size(size.width + 4.dp.toPx(), size.height + 4.dp.toPx()),
            CornerRadius(5.dp.toPx()),
            style = Stroke(width = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 9f), 0f))
        )
    }
}

@Composable
private fun XEdgeFace(book: LibraryItem, colorOverride: Long?) {
    val auto = rememberSpineColor(book)
    val base = colorOverride?.let { Color(it) } ?: auto
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val board = (w * 0.16f).coerceIn(2.dp.toPx(), 5.dp.toPx())
        drawRoundRect(base.shade(0.8f), cornerRadius = CornerRadius(2.dp.toPx()))
        drawRect(Color(0xFFF1E8D3), Offset(board, 1.5.dp.toPx()), Size(w - 2f * board, h - 3.dp.toPx()))
        var x = board + 1.4.dp.toPx()
        while (x < w - board) {
            drawLine(Color(0x33000000), Offset(x, 2.dp.toPx()), Offset(x, h - 2.dp.toPx()), 0.6.dp.toPx())
            x += 2.2.dp.toPx()
        }
        drawRect(Color(0x22000000), Offset(0f, 0f), Size(w * 0.14f, h))
    }
}

@Composable
private fun XBookItem(
    lb: LibraryItem, xb: XBook, selected: Boolean, dragging: Boolean,
    colorOverride: Long?, dens: Float, flat: Boolean = false
) {
    val dims = xBookDims(lb, xb.face)
    val w = dims.first
    val h = dims.second
    Box(
        Modifier
            .offset { IntOffset(((xb.cx - w / 2f) * dens).roundToInt(), ((xb.cy - h / 2f) * dens).roundToInt()) }
            .size(w.dp, h.dp)
            .graphicsLayer {
                scaleX = xb.scale
                scaleY = xb.scale
                rotationZ = xb.rot
                alpha = if (dragging) 0.92f else 1f
            }
    ) {
        when (xb.face) {
            X_FACE_SPINE -> Book3D(lb, "SPINE", colorOverride, flat = flat)
            X_FACE_EDGE -> XEdgeFace(lb, colorOverride)
            else -> Book3D(lb, "FRONT", colorOverride, flat = flat)
        }
        if (selected || dragging) XOutline()
    }
}

@Composable
private fun XDecoItem(d: XDeco, selected: Boolean, dragging: Boolean, dens: Float) {
    val def = xDecoDef(d.key) ?: return
    Box(
        Modifier
            .offset { IntOffset(((d.cx - def.w / 2f) * dens).roundToInt(), ((d.cy - def.h / 2f) * dens).roundToInt()) }
            .size(def.w.dp, def.h.dp)
            .graphicsLayer {
                scaleX = d.scale
                scaleY = d.scale
                rotationZ = d.rot
                alpha = if (dragging) 0.9f else 1f
            }
    ) {
        XDecoView(d.key)
        if (selected || dragging) XOutline()
    }
}

// ── Hojas y diálogos ─────────────────────────────────────────────────────────

@Composable
private fun xFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = XPanelText, unfocusedTextColor = XPanelText,
    focusedBorderColor = XAccent, unfocusedBorderColor = Color(0x44FFFFFF),
    focusedContainerColor = XPanelBtn, unfocusedContainerColor = XPanelBtn,
    cursorColor = XAccent
)

@Composable
private fun XChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.height(34.dp).clip(RoundedCornerShape(17.dp))
            .background(if (selected) XAccent else XPanelBtn).clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (selected) Color(0xFF1B1405) else XPanelText, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun XAddBooksSheet(
    all: List<LibraryItem>, exposed: Set<String>,
    onCancel: () -> Unit, onAdd: (List<String>) -> Unit
) {
    var q by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("Todos") }
    var sel by remember { mutableStateOf(listOf<String>()) }
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val list = remember(all, exposed, q, filter) {
        all.filter { it.id !in exposed }.filter { b ->
            val okQ = q.isBlank() || b.title.contains(q, true) || b.author.contains(q, true) || b.genre.contains(q, true)
            val okF = when (filter) {
                "Favoritos" -> b.isFavorite == 1
                "Leyendo" -> b.statusKey() == "READING"
                "Por leer" -> b.statusKey() == "TBR"
                "Terminados" -> b.statusKey() == "FINISHED"
                else -> true
            }
            okQ && okF
        }
    }
    ModalBottomSheet(onDismissRequest = onCancel, sheetState = sheet, containerColor = XPanelBg) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 16.dp).navigationBarsPadding()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onCancel) { Text("Cancelar", color = XDanger, fontSize = 13.sp) }
                Text(
                    "Desde tu biblioteca", color = XPanelText, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f), textAlign = TextAlign.Center
                )
                TextButton(onClick = { onAdd(sel) }, enabled = sel.isNotEmpty()) {
                    Text(if (sel.isEmpty()) "Añadir" else "Añadir (${sel.size})", color = XAccent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
            OutlinedTextField(
                value = q, onValueChange = { q = it }, singleLine = true,
                placeholder = { Text("Título, autor o género", color = XPanelMuted, fontSize = 13.sp) },
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), colors = xFieldColors()
            )
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Todos", "Favoritos", "Leyendo", "Por leer", "Terminados").forEach { f ->
                    XChip(f, filter == f) { filter = f }
                }
            }
            Spacer(Modifier.height(6.dp))
            if (list.isEmpty()) {
                Text(
                    "No hay libros para añadir con este filtro. Los que ya están en esta estantería no se repiten.",
                    color = XPanelMuted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 24.dp)
                )
            } else {
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 440.dp)) {
                    items(list, key = { it.id }) { b ->
                        val on = b.id in sel
                        Row(
                            Modifier.fillMaxWidth()
                                .clickable { sel = if (on) sel - b.id else sel + b.id }
                                .padding(vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            BookCover(b, Modifier.size(38.dp, 56.dp), textSize = 6.sp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(b.title, color = XPanelText, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(b.author, color = XPanelMuted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Box(
                                Modifier.size(24.dp).clip(CircleShape)
                                    .background(if (on) XAccent else Color.Transparent)
                                    .border(2.dp, if (on) XAccent else Color(0x66FFFFFF), CircleShape),
                                contentAlignment = Alignment.Center
                            ) { if (on) XIcon(XIconKind.CHECK, Color(0xFF1B1405), size = 14.dp) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun XDecoPickerSheet(onPick: (XDecoDef) -> Unit, onDismiss: () -> Unit) {
    var q by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("Todo") }
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val list = remember(q, cat) {
        X_DECOS.filter { (cat == "Todo" || it.cat == cat) && (q.isBlank() || it.label.contains(q, true)) }
    }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheet, containerColor = XPanelBg) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 16.dp).navigationBarsPadding()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onDismiss) { Text("Cancelar", color = XDanger, fontSize = 13.sp) }
                Text(
                    "Añadir objeto", color = XPanelText, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f), textAlign = TextAlign.Center
                )
                Spacer(Modifier.width(72.dp))
            }
            OutlinedTextField(
                value = q, onValueChange = { q = it }, singleLine = true,
                placeholder = { Text("Buscar un objeto", color = XPanelMuted, fontSize = 13.sp) },
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), colors = xFieldColors()
            )
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                X_DECO_CATS.forEach { c -> XChip(c, cat == c) { cat = c } }
            }
            Spacer(Modifier.height(10.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.fillMaxWidth().height(420.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(list, key = { it.key }) { def ->
                    Column(
                        Modifier.clip(RoundedCornerShape(16.dp)).background(XPanelBtn)
                            .clickable { onPick(def) }.padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(Modifier.height(70.dp), contentAlignment = Alignment.Center) {
                            Box(Modifier.graphicsLayer {
                                val k = minOf(1f, 66f / def.h, 66f / def.w)
                                scaleX = k; scaleY = k
                            }) { XDecoView(def.key) }
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(def.label, color = XPanelText, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

@Composable
private fun XSpineSheet(
    lib: LibraryItem, current: Long?, onColor: (Long?) -> Unit,
    onSize: (Int, Int) -> Unit, onDismiss: () -> Unit
) {
    val dims = xBookDims(lib, X_FACE_SPINE)
    var wv by remember { mutableFloatStateOf(dims.first.coerceIn(18f, 60f)) }
    var hv by remember { mutableFloatStateOf(dims.second.coerceIn(80f, 190f)) }
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheet, containerColor = XPanelBg) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp).padding(bottom = 18.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Editar lomo", color = XPanelText, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(lib.title, color = XPanelMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("Color del lomo", color = XPanelText, fontSize = 13.sp)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    Modifier.size(34.dp).clip(CircleShape).border(2.dp, if (current == null) XAccent else Color(0x55FFFFFF), CircleShape)
                        .clickable { onColor(null) },
                    contentAlignment = Alignment.Center
                ) { Text("A", color = XPanelText, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                DECO_COLORS.forEach { c ->
                    Box(
                        Modifier.size(34.dp).clip(CircleShape).background(Color(c.second))
                            .border(2.dp, if (current == c.second) XAccent else Color(0x33FFFFFF), CircleShape)
                            .clickable { onColor(c.second) }
                    )
                }
            }
            Text("Grosor: ${wv.roundToInt()} dp", color = XPanelText, fontSize = 13.sp)
            Slider(
                value = wv, onValueChange = { wv = it }, valueRange = 18f..60f, colors = xSliderColors(),
                onValueChangeFinished = { onSize(wv.roundToInt(), hv.roundToInt()) }
            )
            Text("Altura: ${hv.roundToInt()} dp", color = XPanelText, fontSize = 13.sp)
            Slider(
                value = hv, onValueChange = { hv = it }, valueRange = 80f..190f, colors = xSliderColors(),
                onValueChangeFinished = { onSize(wv.roundToInt(), hv.roundToInt()) }
            )
            Box(
                Modifier.fillMaxWidth().height(44.dp).clip(RoundedCornerShape(22.dp)).background(XAccent).clickable(onClick = onDismiss),
                contentAlignment = Alignment.Center
            ) { Text("Listo", color = Color(0xFF1B1405), fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun XAssistDialog(onDismiss: () -> Unit, onRun: (Int, Int, Int) -> Unit) {
    var source by remember { mutableIntStateOf(0) }
    var mode by remember { mutableIntStateOf(2) }
    var deco by remember { mutableIntStateOf(1) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = XPanelBg,
        title = { Text("Crear con asistente", color = XPanelText, fontSize = 17.sp, fontWeight = FontWeight.SemiBold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Qué libros", color = XPanelMuted, fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Todos", "Favoritos", "Leyendo", "Por leer", "Terminados").forEachIndexed { i, t ->
                        XChip(t, source == i) { source = i }
                    }
                }
                Text("Cómo colocarlos", color = XPanelMuted, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Portadas", "Lomos", "Mezcla").forEachIndexed { i, t -> XChip(t, mode == i) { mode = i } }
                }
                Text("Objetos decorativos", color = XPanelMuted, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Ninguno", "Pocos", "Muchos").forEachIndexed { i, t -> XChip(t, deco == i) { deco = i } }
                }
                Text(
                    "Sustituye lo que hay ahora en esta estantería. Puedes deshacerlo con ↶.",
                    color = XPanelMuted, fontSize = 11.sp
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onRun(source, mode, deco) }) { Text("Crear", color = XAccent, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar", color = XPanelMuted) } }
    )
}

// ══════════════════════════════════════════════════════════════════════════════
// PANTALLA
// ══════════════════════════════════════════════════════════════════════════════

// ── Mis estanterías: lista, crear, renombrar y eliminar ───────────────────────

@Composable
private fun XShelvesSheet(
    shelves: List<XShelfInfo>,
    activeId: String,
    countOf: (String) -> Pair<Int, Int>,
    onOpen: (XShelfInfo) -> Unit,
    onRename: (XShelfInfo) -> Unit,
    onDelete: (XShelfInfo) -> Unit,
    onNew: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val counts = remember(shelves) { shelves.associate { it.id to countOf(it.id) } }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheet, containerColor = XPanelBg) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 16.dp).navigationBarsPadding()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Mis estanterías", color = XPanelText, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                Box(
                    Modifier.clip(RoundedCornerShape(20.dp)).background(XAccent).clickable(onClick = onNew)
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) { Text("Nueva", color = Color(0xFF1B1405), fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            }
            Spacer(Modifier.height(10.dp))
            LazyColumn(Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shelves, key = { it.id }) { sh ->
                    val c = counts[sh.id] ?: (0 to 0)
                    val active = sh.id == activeId
                    Row(
                        Modifier.fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (active) Color(0x33E2A93C) else XPanelBtn)
                            .then(if (active) Modifier.border(1.5.dp, XAccent, RoundedCornerShape(16.dp)) else Modifier)
                            .clickable { onOpen(sh) }
                            .padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                sh.name, color = XPanelText, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                (if (c.first == 1) "1 libro" else "${c.first} libros") +
                                    (if (c.second > 0) " · ${c.second} objetos" else "") +
                                    (if (active) " · abierta" else ""),
                                color = XPanelMuted, fontSize = 12.sp
                            )
                        }
                        IconButton(onClick = { onRename(sh) }) { XIcon(XIconKind.PENCIL, XPanelText, size = 20.dp) }
                        IconButton(onClick = { onDelete(sh) }) { XIcon(XIconKind.TRASH, XDanger, size = 20.dp) }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Toca una estantería para abrirla. Todo se guarda solo mientras la editas.",
                color = XPanelMuted, fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun XNameDialog(title: String, initial: String, confirm: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = XPanelBg,
        title = { Text(title, color = XPanelText) },
        text = {
            OutlinedTextField(
                value = name, onValueChange = { name = it.take(32) }, singleLine = true,
                placeholder = { Text("Nombre de la estantería", color = XPanelMuted, fontSize = 13.sp) },
                shape = RoundedCornerShape(12.dp), colors = xFieldColors()
            )
        },
        confirmButton = {
            TextButton(onClick = { onOk(name) }, enabled = name.isNotBlank()) {
                Text(confirm, color = XAccent, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar", color = XPanelMuted) } }
    )
}

@Composable
internal fun ExpositorScreen(
    books: List<LibraryItem>,
    onDetail: (LibraryItem) -> Unit,
    onRead: (LibraryItem) -> Unit,
    onImport: () -> Unit,
    onScan: () -> Unit,
    onSpineSize: (String, Int, Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val ctx = LocalContext.current
    val dens = LocalDensity.current.density
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    var style by remember { mutableStateOf(ShelfStyleStore.load(ctx)) }
    var bookColors by remember { mutableStateOf(ShelfStyleStore.loadBookColors(ctx)) }
    var shelfId by remember { mutableStateOf(ExpoStore.activeId(ctx)) }
    var shelves by remember { mutableStateOf(ExpoStore.shelves(ctx)) }
    val saved = remember { ExpoStore.load(ctx, shelfId) }
    var board by remember { mutableStateOf(saved ?: XBoard()) }
    var undo by remember { mutableStateOf(listOf<XBoard>()) }
    var redo by remember { mutableStateOf(listOf<XBoard>()) }
    var selBook by remember { mutableStateOf<String?>(null) }
    var selDeco by remember { mutableStateOf<String?>(null) }
    var decorMode by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf(XPanel.MAIN) }
    var placing by remember { mutableStateOf<XPlacing?>(null) }
    var ghost by remember { mutableStateOf<XGhost?>(null) }
    var draggingId by remember { mutableStateOf<String?>(null) }
    var dragStart by remember { mutableStateOf<XBoard?>(null) }
    var sliderBase by remember { mutableStateOf<XBoard?>(null) }
    var areaWDp by remember { mutableFloatStateOf(360f) }
    var viewportH by remember { mutableIntStateOf(0) }
    var autoFilled by remember { mutableStateOf(saved != null) }
    var menuLevel by remember { mutableIntStateOf(-1) }
    var addMenu by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    var showDecoPicker by remember { mutableStateOf(false) }
    var showAssist by remember { mutableStateOf(false) }
    var showStudio by remember { mutableStateOf(false) }
    var showSpine by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    var titleMenu by remember { mutableStateOf(false) }
    var showShelves by remember { mutableStateOf(false) }
    var newShelfDialog by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<XShelfInfo?>(null) }
    var deleteTarget by remember { mutableStateOf<XShelfInfo?>(null) }
    val scroll = rememberScrollState()

    val libMap = remember(books) { books.associateBy { it.id } }
    val libNow by rememberUpdatedState(libMap)
    val plankH = plankDp(style.thickness).toFloat()
    val plankNow by rememberUpdatedState(plankH)
    val areaNow by rememberUpdatedState(areaWDp)
    val booksNow by rememberUpdatedState(books)

    val wallDef = remember(style.wall) { wallOf(style.wall) }
    val woodDef = remember(style.wood) { woodOf(style.wood) }

    // ── Lógica ───────────────────────────────────────────────────────────────
    fun geoOf(b: XBoard): XGeo = XGeo(areaNow, b.bandH, b.shelves, plankNow)

    /** Aplica un cambio y lo guarda; si [from] no es nulo, ese estado queda para «Deshacer». */
    fun commit(nb: XBoard, from: XBoard? = board) {
        if (from != null && from != nb) {
            undo = (undo + from).takeLast(X_MAX_UNDO)
            redo = emptyList()
        }
        board = nb
        ExpoStore.save(ctx, shelfId, nb)
    }

    fun settleAll(b: XBoard): XBoard = xGravity(b, libNow, geoOf(b))

    fun editBook(id: String, f: (XBook) -> XBook): XBoard {
        val cur = board
        val old = cur.books.firstOrNull { it.id == id } ?: return cur
        val lib = libNow[id] ?: return cur
        var nb = f(old)
        val geo = geoOf(cur)
        val dims = xBookDims(lib, nb.face)
        nb = nb.copy(scale = xFitScale(dims.first, dims.second, nb.scale, nb.rot, geo))
        val half = xHalf(dims.first, dims.second, nb.scale, nb.rot)
        val st = xSettle(nb.cx, nb.cy, half.first, half.second, geo, xBoxes(cur, libNow), id, false)
        nb = nb.copy(cx = st.first, cy = st.second)
        return cur.copy(books = cur.books.map { if (it.id == id) nb else it })
    }

    fun editDeco(id: String, f: (XDeco) -> XDeco): XBoard {
        val cur = board
        val old = cur.decos.firstOrNull { it.id == id } ?: return cur
        val nd = f(old)
        val bx = xDecoBox(nd)
        val st = xSettle(nd.cx, nd.cy, bx.hw, bx.hh, geoOf(cur), xBoxes(cur, libNow), id, true)
        return cur.copy(decos = cur.decos.map { if (it.id == id) nd.copy(cx = st.first, cy = st.second) else it })
    }

    fun liveBook(id: String, f: (XBook) -> XBook) {
        if (sliderBase == null) sliderBase = board
        board = editBook(id, f)
    }

    fun liveDeco(id: String, f: (XDeco) -> XDeco) {
        if (sliderBase == null) sliderBase = board
        board = editDeco(id, f)
    }

    fun finishLive() {
        val base = sliderBase
        sliderBase = null
        if (base != null) commit(settleAll(board), from = base)
    }

    fun hitAt(x: Float, y: Float): XRef? {
        val b = board
        val lib = libNow
        if (!decorMode) {
            for (xb in b.books.sortedByDescending { it.z }) {
                val l = lib[xb.id] ?: continue
                val dims = xBookDims(l, xb.face)
                if (xInside(x, y, xb.cx, xb.cy, dims.first, dims.second, xb.scale, xb.rot, 5f)) return XRef(false, xb.id, xb.z)
            }
        }
        for (d in b.decos.sortedByDescending { it.z }) {
            val def = xDecoDef(d.key) ?: continue
            if (xInside(x, y, d.cx, d.cy, def.w.toFloat(), def.h.toFloat(), d.scale, d.rot, 4f)) return XRef(true, d.id, d.z)
        }
        return null
    }

    fun canDrag(r: XRef): Boolean =
        if (r.deco) board.decos.firstOrNull { it.id == r.id }?.locked == false
        else board.books.firstOrNull { it.id == r.id }?.locked == false

    fun dragBegin(r: XRef) {
        dragStart = board
        draggingId = r.id
        val z = xNextZ(board)
        if (r.deco) {
            selDeco = r.id; selBook = null; decorMode = true
            board = board.copy(decos = board.decos.map { if (it.id == r.id) it.copy(z = z) else it })
        } else {
            selBook = r.id; selDeco = null
            board = board.copy(books = board.books.map { if (it.id == r.id) it.copy(z = z) else it })
        }
    }

    fun dragBy(r: XRef, dx: Float, dy0: Float) {
        val geo = geoOf(board)
        var dy = dy0
        val cyNow = if (r.deco) board.decos.firstOrNull { it.id == r.id }?.cy else board.books.firstOrNull { it.id == r.id }?.cy
        if (cyNow != null) {
            val yView = cyNow * dens - scroll.value
            if (yView < 70f * dens && scroll.value > 0) {
                dy += scroll.dispatchRawDelta(-16f * dens) / dens
            } else if (yView > viewportH - 190f * dens) {
                dy += scroll.dispatchRawDelta(16f * dens) / dens
            }
        }
        if (r.deco) {
            val d = board.decos.firstOrNull { it.id == r.id } ?: return
            val nd = d.copy(cx = (d.cx + dx).coerceIn(0f, geo.areaW), cy = (d.cy + dy).coerceIn(0f, geo.totalH))
            board = board.copy(decos = board.decos.map { if (it.id == r.id) nd else it })
            val bx = xDecoBox(nd)
            val st = xSettle(nd.cx, nd.cy, bx.hw, bx.hh, geo, xBoxes(board, libNow), nd.id, true)
            ghost = XGhost(st.first, st.second, bx.hw, bx.hh)
        } else {
            val b = board.books.firstOrNull { it.id == r.id } ?: return
            val l = libNow[r.id] ?: return
            val nb = b.copy(cx = (b.cx + dx).coerceIn(0f, geo.areaW), cy = (b.cy + dy).coerceIn(0f, geo.totalH))
            board = board.copy(books = board.books.map { if (it.id == r.id) nb else it })
            val bx = xBookBox(nb, l)
            val st = xSettle(nb.cx, nb.cy, bx.hw, bx.hh, geo, xBoxes(board, libNow), nb.id, false)
            ghost = XGhost(st.first, st.second, bx.hw, bx.hh)
        }
    }

    fun dragEnd(r: XRef) {
        val start = dragStart
        dragStart = null
        draggingId = null
        ghost = null
        val geo = geoOf(board)
        var nb = board
        if (r.deco) {
            val d = nb.decos.firstOrNull { it.id == r.id }
            if (d != null) {
                val bx = xDecoBox(d)
                val st = xSettle(d.cx, d.cy, bx.hw, bx.hh, geo, xBoxes(nb, libNow), d.id, true)
                nb = nb.copy(decos = nb.decos.map { if (it.id == d.id) it.copy(cx = st.first, cy = st.second) else it })
            }
        } else {
            val b = nb.books.firstOrNull { it.id == r.id }
            val l = libNow[r.id]
            if (b != null && l != null) {
                val bx = xBookBox(b, l)
                val st = xSettle(b.cx, b.cy, bx.hw, bx.hh, geo, xBoxes(nb, libNow), b.id, false)
                nb = nb.copy(books = nb.books.map { if (it.id == b.id) it.copy(cx = st.first, cy = st.second) else it })
                // Los objetos apoyados encima viajan con el libro
                val sb = start?.books?.firstOrNull { it.id == b.id }
                if (sb != null) {
                    val ob = xBookBox(sb, l)
                    val ddx = st.first - sb.cx
                    val ddy = st.second - sb.cy
                    nb = nb.copy(decos = nb.decos.map { d ->
                        val db = xDecoBox(d)
                        if (abs(db.bottom - ob.top) <= 3f && d.cx >= ob.left && d.cx <= ob.right) {
                            d.copy(cx = d.cx + ddx, cy = d.cy + ddy)
                        } else d
                    })
                }
            }
        }
        commit(settleAll(nb), from = start)
    }

    fun dragCancel() {
        val start = dragStart
        dragStart = null
        draggingId = null
        ghost = null
        if (start != null) board = start
    }

    fun placeAt(xDp: Float, yDp: Float) {
        val p = placing ?: return
        var cur = board
        val band0 = geoOf(cur).bandOf(yDp)
        if (p.decoKey != null) {
            val def = xDecoDef(p.decoKey)
            if (def != null) {
                val geo = geoOf(cur)
                val sc = 1.2f
                val d = XDeco(
                    java.util.UUID.randomUUID().toString(), def.key, xDp,
                    geo.floorY(band0) - def.h * sc / 2f, sc, 0f, false, xNextZ(cur)
                )
                val bx = xDecoBox(d)
                val st = xSettle(d.cx, d.cy, bx.hw, bx.hh, geo, xBoxes(cur, libNow), d.id, true)
                cur = cur.copy(decos = cur.decos + d.copy(cx = st.first, cy = st.second))
                selDeco = d.id
            }
        } else {
            var band = band0
            var lx = maxOf(X_SIDE + 6f, xDp - 30f)
            var z = xNextZ(cur)
            for (id in p.bookIds) {
                val lib = libNow[id] ?: continue
                val dims = xBookDims(lib, X_FACE_COVER)
                var geo = geoOf(cur)
                val sc = xFitScale(dims.first, dims.second, 1f, 0f, geo)
                val half = xHalf(dims.first, dims.second, sc, 0f)
                if (lx + 2f * half.first > areaNow - X_SIDE - 4f) {
                    band += 1
                    lx = X_SIDE + 6f
                }
                if (band >= cur.shelves) cur = cur.copy(shelves = band + 1)
                geo = geoOf(cur)
                val cy0 = geo.floorY(band) - half.second
                val st = xSettle(lx + half.first, cy0, half.first, half.second, geo, xBoxes(cur, libNow), id, false)
                cur = cur.copy(books = cur.books + XBook(id, st.first, st.second, sc, 0f, X_FACE_COVER, false, z++))
                lx = st.first + half.first + 3f
            }
        }
        placing = null
        commit(settleAll(cur))
    }

    fun onTapAt(px: Float, py: Float) {
        val x = px / dens
        val y = py / dens
        if (placing != null) { placeAt(x, y); return }
        val hit = hitAt(x, y)
        if (hit == null) {
            if (!decorMode) selBook = null
            selDeco = null
            panel = XPanel.MAIN
            return
        }
        val z = xNextZ(board)
        if (hit.deco) {
            decorMode = true; selDeco = hit.id; selBook = null
            board = board.copy(decos = board.decos.map { if (it.id == hit.id) it.copy(z = z) else it })
        } else {
            if (selBook != hit.id) panel = XPanel.MAIN
            selBook = hit.id; selDeco = null
            board = board.copy(books = board.books.map { if (it.id == hit.id) it.copy(z = z) else it })
        }
    }

    // ── Efectos ──────────────────────────────────────────────────────────────

    // Primera vez: el asistente llena la estantería con los primeros libros
    LaunchedEffect(books.isNotEmpty(), viewportH) {
        if (!autoFilled && books.isNotEmpty() && viewportH > 0) {
            autoFilled = true
            val nb = xAssist(books.take(18), 2, 1, areaNow, board.bandH, plankNow)
            commit(nb, from = null)
        }
    }

    // Autoguardado en tiempo real: cada cambio queda guardado enseguida (también mientras arrastras o mueves un deslizador)
    LaunchedEffect(board) {
        delay(300)
        ExpoStore.save(ctx, shelfId, board)
    }
    val latestBoard by rememberUpdatedState(board)
    val latestShelf by rememberUpdatedState(shelfId)
    DisposableEffect(Unit) {
        onDispose {
            // Al salir de la pestaña se guarda lo último y por dónde ibas
            ExpoStore.save(ctx, latestShelf, latestBoard)
            ctx.getSharedPreferences("libra_prefs", 0).edit().putInt("xp_scroll_$latestShelf", scroll.value).apply()
        }
    }
    // Al volver (o al abrir otra estantería) la vista vuelve a donde la dejaste
    LaunchedEffect(shelfId) {
        val sv = ctx.getSharedPreferences("libra_prefs", 0).getInt("xp_scroll_$shelfId", 0)
        if (sv <= 0) {
            scroll.scrollTo(0)
        } else {
            withTimeoutOrNull(1500) { snapshotFlow { scroll.maxValue }.first { it >= sv } }
            scroll.scrollTo(sv)
        }
    }

    // Libros borrados, cambio de madera y todo lo que flote: se ordena solo
    val dimsSig = board.books.joinToString("|") { b ->
        val l = libMap[b.id]
        b.id + (if (l != null) "${l.spineWidthDp}x${l.spineHeightDp}" else "x")
    }
    LaunchedEffect(dimsSig, areaWDp, plankH, books.isNotEmpty()) {
        if (board.books.isEmpty() && board.decos.isEmpty()) return@LaunchedEffect
        var nb = board
        if (booksNow.isNotEmpty() && nb.books.any { libNow[it.id] == null }) {
            nb = nb.copy(books = nb.books.filter { libNow[it.id] != null })
        }
        if (abs(nb.plank - plankNow) > 0.1f) nb = xReseatPlank(nb, plankNow)
        nb = xGravity(nb, libNow, XGeo(areaNow, nb.bandH, nb.shelves, plankNow))
        if (nb != board) commit(nb, from = null)
    }

    // Al elegir algo, la vista se desplaza para que la barra inferior no lo tape
    LaunchedEffect(selBook, selDeco) {
        val id = selBook ?: selDeco ?: return@LaunchedEffect
        val bottom = if (selBook != null) {
            val xb = board.books.firstOrNull { it.id == id }
            val l = libNow[id]
            if (xb != null && l != null) xBookBox(xb, l).bottom else null
        } else {
            board.decos.firstOrNull { it.id == id }?.let { xDecoBox(it).bottom }
        }
        if (bottom != null && viewportH > 0) {
            val room = viewportH - 200f * dens
            val itemPx = bottom * dens
            if (itemPx > scroll.value + room) scroll.animateScrollTo((itemPx - room).toInt())
        }
    }

    // ── Datos para dibujar ───────────────────────────────────────────────────
    val geoNow = XGeo(areaWDp, board.bandH, board.shelves, plankH)
    val selB = board.books.firstOrNull { it.id == selBook }
    val selD = board.decos.firstOrNull { it.id == selDeco }
    val exposedCount = board.books.count { libMap[it.id] != null }
    val drawList = (board.books.map { XRef(false, it.id, it.z) } + board.decos.map { XRef(true, it.id, it.z) })
        .sortedBy { it.z }
    // Pilas: solo el libro de más arriba se ve en 3D completo; los que tienen otro encima se dibujan planos
    val coveredIds: Set<String> = remember(board, libMap) {
        val bs = xBoxes(board, libMap).filter { !it.deco }
        val out = HashSet<String>()
        for (a in bs) {
            for (b in bs) {
                if (a.id == b.id) continue
                val ox = minOf(a.right, b.right) - maxOf(a.left, b.left)
                if (ox > 1f && abs(b.bottom - a.top) <= 4f && b.cy < a.cy) { out.add(a.id); break }
            }
        }
        out
    }

    fun doDone() {
        selBook = null; selDeco = null; decorMode = false; panel = XPanel.MAIN
    }

    fun doUndo() {
        val prev = undo.lastOrNull() ?: return
        redo = (redo + board).takeLast(X_MAX_UNDO)
        undo = undo.dropLast(1)
        board = prev
        ExpoStore.save(ctx, shelfId, prev)
        if (selBook != null && prev.books.none { it.id == selBook }) selBook = null
        if (selDeco != null && prev.decos.none { it.id == selDeco }) selDeco = null
    }

    fun doRedo() {
        val next = redo.lastOrNull() ?: return
        undo = (undo + board).takeLast(X_MAX_UNDO)
        redo = redo.dropLast(1)
        board = next
        ExpoStore.save(ctx, shelfId, next)
    }

    fun toast(msg: String) {
        scope.launch { snackbar.showSnackbar(msg) }
    }

    /** Deja la pantalla limpia al cambiar de estantería. */
    fun resetUi() {
        undo = emptyList(); redo = emptyList()
        selBook = null; selDeco = null; decorMode = false; panel = XPanel.MAIN
        placing = null; ghost = null; draggingId = null; dragStart = null; sliderBase = null
        autoFilled = true
    }

    /** Abre otra estantería: la actual ya queda guardada tal como está. */
    fun switchShelf(id: String) {
        if (id == shelfId) return
        ExpoStore.save(ctx, shelfId, board)
        ctx.getSharedPreferences("libra_prefs", 0).edit().putInt("xp_scroll_$shelfId", scroll.value).apply()
        ExpoStore.setActive(ctx, id)
        val nb = ExpoStore.load(ctx, id) ?: XBoard()
        shelfId = id
        board = nb
        resetUi()
    }

    fun createShelf(name: String) {
        if (shelves.size >= ExpoStore.MAX_SHELVES) {
            toast("Máximo ${ExpoStore.MAX_SHELVES} estanterías")
            return
        }
        ExpoStore.save(ctx, shelfId, board)
        ctx.getSharedPreferences("libra_prefs", 0).edit().putInt("xp_scroll_$shelfId", scroll.value).apply()
        val id = ExpoStore.create(ctx, name)
        shelves = ExpoStore.shelves(ctx)
        shelfId = id
        board = XBoard()
        resetUi()
    }

    fun deleteShelf(target: XShelfInfo) {
        if (shelves.size <= 1) {
            toast("Debe quedar al menos una estantería")
            return
        }
        val wasActive = target.id == shelfId
        val next = ExpoStore.delete(ctx, target.id)
        shelves = ExpoStore.shelves(ctx)
        if (wasActive) {
            shelfId = next
            board = ExpoStore.load(ctx, next) ?: XBoard()
            resetUi()
        }
    }

    fun sortBoard(kind: String) {
        val ids = board.books.mapNotNull { b -> libNow[b.id]?.let { b.id to it } }
        val sorted = when (kind) {
            "title" -> ids.sortedBy { it.second.title.lowercase() }
            "author" -> ids.sortedBy { it.second.author.lowercase() }
            "progress" -> ids.sortedByDescending { it.second.progress }
            else -> ids.sortedByDescending { it.second.addedAt }
        }
        commit(settleAll(xRepack(board, libNow, sorted.map { it.first }, areaNow)))
    }

    fun rearrange(mode: Int) {
        val geo = geoOf(board)
        val items = board.books
            .sortedWith(compareBy({ geo.bandOf(it.cy) }, { it.cx }))
            .mapNotNull { libNow[it.id] }
        val nb = xAssist(items, mode, 0, areaNow, board.bandH, plankNow, keepDecos = board.decos.sortedBy { it.z })
        commit(settleAll(nb))
    }

    // ── Interfaz ─────────────────────────────────────────────────────────────
    Box(modifier.fillMaxSize().background(Ink)) {
        Column(Modifier.fillMaxSize()) {
            // Cabecera: «Mis estanterías ▾» (cambiar / crear / administrar) y ★ (todas las opciones de edición)
            Row(
                Modifier.fillMaxWidth().padding(start = 18.dp, end = 14.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.weight(1f)) {
                    Column(
                        Modifier.clip(RoundedCornerShape(10.dp)).clickable { titleMenu = true }
                            .padding(vertical = 2.dp, horizontal = 2.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "Mis estanterías", color = Cream, fontSize = 26.sp, fontWeight = FontWeight.Bold,
                                fontFamily = LibellumSerif, letterSpacing = 0.5.sp, maxLines = 1
                            )
                            Spacer(Modifier.width(4.dp))
                            XIcon(XIconKind.CHEVRON_DOWN, Muted, size = 18.dp)
                        }
                        Text(
                            (shelves.firstOrNull { it.id == shelfId }?.name ?: "Mi estantería") + " · " +
                                (if (exposedCount == 1) "1 libro" else "$exposedCount libros"),
                            color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    DropdownMenu(expanded = titleMenu, onDismissRequest = { titleMenu = false }) {
                        shelves.forEach { sh ->
                            DropdownMenuItem(
                                text = { Text((if (sh.id == shelfId) "✓  " else "      ") + sh.name) },
                                onClick = { titleMenu = false; switchShelf(sh.id) }
                            )
                        }
                        HorizontalDivider()
                        DropdownMenuItem(text = { Text("＋  Nueva estantería") }, onClick = {
                            titleMenu = false; newShelfDialog = true
                        })
                        DropdownMenuItem(text = { Text("Administrar estanterías") }, onClick = {
                            titleMenu = false
                            ExpoStore.save(ctx, shelfId, board)
                            showShelves = true
                        })
                    }
                }
                Box {
                    XCircleBtn(XIconKind.SPARKLE, { menuLevel = 0 }, Panel, Gold, size = 42.dp)
                    DropdownMenu(expanded = menuLevel >= 0, onDismissRequest = { menuLevel = -1 }) {
                        when (menuLevel) {
                            0 -> {
                                DropdownMenuItem(text = { Text("Personalizar") }, onClick = { menuLevel = -1; showStudio = true })
                                DropdownMenuItem(text = { Text("Decorar") }, onClick = {
                                    menuLevel = -1; decorMode = true; selBook = null; panel = XPanel.MAIN
                                })
                                DropdownMenuItem(text = { Text("Crear con asistente") }, onClick = { menuLevel = -1; showAssist = true })
                                DropdownMenuItem(text = { Text("Organización  ›") }, onClick = { menuLevel = 2 })
                                DropdownMenuItem(text = { Text("Baldas  ›") }, onClick = { menuLevel = 1 })
                                DropdownMenuItem(text = { Text("Otros  ›") }, onClick = { menuLevel = 3 })
                            }
                            1 -> {
                                DropdownMenuItem(text = { Text("‹  Volver") }, onClick = { menuLevel = 0 })
                                DropdownMenuItem(text = { Text("Añadir una balda") }, onClick = {
                                    menuLevel = -1; commit(board.copy(shelves = (board.shelves + 1).coerceAtMost(40)))
                                })
                                DropdownMenuItem(text = { Text("Quitar la última balda") }, onClick = {
                                    menuLevel = -1
                                    val limit = (board.shelves - 1) * board.bandH
                                    val busy = board.books.any { it.cy > limit } || board.decos.any { it.cy > limit }
                                    if (board.shelves <= 1) toast("Una estantería necesita al menos una balda")
                                    else if (busy) toast("La última balda tiene cosas: muévelas antes")
                                    else commit(board.copy(shelves = board.shelves - 1))
                                })
                                DropdownMenuItem(text = { Text("Baldas bajas") }, onClick = {
                                    menuLevel = -1; commit(settleAll(xRescaleBands(board, 170f)))
                                })
                                DropdownMenuItem(text = { Text("Baldas normales") }, onClick = {
                                    menuLevel = -1; commit(settleAll(xRescaleBands(board, 200f)))
                                })
                                DropdownMenuItem(text = { Text("Baldas altas") }, onClick = {
                                    menuLevel = -1; commit(settleAll(xRescaleBands(board, 240f)))
                                })
                            }
                            2 -> {
                                DropdownMenuItem(text = { Text("‹  Volver") }, onClick = { menuLevel = 0 })
                                DropdownMenuItem(text = { Text("Ordenar por título") }, onClick = { menuLevel = -1; sortBoard("title") })
                                DropdownMenuItem(text = { Text("Ordenar por autor") }, onClick = { menuLevel = -1; sortBoard("author") })
                                DropdownMenuItem(text = { Text("Ordenar por lectura") }, onClick = { menuLevel = -1; sortBoard("progress") })
                                DropdownMenuItem(text = { Text("Más recientes primero") }, onClick = { menuLevel = -1; sortBoard("recent") })
                                HorizontalDivider()
                                DropdownMenuItem(text = { Text("Todos de portada") }, onClick = { menuLevel = -1; rearrange(0) })
                                DropdownMenuItem(text = { Text("Todos de lomo") }, onClick = { menuLevel = -1; rearrange(1) })
                                DropdownMenuItem(text = { Text("Mezcla realista") }, onClick = { menuLevel = -1; rearrange(2) })
                            }
                            else -> {
                                DropdownMenuItem(text = { Text("‹  Volver") }, onClick = { menuLevel = 0 })
                                DropdownMenuItem(text = { Text("Quitar todos los objetos") }, onClick = {
                                    menuLevel = -1; commit(board.copy(decos = emptyList()))
                                })
                                DropdownMenuItem(text = { Text("Vaciar esta estantería") }, onClick = { menuLevel = -1; confirmClear = true })
                            }
                        }
                    }
                }
                Spacer(Modifier.width(10.dp))
                Box {
                    XCircleBtn(XIconKind.PLUS, { addMenu = true }, Gold, Color.White, size = 42.dp)
                    DropdownMenu(expanded = addMenu, onDismissRequest = { addMenu = false }) {
                        DropdownMenuItem(text = { Text("De tu biblioteca") }, onClick = { addMenu = false; showAdd = true })
                        DropdownMenuItem(text = { Text("Importar libros") }, onClick = { addMenu = false; onImport() })
                        DropdownMenuItem(text = { Text("Buscar libros en el teléfono") }, onClick = { addMenu = false; onScan() })
                    }
                }
            }

            // Estantería
            Box(Modifier.weight(1f).fillMaxWidth().onSizeChanged { viewportH = it.height }) {
                Column(Modifier.fillMaxSize().verticalScroll(scroll)) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(geoNow.totalH.dp)
                            .onSizeChanged { areaWDp = it.width / dens }
                            .drawBehind {
                                drawWall(wallDef)
                                val sw = X_SIDE.dp.toPx()
                                drawRect(
                                    Brush.horizontalGradient(listOf(woodDef.light, woodDef.dark), startX = 0f, endX = sw),
                                    Offset.Zero, Size(sw, size.height)
                                )
                                drawRect(
                                    Brush.horizontalGradient(listOf(woodDef.dark, woodDef.light), startX = size.width - sw, endX = size.width),
                                    Offset(size.width - sw, 0f), Size(sw, size.height)
                                )
                            }
                            .drawWithContent { drawContent(); drawLight(style.light) }
                            .pointerInput(Unit) { detectTapGestures(onTap = { off -> onTapAt(off.x, off.y) }) }
                            .pointerInput(Unit) {
                                awaitEachGesture {
                                    val down = awaitFirstDown(requireUnconsumed = false)
                                    val hit = hitAt(down.position.x / dens, down.position.y / dens)
                                    if (hit == null || !canDrag(hit)) return@awaitEachGesture
                                    var over = Offset.Zero
                                    val slop = awaitTouchSlopOrCancellation(down.id) { change, overSlop ->
                                        change.consume()
                                        over = overSlop
                                    }
                                    if (slop == null) return@awaitEachGesture
                                    dragBegin(hit)
                                    dragBy(hit, over.x / dens, over.y / dens)
                                    val done = drag(slop.id) { change ->
                                        val d = change.positionChange()
                                        dragBy(hit, d.x / dens, d.y / dens)
                                        change.consume()
                                    }
                                    if (done) dragEnd(hit) else dragCancel()
                                }
                            }
                    ) {
                        // Baldas
                        for (i in 0 until board.shelves) {
                            val top = geoNow.floorY(i)
                            Canvas(
                                Modifier
                                    .offset { IntOffset(0, (top * dens).roundToInt()) }
                                    .fillMaxWidth()
                                    .height((plankH + 8f).dp)
                            ) {
                                drawWoodRect(woodDef, Offset.Zero, Size(size.width, plankH.dp.toPx()))
                                drawRect(
                                    Brush.verticalGradient(listOf(Color(0x33000000), Color.Transparent)),
                                    Offset(0f, plankH.dp.toPx()), Size(size.width, 8.dp.toPx())
                                )
                            }
                        }
                        // Libros y objetos, del fondo al frente
                        drawList.forEach { r ->
                            key((if (r.deco) "d:" else "b:") + r.id) {
                                if (r.deco) {
                                    val d = board.decos.firstOrNull { it.id == r.id }
                                    if (d != null) XDecoItem(d, selDeco == d.id, draggingId == d.id, dens)
                                } else {
                                    val xb = board.books.firstOrNull { it.id == r.id }
                                    val lb = libMap[r.id]
                                    if (xb != null && lb != null) {
                                        XBookItem(lb, xb, selBook == xb.id, draggingId == xb.id, bookColors[xb.id], dens, flat = xb.id in coveredIds)
                                    }
                                }
                                Unit
                            }
                        }
                        // Dónde se va a apoyar lo que arrastras
                        val g = ghost
                        if (g != null) {
                            Canvas(Modifier.fillMaxSize()) {
                                drawRoundRect(
                                    XGoldLine.copy(alpha = 0.95f),
                                    Offset((g.cx - g.hw) * dens, (g.cy - g.hh) * dens),
                                    Size(g.hw * 2f * dens, g.hh * 2f * dens),
                                    CornerRadius(6.dp.toPx()),
                                    style = Stroke(width = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(16f, 10f), 0f))
                                )
                                drawRect(
                                    XGoldLine.copy(alpha = 0.18f),
                                    Offset((g.cx - g.hw) * dens, (g.cy - g.hh) * dens),
                                    Size(g.hw * 2f * dens, g.hh * 2f * dens)
                                )
                            }
                        }
                        // Animación ambiental global (lluvia, nieve…): la misma en todas tus estanterías
                        ShelfFxOverlay(style.anim, Modifier.matchParentSize())
                    }
                    Spacer(Modifier.height(190.dp))
                }

                // Estantería vacía
                if (board.books.isEmpty() && board.decos.isEmpty() && placing == null) {
                    Column(
                        Modifier.align(Alignment.Center).padding(32.dp).clip(RoundedCornerShape(22.dp))
                            .background(XPanelBg).padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Esta estantería está vacía", color = XPanelText, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            "Añade libros de tu biblioteca o deja que el asistente la monte por ti.",
                            color = XPanelMuted, fontSize = 12.sp, textAlign = TextAlign.Center
                        )
                        Box(
                            Modifier.clip(RoundedCornerShape(20.dp)).background(XAccent).clickable { showAdd = true }
                                .padding(horizontal = 20.dp, vertical = 10.dp)
                        ) { Text("Añadir libros", color = Color(0xFF1B1405), fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                        Box(
                            Modifier.clip(RoundedCornerShape(20.dp)).background(XPanelBtn).clickable { showAssist = true }
                                .padding(horizontal = 20.dp, vertical = 10.dp)
                        ) { Text("Crear con asistente", color = XAccent, fontWeight = FontWeight.Medium, fontSize = 13.sp) }
                    }
                }
            }
        }

        // «Toca una balda para colocar»
        if (placing != null) {
            Row(
                Modifier.align(Alignment.TopCenter).padding(top = 76.dp, start = 16.dp, end = 16.dp).fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp)).background(XPanelBg).padding(start = 18.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Toca una balda para colocar", color = XPanelText, fontSize = 13.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { placing = null }) { Text("Cancelar", color = XAccent, fontSize = 13.sp) }
            }
        }

        // Barras inferiores
        Box(Modifier.align(Alignment.BottomCenter).padding(horizontal = 10.dp, vertical = 10.dp)) {
            if (decorMode && placing == null) {
                XDecorBar(
                    hasSel = selD != null,
                    scale = selD?.scale ?: 1f,
                    locked = selD?.locked == true,
                    canUndo = undo.isNotEmpty(), canRedo = redo.isNotEmpty(),
                    onUndo = { doUndo() }, onRedo = { doRedo() }, onDone = { doDone() },
                    onAdd = { showDecoPicker = true },
                    onLock = {
                        val id = selDeco
                        if (id != null) commit(board.copy(decos = board.decos.map { if (it.id == id) it.copy(locked = !it.locked) else it }))
                    },
                    onTrash = {
                        val id = selDeco
                        if (id != null) {
                            selDeco = null
                            commit(board.copy(decos = board.decos.filter { it.id != id }))
                        }
                    },
                    onScaleLive = { s -> selDeco?.let { id -> liveDeco(id) { it.copy(scale = s) } } },
                    onLiveDone = { finishLive() }
                )
            } else if (selB != null && placing == null) {
                val id = selB.id
                XEditBar(
                    book = selB,
                    panel = panel,
                    onPanel = { panel = it },
                    canUndo = undo.isNotEmpty(), canRedo = redo.isNotEmpty(),
                    onUndo = { doUndo() }, onRedo = { doRedo() }, onDone = { doDone() },
                    onTrash = {
                        selBook = null
                        commit(settleAll(board.copy(books = board.books.filter { it.id != id })))
                    },
                    onLock = { commit(board.copy(books = board.books.map { if (it.id == id) it.copy(locked = !it.locked) else it })) },
                    onFace = { f ->
                        val nb = editBook(id) { it.copy(face = f) }
                        commit(settleAll(nb))
                    },
                    onEditSpine = { showSpine = true },
                    onScaleLive = { s -> liveBook(id) { it.copy(scale = s) } },
                    onLiveDone = { finishLive() },
                    onRotLive = { r -> liveBook(id) { it.copy(rot = r) } },
                    onRotSet = { r ->
                        liveBook(id) { it.copy(rot = r) }
                        finishLive()
                    },
                    onMore = { act ->
                        when (act) {
                            "detail" -> libNow[id]?.let { onDetail(it) }
                            "read" -> libNow[id]?.let { onRead(it) }
                            "front" -> {
                                val z = xNextZ(board)
                                commit(board.copy(books = board.books.map { if (it.id == id) it.copy(z = z) else it }), from = null)
                            }
                            "back" -> {
                                val z = minOf(board.books.minOfOrNull { it.z } ?: 0, board.decos.minOfOrNull { it.z } ?: 0) - 1
                                commit(board.copy(books = board.books.map { if (it.id == id) it.copy(z = z) else it }), from = null)
                            }
                            "reset" -> {
                                val nb = editBook(id) { it.copy(scale = 1f, rot = 0f, face = X_FACE_COVER) }
                                commit(settleAll(nb))
                            }
                            "remove" -> {
                                selBook = null
                                commit(settleAll(board.copy(books = board.books.filter { it.id != id })))
                            }
                        }
                    }
                )
            }
        }

        SnackbarHost(snackbar, Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp))
    }

    // ── Hojas y diálogos ─────────────────────────────────────────────────────
    if (showAdd) {
        XAddBooksSheet(
            all = books,
            exposed = board.books.map { it.id }.toSet(),
            onCancel = { showAdd = false },
            onAdd = { ids ->
                showAdd = false
                decorMode = false
                selBook = null; selDeco = null
                placing = XPlacing(bookIds = ids)
            }
        )
    }
    if (showDecoPicker) {
        XDecoPickerSheet(
            onPick = { def ->
                showDecoPicker = false
                placing = XPlacing(decoKey = def.key)
            },
            onDismiss = { showDecoPicker = false }
        )
    }
    if (showAssist) {
        XAssistDialog(
            onDismiss = { showAssist = false },
            onRun = { source, mode, deco ->
                showAssist = false
                val pool = when (source) {
                    1 -> books.filter { it.isFavorite == 1 }
                    2 -> books.filter { it.statusKey() == "READING" }
                    3 -> books.filter { it.statusKey() == "TBR" }
                    4 -> books.filter { it.statusKey() == "FINISHED" }
                    else -> books
                }
                if (pool.isEmpty()) {
                    toast("No hay libros con ese filtro")
                } else {
                    selBook = null; selDeco = null; decorMode = false
                    commit(xAssist(pool.take(60), mode, deco, areaNow, board.bandH, plankNow))
                }
            }
        )
    }
    if (showStudio) {
        ShelfStudioSheet(
            style = style,
            onChange = { st -> style = st; ShelfStyleStore.save(ctx, st) },
            onDismiss = { showStudio = false }
        )
    }
    if (showSpine && selB != null) {
        val lb = libMap[selB.id]
        if (lb != null) {
            XSpineSheet(
                lib = lb,
                current = bookColors[lb.id],
                onColor = { c ->
                    val m = bookColors.toMutableMap()
                    if (c == null) m.remove(lb.id) else m[lb.id] = c
                    bookColors = m
                    ShelfStyleStore.saveBookColors(ctx, m)
                },
                onSize = { w, h -> onSpineSize(lb.id, w, h) },
                onDismiss = { showSpine = false }
            )
        } else showSpine = false
    }
    if (showShelves) {
        XShelvesSheet(
            shelves = shelves,
            activeId = shelfId,
            countOf = { id -> ExpoStore.counts(ctx, id) },
            onOpen = { sh -> showShelves = false; switchShelf(sh.id) },
            onRename = { sh -> renameTarget = sh },
            onDelete = { sh -> deleteTarget = sh },
            onNew = { newShelfDialog = true },
            onDismiss = { showShelves = false }
        )
    }
    if (newShelfDialog) {
        XNameDialog(
            title = "Nueva estantería",
            initial = "Estantería ${shelves.size + 1}",
            confirm = "Crear",
            onDismiss = { newShelfDialog = false },
            onOk = { n -> newShelfDialog = false; showShelves = false; createShelf(n) }
        )
    }
    val rt = renameTarget
    if (rt != null) {
        XNameDialog(
            title = "Renombrar estantería",
            initial = rt.name,
            confirm = "Guardar",
            onDismiss = { renameTarget = null },
            onOk = { n ->
                renameTarget = null
                ExpoStore.rename(ctx, rt.id, n)
                shelves = ExpoStore.shelves(ctx)
            }
        )
    }
    val dt = deleteTarget
    if (dt != null) {
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            containerColor = XPanelBg,
            title = { Text("¿Eliminar «${dt.name}»?", color = XPanelText) },
            text = {
                Text(
                    "Se borra esta estantería con sus libros y objetos colocados. Tu biblioteca no se toca.",
                    color = XPanelMuted, fontSize = 13.sp
                )
            },
            confirmButton = {
                TextButton(onClick = { deleteTarget = null; deleteShelf(dt) }) {
                    Text("Eliminar", color = XDanger, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancelar", color = XPanelMuted) } }
        )
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            containerColor = XPanelBg,
            title = { Text("¿Vaciar esta estantería?", color = XPanelText) },
            text = { Text("Se quitan los libros y objetos de esta estantería. Tu biblioteca no se toca.", color = XPanelMuted, fontSize = 13.sp) },
            confirmButton = {
                TextButton(onClick = {
                    confirmClear = false
                    selBook = null; selDeco = null
                    commit(board.copy(books = emptyList(), decos = emptyList()))
                }) { Text("Vaciar", color = XDanger, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancelar", color = XPanelMuted) } }
        )
    }
}
