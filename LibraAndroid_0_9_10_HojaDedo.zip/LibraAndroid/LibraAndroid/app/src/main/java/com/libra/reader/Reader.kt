@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.libra.reader

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Rect
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.view.ActionMode
import android.view.GestureDetector
import android.view.Menu
import android.view.MenuItem
import android.view.MotionEvent
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.util.UUID
import java.util.zip.ZipFile
import kotlin.math.abs
import kotlin.math.absoluteValue
import kotlin.math.roundToInt

// ══════════════════════════════════════════════════════════════════════════════
// PANTALLA PRINCIPAL DEL LECTOR
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun ReaderScreen(
    item: LibraryItem,
    onClose: () -> Unit,
    onSave: (Long, Int) -> Unit,
    highlightDao: HighlightDao,
    onUpdateItem: (LibraryItem) -> Unit,  // para guardar readingMode, bookmarkStyle
    startHighlight: Highlight? = null     // abrir el libro directamente en la hoja de este subrayado
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val activity = context as? Activity
    val sp = remember { context.getSharedPreferences("libra_reading_prefs", 0) }

    var showMenu by remember { mutableStateOf(false) }
    var showHighlights by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    BackHandler(onBack = onClose)
    BackHandler(enabled = showSettings || showHighlights) { showSettings = false; showHighlights = false }
    var showContents by remember { mutableStateOf(false) }
    // Chrome del lector: oculto al leer; un toque lo muestra/oculta
    var showChrome by remember { mutableStateOf(false) }
    // Progreso actualizado por el lector (capítulo / página)
    var liveProgress by remember { mutableIntStateOf(item.progress.coerceIn(0, 100)) }
    var liveChapterLabel by remember { mutableStateOf("") }
    // Posición viva (EPUB: índice de capítulo) y petición de salto desde marcadores / resaltados
    var livePos by remember { mutableLongStateOf(item.lastPosition) }
    var jumpChapter by remember { mutableStateOf<Int?>(startHighlight?.chapterIndex) }
    var jumpOffset by remember { mutableIntStateOf(-1) }
    var jumpText by remember { mutableStateOf<String?>(startHighlight?.selectedText) }
    var jumpTextK by remember { mutableIntStateOf(startHighlight?.let { sp.getInt("hlk_${it.id}", 0) } ?: 0) }
    var bookmarkRequest by remember { mutableIntStateOf(0) }
    var chapterNames by remember { mutableStateOf<List<String>>(emptyList()) }
    var pageBookmarked by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current
    // Texto exacto donde se dejó el libro (solo vale si sigue en el mismo capítulo guardado)
    val savedOffset = remember(item.id) {
        sp.getString("pg_${item.id}", null)?.split("|")?.let { parts ->
            if (parts.getOrNull(0)?.toLongOrNull() == item.lastPosition) parts.getOrNull(1)?.toIntOrNull() else null
        } ?: -1
    }
    val isEpub = item.format.equals("epub", ignoreCase = true)
    // Marcadores del libro (SharedPreferences; la base de datos no cambia)
    val bookmarks = remember(item.id) {
        mutableStateListOf<ReaderBookmark>().apply { addAll(loadReaderBookmarks(sp, item.id)) }
    }
    var readingPrefs by remember {
        mutableStateOf(
            ReadingPrefs(
                themeMode = sp.getInt("themeMode", 2),
                fontSizeSp = sp.getInt("fontSizeSp", 18),
                lineHeight = sp.getFloat("lineHeight", 1.65f),
                marginDp = sp.getInt("marginDp", 28),
                brightness = sp.getFloat("brightness", 1f),
                fontFamily = sp.getString("fontFamily", "serif") ?: "serif",
                pageTurnStyle = sp.getString("pageTurnStyle", "slide") ?: "slide",
                orientation = sp.getString("orientation", "auto") ?: "auto",
                showNavButtons = sp.getBoolean("showNavButtons", false),
                leftHanded = sp.getBoolean("leftHanded", false),
                justify = sp.getBoolean("justify", true),
                indent = sp.getBoolean("indent", true)
            )
        )
    }

    // Persistir y aplicar orientación
    LaunchedEffect(readingPrefs) {
        sp.edit()
            .putInt("themeMode", readingPrefs.themeMode)
            .putInt("fontSizeSp", readingPrefs.fontSizeSp)
            .putFloat("lineHeight", readingPrefs.lineHeight)
            .putInt("marginDp", readingPrefs.marginDp)
            .putFloat("brightness", readingPrefs.brightness)
            .putString("fontFamily", readingPrefs.fontFamily)
            .putString("pageTurnStyle", readingPrefs.pageTurnStyle)
            .putString("orientation", readingPrefs.orientation)
            .putBoolean("showNavButtons", readingPrefs.showNavButtons)
            .putBoolean("leftHanded", readingPrefs.leftHanded)
            .putBoolean("justify", readingPrefs.justify)
            .putBoolean("indent", readingPrefs.indent)
            .apply()
        when (readingPrefs.orientation) {
            "portrait" -> activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            "landscape" -> activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            else -> activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    val highlights by highlightDao.observeByBook(item.id).collectAsState(initial = emptyList())
    var editingHighlight by remember { mutableStateOf<Highlight?>(null) }

    // Al abrir: muestra opciones un momento y luego solo el texto
    LaunchedEffect(item.id) {
        showChrome = true
        kotlinx.coroutines.delay(2200)
        if (!showSettings && !showContents && !showHighlights) showChrome = false
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Ink)
            .systemBarsPadding()
    ) {
        // ── Solo el texto del libro ───────────────────────────────────────────
        Box(Modifier.fillMaxSize()) {
            val progressCb: (Long, Int) -> Unit = { pos, pct ->
                livePos = pos
                liveProgress = pct.coerceIn(0, 100)
                onSave(pos, pct)
            }
            val immersivePrefs = readingPrefs.copy(showNavButtons = showChrome && readingPrefs.showNavButtons)
            when (item.format.lowercase()) {
                "epub" -> EpubReader(
                    item, progressCb, highlightDao, onUpdateItem, immersivePrefs, { readingPrefs = it },
                    showContents = showContents,
                    onContentsDismiss = { showContents = false },
                    onChapterLabel = { liveChapterLabel = it },
                    onToggleChrome = { showChrome = !showChrome },
                    jumpChapter = jumpChapter,
                    onJumpConsumed = { jumpChapter = null; jumpOffset = -1; jumpText = null },
                    jumpOffset = jumpOffset,
                    jumpText = jumpText,
                    jumpTextK = jumpTextK,
                    initialOffset = savedOffset,
                    onOffsetSave = { spine, off ->
                        sp.edit().putString("pg_${item.id}", "$spine|$off").apply()
                    },
                    bookmarkOffsets = bookmarks.filter { it.off >= 0 }.map { it.pos.toInt() to it.off },
                    bookmarkRequest = bookmarkRequest,
                    onBookmarkToggle = { spine, off, pct, label, existing ->
                        if (existing >= 0) {
                            bookmarks.removeAll { it.pos == spine.toLong() && it.off == existing }
                        } else if (off >= 0) {
                            bookmarks.add(0, newReaderBookmark(spine.toLong(), off, pct, label))
                        }
                        saveReaderBookmarks(sp, item.id, bookmarks)
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    },
                    ribbonEnabled = item.bookmarkStyle != "NONE",
                    onChapterNames = { chapterNames = it },
                    onPageBookmarked = { pageBookmarked = it }
                )
                "pdf"  -> PdfReader(item, progressCb, item.readingMode, highlightDao, onUpdateItem)
                "txt"  -> TextFileReader(item, progressCb, fb2 = false, highlightDao, onUpdateItem, immersivePrefs)
                "fb2"  -> TextFileReader(item, progressCb, fb2 = true,  highlightDao, onUpdateItem, immersivePrefs)
                "cbz"  -> CbzReader(item, progressCb, item.readingMode)
                else   -> Message(
                    "Los archivos CBR (RAR) todavía no se pueden leer dentro de Libellum. " +
                    "Conviértelo a CBZ y vuelve a importarlo."
                )
            }
        }

        // Franja superior táctil cuando las opciones están ocultas (no interfiere con el texto)
        if (!showChrome) {
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .height(36.dp)
                    .clickable { showChrome = true }
            )
        }

        // ── Opciones: aparecen al tocar la franja superior o el centro del EPUB ─
        if (showChrome) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(Ink.copy(alpha = 0.94f))
                        .clickable { showChrome = false }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LibIconButton(LibIconKind.CLOSE, onClick = onClose, tint = Cream)
                    Text(
                        item.title, color = Cream, fontSize = 13.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f).padding(horizontal = 4.dp)
                    )
                    LibIconButton(LibIconKind.LIST, onClick = { showContents = true }, tint = Cream)
                    // Aquí flota el botón de anotaciones (arriba a la derecha)
                    Spacer(Modifier.width(48.dp))
                }
                Column(
                    Modifier
                        .fillMaxWidth()
                        .background(Ink.copy(alpha = 0.94f))
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    GoldProgressBar(liveProgress / 100f, height = 5.dp)
                    if (liveChapterLabel.isNotBlank()) {
                        Text(liveChapterLabel, color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 2.dp))
                    }
                }
                // Zona central: tocar para ocultar opciones y volver al texto
                Spacer(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .clickable(
                            interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                            indication = null
                        ) { showChrome = false }
                )
            }
        }

        // ── Paneles flotantes: ajustes (abajo derecha) y anotaciones (arriba derecha) ──
        ReaderFloatingPanels(
            item = item,
            prefs = readingPrefs,
            onPrefsChange = { readingPrefs = it },
            onUpdateItem = onUpdateItem,
            highlights = highlights,
            onEditHighlight = { editingHighlight = it },
            onDeleteHighlight = { h -> scope.launch { highlightDao.deleteById(h.id) } },
            bookmarks = bookmarks,
            pageBookmarked = pageBookmarked,
            onToggleBookmark = { bookmarkRequest++ },
            onDeleteBookmark = { b ->
                bookmarks.remove(b)
                saveReaderBookmarks(sp, item.id, bookmarks)
            },
            onJumpHighlight = { h ->
                jumpText = h.selectedText
                jumpTextK = sp.getInt("hlk_${h.id}", 0)
                jumpOffset = -1
                jumpChapter = h.chapterIndex
                showSettings = false; showHighlights = false
            },
            onJumpBookmark = { b ->
                jumpText = null
                jumpChapter = b.pos.toInt(); jumpOffset = b.off
                showSettings = false; showHighlights = false
            },
            chapters = chapterNames,
            currentChapter = livePos.toInt(),
            onGoChapter = { idx ->
                jumpText = null; jumpChapter = idx; jumpOffset = -1
                showSettings = false; showHighlights = false
            },
            onJumpChapter = { idx ->
                jumpText = null; jumpChapter = idx; jumpOffset = -1
                showSettings = false; showHighlights = false
            },
            canJump = isEpub,
            panel = when {
                showSettings -> ReaderPanel.SETTINGS
                showHighlights -> ReaderPanel.NOTES
                else -> ReaderPanel.NONE
            },
            onPanelChange = { p ->
                showSettings = p == ReaderPanel.SETTINGS
                showHighlights = p == ReaderPanel.NOTES
            },
            buttonsVisible = showChrome
        )

        // ── Separador de página: tarjeta con la portada ───────────────────────
        if (item.bookmarkStyle == "COVER") {
            BookmarkDivider(item)
        }
    }

    // Contenido / avance para formatos sin TOC propio (PDF, TXT, CBZ…)
    if (showContents && item.format.lowercase() != "epub") {
        ModalBottomSheet(
            onDismissRequest = { showContents = false },
            containerColor = Panel
        ) {
            Column(
                Modifier
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 24.dp)
            ) {
                Text("AVANCE", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(Modifier.height(10.dp))
                GoldProgressBar(liveProgress / 100f, height = 10.dp)
                Text(
                    "${liveProgress}% leído",
                    color = Cream, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp)
                )
                if (liveChapterLabel.isNotBlank()) {
                    Text(liveChapterLabel, color = Muted, fontSize = 12.sp)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "En EPUB verás aquí la lista de capítulos. En este formato el avance se guarda por posición de lectura.",
                    color = Muted, fontSize = 12.sp, lineHeight = 18.sp
                )
            }
        }
    }

    // ── Diálogo de edición de nota ────────────────────────────────────────────
    editingHighlight?.let { h ->
        HighlightEditDialog(
            highlight = h,
            onSave = { updated ->
                scope.launch { highlightDao.update(updated) }
                editingHighlight = null
            },
            onDismiss = { editingHighlight = null }
        )
    }
}

// (El panel de ajustes y el de anotaciones viven ahora en ReaderPanels.kt)

/** Imagen del libro a pantalla completa: pellizca para acercar, doble toque para ampliar/restablecer. */
@Composable
private fun ImageViewerDialog(bytes: ByteArray, onDismiss: () -> Unit) {
    val bmp = remember(bytes) {
        runCatching {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (bounds.outWidth / sample > 2400 || bounds.outHeight / sample > 2400) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        }.getOrNull()
    }
    if (bmp == null) {
        LaunchedEffect(bytes) { onDismiss() }
        return
    }
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.96f))
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(1f, 6f)
                        offset = if (scale <= 1f) Offset.Zero else offset + pan
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures(onDoubleTap = {
                        scale = if (scale > 1f) 1f else 2.5f
                        offset = Offset.Zero
                    })
                }
        ) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale, scaleY = scale,
                        translationX = offset.x, translationY = offset.y
                    )
            )
            Text(
                "✕",
                color = Color.White, fontSize = 22.sp,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .clickable(onClick = onDismiss)
                    .padding(18.dp)
            )
        }
    }
}
// ── Separador visual de página ─────────────────────────────────────────────────

/** Barra de lectura en dorado vivo: degradado ámbar → oro claro, extremos redondeados y animada. */
@Composable
fun GoldProgressBar(progress: Float, modifier: Modifier = Modifier, height: androidx.compose.ui.unit.Dp = 8.dp) {
    val shape = RoundedCornerShape(50)
    val p by androidx.compose.animation.core.animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = androidx.compose.animation.core.tween(350),
        label = "readProgress"
    )
    Box(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(shape)
            .background(GoldTrack)
    ) {
        if (p > 0f) {
            Box(
                Modifier
                    .fillMaxWidth(p.coerceAtLeast(0.02f))
                    .fillMaxHeight()
                    .clip(shape)
                    .background(
                        androidx.compose.ui.graphics.Brush.horizontalGradient(
                            listOf(GoldDeep, GoldBright, GoldLight)
                        )
                    )
            )
        }
    }
}

@Composable
fun BookmarkDivider(item: LibraryItem) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(48.dp)
            .background(Panel)
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BookCover(item, Modifier.size(width = 25.dp, height = 36.dp))
        Spacer(Modifier.width(10.dp))
        Text("Continuarás aquí", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.weight(1f))
        LibIcon(LibIconKind.BOOKMARK, tint = Gold, size = 20.dp, filled = true)
    }
}

/** Marcapáginas de tela: rectángulo rojo con muesca en V y un hilo dorado en el centro. */
@Composable
fun BookmarkRibbon(modifier: Modifier = Modifier) {
    Canvas(modifier.size(width = 26.dp, height = 78.dp)) {
        val w = size.width
        val h = size.height
        val path = Path().apply {
            moveTo(0f, 0f)
            lineTo(w, 0f)
            lineTo(w, h)
            lineTo(w / 2f, h - w * 0.6f)
            lineTo(0f, h)
            close()
        }
        drawPath(path, Color(0xFFB3322F))
        drawRect(Color(0x33FFFFFF), topLeft = Offset(w * 0.12f, 0f), size = Size(w * 0.14f, h - w * 0.7f))
        drawRect(Gold, topLeft = Offset(w * 0.46f, 0f), size = Size(w * 0.08f, h - w * 0.65f))
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// HELPERS COMUNES
// ══════════════════════════════════════════════════════════════════════════════

@Composable
private fun Message(text: String) {
    Box(Modifier.fillMaxSize().padding(28.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Cream, fontSize = 15.sp, lineHeight = 22.sp, textAlign = TextAlign.Center)
    }
}

/**
 * Detecta el deslizamiento horizontal acumulando el recorrido completo del dedo
 * (comparar solo el delta de cada evento casi nunca llega al umbral).
 */
@Composable
private fun Modifier.pageSwipe(onNext: () -> Unit, onPrev: () -> Unit): Modifier {
    val next by rememberUpdatedState(onNext)
    val prev by rememberUpdatedState(onPrev)
    return pointerInput(Unit) {
        var total = 0f
        detectHorizontalDragGestures(
            onDragStart = { total = 0f },
            onDragEnd = { if (total < -80f) next() else if (total > 80f) prev() },
            onDragCancel = { total = 0f }
        ) { _, amount -> total += amount }
    }
}

/** Cambio de página de los lectores no-EPUB: directo, sin animaciones (la hoja de libro es del lector EPUB). */
@Composable
private fun <T> PagedContent(
    state: T,
    goingForward: Boolean,
    pageTurnStyle: String = "slide",
    modifier: Modifier = Modifier,
    content: @Composable (T) -> Unit
) {
    Box(modifier) { content(state) }
}

// ══════════════════════════════════════════════════════════════════════════════
// EPUB — páginas reales: el capítulo se reparte en columnas del ancho de la pantalla
// y cada «hoja» es una columna (un solo WebView por capítulo, sin recargar).
// ══════════════════════════════════════════════════════════════════════════════

private const val EPUB_HOST = "libra.local"

/** Ajustes de lectura vigentes: se leen desde el hilo del WebView al servir cada capítulo. */
private class EpubTheme {
    @Volatile var prefs: ReadingPrefs = ReadingPrefs()
}

/** Preferencias de lectura en memoria (se aplican a EPUB/TXT) */
data class ReadingPrefs(
    val themeMode: Int = 2,       // 0 oscuro, 1 sepia, 2 blanco, 3 negro
    val fontSizeSp: Int = 18,
    val lineHeight: Float = 1.65f, // interlineado generoso como página de libro
    val marginDp: Int = 28,        // márgenes laterales amplios (captura de referencia)
    val brightness: Float = 1f,   // 0.3 .. 1.0
    val fontFamily: String = "serif",  // serif | sans | classic
    // Nuevas opciones inspiradas en el lector de referencia
    val pageTurnStyle: String = "slide", // slide | fade | curl | none | scroll
    val orientation: String = "auto",    // auto | portrait | landscape
    val showNavButtons: Boolean = false, // por defecto solo el número de página, como en la captura
    val leftHanded: Boolean = false,     // voltear con mano izquierda
    val justify: Boolean = true,         // texto justificado (si no, alineado a la izquierda)
    val indent: Boolean = true           // sangría en la primera línea de cada párrafo
)

private fun chapterUrl(path: String): String =
    Uri.Builder().scheme("https").authority(EPUB_HOST)
        .encodedPath("/" + Uri.encode(path, "/")).build().toString()

/** CSS de lectura (plantilla). Las hojas miden EXACTAMENTE el ancho de pantalla:
 *  columna = ancho - 2·margen y separación entre columnas = 2·margen. */
private const val EPUB_CSS = """
@font-face{font-family:'LibraLora';src:url('https://libra.local/__libra/lora.ttf') format('truetype');font-weight:400 700;font-style:normal}
@font-face{font-family:'LibraLora';src:url('https://libra.local/__libra/lora-italic.ttf') format('truetype');font-weight:400 700;font-style:italic}
html,body,div,span,p,h1,h2,h3,h4,h5,h6,td,th,blockquote,section,article,aside,header,footer,main,nav,figure,figcaption,pre,code,a,em,i,b,strong,small,cite,font{box-sizing:border-box!important;white-space:normal!important;word-wrap:break-word!important;overflow-wrap:break-word!important;word-break:normal!important;writing-mode:horizontal-tb!important;text-orientation:mixed!important;float:none!important;position:static!important;max-width:100%!important;orphans:2!important;widows:2!important;break-before:auto!important;break-after:auto!important;-webkit-column-break-before:auto!important;-webkit-column-break-after:auto!important;page-break-before:auto!important;page-break-after:auto!important}
html{width:100%!important;height:100%!important;margin:0!important;padding:0!important;overflow-x:auto!important;overflow-y:hidden!important;background:%%BG%%!important;scrollbar-width:none!important;-webkit-text-size-adjust:100%}
html::-webkit-scrollbar{display:none!important;width:0!important;height:0!important}
body{display:block!important;box-sizing:border-box!important;position:static!important;width:100%!important;max-width:none!important;height:100%!important;min-height:100%!important;margin:0!important;padding:%%PAD%%px!important;-webkit-column-width:calc(100% - %%PAD2%%px)!important;column-width:calc(100% - %%PAD2%%px)!important;-webkit-column-gap:%%PAD2%%px!important;column-gap:%%PAD2%%px!important;-webkit-column-fill:auto!important;column-fill:auto!important;column-rule:none!important;overflow:visible!important;background:%%BG%%!important;color:%%FG%%!important;font-size:%%FS%%px!important;line-height:%%LH%%!important;font-family:%%FF%%!important;text-align:%%ALIGN%%;-webkit-hyphens:auto;hyphens:auto;-webkit-text-size-adjust:100%}
p,div,section,article,blockquote,h1,h2,h3,h4,h5,h6{display:block!important;width:auto!important;max-width:100%!important}
p,div,span,li,td,th,h1,h2,h3,h4,h5,h6,blockquote,section,article,em,i,b,strong,small,cite,pre,font,a{color:inherit!important;font-size:inherit!important;line-height:inherit!important;font-family:inherit!important}
div,section,article,aside,header,footer,main,nav{height:auto!important;min-height:0!important;max-height:none!important}
h1{font-size:1.35em!important;font-weight:600!important;letter-spacing:.04em;text-align:center;margin:1.2em 0 .6em 0!important}
h2{font-size:1.2em!important;font-weight:600!important;text-align:center;margin:1em 0 .55em 0!important}
h3{font-size:1.1em!important;font-weight:600!important;text-align:center;margin:.9em 0 .5em 0!important}
h4,h5,h6{font-size:1.05em!important;text-align:center;margin:.7em 0 .4em 0!important}
small{font-size:.85em!important}
h1,h2,h3,h4,h5,h6{break-after:avoid!important;-webkit-column-break-after:avoid!important}
p{margin-top:0;margin-bottom:%%PGAP%%em;text-indent:%%INDENT%%}
h1+p,h2+p,h3+p,h4+p,h5+p,h6+p,hr+p,img+p,figure+p,svg+p{text-indent:0}
[data-libra-align]{text-align:%%ALIGN%%!important}
a{color:%%LINK%%!important}
pre,code{white-space:pre-wrap!important;word-break:break-word!important}
table{width:100%!important;table-layout:fixed!important;border-collapse:collapse!important}
ul,ol{padding-left:1.2em;margin:.4em 0}
img,video,picture,canvas{max-width:100%!important;max-height:var(--libra-imgh, %%IMGH%%)!important;object-fit:contain!important;visibility:visible!important;opacity:1!important;break-inside:avoid!important;-webkit-column-break-inside:avoid!important;page-break-inside:avoid!important}
img{display:block!important;margin:0 auto!important;height:auto!important;border:0!important;background:transparent!important}
img.libra-inline{display:inline-block!important;vertical-align:middle!important;max-height:1.6em!important;margin:0 .1em!important;width:auto!important}
svg{max-width:100%!important;break-inside:avoid!important;-webkit-column-break-inside:avoid!important}
svg.libra-page{display:block!important;width:100%!important;height:var(--libra-imgh, %%IMGH%%)!important;max-height:var(--libra-imgh, %%IMGH%%)!important;margin:0 auto!important}
figure{display:block!important;margin:.6em 0!important;break-inside:avoid!important;-webkit-column-break-inside:avoid!important}
figcaption{font-size:.85em!important;text-align:center!important}
*{-webkit-user-select:text!important;user-select:text!important}
span[style*="background-color"]{color:inherit!important}
"""

/** Solo el CSS: sirve para la carga inicial y para aplicar los ajustes EN VIVO sin recargar. */
private fun libraCss(prefs: ReadingPrefs): String {
    val (bg, fg, link) = when (prefs.themeMode) {
        0 -> Triple("#0B1426", "#F3E6C8", "#D4AF37") // oscuro Libellum
        1 -> Triple("#F4ECD8", "#3B2F1E", "#8A5A1F") // sepia
        3 -> Triple("#000000", "#E0E0E0", "#88AAFF") // negro
        else -> Triple("#FFFFFF", "#111111", "#1A5FB4") // blanco
    }
    val pad = prefs.marginDp.coerceIn(8, 48)
    val fs = prefs.fontSizeSp.coerceIn(12, 32)
    val lh = prefs.lineHeight.coerceIn(1.2f, 2.4f)
    val ff = when (prefs.fontFamily) {
        "sans" -> "sans-serif"
        "classic" -> "'LibraLora', 'Times New Roman', serif"   // Lora va incluida en assets/fonts
        else -> "serif"
    }
    return EPUB_CSS
        .replace("%%BG%%", bg)
        .replace("%%FG%%", fg)
        .replace("%%LINK%%", link)
        .replace("%%PAD2%%", (pad * 2).toString())
        .replace("%%PAD%%", pad.toString())
        .replace("%%FS%%", fs.toString())
        .replace("%%LH%%", lh.toString())
        .replace("%%FF%%", ff)
        .replace("%%ALIGN%%", if (prefs.justify) "justify" else "left")
        .replace("%%PGAP%%", if (prefs.indent) "0.2" else "0.85")
        .replace("%%INDENT%%", if (prefs.indent) "1.4em" else "0")
        .replace("%%IMGH%%", "calc(100% - " + (pad * 2) + "px - 6px)")
}

private fun styleFor(prefs: ReadingPrefs): String =
    "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no\">" +
    "<style id=\"libra-style\">" + libraCss(prefs) + "</style>"

private val IC = RegexOption.IGNORE_CASE
private val SCRIPT_SELF_REGEX = Regex("<script\\b[^>]*/\\s*>", IC)
private val SCRIPT_REGEX = Regex("<script\\b[\\s\\S]*?</script\\s*>", IC)
private val TITLE_SELF_REGEX = Regex("<title\\b[^>]*/\\s*>", IC)
private val TITLE_REGEX = Regex("<title\\b[\\s\\S]*?</title\\s*>", IC)
private val XML_PROLOG_REGEX = Regex("^\\s*<\\?xml[^>]*\\?>")
private val SELF_CLOSING_REGEX = Regex("<([a-zA-Z][a-zA-Z0-9:_-]*)(\\s[^<>]*?)?\\s*/>")
private val VOID_TAGS = setOf(
    "area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"
)

/**
 * Los capítulos EPUB son XHTML, pero el WebView los lee como HTML. En HTML una etiqueta como
 * <title/> o <div/> NO se cierra sola y se «traga» todo el capítulo (la página sale en blanco).
 * Aquí se quitan los scripts y el título, y se convierten las etiquetas autocerradas en pares.
 */
private fun fixHtml(raw: String): String {
    var s = raw.replace(XML_PROLOG_REGEX, "")
    s = SCRIPT_SELF_REGEX.replace(s, "")
    s = SCRIPT_REGEX.replace(s, "")
    s = TITLE_SELF_REGEX.replace(s, "")
    s = TITLE_REGEX.replace(s, "")
    s = SELF_CLOSING_REGEX.replace(s) { m ->
        val name = m.groupValues[1]
        if (name.lowercase() in VOID_TAGS) m.value else "<" + name + m.groupValues[2] + "></" + name + ">"
    }
    return s
}

/**
 * Inyecta CSS de lectura y reescribe rutas relativas de imágenes/CSS/fuentes
 * a URLs absolutas https://libra.local/... para que el WebView las pida
 * por shouldInterceptRequest y se vean correctamente (no espacios en blanco).
 */
private fun injectStyle(
    rawHtml: String,
    prefs: ReadingPrefs,
    chapterPath: String = "",
    pkg: EpubPackage? = null
): String {
    var html = fixHtml(rawHtml)
    if (pkg != null && chapterPath.isNotBlank()) {
        html = rewriteResourceUrls(html, chapterPath, pkg)
    }
    val style = styleFor(prefs)
    val index = html.indexOf("</head>", ignoreCase = true)
    return if (index >= 0) html.substring(0, index) + style + html.substring(index) else style + html
}

/** ¿Es una URL externa o especial que no debe reescribirse? */
private fun isExternalOrSpecial(href: String): Boolean {
    if (href.isEmpty()) return true
    val h = href.trim()
    return h.startsWith("#") ||
        h.startsWith("data:", ignoreCase = true) ||
        h.startsWith("javascript:", ignoreCase = true) ||
        h.startsWith("http://", ignoreCase = true) ||
        h.startsWith("https://", ignoreCase = true) ||
        h.startsWith("mailto:", ignoreCase = true) ||
        h.startsWith("blob:", ignoreCase = true)
}

/** Convierte src/href relativos de img, image, source, link, video, audio a https://libra.local/ruta */
private fun rewriteResourceUrls(html: String, chapterPath: String, pkg: EpubPackage): String {
    // Atributos entre comillas
    val attrPattern = Regex(
        """(?i)(\b(?:src|href|xlink:href|poster)\s*=\s*)(["'])([^"']+)\2"""
    )
    var out = attrPattern.replace(html) { m ->
        val prefix = m.groupValues[1]
        val quote = m.groupValues[2]
        val href = m.groupValues[3].trim()
        if (isExternalOrSpecial(href)) {
            m.value
        } else {
            val resolved = pkg.resolveRelative(chapterPath, href)
            val abs = "https://$EPUB_HOST/" + resolved.trimStart('/')
            "$prefix$quote$abs$quote"
        }
    }
    // Atributos sin comillas (algunos EPUB mal formados): src=ruta.jpg
    val unquoted = Regex(
        """(?i)(\b(?:src|href|xlink:href|poster)\s*=\s*)([^\s"'>=]+)"""
    )
    out = unquoted.replace(out) { m ->
        val prefix = m.groupValues[1]
        val href = m.groupValues[2].trim()
        if (isExternalOrSpecial(href) || href.startsWith("https://$EPUB_HOST")) {
            m.value
        } else {
            val resolved = pkg.resolveRelative(chapterPath, href)
            val abs = "https://$EPUB_HOST/" + resolved.trimStart('/')
            "$prefix\"$abs\""
        }
    }
    // url(...) en estilos inline del HTML
    out = rewriteCssUrls(out, chapterPath, pkg)
    return out
}

/** Reescribe url(...) relativas dentro de CSS o de bloques style= */
private fun rewriteCssUrls(css: String, basePath: String, pkg: EpubPackage): String {
    val urlPattern = Regex(
        """(?i)(url\s*\(\s*)(["']?)([^"')]+)\2(\s*\))"""
    )
    return urlPattern.replace(css) { m ->
        val prefix = m.groupValues[1]
        val quote = m.groupValues[2]
        val href = m.groupValues[3].trim()
        val suffix = m.groupValues[4]
        if (isExternalOrSpecial(href) || href.startsWith("https://$EPUB_HOST")) {
            m.value
        } else {
            val resolved = pkg.resolveRelative(basePath, href)
            val abs = "https://$EPUB_HOST/" + resolved.trimStart('/')
            "$prefix$quote$abs$quote$suffix"
        }
    }
}

/** Lee un TXT: UTF-8 si es válido; si no, Windows-1252/Latin-1 (típico de archivos viejos en español). */
internal fun readTextSmart(file: File): String {
    val bytes = file.readBytes()
    return try {
        Charsets.UTF_8.newDecoder()
            .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
            .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
            .decode(java.nio.ByteBuffer.wrap(bytes)).toString().removePrefix("\uFEFF")
    } catch (_: Exception) {
        String(bytes, charset("windows-1252"))
    }
}

internal fun themeBgColor(mode: Int): Int = when (mode) {
    0 -> 0xFF0B1426.toInt()
    1 -> 0xFFF4ECD8.toInt()
    3 -> 0xFF000000.toInt()
    else -> 0xFFFFFFFF.toInt()
}

private fun emptyResponse(status: Int, reason: String) =
    WebResourceResponse("text/plain", "utf-8", status, reason, emptyMap(),
        ByteArrayInputStream(ByteArray(0)))

private val bundledAssetCache = java.util.concurrent.ConcurrentHashMap<String, ByteArray>()

/** Fuentes que viajan dentro de la app (assets/fonts): https://libra.local/__libra/<nombre> */
private fun serveBundledAsset(ctx: android.content.Context, uri: Uri): WebResourceResponse {
    val name = uri.lastPathSegment ?: return emptyResponse(404, "Not found")
    if (name != "lora.ttf" && name != "lora-italic.ttf") return emptyResponse(404, "Not found")
    return try {
        val bytes = bundledAssetCache[name]
            ?: ctx.assets.open("fonts/$name").use { it.readBytes() }.also { bundledAssetCache[name] = it }
        val headers = mapOf(
            "Access-Control-Allow-Origin" to "*",
            "Cache-Control" to "max-age=86400",
            "Content-Length" to bytes.size.toString()
        )
        WebResourceResponse("font/ttf", null, 200, "OK", headers, ByteArrayInputStream(bytes))
    } catch (_: Exception) {
        emptyResponse(404, "Not found")
    }
}

private fun serveEpub(pkg: EpubPackage, theme: EpubTheme, uri: Uri): WebResourceResponse {
    if (uri.host != EPUB_HOST) return emptyResponse(403, "Blocked")
    return try {
        // path puede venir codificado (%20, etc.)
        val rawPath = uri.path?.removePrefix("/") ?: return emptyResponse(404, "Not found")
        val path = try {
            java.net.URLDecoder.decode(rawPath.replace("+", "%2B"), "UTF-8")
        } catch (_: Exception) {
            rawPath
        }
        val bytes = pkg.readBytes(path) ?: return emptyResponse(404, "Not found")
        val mime = pkg.mimeOf(path)
        if (mime.contains("html") || mime.contains("xhtml")) {
            val styled = injectStyle(
                String(bytes, Charsets.UTF_8),
                theme.prefs,
                chapterPath = path,
                pkg = pkg
            )
            WebResourceResponse(
                "text/html", "utf-8",
                ByteArrayInputStream(styled.toByteArray(Charsets.UTF_8))
            )
        } else if (mime.contains("css") || path.endsWith(".css", ignoreCase = true)) {
            // CSS del libro: reescribir url(...) relativas para que imágenes/fuentes carguen
            val cssText = String(bytes, Charsets.UTF_8)
            val rewritten = rewriteCssUrls(cssText, path, pkg)
            val headers = mapOf(
                "Access-Control-Allow-Origin" to "*",
                "Cache-Control" to "max-age=3600"
            )
            WebResourceResponse(
                "text/css", "utf-8", 200, "OK", headers,
                ByteArrayInputStream(rewritten.toByteArray(Charsets.UTF_8))
            )
        } else {
            // Imágenes, fuentes y resto: MIME correcto + cabeceras
            val headers = mapOf(
                "Access-Control-Allow-Origin" to "*",
                "Cache-Control" to "max-age=3600",
                "Content-Length" to bytes.size.toString()
            )
            // Algunos WebView fallan si encoding no es null en binarios
            WebResourceResponse(mime, null, 200, "OK", headers, ByteArrayInputStream(bytes))
        }
    } catch (_: Exception) {
        emptyResponse(404, "Not found")
    }
}

/** {"desplazamiento": hoja, …} que envía la página → mapa */
private fun parseBmPages(json: String): Map<Int, Int> = runCatching {
    val o = JSONObject(json)
    o.keys().asSequence()
        .mapNotNull { k -> k.toIntOrNull()?.let { it to o.optInt(k, -1) } }
        .filter { it.second >= 0 }
        .toMap()
}.getOrDefault(emptyMap())

@Composable
private fun EpubReader(
    item: LibraryItem,
    onSave: (Long, Int) -> Unit,
    highlightDao: HighlightDao,
    onUpdateItem: (LibraryItem) -> Unit,
    prefs: ReadingPrefs,
    onPrefsChange: (ReadingPrefs) -> Unit,
    showContents: Boolean = false,
    onContentsDismiss: () -> Unit = {},
    onChapterLabel: (String) -> Unit = {},
    onToggleChrome: () -> Unit = {},
    jumpChapter: Int? = null,
    onJumpConsumed: () -> Unit = {},
    jumpOffset: Int = -1,                                   // con jumpChapter: ir a ese texto exacto
    jumpText: String? = null,                               // con jumpChapter: ir a la hoja donde está este texto subrayado
    jumpTextK: Int = 0,                                     // …y cuál aparición del texto (0 = la primera)
    initialOffset: Int = -1,                                // texto exacto donde se dejó el libro
    onOffsetSave: (Int, Int) -> Unit = { _, _ -> },         // (capítulo, desplazamiento) para reabrir en la misma hoja
    bookmarkOffsets: List<Pair<Int, Int>> = emptyList(),    // marcadores: (capítulo, desplazamiento)
    bookmarkRequest: Int = 0,                               // +1 = guardar / quitar marcador en esta hoja
    onBookmarkToggle: (Int, Int, Int, String, Int) -> Unit = { _, _, _, _, _ -> }, // capítulo, texto, %, etiqueta, existente
    ribbonEnabled: Boolean = true,
    onChapterNames: (List<String>) -> Unit = {},
    onPageBookmarked: (Boolean) -> Unit = {}
) {
    val pkg = remember(item.id) { runCatching { EpubPackage(File(item.localPath)) }.getOrNull() }
    DisposableEffect(pkg) { onDispose { pkg?.close() } }
    if (pkg == null || pkg.spine.isEmpty()) {
        Message("No se pudo abrir este EPUB. Puede estar dañado o protegido con DRM.")
        return
    }

    val theme = remember { EpubTheme() }
    theme.prefs = prefs

    val highlightsFlow = remember(item.id) { highlightDao.observeByBook(item.id) }
    val allHighlights by highlightsFlow.collectAsState(initial = emptyList())

    var spineIndex by remember(item.id) {
        mutableIntStateOf(item.lastPosition.toInt().coerceIn(0, pkg.spine.lastIndex))
    }
    var subPage by remember { mutableIntStateOf(0) }          // hoja dentro del capítulo (0-based)
    var subPageCount by remember { mutableIntStateOf(1) }
    var startAtEnd by remember { mutableStateOf(false) }      // al retroceder de capítulo: ir a su última hoja
    var anchor by remember { mutableStateOf<String?>(null) }  // al abrir un enlace del índice
    // Texto exacto al que volver (al abrir el libro o al saltar a un marcador); se borra al pasar de hoja
    var restoreAt by remember(item.id) {
        mutableStateOf<Pair<Int, Int>?>(
            if (initialOffset >= 0) item.lastPosition.toInt().coerceIn(0, pkg.spine.lastIndex) to initialOffset else null
        )
    }
    var bmPages by remember { mutableStateOf<Map<Int, Int>>(emptyMap()) }   // marcador → hoja en este capítulo
    val bmJson = remember(bookmarkOffsets, spineIndex) {
        JSONArray().also { a -> bookmarkOffsets.filter { it.first == spineIndex }.forEach { a.put(it.second) } }.toString()
    }
    val pageBookmarked = bmPages.values.contains(subPage)
    val webViewRef = remember { mutableStateOf<WebView?>(null) }
    val scope = rememberCoroutineScope()

    // Nombres reales de capítulo: primero el índice del libro (nav/ncx); los que falten se leen
    // del primer encabezado del propio capítulo; si no hay nada, «Capítulo N».
    val chapterLabels = remember(pkg) {
        mutableStateListOf<String>().apply {
            addAll(pkg.spine.indices.map { i -> pkg.tocTitleFor(i) ?: "" })
        }
    }
    LaunchedEffect(pkg) {
        val missing = pkg.spine.indices.filter { chapterLabels[it].isBlank() }
        if (missing.isNotEmpty()) {
            val found = withContext(Dispatchers.IO) {
                missing.associateWith { i ->
                    runCatching { pkg.headingOf(pkg.spine[i]) }.getOrNull()
                        ?: pkg.spine[i].substringAfterLast('/').substringBeforeLast('.')
                            .let { n ->
                                val low = n.lowercase()
                                when {
                                    low.contains("cover") || low.contains("portada") -> "Portada"
                                    low.contains("title") || low.contains("titulo") -> "Portadilla"
                                    else -> null
                                }
                            }
                }
            }
            found.forEach { (i, t) -> if (!t.isNullOrBlank()) chapterLabels[i] = t }
        }
    }
    fun labelOf(i: Int): String = chapterLabels.getOrNull(i)?.takeIf { it.isNotBlank() } ?: "Capítulo ${i + 1}"
    LaunchedEffect(spineIndex, subPage, subPageCount, chapterLabels.getOrNull(spineIndex)) {
        val pct = ((spineIndex + (subPage + 1).toFloat() / subPageCount.coerceAtLeast(1))
            / pkg.spine.size.coerceAtLeast(1) * 100).toInt().coerceIn(0, 100)
        onChapterLabel("Cap. ${spineIndex + 1}/${pkg.spine.size} · ${labelOf(spineIndex)} · Hoja ${subPage + 1}/$subPageCount")
        onSave(spineIndex.toLong(), pct)
    }

    var dictWord by remember { mutableStateOf<String?>(null) }
    var pendingHighlight by remember { mutableStateOf<String?>(null) }
    var duplicateHighlight by remember { mutableStateOf<String?>(null) }  // texto ya subrayado
    var viewerBytes by remember { mutableStateOf<ByteArray?>(null) }   // imagen abierta a pantalla completa

    fun normHl(s: String) = s.replace(Regex("\\s+"), " ").trim()

    val hlCtx = LocalContext.current
    val hlPrefs = remember { hlCtx.getSharedPreferences("libra_reading_prefs", 0) }
    // Subrayados del capítulo actual, como JSON, para pintarlos dentro de la página.
    // «k» = cuál aparición del texto se subrayó (una palabra repetida se pinta donde la elegiste).
    val highlightsJson = remember(allHighlights, spineIndex) {
        val arr = JSONArray()
        allHighlights.filter { it.chapterIndex == spineIndex }.forEach { h ->
            arr.put(
                JSONObject()
                    .put("t", h.selectedText)
                    .put("c", String.format("#%06X", (h.colorArgb and 0xFFFFFFL).toInt()))
                    .put("k", hlPrefs.getInt("hlk_${h.id}", 0))
            )
        }
        arr.toString()
    }

    // Paso de hoja: ÚNICA animación = hoja de libro que se pliega (ver PageCurl.kt)
    val curl = remember { PageCurlState() }
    val dragPages = remember { IntArray(2) }     // [0] hoja de origen · [1] hoja de destino del arrastre
    var pendingText by remember { mutableStateOf<PendingTextJump?>(null) }

    fun goPage(p: Int) {
        val near = kotlin.math.abs(p - subPage) == 1
        val fwd = p > subPage
        subPage = p
        restoreAt = null
        val wv = webViewRef.value
        if (near && wv != null) {
            curl.turn(scope, wv, fwd) { wv.evaluateJavascript("libraUserGo($p, 'none');", null) }
        } else {
            curl.clear()
            wv?.evaluateJavascript("libraUserGo($p, 'none');", null)
        }
    }

    // Ir al texto exacto de un subrayado (reintenta si el capítulo aún se está paginando)
    fun jumpToPendingText() {
        val pt = pendingText ?: return
        val wv = webViewRef.value ?: return
        if (pt.chapter != spineIndex) return
        pt.tries++
        if (pt.tries > 8) { pendingText = null; return }
        val js = "libraGoText(" + JSONObject.quote(pt.text) + ", " + pt.k + ");"
        wv.evaluateJavascript(js) { r ->
            val pg = r?.trim()?.toIntOrNull()
            if (pg != null && pg >= 0) {
                subPage = pg
                if (pendingText === pt) pendingText = null
            }
        }
    }

    fun nextPage() {
        if (subPage < subPageCount - 1) {
            goPage(subPage + 1)
        } else if (spineIndex < pkg.spine.lastIndex) {
            curl.turn(scope, webViewRef.value, true, waitForPages = true) {
                startAtEnd = false
                anchor = null
                restoreAt = null
                spineIndex++
            }
        }
    }

    fun prevPage() {
        if (subPage > 0) {
            goPage(subPage - 1)
        } else if (spineIndex > 0) {
            curl.turn(scope, webViewRef.value, false, waitForPages = true) {
                startAtEnd = true
                anchor = null
                restoreAt = null
                spineIndex--
            }
        }
    }

    // Salto pedido desde Marcadores / Resaltados: abre ese capítulo desde su primera hoja
    LaunchedEffect(jumpChapter) {
        val target = jumpChapter
        if (target != null) {
            startAtEnd = false
            anchor = null
            val t = target.coerceIn(0, pkg.spine.lastIndex)
            val txtJump = jumpText?.takeIf { it.isNotBlank() }
            if (txtJump != null) {
                curl.clear()
                pendingText = PendingTextJump(t, txtJump, jumpTextK)
                restoreAt = null
                if (t == spineIndex) jumpToPendingText() else spineIndex = t
            } else if (t == spineIndex) {
                if (jumpOffset >= 0) {
                    webViewRef.value?.evaluateJavascript("libraGoOffset($jumpOffset);") { r ->
                        r?.trim()?.toIntOrNull()?.takeIf { it >= 0 }?.let { subPage = it }
                    }
                    restoreAt = null
                } else {
                    goPage(0)
                }
            } else {
                restoreAt = if (jumpOffset >= 0) t to jumpOffset else null
                spineIndex = t
            }
            onJumpConsumed()
        }
    }

    // Guardar el texto exacto de la hoja actual (con retardo: deja terminar la animación de la hoja)
    LaunchedEffect(spineIndex, subPage) {
        kotlinx.coroutines.delay(650)
        webViewRef.value?.evaluateJavascript("libraCharOffset();") { r ->
            val off = r?.trim()?.toIntOrNull() ?: -1
            if (off >= 0) onOffsetSave(spineIndex, off)
        }
    }

    // Marcador en la hoja actual: lo guarda o lo quita (la lista vive en ReaderScreen)
    LaunchedEffect(bookmarkRequest) {
        if (bookmarkRequest > 0) {
            val existing = bmPages.entries.firstOrNull { it.value == subPage }?.key ?: -1
            webViewRef.value?.evaluateJavascript("libraCharOffset();") { r ->
                val off = r?.trim()?.toIntOrNull() ?: -1
                val pct = ((spineIndex + (subPage + 1f) / subPageCount.coerceAtLeast(1))
                    / pkg.spine.size.coerceAtLeast(1) * 100).toInt().coerceIn(0, 100)
                if (existing >= 0 || off >= 0) {
                    onBookmarkToggle(
                        spineIndex, off, pct,
                        "Cap. ${spineIndex + 1}/${pkg.spine.size} · ${labelOf(spineIndex)} · Hoja ${subPage + 1}/$subPageCount",
                        existing
                    )
                }
            }
        }
    }
    LaunchedEffect(pageBookmarked) { onPageBookmarked(pageBookmarked) }
    LaunchedEffect(spineIndex) { bmPages = emptyMap() }
    LaunchedEffect(chapterLabels.toList()) {
        onChapterNames(pkg.spine.indices.map { labelOf(it) })
    }

    fun openLink(target: Int, id: String?) {
        if (target == spineIndex) {
            if (id != null) {
                webViewRef.value?.evaluateJavascript("libraGoAnchor(${JSONObject.quote(id)});", null)
            }
        } else {
            startAtEnd = false
            anchor = id
            restoreAt = null
            spineIndex = target
        }
    }

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            EpubWebView(
                pkg = pkg,
                theme = theme,
                index = spineIndex,
                prefs = prefs,
                highlightsJson = highlightsJson,
                startAtEnd = startAtEnd,
                anchor = anchor,
                bookmarksJson = bmJson,
                restoreOffset = restoreAt?.takeIf { it.first == spineIndex }?.second ?: -1,
                onBookmarkPages = { json -> bmPages = parseBmPages(json) },
                modifier = Modifier.fillMaxSize(),
                onDefine = { w -> dictWord = w },
                onHighlight = { t ->
                    val already = allHighlights.any {
                        it.chapterIndex == spineIndex && normHl(it.selectedText) == normHl(t)
                    }
                    if (already) duplicateHighlight = t else pendingHighlight = t
                },
                onUnhighlight = { t ->
                    val match = allHighlights.firstOrNull {
                        it.chapterIndex == spineIndex && normHl(it.selectedText) == normHl(t)
                    }
                    if (match != null) {
                        scope.launch {
                            highlightDao.deleteById(match.id)
                            // Quitar el span visual en la página
                            webViewRef.value?.evaluateJavascript(
                                "libraRemoveHighlight(" + JSONObject.quote(match.selectedText) + ");",
                                null
                            )
                        }
                    }
                },
                onWebViewReady = { wv -> webViewRef.value = wv },
                onMetrics = { total, page ->
                    subPageCount = total.coerceAtLeast(1)
                    subPage = page.coerceIn(0, subPageCount - 1)
                    startAtEnd = false
                    anchor = null
                    curl.pagesReady()
                    if (pendingText != null) jumpToPendingText()
                },
                onTurn = { forward -> if (forward) nextPage() else prevPage() },
                // La hoja sigue al dedo (solo dentro del capítulo; en los extremos el giro es el normal)
                onDragStart = { forward ->
                    val target = if (forward) subPage + 1 else subPage - 1
                    val wv = webViewRef.value
                    if (wv == null || target < 0 || target >= subPageCount) {
                        false
                    } else {
                        dragPages[0] = subPage
                        dragPages[1] = target
                        curl.beginDrag(
                            scope, wv, forward,
                            change = { wv.evaluateJavascript("libraUserGo($target, 'none');", null) },
                            undo = { wv.evaluateJavascript("libraUserGo(" + dragPages[0] + ", 'none');", null) },
                            commit = { subPage = dragPages[1]; restoreAt = null }
                        )
                    }
                },
                onDragMove = { pr -> curl.dragTo(pr) },
                onDragEnd = { complete -> curl.endDrag(complete) },
                onChapterLink = { target, id -> openLink(target, id) },
                onToggleChrome = onToggleChrome,
                onImage = { url ->
                    val u = Uri.parse(url)
                    val imgPath = u.path?.removePrefix("/")
                    if (u.host == EPUB_HOST && !imgPath.isNullOrBlank()) {
                        scope.launch {
                            val data = withContext(Dispatchers.IO) {
                                runCatching { pkg.readBytes(imgPath) }.getOrNull()
                            }
                            if (data != null) viewerBytes = data
                        }
                    }
                }
            )
            // Hoja de libro que se pliega al pasar de página
            PageCurlOverlay(curl, Modifier.fillMaxSize())
            // Listón rojo pegado al lateral izquierdo en la hoja marcada (mantén pulsado para quitarlo)
            PageRibbon(
                visible = pageBookmarked && ribbonEnabled && !curl.active,
                onLongPress = {
                    val existing = bmPages.entries.firstOrNull { it.value == subPage }?.key ?: -1
                    if (existing >= 0) onBookmarkToggle(spineIndex, existing, 0, "", existing)
                },
                modifier = Modifier.align(Alignment.TopStart)
            )
            // Veladura de brillo (no intercepta toques)
            if (prefs.brightness < 0.99f) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = (1f - prefs.brightness).coerceIn(0f, 0.65f)))
                )
            }
        }

        if (prefs.showNavButtons) {
            Row(
                Modifier.fillMaxWidth().background(Panel).padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (prefs.leftHanded) {
                    LibIconButton(LibIconKind.CHEVRON_RIGHT, onClick = { prevPage() }, tint = Gold)
                } else {
                    LibIconButton(LibIconKind.CHEVRON_LEFT, onClick = { prevPage() }, tint = Gold)
                }
                Text(
                    "Cap. ${spineIndex + 1}/${pkg.spine.size} · Hoja ${subPage + 1}/$subPageCount",
                    color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center
                )
                if (prefs.leftHanded) {
                    LibIconButton(LibIconKind.CHEVRON_LEFT, onClick = { nextPage() }, tint = Gold)
                } else {
                    LibIconButton(LibIconKind.CHEVRON_RIGHT, onClick = { nextPage() }, tint = Gold)
                }
                LibIconButton(
                    LibIconKind.THEME,
                    onClick = { onPrefsChange(prefs.copy(themeMode = (prefs.themeMode + 1) % 4)) },
                    tint = Gold
                )
            }
        }
    }

    // Panel de capítulos y avance
    if (showContents) {
        ModalBottomSheet(
            onDismissRequest = onContentsDismiss,
            containerColor = Panel
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 24.dp)
            ) {
                Text("CONTENIDO", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(Modifier.height(8.dp))
                Text("Avance del libro", color = Cream, fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                val pct = ((spineIndex + (subPage + 1).toFloat() / subPageCount.coerceAtLeast(1))
                    / pkg.spine.size.coerceAtLeast(1) * 100).toInt().coerceIn(0, 100)
                GoldProgressBar(pct / 100f, height = 10.dp)
                Text(
                    "$pct% · Cap. ${spineIndex + 1} de ${pkg.spine.size} · Hoja ${subPage + 1}/$subPageCount",
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)
                )
                Spacer(Modifier.height(14.dp))
                Text("CAPÍTULOS", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(Modifier.height(6.dp))
                LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    items(pkg.spine.size) { i ->
                        val selected = i == spineIndex
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    startAtEnd = false
                                    anchor = null
                                    restoreAt = null
                                    spineIndex = i
                                    onContentsDismiss()
                                }
                                .background(if (selected) Gold.copy(alpha = 0.15f) else Color.Transparent)
                                .padding(vertical = 10.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "${i + 1}.",
                                color = if (selected) Gold else Muted,
                                fontSize = 12.sp,
                                modifier = Modifier.width(28.dp)
                            )
                            Text(
                                labelOf(i),
                                color = if (selected) Cream else Cream.copy(alpha = 0.85f),
                                fontSize = 14.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            if (selected) {
                                Text("●", color = Gold, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    viewerBytes?.let { data ->
        ImageViewerDialog(bytes = data, onDismiss = { viewerBytes = null })
    }
    dictWord?.let { w ->
        DictionaryDialog(word = w, onDismiss = { dictWord = null })
    }
    pendingHighlight?.let { text ->
        HighlightColorPicker(
            selectedText = text,
            onConfirm = { colorArgb, note ->
                val newId = UUID.randomUUID().toString()
                val chapter = spineIndex
                val save = { k: Int ->
                    if (k >= 0) hlPrefs.edit().putInt("hlk_$newId", k).apply()
                    scope.launch {
                        highlightDao.insert(
                            Highlight(
                                id = newId,
                                bookId = item.id,
                                bookTitle = item.title,
                                chapterIndex = chapter,
                                chapterTitle = labelOf(chapter),
                                selectedText = text,
                                note = note,
                                colorArgb = colorArgb
                            )
                        )
                    }
                }
                // Se pinta AL INSTANTE en el sitio exacto de la selección; luego se guarda
                val hex = String.format("#%06X", (colorArgb and 0xFFFFFFL).toInt())
                val wv = webViewRef.value
                if (wv != null) {
                    wv.evaluateJavascript(
                        "libraPaintSelection(" + JSONObject.quote(hex) + "," + JSONObject.quote(text) + ");"
                    ) { r -> save(r?.trim()?.toIntOrNull() ?: -1) }
                } else {
                    save(-1)
                }
                pendingHighlight = null
            },
            onDismiss = { pendingHighlight = null }
        )
    }

    // Aviso minimalista: el texto seleccionado ya está subrayado
    duplicateHighlight?.let { text ->
        AlertDialog(
            onDismissRequest = { duplicateHighlight = null },
            containerColor = Panel,
            title = {
                Text("Ya subrayado", color = Cream, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            },
            text = {
                Text(
                    "Esta oración ya está subrayada. ¿Quieres subrayarla otra vez?",
                    color = Muted,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        duplicateHighlight = null
                        pendingHighlight = text  // abre el selector de color
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = Gold)
                ) { Text("Continuar") }
            },
            dismissButton = {
                TextButton(
                    onClick = { duplicateHighlight = null },
                    colors = ButtonDefaults.textButtonColors(contentColor = Muted)
                ) { Text("Cancelar") }
            }
        )
    }
}

private const val ID_DEFINE = 7001
private const val ID_HIGHLIGHT = 7002
private const val ID_UNHIGHLIGHT = 7003

/** Convierte el resultado de evaluateJavascript (un literal JSON) en texto normal. */
private fun decodeJsString(raw: String?): String {
    if (raw.isNullOrEmpty() || raw == "null") return ""
    return try {
        JSONArray("[$raw]").optString(0, "")
    } catch (_: Exception) {
        ""
    }
}

/**
 * WebView con menú de selección propio: «Copiar · Diccionario · Subrayar».
 * Así solo se abre UNA ventana a la vez y la barra nativa no se queda debajo.
 */
private class LibraWebView(context: Context) : WebView(context) {
    var onDefine: ((String) -> Unit)? = null
    var onHighlight: ((String) -> Unit)? = null
    var onUnhighlight: ((String) -> Unit)? = null

    override fun startActionMode(callback: ActionMode.Callback?): ActionMode? =
        super.startActionMode(wrap(callback))

    override fun startActionMode(callback: ActionMode.Callback?, type: Int): ActionMode? =
        super.startActionMode(wrap(callback), type)

    /** Deja «Copiar» y añade: Diccionario · Subrayar · Quitar subrayado. */
    private fun decorate(menu: Menu) {
        for (i in menu.size() - 1 downTo 0) {
            val id = menu.getItem(i).itemId
            if (id != android.R.id.copy && id != ID_DEFINE && id != ID_HIGHLIGHT && id != ID_UNHIGHLIGHT) {
                menu.removeItem(id)
            }
        }
        if (menu.findItem(ID_DEFINE) == null) menu.add(Menu.NONE, ID_DEFINE, 1, "Diccionario")
        if (menu.findItem(ID_HIGHLIGHT) == null) menu.add(Menu.NONE, ID_HIGHLIGHT, 2, "Subrayar")
        if (menu.findItem(ID_UNHIGHLIGHT) == null) menu.add(Menu.NONE, ID_UNHIGHLIGHT, 3, "Quitar subrayado")
    }

    private fun wrap(original: ActionMode.Callback?): ActionMode.Callback? {
        if (original == null) return null
        return object : ActionMode.Callback2() {
            override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
                original.onCreateActionMode(mode, menu)
                decorate(menu)
                return true
            }

            override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
                original.onPrepareActionMode(mode, menu)
                decorate(menu)
                return true
            }

            override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
                if (item.itemId == ID_DEFINE || item.itemId == ID_HIGHLIGHT || item.itemId == ID_UNHIGHLIGHT) {
                    val action = item.itemId
                    evaluateJavascript("window.getSelection().toString()") { raw ->
                        val sel = decodeJsString(raw).trim()
                        if (sel.isNotEmpty()) {
                            when (action) {
                                ID_DEFINE -> onDefine?.invoke(sel)
                                ID_HIGHLIGHT -> onHighlight?.invoke(sel)
                                ID_UNHIGHLIGHT -> onUnhighlight?.invoke(sel)
                            }
                        }
                        mode.finish()
                    }
                    return true
                }
                return original.onActionItemClicked(mode, item)
            }

            override fun onDestroyActionMode(mode: ActionMode) {
                original.onDestroyActionMode(mode)
            }

            override fun onGetContentRect(mode: ActionMode, view: View, outRect: Rect) {
                if (original is ActionMode.Callback2) {
                    original.onGetContentRect(mode, view, outRect)
                } else {
                    super.onGetContentRect(mode, view, outRect)
                }
            }
        }
    }
}

private class WebState {
    var key: String = ""            // capítulo cargado (URL)
    var styleKey: String = ""       // ajustes de lectura pedidos más recientes
    var loadedStyleKey: String = "" // ajustes con los que se sirvió/aplicó la página
    var loaded: Boolean = false
    var applied: String = ""
    var revealed: Boolean = true    // false mientras el capítulo carga: así no se ve la hoja equivocada
    var bm: String = ""             // marcadores ya enviados a la página (JSON)
}

/** Puente JS → Kotlin (los métodos se llaman desde un hilo del WebView: se vuelve al hilo principal). */
private class EpubBridge(
    private val metricsCb: (Int, Int) -> Unit,
    private val turnCb: (Boolean) -> Unit,
    private val chromeCb: () -> Unit = {},
    private val imageCb: (String) -> Unit = {},
    private val bookmarkPagesCb: (String) -> Unit = {}
) {
    private val main = Handler(Looper.getMainLooper())

    /** Hojas donde cae cada marcador del capítulo: {"desplazamiento": hoja, ...} */
    @JavascriptInterface
    fun onBookmarkPages(json: String) {
        main.post { bookmarkPagesCb(json) }
    }

    @JavascriptInterface
    fun onMetrics(total: Int, page: Int) {
        main.post { metricsCb(total, page) }
    }

    @JavascriptInterface
    fun onTurn(forward: Boolean) {
        main.post { turnCb(forward) }
    }

    @JavascriptInterface
    fun onToggleChrome() {
        main.post { chromeCb() }
    }

    @JavascriptInterface
    fun onImage(url: String) {
        main.post { imageCb(url) }
    }
}

// Funciones JS del lector: paginación por columnas, navegación, subrayados, imágenes, ajustes en vivo y toques.
// Modelo: body alto = 100vh; columna = ancho − 2·margen y separación = 2·margen → cada hoja mide justo el ancho de pantalla.
private const val EPUB_JS = """
(function () {
  if (window.__libraReady) return;
  window.__libraReady = true;
  window.__libraPage = 0;
  window.__libraDone = {};
  window.__libraEnd = false;

  function pageWidth() {
    var iw = window.innerWidth || document.documentElement.clientWidth || 1;
    return iw < 1 ? 1 : iw;
  }
  // Fuerza altura y ancho REALES del viewport en píxeles.
  // En WebView (sobre todo dentro de Compose) 100vh/100vw a veces resuelven mal
  // y el layout multi-columna solo muestra la primera línea y deja el resto en blanco.
  window.libraFitViewport = function () {
    try {
      var w = window.innerWidth || document.documentElement.clientWidth || 0;
      var h = window.innerHeight || document.documentElement.clientHeight || 0;
      if (w < 2 || h < 2) return false;
      var st = document.getElementById('libra-style');
      var pad = 28;
      try {
        if (st && st.textContent) {
          var m = st.textContent.match(/padding:\s*(\d+)px/);
          if (m) pad = parseInt(m[1], 10) || 28;
        }
      } catch (e0) {}
      var pad2 = pad * 2;
      var colW = Math.max(40, w - pad2);
      var imgH = Math.max(40, h - pad2 - 6);
      var html = document.documentElement;
      var body = document.body;
      if (!body) return false;
      html.style.setProperty('width', w + 'px', 'important');
      html.style.setProperty('height', h + 'px', 'important');
      body.style.setProperty('width', w + 'px', 'important');
      body.style.setProperty('height', h + 'px', 'important');
      body.style.setProperty('min-height', h + 'px', 'important');
      body.style.setProperty('max-height', h + 'px', 'important');
      body.style.setProperty('-webkit-column-width', colW + 'px', 'important');
      body.style.setProperty('column-width', colW + 'px', 'important');
      body.style.setProperty('-webkit-column-gap', pad2 + 'px', 'important');
      body.style.setProperty('column-gap', pad2 + 'px', 'important');
      body.style.setProperty('padding', pad + 'px', 'important');
      html.style.setProperty('--libra-imgh', imgH + 'px');
      body.style.setProperty('--libra-imgh', imgH + 'px');
      return true;
    } catch (e) { return false; }
  };
  function endMark() {
    var e = document.getElementById('libra-end');
    if (!e) {
      e = document.createElement('div');
      e.id = 'libra-end';
      e.style.cssText = 'height:0;width:0;margin:0;padding:0;border:0;overflow:hidden;';
      document.body.appendChild(e);
    }
    return e;
  }
  // ¿Este nodo tiene algo que se vea? (texto, imagen, svg, tabla, línea)
  function meaningful(n) {
    if (n.nodeType === 3) {
      if (!n.nodeValue || !n.nodeValue.trim().length) return false;
      var pe = n.parentNode;
      if (!pe || pe.ownerSVGElement) return false;
      var tn = pe.nodeName;
      return tn !== 'SCRIPT' && tn !== 'STYLE' && tn !== 'TITLE';
    }
    if (n.nodeType !== 1 || n.ownerSVGElement) return false;
    var nm = n.nodeName.toUpperCase();
    if (nm !== 'IMG' && nm !== 'SVG' && nm !== 'VIDEO' && nm !== 'CANVAS' && nm !== 'HR' && nm !== 'TABLE') return false;
    var r = n.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }
  // Columna (0-based) donde cae un nodo con contenido; first=true usa su primer trozo, si no el último
  function pageOfNode(n, first) {
    try {
      var rects;
      if (n.nodeType === 3) {
        var rg = document.createRange();
        rg.selectNodeContents(n);
        rects = rg.getClientRects();
      } else {
        rects = n.getClientRects();
      }
      if (!rects || !rects.length) return -1;
      var r = first ? rects[0] : rects[rects.length - 1];
      var cx = (r.left + r.right) / 2 + (window.pageXOffset || 0);
      return Math.max(0, Math.floor(cx / pageWidth()));
    } catch (e) { return -1; }
  }
  // Primera y última columna con contenido real: las columnas en blanco del principio o del
  // final (imagen que no cabe, párrafos vacíos, marca final) no cuentan como hojas.
  function contentRange() {
    var body = document.body;
    var first = 0, last = 0;
    try {
      var w = document.createTreeWalker(body, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, null);
      var n = w.nextNode();
      first = -1;
      while (n) {
        if (meaningful(n)) { var pf = pageOfNode(n, true); if (pf >= 0) { first = pf; break; } }
        n = w.nextNode();
      }
      if (first < 0) return [0, 0];
      w.currentNode = body;
      var deep = body;
      for (var c = w.lastChild(); c; c = w.lastChild()) deep = c;
      n = deep;
      last = first;
      while (n && n !== body) {
        if (meaningful(n)) { var pl = pageOfNode(n, false); if (pl >= 0) { last = Math.max(first, pl); break; } }
        n = w.previousNode();
      }
    } catch (e) { return [0, 0]; }
    return [first, last];
  }
  // El scroll de un contenedor multicolumna no cuenta el margen derecho de la última columna:
  // sin esto la última hoja se queda corrida un margen a la derecha y el texto sale cortado.
  function ensureScrollWidth(pagesEnd) {
    var s = document.getElementById('libra-pad');
    if (!s) {
      s = document.createElement('div');
      s.id = 'libra-pad';
      document.body.appendChild(s);
    }
    s.style.setProperty('position', 'absolute', 'important');
    s.style.setProperty('top', '0px', 'important');
    s.style.setProperty('left', Math.max(0, Math.round(pagesEnd * pageWidth()) - 1) + 'px', 'important');
    s.style.setProperty('width', '1px', 'important');
    s.style.setProperty('height', '1px', 'important');
    s.style.setProperty('margin', '0', 'important');
    s.style.setProperty('padding', '0', 'important');
    s.style.setProperty('border', '0', 'important');
    s.style.setProperty('visibility', 'hidden', 'important');
    s.style.setProperty('pointer-events', 'none', 'important');
  }
  // Hojas = columnas entre la primera y la última con contenido (cada hoja mide el ancho de pantalla)
  window.__libraFirst = 0;
  window.libraPages = function () {
    var rg = contentRange();
    window.__libraFirst = rg[0];
    var total = Math.max(1, rg[1] - rg[0] + 1);
    window.__libraTotal = total;
    ensureScrollWidth(rg[0] + total);
    return total;
  };
  window.libraGo = function (n) {
    window.__libraPage = n;
    window.scrollTo(Math.round(((window.__libraFirst || 0) + n) * pageWidth()), 0);
  };
  function pageOfX(absX, total) {
    var p = Math.floor((absX + 1) / pageWidth()) - (window.__libraFirst || 0);
    return Math.max(0, Math.min(total - 1, p));
  }
  function pageOfAnchor(anchor, total) {
    var el = document.getElementById(anchor) || document.getElementsByName(anchor)[0];
    var page = 0;
    if (el) {
      var r = el.getBoundingClientRect();
      page = pageOfX(r.left + (window.pageXOffset || 0), total);
    }
    return page;
  }

  // Quita márgenes enormes y saltos <br> repetidos del libro
  window.libraSanitize = function () {
    try {
      var limit = (window.innerHeight || 600) * 0.10;
      var body = document.body;
      var all = body ? body.getElementsByTagName('*') : [];
      var props = ['marginTop', 'marginBottom', 'paddingTop', 'paddingBottom'];
      var css = ['margin-top', 'margin-bottom', 'padding-top', 'padding-bottom'];
      for (var i = 0; i < all.length; i++) {
        var el = all[i];
        var cs = window.getComputedStyle(el);
        for (var k = 0; k < props.length; k++) {
          var v = parseFloat(cs[props[k]]);
          if (v > limit) el.style.setProperty(css[k], '0.6em', 'important');
        }
      }
      var brs = body ? body.getElementsByTagName('br') : [];
      for (var j = brs.length - 1; j >= 0; j--) {
        var b = brs[j];
        var prev = b.previousSibling;
        while (prev && prev.nodeType === 3 && !prev.nodeValue.trim()) prev = prev.previousSibling;
        var prev2 = prev && prev.previousSibling;
        while (prev2 && prev2.nodeType === 3 && !prev2.nodeValue.trim()) prev2 = prev2.previousSibling;
        if (prev && prev.nodeName === 'BR' && prev2 && prev2.nodeName === 'BR' && b.parentNode) {
          b.parentNode.removeChild(b);
        }
      }
    } catch (e) {}
  };

  // Marca los párrafos de texto normal: ahí manda tu elección (justificado/izquierda).
  // Los centrados/derecha del propio libro (epígrafes, firmas…) se respetan.
  window.libraTagAlign = function () {
    try {
      var els = document.querySelectorAll('p,li,blockquote');
      for (var i = 0; i < els.length; i++) {
        var ta = window.getComputedStyle(els[i]).textAlign;
        if (ta === 'left' || ta === 'start' || ta === 'justify' || ta === 'auto' || ta === '-webkit-auto') {
          els[i].setAttribute('data-libra-align', '');
        }
      }
    } catch (e) {}
  };

  function hasTextAround(im) {
    var p = im.parentNode;
    if (!p) return false;
    var n = p.firstChild;
    while (n) {
      if (n !== im) {
        if (n.nodeType === 3 && n.nodeValue.trim().length) return true;
        if (n.nodeType === 1 && ' SPAN EM I B STRONG A SUP SUB SMALL '.indexOf(' ' + n.nodeName + ' ') >= 0 &&
            n.textContent.trim().length) return true;
      }
      n = n.nextSibling;
    }
    return false;
  }
  var remeasureTimer = 0;
  function scheduleRemeasure() {
    if (remeasureTimer) clearTimeout(remeasureTimer);
    remeasureTimer = setTimeout(function () {
      remeasureTimer = 0;
      if (window.libraRemeasure) window.libraRemeasure();
    }, 50);
  }
  // Imágenes: las de línea (dentro de un párrafo con texto) quedan en la línea;
  // las demás son bloque centrado que cabe entera en la hoja. SVG de página completa (portadas).
  window.libraFixImages = function () {
    try {
      var imgs = document.getElementsByTagName('img');
      for (var i = 0; i < imgs.length; i++) {
        var im = imgs[i];
        if (!im.__libraW) {
          im.__libraW = true;
          if (!im.complete) {
            im.addEventListener('load', function () {
              this.style.removeProperty('display');
              scheduleRemeasure();
            });
            im.addEventListener('error', function () {
              // No ocultar de forma permanente: a veces el recurso llega un momento después
              // vía shouldInterceptRequest. Solo reducir opacidad y reintentar layout.
              this.style.setProperty('opacity', '0.15', 'important');
              scheduleRemeasure();
            });
          } else if (im.naturalWidth === 0 && im.complete) {
            // imagen rota de verdad
            im.style.setProperty('opacity', '0.15', 'important');
          } else {
            im.style.removeProperty('display');
            im.style.setProperty('opacity', '1', 'important');
          }
        }
        if (hasTextAround(im)) im.classList.add('libra-inline');
        else im.classList.remove('libra-inline');
      }
      var svgs = document.getElementsByTagName('svg');
      for (var s = 0; s < svgs.length; s++) {
        var sv = svgs[s];
        if (!sv.querySelector('image')) continue;
        var vb = sv.viewBox && sv.viewBox.baseVal;
        var hh = vb && vb.height ? vb.height : (parseFloat(sv.getAttribute('height')) || 0);
        if (hh >= 400 || (sv.getAttribute('height') || '').indexOf('%') > 0) sv.classList.add('libra-page');
      }
    } catch (e) {}
  };

  function firstVisibleRange() {
    try {
      var cs = window.getComputedStyle(document.body);
      var x = (parseFloat(cs.paddingLeft) || 0) + 6;
      var y = (parseFloat(cs.paddingTop) || 0) + 6;
      var r = document.caretRangeFromPoint(x, y);
      if (!r) return null;
      var n = r.startContainer, o = r.startOffset, rr = document.createRange();
      if (n.nodeType === 3 && n.nodeValue.length) {
        if (o >= n.nodeValue.length) o = n.nodeValue.length - 1;
        rr.setStart(n, o); rr.setEnd(n, o + 1);
        return rr;
      }
      if (n.nodeType === 1) { rr.selectNode(n); return rr; }
    } catch (e) {}
    return null;
  }

  window.libraInit = function (startAtEnd, anchor, restoreOff) {
    window.__libraAnchor = null;
    window.libraFitViewport();
    window.libraSanitize();
    window.libraTagAlign();
    window.libraFixImages();
    void document.body.offsetHeight;
    window.libraFitViewport();
    window.__libraEnd = !!startAtEnd;
    var total = window.libraPages();
    var page = 0;
    window.__libraRestoreOff = (typeof restoreOff === 'number' && restoreOff >= 0 && !anchor) ? restoreOff : -1;
    if (anchor) { page = pageOfAnchor(anchor, total); }
    else if (window.__libraRestoreOff >= 0) {
      var rp = offsetToPage(window.__libraRestoreOff, total);
      page = rp >= 0 ? rp : 0;
    }
    else if (startAtEnd) { page = Math.max(0, total - 1); }
    window.libraGo(page);
    if (typeof LibraAndroid !== 'undefined') LibraAndroid.onMetrics(total, page);
    window.libraReportBookmarks();
    setTimeout(window.libraFixImages, 300);
    setTimeout(window.libraFixImages, 1200);
  };
  window.libraRemeasure = function () {
    window.libraFitViewport();
    window.libraFixImages();
    void document.body.offsetHeight;
    window.libraFitViewport();
    var total = window.libraPages();
    var page = window.__libraEnd ? Math.max(0, total - 1) : Math.min(window.__libraPage || 0, total - 1);
    if (!window.__libraEnd && window.__libraRestoreOff >= 0) {
      // al abrir el libro: seguir el texto exacto donde lo dejaste aunque cambie el maquetado
      var rp2 = offsetToPage(window.__libraRestoreOff, total);
      if (rp2 >= 0) page = rp2;
    }
    window.libraGo(page);
    if (typeof LibraAndroid !== 'undefined') LibraAndroid.onMetrics(total, page);
    window.libraReportBookmarks();
  };
  // Cambio de ajustes EN VIVO: reemplaza el CSS sin recargar y se queda en el mismo texto
  window.libraSetStyle = function (css) {
    window.__libraCss = css;
    if (window.__libraRaf) return;
    window.__libraRaf = requestAnimationFrame(function () {
      window.__libraRaf = 0;
      var st = document.getElementById('libra-style');
      if (!st || window.__libraCss == null) return;
      window.__libraRestoreOff = -1;
      // el ancla se conserva mientras no pases de hoja (así varios ajustes seguidos no se desplazan)
      if (!window.__libraEnd && !window.__libraAnchor) window.__libraAnchor = firstVisibleRange();
      var range = window.__libraEnd ? null : window.__libraAnchor;
      st.textContent = window.__libraCss;
      window.__libraCss = null;
      window.libraFitViewport();
      void document.body.offsetHeight;
      window.libraFixImages();
      void document.body.offsetHeight;
      window.libraFitViewport();
      var total = window.libraPages();
      var page = window.__libraEnd ? Math.max(0, total - 1) : Math.min(window.__libraPage || 0, total - 1);
      if (range) {
        try {
          var rc = range.getClientRects();
          var rect = rc.length ? rc[0] : range.getBoundingClientRect();
          // el scroll actual sigue en la hoja vieja: se mide respecto al documento
          page = pageOfX(rect.left + (window.pageXOffset || 0), total);
        } catch (e) {}
      }
      window.libraGo(page);
      if (typeof LibraAndroid !== 'undefined') LibraAndroid.onMetrics(total, page);
      window.libraReportBookmarks();
      // si el cambio es de fuente (p. ej. «Clásica»), esperar a que cargue y recolocar en el mismo texto
      try {
        if (document.fonts && document.fonts.ready) {
          document.fonts.ready.then(function () {
            setTimeout(function () {
              if (window.__libraEnd || !window.__libraAnchor) return;
              window.libraFitViewport();
              var t2 = window.libraPages();
              var p2 = window.__libraPage || 0;
              try {
                var rc2 = window.__libraAnchor.getClientRects();
                var rect2 = rc2.length ? rc2[0] : window.__libraAnchor.getBoundingClientRect();
                p2 = pageOfX(rect2.left + (window.pageXOffset || 0), t2);
              } catch (e2) {}
              window.libraGo(p2);
              if (typeof LibraAndroid !== 'undefined') LibraAndroid.onMetrics(t2, p2);
              window.libraReportBookmarks();
            }, 40);
          });
        }
      } catch (e3) {}
    });
  };

  // ── Animación de paso de hoja: Cambio · Retirada · Superposición · Voluta ──
  // Solo se anima el paso que pide el lector (toque o deslizar). Todo lo demás (abrir, ajustes
  // en vivo, remedir) sigue siendo instantáneo. Cada animación termina SIEMPRE en la hoja exacta.
  window.__fxId = 0;
  function fxEl() {
    var e = document.getElementById('libra-fx');
    if (!e) {
      e = document.createElement('div');
      e.id = 'libra-fx';
      document.documentElement.appendChild(e);
    }
    return e;
  }
  function fxSet(e, css) {
    for (var k in css) { if (css.hasOwnProperty(k)) e.style.setProperty(k, css[k], 'important'); }
  }
  function fxClear() {
    var e = document.getElementById('libra-fx');
    if (e) fxSet(e, { 'display': 'none', 'opacity': '1', 'transition': 'none', 'background': 'none' });
  }
  function fxBase(e) {
    fxSet(e, { 'position': 'fixed', 'top': '0px', 'bottom': '0px', 'height': 'auto', 'margin': '0px',
      'padding': '0px', 'border': '0px', 'z-index': '2147483000', 'pointer-events': 'none',
      'display': 'block', 'transition': 'none', 'opacity': '1' });
  }
  function fxSlide(n, from, target, id, style) {
    var W = pageWidth();
    var fwd = target > from;
    var dur = style === 'curl' ? 380 : (style === 'scroll' ? 460 : 240);
    var sh = null;
    if (style === 'curl') {
      // sombra del canto de la hoja que se retira
      sh = fxEl();
      fxBase(sh);
      fxSet(sh, { 'width': '36px', 'left': '0px', 'right': 'auto',
        'background': 'linear-gradient(to right, rgba(0,0,0,0.30), rgba(0,0,0,0))' });
    }
    var t0 = null;
    function ease(t) {
      if (style === 'slide') return 1 - Math.pow(1 - t, 3);
      if (style === 'scroll') return 0.5 - Math.cos(Math.PI * t) / 2;
      return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
    }
    function step(ts) {
      if (id !== window.__fxId) return;
      if (t0 === null) t0 = ts;
      var t = Math.min(1, (ts - t0) / dur);
      var x = from + (target - from) * ease(t);
      window.scrollTo(Math.round(x), 0);
      if (sh) {
        var bx = fwd ? (from + W - x) : (from - x);
        fxSet(sh, { 'left': Math.round(bx) + 'px', 'opacity': String(Math.max(0, 1 - t * t)) });
      }
      if (t < 1) { requestAnimationFrame(step); }
      else { window.libraGo(n); fxClear(); }
    }
    requestAnimationFrame(step);
    // seguro: si el WebView no pinta frames, la hoja igualmente queda en su sitio
    setTimeout(function () { if (id === window.__fxId) { window.libraGo(n); fxClear(); } }, dur + 200);
  }
  function fxFade(n, id) {
    var e = fxEl();
    fxBase(e);
    var bg = '#000000';
    try { bg = window.getComputedStyle(document.body).backgroundColor || bg; } catch (x) {}
    fxSet(e, { 'left': '0px', 'right': '0px', 'width': 'auto', 'background': bg, 'opacity': '0' });
    void e.offsetHeight;
    fxSet(e, { 'transition': 'opacity 110ms ease-in', 'opacity': '1' });
    setTimeout(function () {
      if (id !== window.__fxId) return;
      window.libraGo(n);
      fxSet(e, { 'transition': 'opacity 170ms ease-out', 'opacity': '0' });
      setTimeout(function () { if (id === window.__fxId) fxClear(); }, 200);
    }, 120);
  }
  window.libraUserGo = function (n, style) {
    window.__libraEnd = false;
    window.__libraAnchor = null;
    window.__libraRestoreOff = -1;
    var id = ++window.__fxId;
    fxClear();
    var from = window.pageXOffset || 0;
    var W = pageWidth();
    var target = Math.round(((window.__libraFirst || 0) + n) * W);
    window.__libraPage = n;
    var dist = Math.abs(target - from);
    if (!style || style === 'none' || dist < 2 || dist > W * 1.6) { window.libraGo(n); return; }
    try {
      if (style === 'fade') fxFade(n, id); else fxSlide(n, from, target, id, style);
    } catch (err) { window.libraGo(n); fxClear(); }
  };
  window.libraGoAnchor = function (anchor) {
    window.__libraEnd = false;
    window.__libraAnchor = null;
    window.__libraRestoreOff = -1;
    var total = window.libraPages();
    var page = pageOfAnchor(anchor, total);
    window.libraGo(page);
    if (typeof LibraAndroid !== 'undefined') LibraAndroid.onMetrics(total, page);
  };

  // ── Posición exacta por texto: sobrevive a cambios de tamaño, fuente o márgenes ──
  function textWalker() { return document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null); }
  function offsetToPage(off, total) {
    try {
      var w = textWalker(), n, count = 0;
      while ((n = w.nextNode())) {
        var len = n.nodeValue.length;
        if (off < count + len) {
          var r = document.createRange();
          var i = off - count;
          r.setStart(n, i);
          r.setEnd(n, Math.min(len, i + 1));
          var rc = r.getClientRects();
          var rect = rc.length ? rc[0] : r.getBoundingClientRect();
          if (rect.width > 0 || rect.height > 0) return pageOfX(rect.left + (window.pageXOffset || 0), total);
          off = count + len;
        }
        count += len;
      }
    } catch (e) {}
    return -1;
  }
  // Desplazamiento (en caracteres) del primer texto visible de la hoja actual
  window.libraCharOffset = function () {
    try {
      var cs = window.getComputedStyle(document.body);
      var px = (parseFloat(cs.paddingLeft) || 0) + 6;
      var py = (parseFloat(cs.paddingTop) || 0) + 6;
      var dys = [0, 24, 48, 80, 120, 180];
      for (var a = 0; a < dys.length; a++) {
        var r = document.caretRangeFromPoint(px, py + dys[a]);
        if (r && r.startContainer && r.startContainer.nodeType === 3) {
          var w = textWalker(), n, count = 0;
          while ((n = w.nextNode())) {
            if (n === r.startContainer) return count + r.startOffset;
            count += n.nodeValue.length;
          }
        }
      }
    } catch (e) {}
    return -1;
  };
  // Ir a la hoja que contiene ese texto (devuelve la hoja, o -1)
  window.libraGoOffset = function (off) {
    window.__libraEnd = false;
    window.__libraAnchor = null;
    window.__libraRestoreOff = -1;
    var total = window.libraPages();
    var p = offsetToPage(off, total);
    if (p < 0) return -1;
    window.libraGo(p);
    return p;
  };
  // Posición (en caracteres) de un punto de un nodo de texto, con el mismo conteo que offsetToPage
  function textOffsetOf(node, inner) {
    try {
      if (!node || node.nodeType !== 3) return -1;
      var w = textWalker(), n, count = 0;
      while ((n = w.nextNode())) {
        if (n === node) return count + inner;
        count += n.nodeValue.length;
      }
    } catch (e) {}
    return -1;
  }
  // Ir al subrayado exacto: busca el texto (la k-ésima aparición) y abre la hoja donde está.
  // Se ancla al texto (no al número de hoja): si luego cambia el maquetado, sigue en su sitio.
  window.libraGoText = function (text, k) {
    try {
      window.__libraEnd = false;
      window.__libraAnchor = null;
      window.__libraRestoreOff = -1;
      var total = window.libraPages();
      var parts = ('' + text).split(/\n+/);
      var first = '';
      for (var q = 0; q < parts.length; q++) {
        var s0 = parts[q].replace(/\s+/g, ' ').trim();
        if (s0.length >= 2) { first = s0; break; }
      }
      if (!first) return -1;
      var rect = null;
      var off = -1;
      var sel = window.getSelection();
      sel.removeAllRanges();
      var ok = false;
      for (var j = 0; j <= (k || 0); j++) {
        ok = window.find(first, false, false, true, false, false, false);
        if (!ok) break;
      }
      if (ok && sel.rangeCount > 0) {
        var rg = sel.getRangeAt(0);
        var rcs = rg.getClientRects();
        rect = rcs.length ? rcs[0] : rg.getBoundingClientRect();
        off = textOffsetOf(rg.startContainer, rg.startOffset);
      }
      sel.removeAllRanges();
      if (!rect || (rect.width === 0 && rect.height === 0)) {
        rect = null;
        var spans = document.querySelectorAll('span.libra-hl');
        for (var i = 0; i < spans.length; i++) {
          var tt = (spans[i].textContent || '').replace(/\s+/g, ' ').trim();
          if (tt && (tt === first || first.indexOf(tt) === 0 || tt.indexOf(first) === 0)) {
            var rc = spans[i].getClientRects();
            if (rc.length) { rect = rc[0]; off = textOffsetOf(spans[i].firstChild, 0); break; }
          }
        }
      }
      if (!rect) return -1;
      var pg = pageOfX(rect.left + (window.pageXOffset || 0), total);
      window.libraGo(pg);
      if (off >= 0) window.__libraRestoreOff = off;
      return pg;
    } catch (e) { return -1; }
  };
  // Marcadores del capítulo: la página informa en qué hoja cae cada uno
  window.__libraBm = [];
  window.libraSetBookmarks = function (arr) {
    window.__libraBm = arr || [];
    window.libraReportBookmarks();
  };
  window.libraReportBookmarks = function () {
    try {
      var total = window.__libraTotal || 1;
      var out = {};
      (window.__libraBm || []).forEach(function (o) {
        var p = offsetToPage(o, total);
        if (p >= 0) out[o] = p;
      });
      if (typeof LibraAndroid !== 'undefined' && LibraAndroid.onBookmarkPages) {
        LibraAndroid.onBookmarkPages(JSON.stringify(out));
      }
    } catch (e) {}
  };
  // Subrayado EN VIVO y en el sitio exacto: se guarda la selección y se pinta al confirmar
  window.__libraSel = null;
  document.addEventListener('selectionchange', function () {
    try {
      var s = window.getSelection();
      if (s && s.rangeCount > 0 && !s.isCollapsed && ('' + s).trim().length > 0) {
        window.__libraSel = s.getRangeAt(0).cloneRange();
      }
    } catch (e) {}
  });
  window.libraPaintSelection = function (color, text) {
    try {
      var r = window.__libraSel;
      if (!r) return -1;
      var w = textWalker(), n, count = 0, full = '', startOff = -1;
      while ((n = w.nextNode())) {
        if (n === r.startContainer) startOff = count + r.startOffset;
        full += n.nodeValue;
        count += n.nodeValue.length;
      }
      var k = 0;
      if (startOff >= 0 && text) {
        var hay = full.slice(0, startOff).toLowerCase();
        var needle = ('' + text).toLowerCase();
        var idx = hay.indexOf(needle);
        while (idx >= 0) { k++; idx = hay.indexOf(needle, idx + 1); }
      }
      wrapRange(r, color);
      if (!window.__libraDone) window.__libraDone = {};
      window.__libraDone[text + '|' + color] = 1;
      var sel = window.getSelection();
      if (sel) sel.removeAllRanges();
      window.__libraSel = null;
      return k;
    } catch (e) { return -1; }
  };

  function wrapRange(range, color) {
    var root = range.commonAncestorContainer;
    var nodes = [];
    if (root.nodeType === 3) { nodes.push(root); }
    else {
      var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
      var n;
      while ((n = walker.nextNode())) {
        var tag = n.parentNode && n.parentNode.nodeName;
        if (tag === 'SCRIPT' || tag === 'STYLE') continue;
        if (range.intersectsNode(n)) nodes.push(n);
      }
    }
    nodes.forEach(function (node) {
      var start = (node === range.startContainer) ? range.startOffset : 0;
      var end = (node === range.endContainer) ? range.endOffset : node.nodeValue.length;
      if (end <= start) return;
      if (!node.nodeValue.slice(start, end).trim()) return;
      var mid = start > 0 ? node.splitText(start) : node;
      if (end - start < mid.nodeValue.length) mid.splitText(end - start);
      var span = document.createElement('span');
      span.className = 'libra-hl';
      span.style.backgroundColor = color;
      span.style.color = '#1b1b1b';
      mid.parentNode.replaceChild(span, mid);
      span.appendChild(mid);
    });
  }
  window.libraRemoveHighlight = function (text) {
    try {
      if (!text) return;
      var target = ('' + text).replace(/\s+/g, ' ').trim();
      var spans = document.querySelectorAll('span.libra-hl');
      for (var i = spans.length - 1; i >= 0; i--) {
        var sp = spans[i];
        var t = (sp.textContent || '').replace(/\s+/g, ' ').trim();
        if (t === target || target.indexOf(t) >= 0 || t.indexOf(target) >= 0) {
          var parent = sp.parentNode;
          while (sp.firstChild) parent.insertBefore(sp.firstChild, sp);
          parent.removeChild(sp);
          parent.normalize();
        }
      }
      // limpia clave en __libraDone para poder volver a subrayar
      if (window.__libraDone) {
        Object.keys(window.__libraDone).forEach(function (k) {
          if (k.indexOf(target) === 0 || target.indexOf(k.split('|')[0]) >= 0) {
            delete window.__libraDone[k];
          }
        });
      }
    } catch (e) {}
  };
  window.libraApply = function (items) {
    try {
      var sel = window.getSelection();
      items.forEach(function (it) {
        var key = it.t + '|' + it.c;
        if (window.__libraDone[key]) return;
        window.__libraDone[key] = 1;
        var parts = it.t.split(/\n+/);
        var kk = (parts.length === 1 && typeof it.k === 'number' && it.k > 0) ? it.k : 0;
        parts.forEach(function (part) {
          part = part.trim();
          if (part.length < 2) return;
          sel.removeAllRanges();
          var ok = false;
          // la n-ésima aparición: así una palabra repetida se pinta donde la subrayaste
          for (var j = 0; j <= kk; j++) {
            ok = window.find(part, false, false, true, false, false, false);
            if (!ok) break;
          }
          if (ok && sel.rangeCount > 0) wrapRange(sel.getRangeAt(0), it.c);
        });
        sel.removeAllRanges();
      });
      window.scrollTo(Math.round(((window.__libraFirst || 0) + (window.__libraPage || 0)) * pageWidth()), 0);
    } catch (e) {}
  };

  function imageSrc(t) {
    if (!t || !t.closest) return '';
    var im = t.closest('img');
    if (im && !im.classList.contains('libra-inline')) return im.currentSrc || im.src || '';
    var sv = t.closest('svg');
    if (sv) {
      var i = sv.querySelector('image');
      if (i) return i.getAttribute('href') || i.getAttribute('xlink:href') || '';
    }
    return '';
  }
  // Bordes: pasar hoja. Centro: tocar imagen = verla grande; si no, mostrar/ocultar opciones.
  document.addEventListener('click', function (e) {
    var t = e.target;
    if (t && t.closest && t.closest('a')) return;
    var s = window.getSelection ? window.getSelection().toString() : '';
    if (s && s.length > 0) return;
    var x = e.clientX / pageWidth();
    if (x > 0.68) LibraAndroid.onTurn(true);
    else if (x < 0.32) LibraAndroid.onTurn(false);
    else {
      var src = imageSrc(t);
      if (src && LibraAndroid.onImage) LibraAndroid.onImage(src);
      else if (LibraAndroid.onToggleChrome) LibraAndroid.onToggleChrome();
    }
  });
  var __libraResizeT = 0;
  window.addEventListener('resize', function () {
    clearTimeout(__libraResizeT);
    __libraResizeT = setTimeout(function () {
      if (window.libraRemeasure) window.libraRemeasure();
    }, 120);
  });
})();
"""

@Composable
private fun EpubWebView(
    pkg: EpubPackage,
    theme: EpubTheme,
    index: Int,
    prefs: ReadingPrefs,
    highlightsJson: String,
    startAtEnd: Boolean,
    anchor: String?,
    bookmarksJson: String = "[]",
    restoreOffset: Int = -1,
    onBookmarkPages: (String) -> Unit = {},
    modifier: Modifier = Modifier,
    onDefine: (String) -> Unit,
    onHighlight: (String) -> Unit,
    onUnhighlight: (String) -> Unit = {},
    onWebViewReady: (WebView) -> Unit,
    onMetrics: (Int, Int) -> Unit,
    onTurn: (Boolean) -> Unit,
    onChapterLink: (Int, String?) -> Unit,
    onToggleChrome: () -> Unit = {},
    onImage: (String) -> Unit = {},
    onDragStart: (Boolean) -> Boolean = { false },
    onDragMove: (Float) -> Unit = {},
    onDragEnd: (Boolean) -> Unit = {}
) {
    val dragStartCb by rememberUpdatedState(onDragStart)
    val dragMoveCb by rememberUpdatedState(onDragMove)
    val dragEndCb by rememberUpdatedState(onDragEnd)
    val imageCb by rememberUpdatedState(onImage)
    val prefsNow by rememberUpdatedState(prefs)
    val defineCb by rememberUpdatedState(onDefine)
    val highlightCb by rememberUpdatedState(onHighlight)
    val unhighlightCb by rememberUpdatedState(onUnhighlight)
    val metricsCb by rememberUpdatedState(onMetrics)
    val turnCb by rememberUpdatedState(onTurn)
    val linkCb by rememberUpdatedState(onChapterLink)
    val chromeCb by rememberUpdatedState(onToggleChrome)
    val hlNow by rememberUpdatedState(highlightsJson)
    val startNow by rememberUpdatedState(startAtEnd)
    val anchorNow by rememberUpdatedState(anchor)
    val bmNow by rememberUpdatedState(bookmarksJson)
    val restoreNow by rememberUpdatedState(restoreOffset)
    val bmPagesCb by rememberUpdatedState(onBookmarkPages)

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            LibraWebView(ctx).apply {
                val state = WebState()
                tag = state
                setBackgroundColor(themeBgColor(prefs.themeMode))
                settings.javaScriptEnabled = true      // los <script> del libro se eliminan al servirlo
                settings.allowFileAccess = false
                settings.allowContentAccess = false
                settings.domStorageEnabled = false
                settings.loadsImagesAutomatically = true
                settings.blockNetworkImage = false
                settings.blockNetworkLoads = false
                // Layout: texto a ancho de pantalla, sin zoom raro que deje una sola línea
                settings.useWideViewPort = false
                settings.loadWithOverviewMode = false
                settings.textZoom = 100
                settings.setSupportZoom(false)
                settings.builtInZoomControls = false
                settings.displayZoomControls = false
                settings.layoutAlgorithm = android.webkit.WebSettings.LayoutAlgorithm.NORMAL
                isVerticalScrollBarEnabled = false
                isHorizontalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
                // this.* porque los parámetros de la función se llaman igual que las propiedades del WebView
                this.onDefine = { text -> defineCb(text) }
                this.onHighlight = { text -> highlightCb(text) }
                this.onUnhighlight = { text -> unhighlightCb(text) }
                addJavascriptInterface(
                    EpubBridge(
                        { total, page ->
                            metricsCb(total, page)
                            val stNow = tag as? WebState
                            if (stNow != null && !stNow.revealed) {
                                stNow.revealed = true
                                animate().cancel()
                                // el capítulo nuevo aparece sin fundido: la hoja de libro lo cubre al pasar
                                alpha = 1f
                            }
                        },
                        { forward -> turnCb(forward) },
                        { chromeCb() },
                        { url -> imageCb(url) },
                        { json -> bmPagesCb(json) }
                    ),
                    "LibraAndroid"
                )

                // Deslizar el dedo también pasa de hoja
                val detector = GestureDetector(
                    ctx,
                    object : GestureDetector.SimpleOnGestureListener() {
                        override fun onFling(
                            e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float
                        ): Boolean {
                            val start = e1 ?: return false
                            val dx = e2.x - start.x
                            val dy = e2.y - start.y
                            if (abs(dx) > 120f && abs(dx) > abs(dy) * 1.4f && abs(velocityX) > 350f) {
                                turnCb(dx < 0)
                            }
                            return false
                        }
                    }
                )
                // Arrastrar horizontalmente: la hoja sigue al dedo. Mantener pulsado = seleccionar texto.
                val slop = android.view.ViewConfiguration.get(ctx).scaledTouchSlop.toFloat()
                val longPressMs = android.view.ViewConfiguration.getLongPressTimeout().toLong()
                var downX = 0f
                var downY = 0f
                var downAt = 0L
                var tracking = false
                var dragging = false
                var dragForward = true
                var lastT = 0f
                var tracker: android.view.VelocityTracker? = null
                setOnTouchListener { v, event ->
                    when (event.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            downX = event.x; downY = event.y; downAt = event.eventTime
                            tracking = true; dragging = false; lastT = 0f
                            tracker?.recycle()
                            tracker = android.view.VelocityTracker.obtain().also { it.addMovement(event) }
                            detector.onTouchEvent(event)
                            false
                        }
                        MotionEvent.ACTION_MOVE -> {
                            tracker?.addMovement(event)
                            if (dragging) {
                                val w = v.width.toFloat().coerceAtLeast(1f)
                                val dx = event.x - downX
                                lastT = (
                                    if (dragForward) -dx / kotlin.math.max(0.5f * w, downX + 0.04f * w)
                                    else dx / kotlin.math.max(0.5f * w, (w - downX) + 0.04f * w)
                                ).coerceIn(0f, 1f)
                                dragMoveCb(lastT)
                                true
                            } else {
                                if (tracking) {
                                    val dx = event.x - downX
                                    val dy = event.y - downY
                                    if (event.eventTime - downAt > longPressMs) {
                                        tracking = false
                                    } else if (abs(dx) > slop * 2f && abs(dx) > abs(dy) * 1.4f) {
                                        tracking = false
                                        dragForward = dx < 0
                                        if (dragStartCb(dragForward)) {
                                            dragging = true
                                            // el WebView deja de recibir este gesto (sin clic ni selección)
                                            val cancel = MotionEvent.obtain(event)
                                            cancel.action = MotionEvent.ACTION_CANCEL
                                            v.onTouchEvent(cancel)
                                            cancel.recycle()
                                        }
                                    }
                                }
                                if (dragging) true else { detector.onTouchEvent(event); false }
                            }
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                            tracker?.addMovement(event)
                            if (dragging) {
                                dragging = false
                                tracker?.computeCurrentVelocity(1000)
                                val vx = tracker?.xVelocity ?: 0f
                                val complete =
                                    if (event.actionMasked == MotionEvent.ACTION_CANCEL) false
                                    else if (dragForward) (lastT > 0.32f && vx < 400f) || vx < -900f
                                    else (lastT > 0.32f && vx > -400f) || vx > 900f
                                tracker?.recycle(); tracker = null
                                dragEndCb(complete)
                                true
                            } else {
                                tracking = false
                                tracker?.recycle(); tracker = null
                                detector.onTouchEvent(event)
                                false
                            }
                        }
                        else -> dragging
                    }
                }

                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(
                        view: WebView?, request: WebResourceRequest?
                    ): WebResourceResponse? {
                        val uri = request?.url ?: return null
                        if (uri.host == EPUB_HOST && uri.path?.startsWith("/__libra/") == true) {
                            return serveBundledAsset(ctx, uri)
                        }
                        return serveEpub(pkg, theme, uri)
                    }

                    override fun shouldOverrideUrlLoading(
                        view: WebView?, request: WebResourceRequest?
                    ): Boolean {
                        val uri = request?.url ?: return true
                        if (uri.host != EPUB_HOST) return true      // nada sale a internet desde el libro
                        val path = uri.path?.removePrefix("/")
                        val target = if (path != null) pkg.spine.indexOf(path) else -1
                        if (target >= 0) {
                            linkCb(target, uri.fragment)            // lo gestiona el lector (índice, notas…)
                            return true
                        }
                        return false
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        val wv = view ?: return
                        val st = wv.tag as? WebState ?: return
                        st.loaded = true
                        st.applied = hlNow
                        st.bm = bmNow
                        val anchorJs = anchorNow?.let { JSONObject.quote(it) } ?: "null"
                        wv.evaluateJavascript(EPUB_JS, null)
                        // Si los ajustes cambiaron mientras cargaba el capítulo, se aplican ahora
                        var pendingStyle = ""
                        if (st.styleKey != st.loadedStyleKey) {
                            st.loadedStyleKey = st.styleKey
                            pendingStyle = "libraSetStyle(" + JSONObject.quote(libraCss(prefsNow)) + ");"
                        }
                        wv.evaluateJavascript(
                            // Fit inmediato + init; remeasure a 300/900/2000 ms por si el WebView
                            // aún no tiene tamaño real en el primer frame (Compose).
                            "if(window.libraFitViewport)libraFitViewport();" +
                            "setTimeout(function(){libraInit(" + startNow + "," + anchorJs + "," + restoreNow + ");" +
                                "libraApply(" + hlNow + ");libraSetBookmarks(" + bmNow + ");" + pendingStyle + "},120);" +
                                "setTimeout(function(){libraRemeasure();},300);" +
                                "setTimeout(function(){libraRemeasure();},900);" +
                                "setTimeout(function(){libraRemeasure();},2000);",
                            null
                        )
                    }
                }
            }
        },
        update = { wv ->
            val st = wv.tag as WebState
            wv.setBackgroundColor(themeBgColor(prefs.themeMode))
            onWebViewReady(wv)
            val url = chapterUrl(pkg.spine[index])
            val styleKey = "${prefs.themeMode}|${prefs.fontSizeSp}|${prefs.marginDp}|${prefs.lineHeight}|${prefs.fontFamily}|${prefs.justify}|${prefs.indent}"
            if (st.key != url) {
                // Capítulo nuevo: se carga con los ajustes vigentes
                st.key = url
                st.styleKey = styleKey
                st.loadedStyleKey = styleKey
                st.loaded = false
                st.applied = ""
                // Se oculta la hoja vieja hasta que el capítulo nuevo esté colocado en su sitio
                // (al retroceder, en su última hoja); si algo falla se muestra igualmente a los 900 ms.
                st.revealed = false
                wv.alpha = 0f
                wv.postDelayed({
                    val cur = wv.tag as? WebState
                    if (cur != null && !cur.revealed) { cur.revealed = true; wv.alpha = 1f }
                }, 900)
                wv.loadUrl(url)
            } else if (st.styleKey != styleKey) {
                // Cambio de ajustes: EN VIVO, sin recargar y sin perder el lugar de lectura
                st.styleKey = styleKey
                if (st.loaded) {
                    st.loadedStyleKey = styleKey
                    wv.evaluateJavascript("libraSetStyle(" + JSONObject.quote(libraCss(prefs)) + ");", null)
                }
            } else if (st.loaded && st.applied != highlightsJson) {
                // Se acaba de crear un subrayado: se pinta sin recargar el capítulo
                st.applied = highlightsJson
                wv.evaluateJavascript("libraApply($highlightsJson);", null)
            }
            if (st.loaded && st.bm != bookmarksJson) {
                // Marcador nuevo o quitado: la hoja informa en cuál cae
                st.bm = bookmarksJson
                wv.evaluateJavascript("libraSetBookmarks($bookmarksJson);", null)
            }
        }
    )
}

// ══════════════════════════════════════════════════════════════════════════════
// PDF
// ══════════════════════════════════════════════════════════════════════════════

private class PdfHolder(file: File) {
    private val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(pfd)
    private val mutex = Mutex()
    val pageCount: Int = renderer.pageCount

    suspend fun render(index: Int, width: Int): Bitmap = mutex.withLock {
        withContext(Dispatchers.IO) {
            val page = renderer.openPage(index)
            try {
                val height = (width.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(android.graphics.Color.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                bmp
            } finally { page.close() }
        }
    }

    fun close() {
        runCatching { renderer.close() }
        runCatching { pfd.close() }
    }
}

@Composable
private fun PdfReader(
    item: LibraryItem,
    onSave: (Long, Int) -> Unit,
    readingMode: String,
    highlightDao: HighlightDao,
    onUpdateItem: (LibraryItem) -> Unit
) {
    val holder = remember(item.id) { runCatching { PdfHolder(File(item.localPath)) }.getOrNull() }
    DisposableEffect(holder) { onDispose { holder?.close() } }
    if (holder == null || holder.pageCount == 0) {
        Message("No se pudo abrir este PDF.")
        return
    }

    var index by remember(item.id) {
        mutableIntStateOf(item.lastPosition.toInt().coerceIn(0, holder.pageCount - 1))
    }
    var goingForward by remember { mutableStateOf(true) }
    LaunchedEffect(index) { onSave(index.toLong(), (index + 1) * 100 / holder.pageCount) }

    Column(Modifier.fillMaxSize()) {
        BoxWithConstraints(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .pageSwipe(
                    onNext = { if (index < holder.pageCount - 1) { goingForward = true; index++ } },
                    onPrev = { if (index > 0) { goingForward = false; index-- } }
                )
        ) {
            val widthPx = constraints.maxWidth.coerceAtLeast(1)
            PagedContent(state = index, goingForward = goingForward, modifier = Modifier.fillMaxSize()) { pg ->
                val bitmap by produceState<Bitmap?>(null, pg, widthPx) {
                    value = try { holder.render(pg, widthPx) } catch (_: Exception) { null }
                }
                bitmap?.let {
                    Image(
                        bitmap = it.asImageBitmap(),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                } ?: Box(Modifier.fillMaxSize().background(Panel))
            }
        }
        Row(
            Modifier.fillMaxWidth().background(Panel).padding(4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            LibIconButton(LibIconKind.CHEVRON_LEFT, onClick = { if (index > 0) { goingForward = false; index-- } }, tint = Gold)
            Text("${index + 1} / ${holder.pageCount}", color = Muted, fontSize = 12.sp)
            LibIconButton(LibIconKind.CHEVRON_RIGHT, onClick = { if (index < holder.pageCount - 1) { goingForward = true; index++ } }, tint = Gold)
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// TXT / FB2
// ══════════════════════════════════════════════════════════════════════════════

@Composable
private fun TextFileReader(
    item: LibraryItem,
    onSave: (Long, Int) -> Unit,
    fb2: Boolean,
    highlightDao: HighlightDao,
    onUpdateItem: (LibraryItem) -> Unit,
    prefs: ReadingPrefs = ReadingPrefs()
) {
    val loaded by produceState<List<String>?>(null, item.id) {
        value = withContext(Dispatchers.IO) {
            try {
                val file = File(item.localPath)
                if (fb2) Fb2Parser.parse(file).paragraphs
                else readTextSmart(file).split(Regex("\\r?\\n"))
            } catch (_: Exception) { emptyList() }
        }
    }
    when {
        loaded == null -> Message("Abriendo…")
        loaded!!.isEmpty() -> Message("No se pudo leer el contenido de este archivo.")
        else -> ParagraphList(loaded!!, item, onSave, highlightDao, prefs)
    }
}

@Composable
private fun ParagraphList(
    paragraphs: List<String>,
    item: LibraryItem,
    onSave: (Long, Int) -> Unit,
    highlightDao: HighlightDao,
    prefs: ReadingPrefs = ReadingPrefs()
) {
    val highlights by highlightDao.observeByBook(item.id).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var fontSize by remember(prefs.fontSizeSp) { mutableIntStateOf(prefs.fontSizeSp) }
    LaunchedEffect(prefs.fontSizeSp) { fontSize = prefs.fontSizeSp }
    val pageBg = when (prefs.themeMode) {
        0 -> Color(0xFF0B1426)
        1 -> Color(0xFFF4ECD8)
        3 -> Color(0xFF000000)
        else -> Color(0xFFFFFFFF)
    }
    val pageFg = when (prefs.themeMode) {
        0 -> Color(0xFFF3E6C8)
        1 -> Color(0xFF3B2F1E)
        3 -> Color(0xFFCCCCCC)
        else -> Color(0xFF111111)
    }

    var dictWord by remember { mutableStateOf<String?>(null) }
    var pendingText by remember { mutableStateOf<Pair<String, Int>?>(null) }

// Páginas adaptadas a pantalla: agrupa párrafos en "hojas".
    // Ajusta la cantidad de caracteres según tamaño de fuente, interlineado y márgenes
    // para que el contenido refluya y continúe en la siguiente página.
    val pages = remember(paragraphs, prefs.fontSizeSp, prefs.marginDp, prefs.lineHeight) {
        val marginFactor = (28.0 / prefs.marginDp.coerceIn(8, 40)).coerceIn(0.7, 1.4)
        val charsPerPage = (2000.0 * (18.0 / prefs.fontSizeSp) * (1.55 / prefs.lineHeight) * marginFactor)
            .toInt().coerceIn(600, 4500)
        val result = mutableListOf<List<Pair<Int, String>>>()
        var bucket = mutableListOf<Pair<Int, String>>()
        var count = 0
        paragraphs.forEachIndexed { i, p ->
            if (p.isBlank()) return@forEachIndexed
            bucket.add(i to p)
            count += p.length
            if (count >= charsPerPage) {
                result.add(bucket.toList())
                bucket = mutableListOf()
                count = 0
            }
        }
        if (bucket.isNotEmpty()) result.add(bucket.toList())
        if (result.isEmpty()) listOf(listOf(0 to "")) else result.toList()
    }
    var pageIndex by remember(item.id) {
        mutableIntStateOf(
            item.lastPosition.toInt().coerceIn(0, (pages.size - 1).coerceAtLeast(0))
        )
    }
    LaunchedEffect(pageIndex, pages.size) {
        if (pageIndex > pages.lastIndex) pageIndex = pages.lastIndex.coerceAtLeast(0)
        onSave(pageIndex.toLong(), ((pageIndex + 1) * 100 / pages.size.coerceAtLeast(1)))
    }
    var goingForward by remember { mutableStateOf(true) }

    val goNext = {
        if (pageIndex < pages.lastIndex) { goingForward = true; pageIndex++ }
    }
    val goPrev = {
        if (pageIndex > 0) { goingForward = false; pageIndex-- }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(pageBg)
            .graphicsLayer { alpha = prefs.brightness }
    ) {
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = prefs.marginDp.dp, vertical = 12.dp)
                .pageSwipe(
                    onNext = if (prefs.leftHanded) goPrev else goNext,
                    onPrev = if (prefs.leftHanded) goNext else goPrev
                )
        ) {
            PagedContent(
                state = pageIndex,
                goingForward = goingForward,
                pageTurnStyle = prefs.pageTurnStyle,
                modifier = Modifier.fillMaxSize()
            ) { pi ->
                val leaf = pages.getOrNull(pi).orEmpty()
                // Preferimos que cada hoja quepa sin scroll; si se desborda, permite scroll suave
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                    leaf.forEach { (i, p) ->
                        val match = highlights.firstOrNull { h ->
                            h.chapterIndex == i || p.contains(h.selectedText)
                        }
                        val bg = match?.let { Color(it.colorArgb).copy(alpha = 0.35f) }
                        // Títulos cortos / CAPÍTULOS centrados como en un libro impreso
                        val trimmed = p.trim()
                        val isHeading = trimmed.length in 2..48 && (
                            trimmed == trimmed.uppercase() ||
                            trimmed.startsWith("Capítulo", ignoreCase = true) ||
                            trimmed.startsWith("Chapter", ignoreCase = true) ||
                            trimmed.startsWith("Parte", ignoreCase = true) ||
                            Regex("^(CAP[IÍ]TULO|CHAPTER|PARTE)\\b", RegexOption.IGNORE_CASE).containsMatchIn(trimmed)
                        )
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .then(if (bg != null) Modifier.background(bg, RoundedCornerShape(6.dp)) else Modifier)
                                .padding(vertical = if (isHeading) 10.dp else 4.dp)
                        ) {
                            if (isHeading) {
                                Text(
                                    trimmed,
                                    color = pageFg,
                                    fontSize = (fontSize + 2).sp,
                                    fontWeight = FontWeight.SemiBold,
                                    fontFamily = when (prefs.fontFamily) {
                                        "sans" -> FontFamily.SansSerif
                                        else -> FontFamily.Serif
                                    },
                                    textAlign = TextAlign.Center,
                                    lineHeight = ((fontSize + 2) * prefs.lineHeight).sp,
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                                )
                            } else {
                                SelectableText(
                                    text = p,
                                    fontSize = fontSize,
                                    lineHeightMult = prefs.lineHeight,
                                    fontFamily = prefs.fontFamily,
                                    color = pageFg,
                                    onWordLongPress = { word -> dictWord = word },
                                    onTextSelected = { text -> pendingText = text to i }
                                )
                            }
                        }
                    }
                }
            }
        }
        // Pie de página limpio: «3 / 2009» centrado (como en la captura de referencia)
        if (prefs.showNavButtons) {
            Row(
                Modifier.fillMaxWidth().background(pageBg).padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                if (prefs.leftHanded) {
                    LibIconButton(LibIconKind.CHEVRON_RIGHT, onClick = goPrev, tint = pageFg.copy(alpha = 0.45f))
                    Text(
                        "${pageIndex + 1} / ${pages.size}",
                        color = pageFg.copy(alpha = 0.45f),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    LibIconButton(LibIconKind.CHEVRON_LEFT, onClick = goNext, tint = pageFg.copy(alpha = 0.45f))
                } else {
                    LibIconButton(LibIconKind.CHEVRON_LEFT, onClick = goPrev, tint = pageFg.copy(alpha = 0.45f))
                    Text(
                        "${pageIndex + 1} / ${pages.size}",
                        color = pageFg.copy(alpha = 0.45f),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    LibIconButton(LibIconKind.CHEVRON_RIGHT, onClick = goNext, tint = pageFg.copy(alpha = 0.45f))
                }
            }
        } else {
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(pageBg)
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "${pageIndex + 1} / ${pages.size}",
                    color = pageFg.copy(alpha = 0.4f),
                    fontSize = 12.sp
                )
            }
        }
    }

    dictWord?.let { DictionaryDialog(word = it, onDismiss = { dictWord = null }) }

    pendingText?.let { (text, parIdx) ->
        HighlightColorPicker(
            selectedText = text,
            onConfirm = { colorArgb, note ->
                scope.launch {
                    highlightDao.insert(
                        Highlight(
                            id = UUID.randomUUID().toString(),
                            bookId = item.id,
                            bookTitle = item.title,
                            chapterIndex = parIdx,
                            chapterTitle = "Párrafo ${parIdx + 1}",
                            selectedText = text,
                            note = note,
                            colorArgb = colorArgb
                        )
                    )
                }
                pendingText = null
            },
            onDismiss = { pendingText = null }
        )
    }
}

/** Texto seleccionable con callback al mantener pulsado */
@Composable
private fun SelectableText(
    text: String,
    fontSize: Int,
    lineHeightMult: Float = 1.55f,
    fontFamily: String = "serif",
    color: Color,
    onWordLongPress: (String) -> Unit,
    onTextSelected: (String) -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }
    var lastSelected by remember { mutableStateOf("") }
    var askWord by remember { mutableStateOf(false) }
    var wordInput by remember { mutableStateOf("") }

    Box(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .pointerInput(Unit) {
                detectTapGestures(
                    onLongPress = {
                        // En texto plano, abrimos el picker con todo el párrafo
                        lastSelected = text
                        showMenu = true
                    }
                )
            }
    ) {
        val classicFf = libraClassicFamily(LocalContext.current)
        val ff = when (fontFamily) {
            "sans" -> FontFamily.SansSerif
            "classic" -> classicFf
            else -> FontFamily.Serif
        }
        Text(
            text, color = color,
            fontSize = fontSize.sp,
            lineHeight = (fontSize * lineHeightMult).sp,
            fontFamily = ff
        )
    }

    if (showMenu) {
        AlertDialog(
            onDismissRequest = { showMenu = false },
            containerColor = Panel,
            title = { Text("Opciones de texto", color = Cream) },
            text = {
                Column {
                    TextButton(onClick = {
                        showMenu = false
                        wordInput = ""
                        askWord = true
                    }) {
                        LibIcon(LibIconKind.DICTIONARY, tint = Gold, size = 18.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("Buscar una palabra", color = Gold)
                    }
                    TextButton(onClick = {
                        showMenu = false
                        onTextSelected(text)
                    }) {
                        LibIcon(LibIconKind.NOTES, tint = Gold, size = 18.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("Subrayar párrafo", color = Gold)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showMenu = false }) { Text("Cancelar", color = Muted) }
            }
        )
    }

    if (askWord) {
        AlertDialog(
            onDismissRequest = { askWord = false },
            containerColor = Panel,
            title = { Text("¿Qué palabra buscas?", color = Cream) },
            text = {
                OutlinedTextField(
                    value = wordInput,
                    onValueChange = { wordInput = it },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Cream, unfocusedTextColor = Cream,
                        focusedBorderColor = Gold, unfocusedBorderColor = Muted
                    )
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    askWord = false
                    if (wordInput.isNotBlank()) onWordLongPress(wordInput.trim())
                }) { Text("Buscar", color = Gold) }
            },
            dismissButton = {
                TextButton(onClick = { askWord = false }) { Text("Cancelar", color = Muted) }
            }
        )
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// CBZ
// ══════════════════════════════════════════════════════════════════════════════

@Composable
private fun CbzReader(
    item: LibraryItem,
    onSave: (Long, Int) -> Unit,
    readingMode: String
) {
    val zip = remember(item.id) { runCatching { ZipFile(File(item.localPath)) }.getOrNull() }
    DisposableEffect(zip) { onDispose { runCatching { zip?.close() } } }
    if (zip == null) { Message("No se pudo abrir este CBZ."); return }

    val pages = remember(zip) {
        zip.entries().toList()
            .filter { !it.isDirectory && it.name.substringAfterLast('.').lowercase() in IMAGE_EXTENSIONS }
            .sortedBy { naturalKey(it.name) }
            .map { it.name }
    }
    if (pages.isEmpty()) { Message("Este CBZ no contiene imágenes."); return }

    var index by remember(item.id) {
        mutableIntStateOf(item.lastPosition.toInt().coerceIn(0, pages.lastIndex))
    }
    var goingForward by remember { mutableStateOf(true) }
    LaunchedEffect(index) { onSave(index.toLong(), (index + 1) * 100 / pages.size) }

    Column(Modifier.fillMaxSize()) {
        BoxWithConstraints(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .pageSwipe(
                    onNext = { if (index < pages.lastIndex) { goingForward = true; index++ } },
                    onPrev = { if (index > 0) { goingForward = false; index-- } }
                )
        ) {
            val widthPx = constraints.maxWidth.coerceAtLeast(1)
            PagedContent(state = index, goingForward = goingForward, modifier = Modifier.fillMaxSize()) { pg ->
                val bitmap by produceState<Bitmap?>(null, pages[pg], widthPx) {
                    value = withContext(Dispatchers.IO) {
                        try {
                            val entry = zip.getEntry(pages[pg])
                            val bytes = zip.getInputStream(entry).use { it.readBytes() }
                            decodeSampled(bytes, widthPx)
                        } catch (_: Exception) { null }
                    }
                }
                bitmap?.let {
                    Image(
                        bitmap = it.asImageBitmap(),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                } ?: Box(Modifier.fillMaxSize().background(Panel))
            }
        }
        Row(
            Modifier.fillMaxWidth().background(Panel).padding(4.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            LibIconButton(LibIconKind.CHEVRON_LEFT, onClick = { if (index > 0) { goingForward = false; index-- } }, tint = Gold)
            Text("${index + 1} / ${pages.size}", color = Muted, fontSize = 12.sp)
            LibIconButton(LibIconKind.CHEVRON_RIGHT, onClick = { if (index < pages.lastIndex) { goingForward = true; index++ } }, tint = Gold)
        }
    }
}

