package com.libra.reader

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Iconos propios de Libellum: trazo fino de puntas redondeadas sobre una rejilla de 24×24,
 * con un detalle en dorado. Se dibujan con Canvas (sin librerías de iconos).
 */
enum class LibIconKind {
    HOME, LIBRARY, NOTES, AUDIO, SETTINGS, SEARCH, STAR, TRASH, PLUS, SCAN,
    CHEVRON_LEFT, CHEVRON_RIGHT, CLOSE, TEXT_SIZE, THEME, BOOKMARK, LOCK, HELP,
    PLAY, PAUSE, REPLAY, FORWARD, GRID, LIST, SHELF, DICTIONARY
}

@Composable
fun LibIcon(
    kind: LibIconKind,
    modifier: Modifier = Modifier,
    tint: Color = Cream,
    size: Dp = 24.dp,
    filled: Boolean = false,
    accent: Color = Gold
) {
    Canvas(modifier.size(size)) { drawLibIcon(kind, tint, accent, filled) }
}

/** Botón de icono con zona táctil de 40 dp. */
@Composable
fun LibIconButton(
    kind: LibIconKind,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = Cream,
    iconSize: Dp = 22.dp,
    filled: Boolean = false
) {
    IconButton(onClick = onClick, modifier = modifier.size(40.dp)) {
        LibIcon(kind, tint = tint, size = iconSize, filled = filled)
    }
}

private fun DrawScope.drawLibIcon(kind: LibIconKind, c: Color, accent: Color, filled: Boolean) {
    val u = size.minDimension / 24f
    val line = Stroke(width = 1.8f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
    val thin = Stroke(width = 1.4f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
    val soft = c.copy(alpha = 0.22f)

    fun Path.m(x: Float, y: Float) = moveTo(x * u, y * u)
    fun Path.l(x: Float, y: Float) = lineTo(x * u, y * u)
    fun Path.rr(l: Float, t: Float, r: Float, b: Float, rad: Float) =
        addRoundRect(RoundRect(l * u, t * u, r * u, b * u, CornerRadius(rad * u, rad * u)))
    fun path(block: Path.() -> Unit): Path = Path().apply(block)
    fun seg(x1: Float, y1: Float, x2: Float, y2: Float, color: Color = c, w: Float = 1.8f) =
        drawLine(color, Offset(x1 * u, y1 * u), Offset(x2 * u, y2 * u), strokeWidth = w * u, cap = StrokeCap.Round)
    fun ring(cx: Float, cy: Float, r: Float, color: Color = c, w: Float = 1.8f) =
        drawCircle(color, radius = r * u, center = Offset(cx * u, cy * u), style = Stroke(width = w * u))
    fun dot(cx: Float, cy: Float, r: Float, color: Color = c) =
        drawCircle(color, radius = r * u, center = Offset(cx * u, cy * u))
    fun arrowHead(cx: Float, cy: Float, r: Float, endDeg: Float, dir: Float) {
        // punta de flecha al final de un arco: dir = +1 (horario) o -1 (antihorario)
        val a = endDeg * (PI / 180.0).toFloat()
        val ex = cx + r * cos(a)
        val ey = cy + r * sin(a)
        val tx = -sin(a) * dir
        val ty = cos(a) * dir
        val spread = 0.62f
        val len = 3.6f
        for (sgn in listOf(-1f, 1f)) {
            val cs = cos(spread * sgn)
            val sn = sin(spread * sgn)
            val bx = -(tx * cs - ty * sn)
            val by = -(tx * sn + ty * cs)
            seg(ex, ey, ex + bx * len, ey + by * len, w = 1.8f)
        }
    }

    when (kind) {
        LibIconKind.HOME -> {
            if (filled) drawPath(path { m(5.8f, 10f); l(12f, 5f); l(18.2f, 10f); l(18.2f, 19.2f); l(5.8f, 19.2f); close() }, soft)
            drawPath(path { m(3.2f, 11.2f); l(12f, 4f); l(20.8f, 11.2f) }, c, style = line)
            drawPath(path { m(5.8f, 9.6f); l(5.8f, 19.2f); l(18.2f, 19.2f); l(18.2f, 9.6f) }, c, style = line)
            drawPath(path { m(10f, 19.2f); l(10f, 14.4f); l(14f, 14.4f); l(14f, 19.2f) }, accent, style = line)
        }
        LibIconKind.LIBRARY -> {
            val b1 = path { rr(4f, 7f, 8.2f, 19.2f, 1f) }
            val b2 = path { rr(9.6f, 4.2f, 13.8f, 19.2f, 1f) }
            val b3 = path { m(15.6f, 9f); l(19.2f, 8f); l(21.6f, 17.4f); l(18f, 18.4f); close() }
            if (filled) { drawPath(b1, soft); drawPath(b2, soft); drawPath(b3, soft) }
            drawPath(b1, c, style = line)
            drawPath(b2, c, style = line)
            drawPath(b3, c, style = line)
            seg(9.6f, 8.6f, 13.8f, 8.6f, accent, 1.4f)
            seg(9.6f, 11.2f, 13.8f, 11.2f, accent, 1.4f)
            seg(3f, 21f, 21f, 21f)
        }
        LibIconKind.NOTES -> {
            val body = path { m(14.4f, 4.4f); l(19.6f, 9.6f); l(12f, 17.2f); l(6.8f, 12f); close() }
            val nib = path { m(6.8f, 12f); l(12f, 17.2f); l(4.8f, 18.8f); close() }
            if (filled) { drawPath(body, soft); drawPath(nib, soft) }
            drawPath(body, c, style = line)
            drawPath(nib, c, style = line)
            seg(10f, 21.2f, 20.4f, 21.2f, accent, 2.2f)
        }
        LibIconKind.AUDIO -> {
            val band = path {
                m(4.6f, 14f); l(4.6f, 12f)
                arcTo(Rect(4.6f * u, 4.6f * u, 19.4f * u, 19.4f * u), 180f, 180f, false)
                l(19.4f, 14f)
            }
            drawPath(band, c, style = line)
            val cupL = path { rr(3.4f, 13.2f, 7.2f, 19.8f, 1.7f) }
            val cupR = path { rr(16.8f, 13.2f, 20.6f, 19.8f, 1.7f) }
            if (filled) { drawPath(cupL, accent.copy(alpha = 0.55f)); drawPath(cupR, accent.copy(alpha = 0.55f)) }
            drawPath(cupL, c, style = line)
            drawPath(cupR, c, style = line)
        }
        LibIconKind.SETTINGS -> {
            seg(4f, 7f, 8.2f, 7f); ring(10.4f, 7f, 2.2f); seg(12.6f, 7f, 20f, 7f)
            seg(4f, 12f, 11.8f, 12f); ring(14f, 12f, 2.2f); seg(16.2f, 12f, 20f, 12f)
            seg(4f, 17f, 5.8f, 17f); ring(8f, 17f, 2.2f); seg(10.2f, 17f, 20f, 17f)
            if (filled) { dot(10.4f, 7f, 2.2f, accent); dot(14f, 12f, 2.2f, accent); dot(8f, 17f, 2.2f, accent) }
            else { dot(14f, 12f, 0.9f, accent) }
        }
        LibIconKind.SEARCH -> {
            ring(10.5f, 10.5f, 6.2f)
            seg(15.2f, 15.2f, 20.2f, 20.2f, accent, 2.2f)
        }
        LibIconKind.STAR -> {
            val star = path {
                for (i in 0 until 10) {
                    val ang = (-90.0 + i * 36.0) * PI / 180.0
                    val r = if (i % 2 == 0) 8.8f else 3.9f
                    val x = 12f + r * cos(ang).toFloat()
                    val y = 12.8f + r * sin(ang).toFloat()
                    if (i == 0) m(x, y) else l(x, y)
                }
                close()
            }
            if (filled) drawPath(star, accent)
            drawPath(star, if (filled) accent else c, style = line)
        }
        LibIconKind.TRASH -> {
            seg(5f, 7f, 19f, 7f)
            drawPath(path { m(9.5f, 7f); l(9.5f, 4.8f); l(14.5f, 4.8f); l(14.5f, 7f) }, c, style = line)
            drawPath(path { m(6.6f, 7f); l(7.6f, 19.6f); l(16.4f, 19.6f); l(17.4f, 7f) }, c, style = line)
            seg(10.6f, 10.6f, 10.6f, 16.2f, accent, 1.4f)
            seg(13.4f, 10.6f, 13.4f, 16.2f, accent, 1.4f)
        }
        LibIconKind.PLUS -> {
            seg(12f, 5f, 12f, 19f)
            seg(5f, 12f, 19f, 12f)
        }
        LibIconKind.SCAN -> {
            drawPath(path { m(3.5f, 8.5f); l(3.5f, 4.5f); l(7.5f, 4.5f) }, c, style = line)
            drawPath(path { m(16.5f, 4.5f); l(20.5f, 4.5f); l(20.5f, 8.5f) }, c, style = line)
            drawPath(path { m(3.5f, 15.5f); l(3.5f, 19.5f); l(7.5f, 19.5f) }, c, style = line)
            drawPath(path { m(16.5f, 19.5f); l(20.5f, 19.5f); l(20.5f, 15.5f) }, c, style = line)
            seg(6.8f, 12f, 17.2f, 12f, accent, 2f)
        }
        LibIconKind.CHEVRON_LEFT -> drawPath(path { m(14.5f, 5.5f); l(8f, 12f); l(14.5f, 18.5f) }, c, style = line)
        LibIconKind.CHEVRON_RIGHT -> drawPath(path { m(9.5f, 5.5f); l(16f, 12f); l(9.5f, 18.5f) }, c, style = line)
        LibIconKind.CLOSE -> {
            seg(6f, 6f, 18f, 18f)
            seg(18f, 6f, 6f, 18f)
        }
        LibIconKind.TEXT_SIZE -> {
            drawPath(path { m(2.8f, 19f); l(8f, 5.5f); l(13.2f, 19f) }, c, style = line)
            seg(4.7f, 14.4f, 11.3f, 14.4f)
            drawPath(path { m(14.8f, 19f); l(17.7f, 11.8f); l(20.6f, 19f) }, accent, style = thin)
            seg(15.9f, 16.6f, 19.5f, 16.6f, accent, 1.4f)
        }
        LibIconKind.THEME -> {
            ring(12f, 12f, 8f)
            drawPath(path {
                m(12f, 4f)
                arcTo(Rect(4f * u, 4f * u, 20f * u, 20f * u), -90f, 180f, false)
                close()
            }, c)
        }
        LibIconKind.BOOKMARK -> {
            val bm = path { m(7f, 4f); l(17f, 4f); l(17f, 20f); l(12f, 15.8f); l(7f, 20f); close() }
            if (filled) drawPath(bm, accent)
            drawPath(bm, if (filled) accent else c, style = line)
        }
        LibIconKind.LOCK -> {
            drawPath(path { rr(5.5f, 11f, 18.5f, 20.2f, 2.2f) }, c, style = line)
            drawPath(path {
                m(8.5f, 11f); l(8.5f, 8.4f)
                arcTo(Rect(8.5f * u, 4.9f * u, 15.5f * u, 11.9f * u), 180f, 180f, false)
                l(15.5f, 11f)
            }, c, style = line)
            dot(12f, 15.4f, 1.2f, accent)
        }
        LibIconKind.HELP -> {
            ring(12f, 12f, 9f)
            drawPath(path {
                m(9.3f, 9.8f)
                cubicTo(9.3f * u, 6.4f * u, 14.7f * u, 6.4f * u, 14.7f * u, 9.6f * u)
                cubicTo(14.7f * u, 11.6f * u, 12f * u, 11.8f * u, 12f * u, 14.2f * u)
            }, c, style = line)
            dot(12f, 17.3f, 1.1f, accent)
        }
        LibIconKind.PLAY -> drawPath(path { m(8f, 5.5f); l(18.5f, 12f); l(8f, 18.5f); close() }, c)
        LibIconKind.PAUSE -> {
            drawPath(path { rr(6.6f, 5.5f, 10.4f, 18.5f, 1.2f) }, c)
            drawPath(path { rr(13.6f, 5.5f, 17.4f, 18.5f, 1.2f) }, c)
        }
        LibIconKind.REPLAY -> {
            drawPath(path {
                arcTo(Rect(5f * u, 6.5f * u, 19f * u, 20.5f * u), -60f, -280f, true)
            }, c, style = line)
            arrowHead(12f, 13.5f, 7f, 20f, -1f)
        }
        LibIconKind.FORWARD -> {
            drawPath(path {
                arcTo(Rect(5f * u, 6.5f * u, 19f * u, 20.5f * u), -120f, 280f, true)
            }, c, style = line)
            arrowHead(12f, 13.5f, 7f, 160f, 1f)
        }
        LibIconKind.GRID -> {
            val sq = listOf(4f to 4f, 13.6f to 4f, 4f to 13.6f, 13.6f to 13.6f)
            sq.forEach { (x, y) ->
                val p = path { rr(x, y, x + 6.4f, y + 6.4f, 1.4f) }
                if (filled) drawPath(p, soft)
                drawPath(p, c, style = line)
            }
        }
        LibIconKind.LIST -> {
            for (y in listOf(6.5f, 12f, 17.5f)) {
                dot(5f, y, 1.2f, accent)
                seg(9f, y, 20f, y)
            }
        }
        LibIconKind.SHELF -> {
            drawPath(path { rr(4.6f, 4.6f, 8f, 10.4f, 0.8f) }, c, style = thin)
            drawPath(path { rr(9.6f, 3.4f, 13f, 10.4f, 0.8f) }, c, style = thin)
            drawPath(path { m(14.8f, 6f); l(17.8f, 5.2f); l(19.4f, 10.4f); l(16.4f, 10.4f); close() }, c, style = thin)
            seg(3f, 11.4f, 21f, 11.4f)
            drawPath(path { rr(4.6f, 14.2f, 8f, 19.8f, 0.8f) }, c, style = thin)
            drawPath(path { rr(9.6f, 15.2f, 13f, 19.8f, 0.8f) }, accent, style = thin)
            seg(3f, 20.8f, 21f, 20.8f)
        }
        LibIconKind.DICTIONARY -> {
            val cover = path { rr(4.6f, 3.6f, 18.4f, 20.4f, 1.8f) }
            if (filled) drawPath(cover, soft)
            drawPath(cover, c, style = line)
            seg(8.2f, 3.8f, 8.2f, 20.2f, c, 1.4f)
            ring(13.4f, 10.4f, 2.6f, accent, 1.5f)
            seg(15.3f, 12.3f, 17f, 14f, accent, 1.5f)
        }
    }
}
