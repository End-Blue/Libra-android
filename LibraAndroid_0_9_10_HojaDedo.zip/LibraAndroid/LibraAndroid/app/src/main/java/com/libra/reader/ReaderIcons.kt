package com.libra.reader

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Iconos extra del panel del lector (Libellum 0.9.6).
 * Mismo estilo que Icons.kt: trazo fino redondeado sobre rejilla 24×24, sin librerías de iconos.
 * Los que ya existen en LibIconKind (TEXT_SIZE, THEME, BOOKMARK, NOTES, PLUS, CLOSE, TRASH,
 * REPLAY, CHEVRON_*) se reutilizan desde allí.
 */
enum class RdIcon {
    PAGE, SWAP, NOTE,
    DENSITY_LOW, DENSITY_HIGH,
    MARGIN_WIDE, MARGIN_NARROW,
    JUSTIFY, INDENT,
    SLIDE, LAYERS, SCROLL, BAN,
    ROTATE, PHONE_V, PHONE_H, HAND, ARROWS_LR,
    SUN_LOW, SUN_HIGH,
    CHEV_UP, CHEV_DOWN, GOTO
}

@Composable
fun RdGlyph(
    kind: RdIcon,
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    size: Dp = 22.dp,
    accent: Color = tint
) {
    Canvas(modifier.size(size)) { drawRdIcon(kind, tint, accent) }
}

private fun DrawScope.drawRdIcon(kind: RdIcon, c: Color, accent: Color) {
    val u = size.minDimension / 24f
    val line = Stroke(width = 1.8f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)

    fun Path.m(x: Float, y: Float) = moveTo(x * u, y * u)
    fun Path.l(x: Float, y: Float) = lineTo(x * u, y * u)
    fun Path.rr(l: Float, t: Float, r: Float, b: Float, rad: Float) =
        addRoundRect(RoundRect(l * u, t * u, r * u, b * u, CornerRadius(rad * u, rad * u)))
    fun path(block: Path.() -> Unit): Path = Path().apply(block)
    fun seg(x1: Float, y1: Float, x2: Float, y2: Float, color: Color = c, w: Float = 1.8f) =
        drawLine(color, Offset(x1 * u, y1 * u), Offset(x2 * u, y2 * u), strokeWidth = w * u, cap = StrokeCap.Round)
    fun ring(cx: Float, cy: Float, r: Float, color: Color = c, w: Float = 1.8f) =
        drawCircle(color, radius = r * u, center = Offset(cx * u, cy * u), style = Stroke(width = w * u))
    fun dot(cx: Float, cy: Float, r: Float, color: Color = c) =
        drawCircle(color, radius = r * u, center = Offset(cx * u, cy * u))
    // punta de flecha al final de un arco (misma lógica que Icons.kt)
    fun arrowHead(cx: Float, cy: Float, r: Float, endDeg: Float, dir: Float) {
        val a = endDeg * (PI / 180.0).toFloat()
        val ex = cx + r * cos(a)
        val ey = cy + r * sin(a)
        val tx = -sin(a) * dir
        val ty = cos(a) * dir
        val spread = 0.62f
        val len = 3.6f
        for (sgn in listOf(-1f, 1f)) {
            val cs = cos(spread * sgn)
            val sn = sin(spread * sgn)
            val bx = -(tx * cs - ty * sn)
            val by = -(tx * sn + ty * cs)
            seg(ex, ey, ex + bx * len, ey + by * len, w = 1.8f)
        }
    }

    when (kind) {
        RdIcon.PAGE -> {
            drawPath(path { rr(5f, 3.5f, 19f, 20.5f, 2.2f) }, c, style = line)
            seg(8.6f, 9f, 15.4f, 9f)
            seg(8.6f, 12.6f, 15.4f, 12.6f)
            seg(8.6f, 16.2f, 12.6f, 16.2f, accent)
        }
        RdIcon.SWAP -> {
            seg(4f, 9f, 19f, 9f)
            drawPath(path { m(16f, 6f); l(19.4f, 9f); l(16f, 12f) }, c, style = line)
            seg(5f, 15f, 20f, 15f, accent)
            drawPath(path { m(8f, 12f); l(4.6f, 15f); l(8f, 18f) }, accent, style = line)
        }
        RdIcon.NOTE -> {
            drawPath(path { rr(4.8f, 4f, 19.2f, 20f, 2.2f) }, c, style = line)
            seg(8.2f, 9.4f, 15.8f, 9.4f)
            seg(8.2f, 13f, 15.8f, 13f)
            seg(8.2f, 16.6f, 12.2f, 16.6f, accent)
        }
        RdIcon.DENSITY_LOW -> {
            seg(5f, 9f, 19f, 9f)
            seg(5f, 12f, 19f, 12f)
            seg(5f, 15f, 19f, 15f)
        }
        RdIcon.DENSITY_HIGH -> {
            seg(5f, 5.5f, 19f, 5.5f)
            seg(5f, 12f, 19f, 12f)
            seg(5f, 18.5f, 19f, 18.5f)
        }
        RdIcon.MARGIN_WIDE -> {
            drawPath(path { rr(3f, 4.6f, 21f, 19.4f, 2.2f) }, c, style = line)
            seg(5.8f, 10f, 18.2f, 10f, accent, 1.6f)
            seg(5.8f, 14f, 18.2f, 14f, accent, 1.6f)
        }
        RdIcon.MARGIN_NARROW -> {
            drawPath(path { rr(3f, 4.6f, 21f, 19.4f, 2.2f) }, c, style = line)
            seg(9.2f, 10f, 14.8f, 10f, accent, 1.6f)
            seg(9.2f, 14f, 14.8f, 14f, accent, 1.6f)
        }
        RdIcon.JUSTIFY -> {
            seg(5f, 6f, 19f, 6f)
            seg(5f, 10.5f, 19f, 10.5f)
            seg(5f, 15f, 19f, 15f)
            seg(5f, 19.5f, 19f, 19.5f)
        }
        RdIcon.INDENT -> {
            drawPath(path { m(4.6f, 8f); l(8.4f, 11f); l(4.6f, 14f) }, accent, style = line)
            seg(11f, 7f, 19.4f, 7f)
            seg(11f, 12f, 19.4f, 12f)
            seg(4.6f, 17.4f, 19.4f, 17.4f)
        }
        RdIcon.SLIDE -> {
            seg(4f, 12f, 16.6f, 12f)
            drawPath(path { m(12.8f, 8.2f); l(16.6f, 12f); l(12.8f, 15.8f) }, c, style = line)
            seg(20f, 6f, 20f, 18f, accent)
        }
        RdIcon.LAYERS -> {
            drawPath(path { rr(9f, 4.6f, 19.8f, 15.4f, 2f) }, accent, style = line)
            drawPath(path { rr(4.2f, 8.6f, 15f, 19.4f, 2f) }, c, style = line)
        }
        RdIcon.SCROLL -> {
            seg(12f, 4.6f, 12f, 19.4f)
            drawPath(path { m(8.4f, 8f); l(12f, 4.4f); l(15.6f, 8f) }, c, style = line)
            drawPath(path { m(8.4f, 16f); l(12f, 19.6f); l(15.6f, 16f) }, accent, style = line)
        }
        RdIcon.BAN -> {
            ring(12f, 12f, 8f)
            seg(6.4f, 17.6f, 17.6f, 6.4f, accent)
        }
        RdIcon.ROTATE -> {
            drawPath(path {
                arcTo(Rect(5f * u, 5f * u, 19f * u, 19f * u), -50f, 280f, true)
            }, c, style = line)
            arrowHead(12f, 12f, 7f, 230f, 1f)
            dot(12f, 12f, 1.4f, accent)
        }
        RdIcon.PHONE_V -> {
            drawPath(path { rr(7.6f, 3.4f, 16.4f, 20.6f, 2.4f) }, c, style = line)
            dot(12f, 17.8f, 1.1f, accent)
        }
        RdIcon.PHONE_H -> {
            drawPath(path { rr(3.4f, 7.6f, 20.6f, 16.4f, 2.4f) }, c, style = line)
            dot(17.8f, 12f, 1.1f, accent)
        }
        RdIcon.HAND -> {
            drawPath(path { rr(7.4f, 11f, 17.4f, 20.4f, 2.6f) }, c, style = line)
            seg(9.2f, 6.8f, 9.2f, 11f, c, 1.7f)
            seg(11.6f, 5.2f, 11.6f, 11f, c, 1.7f)
            seg(14f, 5.2f, 14f, 11f, c, 1.7f)
            seg(16.4f, 6.8f, 16.4f, 11f, c, 1.7f)
            seg(7.4f, 14.4f, 4.8f, 11.8f, accent, 1.7f)
        }
        RdIcon.ARROWS_LR -> {
            drawPath(path { m(8.6f, 6.6f); l(3.8f, 12f); l(8.6f, 17.4f) }, c, style = line)
            drawPath(path { m(15.4f, 6.6f); l(20.2f, 12f); l(15.4f, 17.4f) }, accent, style = line)
        }
        RdIcon.SUN_LOW -> {
            ring(12f, 12f, 3.4f)
            seg(12f, 4.6f, 12f, 6.4f, accent)
            seg(12f, 17.6f, 12f, 19.4f, accent)
            seg(4.6f, 12f, 6.4f, 12f, accent)
            seg(17.6f, 12f, 19.4f, 12f, accent)
        }
        RdIcon.SUN_HIGH -> {
            ring(12f, 12f, 4.2f)
            for (k in 0 until 8) {
                val a = (k * 45f) * (PI / 180.0).toFloat()
                seg(
                    12f + 7.2f * cos(a), 12f + 7.2f * sin(a),
                    12f + 9.8f * cos(a), 12f + 9.8f * sin(a),
                    accent
                )
            }
        }
        RdIcon.CHEV_UP -> drawPath(path { m(6f, 15f); l(12f, 9f); l(18f, 15f) }, c, style = line)
        RdIcon.CHEV_DOWN -> drawPath(path { m(6f, 9f); l(12f, 15f); l(18f, 9f) }, c, style = line)
        RdIcon.GOTO -> {
            seg(7f, 17f, 17f, 7f)
            drawPath(path { m(9.4f, 7f); l(17f, 7f); l(17f, 14.6f) }, accent, style = line)
        }
    }
}
