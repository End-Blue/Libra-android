package com.libra.reader

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class FoundBook(
    val uri: Uri,
    val name: String,
    val extension: String,
    val sizeKb: Long,
    val folder: String = "",
    val modified: Long = 0L
)

private val SCAN_EXTENSIONS = setOf("epub", "pdf", "txt", "fb2", "cbz")
private val SKIP_DIRS = setOf("android", "cache", "thumbnails", "lost.dir", "obb")
private const val MAX_FILES = 5000
private const val MAX_DEPTH = 12
private const val MIN_BYTES = 20L * 1024   // se ignoran archivos de menos de 20 KB (notas, logs…)

// ── Permiso de almacenamiento ─────────────────────────────────────────────────

/** Android 11+: «Acceso a todos los archivos». Android 10 o menos: permiso de lectura. */
fun hasStorageAccess(context: Context): Boolean =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Environment.isExternalStorageManager()
    } else {
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED
    }

private fun openAllFilesSettings(context: Context) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
    try {
        context.startActivity(
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                .setData(Uri.parse("package:${context.packageName}"))
        )
    } catch (_: Exception) {
        context.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
    }
}

// ── Escaneo automático de todo el almacenamiento ──────────────────────────────

suspend fun scanDeviceForBooks(context: Context): List<FoundBook> = withContext(Dispatchers.IO) {
    val roots = LinkedHashSet<File>()
    roots.add(Environment.getExternalStorageDirectory())
    // Tarjeta SD u otros volúmenes: se deduce su raíz a partir de la carpeta privada de la app
    context.getExternalFilesDirs(null).forEach { dir ->
        dir?.absolutePath?.substringBefore("/Android/")?.let { roots.add(File(it)) }
    }

    val results = ArrayList<FoundBook>()
    val seen = HashSet<String>()
    val stack = ArrayDeque<Pair<File, Int>>()
    roots.forEach { stack.addLast(it to 0) }

    while (stack.isNotEmpty() && results.size < MAX_FILES) {
        val (dir, depth) = stack.removeLast()
        val children = try {
            dir.listFiles()
        } catch (_: Exception) {
            null
        } ?: continue
        for (f in children) {
            val name = f.name
            if (f.isDirectory) {
                if (depth < MAX_DEPTH && !name.startsWith(".") && name.lowercase() !in SKIP_DIRS) {
                    stack.addLast(f to depth + 1)
                }
            } else {
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext in SCAN_EXTENSIONS && f.length() >= MIN_BYTES && seen.add(f.absolutePath)) {
                    results.add(
                        FoundBook(
                            uri = Uri.fromFile(f),
                            name = name,
                            extension = ext,
                            sizeKb = f.length() / 1024,
                            folder = f.parentFile?.name ?: "",
                            modified = f.lastModified()
                        )
                    )
                }
            }
        }
    }
    results.sortedByDescending { it.modified }
}

// ── Diálogo del escáner ───────────────────────────────────────────────────────

@Composable
fun ScannerDialog(
    onImport: (List<Uri>) -> Unit,
    onDismiss: () -> Unit,
    context: Context
) {
    val appContext = LocalContext.current
    var hasAccess by remember { mutableStateOf(hasStorageAccess(context)) }
    var scanning by remember { mutableStateOf(false) }
    var scanned by remember { mutableStateOf(false) }
    var found by remember { mutableStateOf<List<FoundBook>>(emptyList()) }
    var selected by remember { mutableStateOf<Set<Uri>>(emptySet()) }
    var typeFilter by remember { mutableStateOf("TODOS") }

    // Android 10 o menos: permiso de lectura normal
    val readPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasAccess = granted
    }

    // Al volver de Ajustes se vuelve a comprobar el permiso (y el escaneo arranca solo)
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) hasAccess = hasStorageAccess(context)
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(Unit) {
        if (!hasAccess && Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            readPermission.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    // En cuanto hay permiso se escanea todo el almacenamiento, sin elegir carpetas
    LaunchedEffect(hasAccess) {
        if (hasAccess) {
            scanning = true
            found = scanDeviceForBooks(context)
            // Ya vienen marcados los que parecen libros: EPUB, FB2, CBZ y PDF de más de 1 MB
            selected = found.filter {
                it.extension in setOf("epub", "fb2", "cbz") || (it.extension == "pdf" && it.sizeKb >= 1024)
            }.map { it.uri }.toSet()
            scanning = false
            scanned = true
        }
    }

    val visible = if (typeFilter == "TODOS") found else found.filter { it.extension.uppercase() == typeFilter }
    val types = listOf("TODOS") + SCAN_EXTENSIONS.map { it.uppercase() }.filter { t -> found.any { it.extension.uppercase() == t } }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Panel,
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.88f)
        ) {
            Column(Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LibIcon(LibIconKind.SCAN, tint = Cream, size = 24.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Libros en tu dispositivo",
                        color = Cream,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    "Busca automáticamente en todas las carpetas y deja marcados los que parecen libros.",
                    color = Muted,
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(12.dp))

                when {
                    !hasAccess -> {
                        Box(
                            Modifier.fillMaxWidth().weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                LibIcon(LibIconKind.LOCK, tint = Gold, size = 44.dp)
                                Spacer(Modifier.height(10.dp))
                                Text(
                                    "Para encontrar tus libros, Libra necesita permiso de almacenamiento.",
                                    color = Cream, fontSize = 14.sp, textAlign = TextAlign.Center,
                                    lineHeight = 20.sp
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
                                        "Se abrirán los Ajustes de Android: activa «Permitir acceso para administrar todos los archivos» y vuelve a Libra."
                                    else "Acepta el permiso de lectura que te va a pedir Android.",
                                    color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center,
                                    lineHeight = 18.sp
                                )
                                Spacer(Modifier.height(14.dp))
                                Button(
                                    onClick = {
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) openAllFilesSettings(appContext)
                                        else readPermission.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)
                                ) { Text("Dar permiso") }
                            }
                        }
                    }
                    scanning || !scanned -> {
                        Box(
                            Modifier.fillMaxWidth().weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CircularProgressIndicator(color = Gold)
                                Spacer(Modifier.height(12.dp))
                                Text("Buscando libros…", color = Muted)
                            }
                        }
                    }
                    found.isEmpty() -> {
                        Box(
                            Modifier.fillMaxWidth().weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "No se encontraron libros (EPUB, PDF, TXT, FB2 o CBZ) en el dispositivo.",
                                color = Muted,
                                fontSize = 14.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                    else -> {
                        // Filtro por tipo de libro
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            types.forEach { t ->
                                val count = if (t == "TODOS") found.size else found.count { it.extension.uppercase() == t }
                                FilterChip(
                                    selected = typeFilter == t,
                                    onClick = { typeFilter = t },
                                    label = { Text("$t $count", fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Gold,
                                        selectedLabelColor = Ink,
                                        labelColor = Cream
                                    )
                                )
                            }
                        }
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${visible.size} archivos", color = Muted, fontSize = 12.sp)
                            val allSelected = visible.isNotEmpty() && visible.all { it.uri in selected }
                            TextButton(onClick = {
                                selected = if (allSelected) selected - visible.map { it.uri }.toSet()
                                else selected + visible.map { it.uri }
                            }) {
                                Text(
                                    if (allSelected) "Quitar selección" else "Seleccionar todo",
                                    color = Gold, fontSize = 12.sp
                                )
                            }
                        }

                        LazyColumn(
                            Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            items(visible, key = { it.uri.toString() }) { book ->
                                val isSelected = book.uri in selected
                                // Un solo hijo por item: fila + separador dentro de una Column
                                Column {
                                    Row(
                                        Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                selected = if (isSelected) selected - book.uri
                                                else selected + book.uri
                                            }
                                            .padding(vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Checkbox(
                                            checked = isSelected,
                                            onCheckedChange = {
                                                selected = if (it) selected + book.uri else selected - book.uri
                                            },
                                            colors = CheckboxDefaults.colors(checkedColor = Gold)
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(
                                                book.name,
                                                color = Cream,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                "${book.extension.uppercase()} · ${book.sizeKb} KB · ${book.folder}",
                                                color = Muted,
                                                fontSize = 11.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                    HorizontalDivider(color = Ink, thickness = 0.5.dp)
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Muted)
                    ) { Text("Cancelar") }

                    Button(
                        onClick = {
                            if (selected.isNotEmpty()) onImport(selected.toList())
                            onDismiss()
                        },
                        enabled = selected.isNotEmpty(),
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)
                    ) {
                        Text(
                            if (selected.isEmpty()) "Importar"
                            else "Importar (${selected.size})"
                        )
                    }
                }
            }
        }
    }
}
