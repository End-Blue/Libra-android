package com.libra.reader

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionParametersOf
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.ContentScale
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs

/** Clave con la que el widget le dice a la app qué libro abrir. */
val OPEN_BOOK_KEY = ActionParameters.Key<String>("open_book_id")

private class WBook(val id: String, val title: String, val bitmap: Bitmap?, val color: Color)
private class WData(val books: List<WBook>, val total: Int)

private val WIDGET_PALETTE = listOf(
    Color(0xFF2F4B6B), Color(0xFF7A2E3A), Color(0xFF35563F), Color(0xFF8A4B2B), Color(0xFF4A3B6B)
)

private fun loadCover(path: String?): Bitmap? {
    if (path == null) return null
    val f = File(path)
    if (!f.exists()) return null
    return try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 260) sample *= 2
        BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
    } catch (_: Throwable) {
        null
    }
}

private suspend fun loadShelf(context: Context): WData = withContext(Dispatchers.IO) {
    val all = LibraryDatabase.get(context).libraryDao().getAll().filter { it.mediaType == "BOOK" }
    // Primero favoritos, luego los que estás leyendo y por último los más recientes
    val ordered = all.sortedWith(
        compareByDescending<LibraryItem> { it.isFavorite }
            .thenByDescending { if (it.statusKey() == "READING") 1 else 0 }
            .thenByDescending { it.addedAt }
    ).take(8)
    WData(
        ordered.map { b ->
            WBook(b.id, b.title, loadCover(b.coverPath), WIDGET_PALETTE[abs(b.title.hashCode()) % WIDGET_PALETTE.size])
        },
        all.size
    )
}

class ShelfWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val data = loadShelf(context)
        provideContent { ShelfContent(context, data) }
    }
}

class ShelfWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = ShelfWidget()
}

private val W_TEXT = Color(0xFF1B2A41)
private val W_PAPER = Color(0xFFF5EFE3)
private val W_WOOD = Color(0xFF86592F)

@Composable
private fun ShelfContent(context: Context, data: WData) {
    Column(
        GlanceModifier
            .fillMaxSize()
            .background(ColorProvider(W_PAPER))
            .cornerRadius(18.dp)
            .padding(10.dp)
    ) {
        Row(
            GlanceModifier.fillMaxWidth().clickable(
                actionStartActivity(Intent(context, MainActivity::class.java))
            ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Mi estantería",
                style = TextStyle(color = ColorProvider(W_TEXT), fontSize = 14.sp, fontWeight = FontWeight.Bold),
                modifier = GlanceModifier.defaultWeight()
            )
            Text(
                "${data.total} libros",
                style = TextStyle(color = ColorProvider(Color(0xFF7B8798)), fontSize = 11.sp)
            )
        }
        Spacer(GlanceModifier.height(6.dp))
        if (data.books.isEmpty()) {
            Text(
                "Importa libros en Libellum para verlos aquí.",
                style = TextStyle(color = ColorProvider(W_TEXT), fontSize = 12.sp)
            )
        } else {
            data.books.chunked(4).forEach { row -> ShelfRow(context, row) }
        }
    }
}

@Composable
private fun ShelfRow(context: Context, row: List<WBook>) {
    Column(GlanceModifier.fillMaxWidth().padding(bottom = 6.dp)) {
        Row(GlanceModifier.fillMaxWidth().height(78.dp), verticalAlignment = Alignment.Bottom) {
            row.forEach { b ->
                BookTile(context, b, GlanceModifier.defaultWeight().height(78.dp).padding(horizontal = 2.dp))
            }
            repeat(4 - row.size) { Spacer(GlanceModifier.defaultWeight()) }
        }
        Box(GlanceModifier.fillMaxWidth().height(5.dp).background(ColorProvider(W_WOOD))) {}
    }
}

@Composable
private fun BookTile(context: Context, b: WBook, modifier: GlanceModifier) {
    val open = actionStartActivity(
        Intent(context, MainActivity::class.java),
        actionParametersOf(OPEN_BOOK_KEY to b.id)
    )
    val bmp = b.bitmap
    if (bmp != null) {
        Image(
            provider = ImageProvider(bmp),
            contentDescription = b.title,
            contentScale = ContentScale.Crop,
            modifier = modifier.clickable(open)
        )
    } else {
        Box(
            modifier = modifier.background(ColorProvider(b.color)).clickable(open),
            contentAlignment = Alignment.Center
        ) {
            Text(
                b.title,
                style = TextStyle(color = ColorProvider(Color(0xFFF3E6C8)), fontSize = 9.sp, fontWeight = FontWeight.Bold),
                maxLines = 4
            )
        }
    }
}
