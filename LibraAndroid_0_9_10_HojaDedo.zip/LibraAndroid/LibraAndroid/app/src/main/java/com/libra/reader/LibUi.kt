package com.libra.reader

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// ══════════════════════════════════════════════════════════════════════════════
// Kit visual «papel dorado» de Inicio, Favoritos y Audiolibros
// ══════════════════════════════════════════════════════════════════════════════

internal val LbBg = Color(0xFFF7E8D1)          // fondo de página (el mismo que las ilustraciones)
internal val LbCardTop = Color(0xFFFDF4E4)
internal val LbCardBottom = Color(0xFFF9EBD2)
internal val LbCardEdge = Color(0xFFEAD7B5)
internal val LbBrown = Color(0xFF834906)       // botones, chips activos, progreso
internal val LbBrownLight = Color(0xFFA3610B)
internal val LbTitle = Color(0xFF2A1503)       // títulos
internal val LbText = Color(0xFF45301B)
internal val LbMuted = Color(0xFF7A6446)
internal val LbLine = Color(0xFFD9B787)
internal val LbTrack = Color(0xFFECD5B1)
internal val LbBar = Color(0xFFB07830)
internal val LbBarSel = Color(0xFF8E5410)
internal val LbNavActive = Color(0xFFF2D8B0)

/** Tarjeta de papel con borde fino y sombra suave. */
@Composable
internal fun LbCard(
    modifier: Modifier = Modifier,
    padding: Dp = 14.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier
            .shadow(3.dp, shape, ambientColor = Color(0x22805020), spotColor = Color(0x33805020))
            .clip(shape)
            .background(Brush.verticalGradient(listOf(LbCardTop, LbCardBottom)))
            .border(1.dp, LbCardEdge, shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(padding),
        content = content
    )
}

/** Título de sección: icono, texto en cursiva, línea fina y acción opcional a la derecha. */
@Composable
internal fun LbSectionHeader(
    title: String,
    icon: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    trailing: (@Composable () -> Unit)? = null
) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        icon()
        Spacer(Modifier.width(8.dp))
        Text(
            title, color = LbTitle, fontSize = 22.sp, fontWeight = FontWeight.Bold,
            fontFamily = LibellumSerif, fontStyle = FontStyle.Italic, maxLines = 1
        )
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f).height(1.dp).background(LbLine.copy(alpha = 0.8f)))
        if (trailing != null) {
            Spacer(Modifier.width(10.dp))
            trailing()
        }
    }
}

/** «Ver todos ›» */
@Composable
internal fun LbLink(text: String, onClick: () -> Unit) {
    Row(Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(vertical = 4.dp)) {
        Text(
            text, color = LbBrownLight, fontSize = 14.sp, fontFamily = LibellumSerif,
            fontStyle = FontStyle.Italic
        )
        Spacer(Modifier.width(2.dp))
        LbIcon(LbIconKind.CHEVRON_RIGHT, tint = LbBrownLight, size = 16.dp)
    }
}

/** Chip de filtro: activo en marrón, inactivo en crema. */
@Composable
internal fun LbChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    icon: (@Composable (Color) -> Unit)? = null
) {
    val shape = RoundedCornerShape(50)
    val fg = if (selected) Color(0xFFFDF1DC) else LbText
    Row(
        Modifier
            .clip(shape)
            .background(if (selected) LbBrown else Color(0xFFF8EEDB))
            .border(1.dp, if (selected) LbBrown else LbCardEdge, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            icon(fg)
            Spacer(Modifier.width(7.dp))
        }
        Text(label, color = fg, fontSize = 14.sp, fontFamily = LibellumSerif, maxLines = 1)
    }
}

/** Cinta de marcador dorada (esquina de las tarjetas). */
@Composable
internal fun RibbonMark(modifier: Modifier = Modifier, on: Boolean = true, onClick: (() -> Unit)? = null) {
    Canvas(
        modifier
            .size(width = 22.dp, height = 30.dp)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
    ) {
        val w = size.width
        val h = size.height
        val p = Path().apply {
            moveTo(0f, 0f); lineTo(w, 0f); lineTo(w, h); lineTo(w / 2f, h * 0.74f); lineTo(0f, h); close()
        }
        if (on) {
            drawPath(p, Brush.verticalGradient(listOf(Color(0xFFD9A441), Color(0xFFB07A1F))))
        } else {
            drawPath(p, Color(0x33B07A1F))
            drawPath(p, Color(0xFFB07A1F), style = Stroke(width = 1.5.dp.toPx(), join = StrokeJoin.Round))
        }
    }
}

// ── Cabecera con ilustración ─────────────────────────────────────────────────

/**
 * Cabecera de Inicio / Favoritos / Audiolibros: ilustración a ancho completo y el texto encima.
 * [onGear] != null dibuja el botón de ajustes (solo en Inicio).
 */
@Composable
internal fun HeroHeader(
    @DrawableRes art: Int,
    title: String,
    sub: String,
    quote: String,
    modifier: Modifier = Modifier,
    titleSize: Int = 36,
    subSize: Int = 16,
    subItalic: Boolean = false,
    onGear: (() -> Unit)? = null
) {
    Box(modifier.fillMaxWidth()) {
        Image(
            painter = painterResource(id = art),
            contentDescription = null,
            contentScale = ContentScale.FillWidth,
            modifier = Modifier.fillMaxWidth()
        )
        Column(Modifier.fillMaxWidth(0.66f).padding(start = 20.dp, top = 8.dp, bottom = 6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LbIcon(LbIconKind.BOOK_OPEN, tint = LbBrown, size = 30.dp)
                Spacer(Modifier.width(10.dp))
                Box(Modifier.width(1.dp).height(24.dp).background(LbBrown.copy(alpha = 0.35f)))
                Spacer(Modifier.width(10.dp))
                Text(
                    "LIBELLUM", color = LbBrown, fontSize = 14.sp, letterSpacing = 4.sp,
                    fontFamily = LibellumSerif, maxLines = 1, softWrap = false
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                title, color = LbTitle, fontSize = titleSize.sp, fontWeight = FontWeight.Bold,
                fontFamily = LibellumSerif, fontStyle = FontStyle.Italic,
                maxLines = 1, softWrap = false, lineHeight = (titleSize + 6).sp
            )
            Text(
                sub, color = LbTitle, fontSize = subSize.sp,
                fontFamily = LibellumSerif,
                fontStyle = if (subItalic) FontStyle.Italic else FontStyle.Normal,
                lineHeight = (subSize + 6).sp, modifier = Modifier.padding(top = 4.dp)
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "“$quote”", color = LbText, fontSize = 13.sp, fontFamily = LibellumSerif,
                fontStyle = FontStyle.Italic, lineHeight = 18.sp
            )
            Spacer(Modifier.height(8.dp))
            Flourish()
        }
        if (onGear != null) {
            Box(
                Modifier.align(Alignment.TopEnd).padding(top = 10.dp, end = 14.dp)
                    .size(44.dp)
                    .shadow(3.dp, CircleShape, ambientColor = Color(0x33805020), spotColor = Color(0x44805020))
                    .clip(CircleShape)
                    .background(Color(0xFFFFF8EA))
                    .clickable(onClick = onGear),
                contentAlignment = Alignment.Center
            ) { LbIcon(LbIconKind.GEAR, tint = LbBrown, size = 24.dp) }
        }
    }
}

/** Adorno «—— ✦ ——» bajo la cita. */
@Composable
internal fun Flourish(modifier: Modifier = Modifier) {
    Canvas(modifier.size(width = 120.dp, height = 12.dp)) {
        val cy = size.height / 2f
        val col = LbBrownLight
        drawLine(col.copy(alpha = 0.7f), Offset(0f, cy), Offset(size.width * 0.36f, cy), 1.2.dp.toPx())
        drawLine(col.copy(alpha = 0.7f), Offset(size.width * 0.64f, cy), Offset(size.width, cy), 1.2.dp.toPx())
        val cx = size.width / 2f
        val r = 5.dp.toPx()
        val p = Path().apply {
            moveTo(cx, cy - r)
            quadraticBezierTo(cx, cy, cx + r, cy)
            quadraticBezierTo(cx, cy, cx, cy + r)
            quadraticBezierTo(cx, cy, cx - r, cy)
            quadraticBezierTo(cx, cy, cx, cy - r)
            close()
        }
        drawPath(p, col)
    }
}

// ── Barra inferior con laureles ──────────────────────────────────────────────

/**
 * Barra inferior de Libellum. La 4.ª pestaña es «Racha» y pasa a «Audiolibros» cuando estás en esa pantalla.
 */
@Composable
internal fun LibellumNavBar(
    selectedTab: String,
    moreSelected: Boolean,
    onSelect: (String) -> Unit,
    onMore: () -> Unit
) {
    val fourth = if (selectedTab == "Audio") "Audio" else "Racha"
    val tabs = listOf("Panel", "Estantería", "Favoritos", fourth, "Más")
    Box(Modifier.fillMaxWidth().background(LbBg).navigationBarsPadding()) {
        Laurel(Modifier.align(Alignment.BottomStart), flip = false)
        Laurel(Modifier.align(Alignment.BottomEnd), flip = true)
        Column(Modifier.fillMaxWidth().padding(start = 22.dp, end = 22.dp, top = 6.dp, bottom = 4.dp)) {
            val shape = RoundedCornerShape(28.dp)
            Row(
                Modifier.fillMaxWidth()
                    .shadow(4.dp, shape, ambientColor = Color(0x22805020), spotColor = Color(0x33805020))
                    .clip(shape)
                    .background(Color(0xFFFCEFDA))
                    .border(1.dp, LbCardEdge, shape)
                    .padding(horizontal = 5.dp, vertical = 5.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                tabs.forEach { tab ->
                    val sel = if (tab == "Más") moreSelected else selectedTab == tab
                    val fg = if (sel) LbBrown else Color(0xFF8A6A3C)
                    Column(
                        Modifier.weight(1f)
                            .clip(RoundedCornerShape(22.dp))
                            .background(if (sel) LbNavActive else Color.Transparent)
                            .clickable { if (tab == "Más") onMore() else onSelect(tab) }
                            .padding(vertical = 7.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        when (tab) {
                            "Panel" -> LibIcon(LibIconKind.HOME, tint = fg, size = 24.dp, filled = sel, accent = fg)
                            "Estantería" -> LibIcon(LibIconKind.SHELF, tint = fg, size = 24.dp, filled = sel, accent = fg)
                            "Favoritos" -> LibIcon(LibIconKind.STAR, tint = fg, size = 24.dp, filled = sel, accent = fg)
                            "Racha" -> LbIcon(LbIconKind.FLAME, tint = fg, size = 24.dp, filled = false)
                            "Audio" -> LibIcon(LibIconKind.AUDIO, tint = fg, size = 24.dp, filled = sel, accent = fg)
                            else -> LibIcon(LibIconKind.LIST, tint = fg, size = 24.dp, accent = fg)
                        }
                        Spacer(Modifier.height(2.dp))
                        Text(
                            if (tab == "Audio") "Audiolibros" else tab,
                            color = fg, fontSize = 11.sp, fontFamily = LibellumSerif,
                            fontStyle = FontStyle.Italic,
                            fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                            maxLines = 1, softWrap = false
                        )
                    }
                }
            }
            Box(Modifier.fillMaxWidth().padding(top = 3.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(width = 150.dp, height = 10.dp)) {
                    val cy = size.height / 2f
                    drawLine(LbLine, Offset(0f, cy), Offset(size.width * 0.38f, cy), 1.dp.toPx())
                    drawLine(LbLine, Offset(size.width * 0.62f, cy), Offset(size.width, cy), 1.dp.toPx())
                    val cx = size.width / 2f
                    val r = 4.dp.toPx()
                    val p = Path().apply {
                        moveTo(cx, cy - r)
                        quadraticBezierTo(cx, cy, cx + r, cy)
                        quadraticBezierTo(cx, cy, cx, cy + r)
                        quadraticBezierTo(cx, cy, cx - r, cy)
                        quadraticBezierTo(cx, cy, cx, cy - r)
                        close()
                    }
                    drawPath(p, LbBrownLight)
                }
            }
        }
    }
}

/** Rama de laurel decorativa de las esquinas de la barra. */
@Composable
internal fun Laurel(modifier: Modifier = Modifier, flip: Boolean) {
    Canvas(modifier.size(width = 54.dp, height = 78.dp)) {
        val w = size.width
        val h = size.height
        fun px(x: Float) = if (flip) w - x else x
        val leaf = Color(0xFFC9A268).copy(alpha = 0.62f)
        // tallo curvo desde abajo hacia arriba
        val x0 = 10.dp.toPx(); val y0 = h - 2.dp.toPx()
        val cx = -2.dp.toPx();  val cy = h * 0.45f
        val x1 = 26.dp.toPx();  val y1 = 4.dp.toPx()
        val stem = Path().apply {
            moveTo(px(x0), y0)
            quadraticBezierTo(px(cx), cy, px(x1), y1)
        }
        drawPath(stem, leaf, style = Stroke(width = 1.3.dp.toPx(), cap = StrokeCap.Round))
        for (i in 1..8) {
            val t = i / 9f
            val bx = (1 - t) * (1 - t) * x0 + 2 * (1 - t) * t * cx + t * t * x1
            val by = (1 - t) * (1 - t) * y0 + 2 * (1 - t) * t * cy + t * t * y1
            val dx = 2 * (1 - t) * (cx - x0) + 2 * t * (x1 - cx)
            val dy = 2 * (1 - t) * (cy - y0) + 2 * t * (y1 - cy)
            val ang = (kotlin.math.atan2(dy, dx) * 180.0 / PI).toFloat()
            val len = (15f - t * 5f).dp.toPx()
            val wid = (6f - t * 1.5f).dp.toPx()
            for (side in listOf(-1f, 1f)) {
                val a = ang + side * 52f
                val ox = px(bx)
                rotate(if (flip) -a + 180f else a, Offset(ox, by)) {
                    drawOval(leaf, Offset(ox, by - wid / 2f), Size(len, wid))
                }
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// Iconos de trazo fino (rejilla 24×24)
// ══════════════════════════════════════════════════════════════════════════════

internal enum class LbIconKind {
    GEAR, FLAME, CLOCK, CALENDAR, CHART, SPARKLE, BOOK_OPEN, TROPHY, HEART, PERSON, SHUFFLE,
    CHEVRON_DOWN, CHEVRON_RIGHT, DOTS_H, DOTS_V, CHECK, BADGE,
    CAT_FANTASY, CAT_DRAMA, CAT_LEAF, CAT_HISTORY, CAT_ADVENTURE, CAT_SUSPENSE, CAT_ROMANCE, CAT_SCIFI
}

@Composable
internal fun LbIcon(
    kind: LbIconKind,
    modifier: Modifier = Modifier,
    tint: Color = LbBrown,
    size: Dp = 24.dp,
    filled: Boolean = false,
    accent: Color = tint
) {
    Canvas(modifier.size(size)) { drawLbIcon(kind, tint, accent, filled) }
}

private fun DrawScope.drawLbIcon(kind: LbIconKind, c: Color, accent: Color, filled: Boolean) {
    val u = size.minDimension / 24f
    val line = Stroke(width = 1.7f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
    val thin = Stroke(width = 1.3f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
    val soft = c.copy(alpha = 0.22f)

    fun path(block: Path.() -> Unit): Path = Path().apply(block)
    fun Path.m(x: Float, y: Float) = moveTo(x * u, y * u)
    fun Path.l(x: Float, y: Float) = lineTo(x * u, y * u)
    fun Path.cu(a: Float, b: Float, c2: Float, d: Float, e: Float, f: Float) =
        cubicTo(a * u, b * u, c2 * u, d * u, e * u, f * u)
    fun Path.q(a: Float, b: Float, c2: Float, d: Float) = quadraticBezierTo(a * u, b * u, c2 * u, d * u)
    fun Path.rr(l: Float, t: Float, r: Float, b: Float, rad: Float) =
        addRoundRect(RoundRect(l * u, t * u, r * u, b * u, CornerRadius(rad * u, rad * u)))
    fun seg(x1: Float, y1: Float, x2: Float, y2: Float, color: Color = c, w: Float = 1.7f) =
        drawLine(color, Offset(x1 * u, y1 * u), Offset(x2 * u, y2 * u), strokeWidth = w * u, cap = StrokeCap.Round)
    fun ring(cx: Float, cy: Float, r: Float, color: Color = c, w: Float = 1.7f) =
        drawCircle(color, radius = r * u, center = Offset(cx * u, cy * u), style = Stroke(width = w * u))
    fun dot(cx: Float, cy: Float, r: Float, color: Color = c) =
        drawCircle(color, radius = r * u, center = Offset(cx * u, cy * u))
    fun star4(cx: Float, cy: Float, r: Float): Path = path {
        m(cx, cy - r)
        q(cx, cy, cx + r, cy)
        q(cx, cy, cx, cy + r)
        q(cx, cy, cx - r, cy)
        q(cx, cy, cx, cy - r)
        close()
    }
    fun heart(): Path = path {
        m(12f, 20.4f)
        cu(3.6f, 14.2f, 3f, 8.6f, 7f, 6.4f)
        cu(9.2f, 5.3f, 11.2f, 6.3f, 12f, 8f)
        cu(12.8f, 6.3f, 14.8f, 5.3f, 17f, 6.4f)
        cu(21f, 8.6f, 20.4f, 14.2f, 12f, 20.4f)
        close()
    }

    when (kind) {
        LbIconKind.GEAR -> {
            val p = Path()
            var first = true
            for (i in 0 until 8) {
                val base = i * 45.0
                for ((da, r) in listOf(-14.0 to 7.7, -8.0 to 10.2, 8.0 to 10.2, 14.0 to 7.7)) {
                    val ang = (base + da - 90.0) * PI / 180.0
                    val x = (12.0 + r * cos(ang)).toFloat()
                    val y = (12.0 + r * sin(ang)).toFloat()
                    if (first) { p.m(x, y); first = false } else p.l(x, y)
                }
            }
            p.close()
            drawPath(p, c, style = line)
            ring(12f, 12f, 3.3f)
        }
        LbIconKind.FLAME -> {
            val outer = path {
                m(12f, 2.4f)
                cu(13.4f, 6.4f, 18.2f, 8.4f, 18.2f, 14.2f)
                cu(18.2f, 18.4f, 15.4f, 21.6f, 12f, 21.6f)
                cu(8.6f, 21.6f, 5.8f, 18.4f, 5.8f, 14.2f)
                cu(5.8f, 11.6f, 7.2f, 9.6f, 8.8f, 8.2f)
                cu(9f, 10.2f, 10f, 11.2f, 11f, 11.6f)
                cu(11.4f, 8.4f, 11.6f, 5.2f, 12f, 2.4f)
                close()
            }
            if (filled) {
                drawPath(outer, Brush.verticalGradient(listOf(Color(0xFFFFA726), Color(0xFFF4511E)), startY = 2f * u, endY = 22f * u))
                val inner = path {
                    m(12f, 11.2f)
                    cu(13.4f, 13.2f, 15.2f, 14.6f, 15.2f, 17f)
                    cu(15.2f, 19f, 13.8f, 20.2f, 12f, 20.2f)
                    cu(10.2f, 20.2f, 8.8f, 19f, 8.8f, 17f)
                    cu(8.8f, 15.2f, 10.8f, 14f, 12f, 11.2f)
                    close()
                }
                drawPath(inner, Color(0xFFFFE082))
            } else {
                drawPath(outer, c, style = line)
                val inner = path {
                    m(12f, 14f)
                    cu(13f, 15.4f, 14f, 16.2f, 14f, 17.6f)
                    cu(14f, 18.8f, 13.2f, 19.6f, 12f, 19.6f)
                    cu(10.8f, 19.6f, 10f, 18.8f, 10f, 17.6f)
                    cu(10f, 16.2f, 11.2f, 15.4f, 12f, 14f)
                }
                drawPath(inner, c, style = thin)
            }
        }
        LbIconKind.CLOCK -> {
            ring(12f, 12f, 9f)
            drawPath(path { m(12f, 7f); l(12f, 12f); l(15.6f, 14.2f) }, c, style = line)
        }
        LbIconKind.CALENDAR -> {
            drawPath(path { rr(3.5f, 5f, 20.5f, 20.5f, 3f) }, c, style = line)
            seg(3.5f, 10f, 20.5f, 10f)
            seg(8f, 3f, 8f, 6.8f)
            seg(16f, 3f, 16f, 6.8f)
            drawPath(path { m(8.6f, 15.2f); l(11f, 17.6f); l(15.6f, 13f) }, accent, style = thin)
        }
        LbIconKind.CHART -> {
            val b1 = path { rr(3.5f, 13f, 8f, 20.5f, 1f) }
            val b2 = path { rr(9.8f, 8f, 14.2f, 20.5f, 1f) }
            val b3 = path { rr(16f, 3.5f, 20.5f, 20.5f, 1f) }
            if (filled) { drawPath(b1, soft); drawPath(b2, soft); drawPath(b3, soft) }
            drawPath(b1, c, style = line)
            drawPath(b2, c, style = line)
            drawPath(b3, c, style = line)
        }
        LbIconKind.SPARKLE -> {
            val big = star4(10.5f, 13.5f, 8f)
            val small = star4(18.6f, 5.4f, 3.4f)
            if (filled) { drawPath(big, soft); drawPath(small, soft) }
            drawPath(big, c, style = line)
            drawPath(small, c, style = thin)
        }
        LbIconKind.BOOK_OPEN -> {
            val left = path {
                m(12f, 6.2f)
                cu(9.6f, 4.6f, 5.6f, 4.4f, 2.6f, 5.2f)
                l(2.6f, 18.6f)
                cu(5.6f, 17.8f, 9.6f, 18f, 12f, 19.6f)
            }
            val right = path {
                m(12f, 6.2f)
                cu(14.4f, 4.6f, 18.4f, 4.4f, 21.4f, 5.2f)
                l(21.4f, 18.6f)
                cu(18.4f, 17.8f, 14.4f, 18f, 12f, 19.6f)
            }
            drawPath(left, c, style = line)
            drawPath(right, c, style = line)
            seg(12f, 6.2f, 12f, 19.6f, w = 1.4f)
            for (k in 0 until 3) {
                val y = 8.8f + k * 3f
                seg(5f, y, 9.4f, y + 0.8f, c, 1.1f)
                seg(14.6f, y + 0.8f, 19f, y, c, 1.1f)
            }
        }
        LbIconKind.TROPHY -> {
            val bowl = path {
                m(7.2f, 3.8f); l(16.8f, 3.8f); l(16.2f, 10.4f)
                cu(15.9f, 12.8f, 14.1f, 14.4f, 12f, 14.4f)
                cu(9.9f, 14.4f, 8.1f, 12.8f, 7.8f, 10.4f)
                close()
            }
            if (filled) drawPath(bowl, soft)
            drawPath(bowl, c, style = line)
            drawPath(path { m(7.2f, 5.6f); cu(3.4f, 5.4f, 3.4f, 10.4f, 8f, 10.8f) }, c, style = line)
            drawPath(path { m(16.8f, 5.6f); cu(20.6f, 5.4f, 20.6f, 10.4f, 16f, 10.8f) }, c, style = line)
            seg(12f, 14.4f, 12f, 18.2f)
            drawPath(path { rr(8f, 18.2f, 16f, 20.8f, 1f) }, c, style = line)
        }
        LbIconKind.HEART -> {
            if (filled) drawPath(heart(), c) else drawPath(heart(), c, style = line)
        }
        LbIconKind.PERSON -> {
            ring(12f, 8f, 3.8f)
            drawPath(path { m(4.8f, 20.4f); cu(4.8f, 15.2f, 19.2f, 15.2f, 19.2f, 20.4f) }, c, style = line)
        }
        LbIconKind.SHUFFLE -> {
            drawPath(path { m(3f, 7.4f); l(7.4f, 7.4f); cu(11.4f, 7.4f, 12.2f, 16.6f, 16.2f, 16.6f); l(20f, 16.6f) }, c, style = line)
            drawPath(path { m(3f, 16.6f); l(7.4f, 16.6f); cu(9f, 16.6f, 10f, 15.6f, 10.8f, 14.4f) }, c, style = line)
            drawPath(path { m(13.2f, 9.6f); cu(14f, 8.4f, 15f, 7.4f, 16.6f, 7.4f); l(20f, 7.4f) }, c, style = line)
            drawPath(path { m(17.6f, 14.2f); l(20f, 16.6f); l(17.6f, 19f) }, c, style = line)
            drawPath(path { m(17.6f, 5f); l(20f, 7.4f); l(17.6f, 9.8f) }, c, style = line)
        }
        LbIconKind.CHEVRON_DOWN -> drawPath(path { m(5.6f, 9f); l(12f, 15.4f); l(18.4f, 9f) }, c, style = line)
        LbIconKind.CHEVRON_RIGHT -> drawPath(path { m(9.5f, 5.5f); l(16f, 12f); l(9.5f, 18.5f) }, c, style = line)
        LbIconKind.DOTS_H -> {
            dot(5f, 12f, 1.7f); dot(12f, 12f, 1.7f); dot(19f, 12f, 1.7f)
        }
        LbIconKind.DOTS_V -> {
            dot(12f, 5f, 1.7f); dot(12f, 12f, 1.7f); dot(12f, 19f, 1.7f)
        }
        LbIconKind.CHECK -> drawPath(path { m(5f, 12.8f); l(9.8f, 17.4f); l(19f, 7f) }, c, style = line)
        LbIconKind.BADGE -> {
            ring(12f, 9.6f, 6.6f)
            seg(8.6f, 14.8f, 7f, 21.2f)
            seg(15.4f, 14.8f, 17f, 21.2f)
            val st = path {
                for (i in 0 until 10) {
                    val ang = (-90.0 + i * 36.0) * PI / 180.0
                    val r = if (i % 2 == 0) 3.4f else 1.5f
                    val x = 12f + r * cos(ang).toFloat()
                    val y = 9.8f + r * sin(ang).toFloat()
                    if (i == 0) m(x, y) else l(x, y)
                }
                close()
            }
            drawPath(st, accent)
        }
        LbIconKind.CAT_FANTASY -> {
            // castillo con bandera
            drawPath(path {
                m(5f, 20.4f); l(5f, 8f); l(8f, 8f); l(8f, 10f); l(10.6f, 10f); l(10.6f, 8f)
                l(13.4f, 8f); l(13.4f, 10f); l(16f, 10f); l(16f, 8f); l(19f, 8f); l(19f, 20.4f); close()
            }, c, style = line)
            drawPath(path { m(10f, 20.4f); l(10f, 16.4f); cu(10f, 13.8f, 14f, 13.8f, 14f, 16.4f); l(14f, 20.4f) }, c, style = thin)
            seg(12f, 3f, 12f, 8f, w = 1.4f)
            drawPath(path { m(12f, 3f); l(16f, 4.6f); l(12f, 6.2f); close() }, accent)
        }
        LbIconKind.CAT_DRAMA -> {
            drawPath(path {
                m(3.6f, 5.4f); l(13.2f, 5.4f); l(13.2f, 11f)
                cu(13.2f, 15.4f, 10.6f, 17.6f, 8.4f, 17.6f)
                cu(6.2f, 17.6f, 3.6f, 15.4f, 3.6f, 11f); close()
            }, c, style = line)
            dot(6.4f, 9.4f, 0.9f); dot(10.4f, 9.4f, 0.9f)
            drawPath(path { m(6.2f, 13.2f); cu(7.4f, 14.6f, 9.4f, 14.6f, 10.6f, 13.2f) }, c, style = thin)
            drawPath(path {
                m(10.8f, 8.2f); l(20.4f, 8.2f); l(20.4f, 13.8f)
                cu(20.4f, 18.2f, 17.8f, 20.6f, 15.6f, 20.6f)
                cu(13.4f, 20.6f, 10.8f, 18.2f, 10.8f, 13.8f); close()
            }, c, style = line)
            dot(13.6f, 12.4f, 0.9f); dot(17.6f, 12.4f, 0.9f)
            drawPath(path { m(13.4f, 17.2f); cu(14.6f, 15.8f, 16.6f, 15.8f, 17.8f, 17.2f) }, c, style = thin)
        }
        LbIconKind.CAT_LEAF -> {
            val leaf = path {
                m(5f, 19f)
                cu(4f, 10f, 10f, 4.5f, 20f, 4.5f)
                cu(20.5f, 13.5f, 14f, 19.5f, 5f, 19f)
                close()
            }
            if (filled) drawPath(leaf, soft)
            drawPath(leaf, c, style = line)
            seg(5f, 19f, 14f, 10f, accent, 1.4f)
        }
        LbIconKind.CAT_HISTORY -> {
            drawPath(path { m(3.5f, 9f); l(12f, 4f); l(20.5f, 9f); close() }, c, style = line)
            for (x in listOf(6.6f, 10.2f, 13.8f, 17.4f)) seg(x, 10.8f, x, 17.6f, w = 1.5f)
            seg(4.5f, 19.8f, 19.5f, 19.8f)
        }
        LbIconKind.CAT_ADVENTURE -> {
            ring(12f, 12f, 9f)
            val needle = path { m(15.8f, 8.2f); l(13.4f, 13.4f); l(8.2f, 15.8f); l(10.6f, 10.6f); close() }
            if (filled) drawPath(needle, soft)
            drawPath(needle, c, style = thin)
            dot(12f, 12f, 1.1f)
        }
        LbIconKind.CAT_SUSPENSE -> {
            drawPath(path {
                m(2.4f, 12f)
                cu(6f, 6.4f, 18f, 6.4f, 21.6f, 12f)
                cu(18f, 17.6f, 6f, 17.6f, 2.4f, 12f)
                close()
            }, c, style = line)
            ring(12f, 12f, 3.2f)
            dot(12f, 12f, 1.2f)
        }
        LbIconKind.CAT_ROMANCE -> {
            if (filled) drawPath(heart(), c) else drawPath(heart(), c, style = line)
        }
        LbIconKind.CAT_SCIFI -> {
            ring(12f, 12f, 5.4f)
            rotate(-25f, Offset(12f * u, 12f * u)) {
                drawOval(c, Offset(2.4f * u, 9.2f * u), Size(19.2f * u, 5.6f * u), style = thin)
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// Barra de progreso y gráfico semanal
// ══════════════════════════════════════════════════════════════════════════════

/** Barra de progreso dorada con extremos redondeados. */
@Composable
internal fun LbProgress(fraction: Float, modifier: Modifier = Modifier, height: Dp = 8.dp) {
    Box(modifier.height(height).clip(RoundedCornerShape(50)).background(LbTrack)) {
        Box(
            Modifier.fillMaxHeight().fillMaxWidth(fraction.coerceIn(0f, 1f))
                .clip(RoundedCornerShape(50))
                .background(Brush.horizontalGradient(listOf(LbBrownLight, LbBrown)))
        )
    }
}

/**
 * Barras de los 7 días de la semana (L M X J V S D). Toca una barra para ver su valor en una burbuja.
 * [selected] = -1 no muestra burbuja.
 */
@Composable
internal fun WeekBarsChart(
    labels: List<String>,
    values: List<Long>,
    selected: Int,
    onSelect: (Int) -> Unit,
    valueText: (Long) -> String,
    modifier: Modifier = Modifier
) {
    val maxV = (values.maxOrNull() ?: 0L).coerceAtLeast(1L)
    val barMax = 46.dp
    Box(modifier.fillMaxWidth().height(barMax + 34.dp + 24.dp)) {
        // ola suave de fondo
        Canvas(Modifier.matchParentSize()) {
            val w = size.width
            val h = size.height
            val p = Path().apply {
                moveTo(0f, h * 0.34f)
                cubicTo(w * 0.22f, h * 0.06f, w * 0.42f, h * 0.50f, w * 0.68f, h * 0.24f)
                cubicTo(w * 0.84f, h * 0.08f, w * 0.94f, h * 0.22f, w, h * 0.16f)
                lineTo(w, h); lineTo(0f, h); close()
            }
            drawPath(p, Color(0x16B07830))
        }
        Row(
            Modifier.matchParentSize().padding(horizontal = 10.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Bottom
        ) {
            values.forEachIndexed { i, v ->
                val sel = i == selected
                val barH = (barMax * (v.toFloat() / maxV.toFloat())).coerceAtLeast(10.dp)
                Column(
                    Modifier.weight(1f).fillMaxHeight().clickable { onSelect(i) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Bottom
                ) {
                    if (sel) {
                        Box(
                            Modifier.requiredWidth(80.dp).height(24.dp)
                                .clip(RoundedCornerShape(12.dp)).background(Color(0xFF5B3A12)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                valueText(v), color = Color(0xFFFDF1DC), fontSize = 12.sp,
                                fontFamily = LibellumSerif, maxLines = 1, softWrap = false
                            )
                        }
                        Spacer(Modifier.height(3.dp))
                        Box(
                            Modifier.size(8.dp).clip(CircleShape).background(Color.White)
                                .border(2.dp, LbBarSel, CircleShape)
                        )
                    }
                    Box(
                        Modifier.width(28.dp).height(barH)
                            .clip(RoundedCornerShape(topStart = 7.dp, topEnd = 7.dp))
                            .background(
                                Brush.verticalGradient(
                                    if (sel) listOf(LbBarSel, Color(0xFFA9691C))
                                    else listOf(Color(0xFFB87A2D), LbBar)
                                )
                            )
                    )
                    Spacer(Modifier.height(5.dp))
                    Text(
                        labels.getOrElse(i) { "" },
                        color = if (sel) LbTitle else LbText, fontSize = 13.sp,
                        fontFamily = LibellumSerif,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.height(19.dp)
                    )
                }
            }
        }
    }
}
