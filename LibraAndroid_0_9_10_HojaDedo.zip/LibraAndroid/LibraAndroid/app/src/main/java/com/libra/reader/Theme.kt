package com.libra.reader

import androidx.compose.ui.graphics.Color
import androidx.compose.material3.Typography
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

/**
 * Sistema tipográfico Libellum.
 * Jerarquía editorial: serif para encabezados y sans-serif para controles y texto funcional.
 * La familia serif del sistema es un fallback temporal; no se etiqueta como Fraunces.
 */
internal val LibellumSerif = FontFamily.Serif
internal val LibellumSans = FontFamily.SansSerif

internal val LibellumTypography = Typography().let { base ->
    base.copy(
        displayLarge = base.displayLarge.copy(fontFamily = LibellumSerif, fontWeight = FontWeight.Bold),
        displayMedium = base.displayMedium.copy(fontFamily = LibellumSerif, fontWeight = FontWeight.Bold),
        displaySmall = base.displaySmall.copy(fontFamily = LibellumSerif, fontWeight = FontWeight.Bold),
        headlineLarge = base.headlineLarge.copy(fontFamily = LibellumSerif, fontWeight = FontWeight.Bold),
        headlineMedium = base.headlineMedium.copy(fontFamily = LibellumSerif, fontWeight = FontWeight.Bold),
        headlineSmall = base.headlineSmall.copy(fontFamily = LibellumSerif, fontWeight = FontWeight.SemiBold),
        titleLarge = base.titleLarge.copy(fontFamily = LibellumSerif, fontWeight = FontWeight.SemiBold),
        titleMedium = base.titleMedium.copy(fontFamily = LibellumSans, fontWeight = FontWeight.SemiBold),
        titleSmall = base.titleSmall.copy(fontFamily = LibellumSans, fontWeight = FontWeight.Medium),
        bodyLarge = base.bodyLarge.copy(fontFamily = LibellumSans),
        bodyMedium = base.bodyMedium.copy(fontFamily = LibellumSans),
        bodySmall = base.bodySmall.copy(fontFamily = LibellumSans),
        labelLarge = base.labelLarge.copy(fontFamily = LibellumSans, fontWeight = FontWeight.SemiBold),
        labelMedium = base.labelMedium.copy(fontFamily = LibellumSans),
        labelSmall = base.labelSmall.copy(fontFamily = LibellumSans)
    )
}

// ── Paleta Libellum «papel»: fondo crema, texto azul tinta y acento dorado ───
internal val Ink    = Color(0xFFF5EFE3)  // fondo (papel)
internal val Panel  = Color(0xFFFFFAF1)  // tarjetas
internal val Cream  = Color(0xFF292D3B)  // texto principal (azul tinta)
internal val Gold   = Color(0xFF986A24)  // acento dorado/ocre
internal val Muted  = Color(0xFF5C5346)  // texto secundario

// ── Dorado vivo para la barra de lectura ───────────────────────────────────
internal val GoldDeep   = Color(0xFF986A24)  // ámbar profundo
internal val GoldBright = Color(0xFFB98232)  // oro vivo
internal val GoldLight  = Color(0xFFD9B77D)  // destello claro
internal val GoldTrack  = Color(0xFFE9DDC2)  // riel de la barra
internal val Line   = Color(0xFFE5DAC3)  // bordes finos
internal val WoodLight = Color(0xFFB98D5C)
internal val WoodDark  = Color(0xFF86592F)
internal val ShelfBack = Color(0xFFEADFC6)

// ── Colores pastel para subrayado ───────────────────────────────────────────
internal val HighlightYellow  = Color(0xFFFFF176)
internal val HighlightGreen   = Color(0xFFB9F6CA)
internal val HighlightBlue    = Color(0xFFB3E5FC)
internal val HighlightPink    = Color(0xFFF8BBD0)
internal val HighlightLavender= Color(0xFFE1BEE7)
internal val HighlightPeach   = Color(0xFFFFCCBC)

val HIGHLIGHT_COLORS = listOf(
    0xFFFFF176L to "Amarillo",
    0xFFB9F6CAL to "Verde",
    0xFFB3E5FCL to "Azul",
    0xFFF8BBD0L to "Rosa",
    0xFFE1BEE7L to "Lavanda",
    0xFFFFCCBCL to "Melocotón"
)
