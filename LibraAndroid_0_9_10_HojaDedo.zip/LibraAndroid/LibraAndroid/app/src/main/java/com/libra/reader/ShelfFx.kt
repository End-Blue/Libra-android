package com.libra.reader

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

// ══════════════════════════════════════════════════════════════════════════════
// Animaciones ambientales de la estantería (lluvia, nieve, luciérnagas…).
// Son globales: la que elijas en «Personalizar → Animación» se ve en TODAS tus estanterías,
// igual que la luz. Se dibujan encima, no tocan los gestos y el bucle es continuo (sin saltos).
// ══════════════════════════════════════════════════════════════════════════════

internal data class FxDef(val key: String, val label: String)

internal val FX_LIST: List<FxDef> = listOf(
    FxDef("NONE", "Ninguna"),
    FxDef("RAIN", "Lluvia"),
    FxDef("SNOW", "Nieve"),
    FxDef("FIREFLIES", "Luciérnagas"),
    FxDef("DUST", "Polvo de luz"),
    FxDef("STARS", "Estrellas"),
    FxDef("LEAVES", "Hojas de otoño"),
    FxDef("PETALS", "Pétalos"),
    FxDef("BUBBLES", "Burbujas"),
    FxDef("EMBERS", "Brasas")
)

private const val FX_CYCLE_MS = 30000
private val TWO_PI = (2.0 * PI).toFloat()
private val PI_F = PI.toFloat()

/** Número «aleatorio» estable en [0, 1) para la partícula [i] (misma partícula = mismo valor). */
private fun rnd(i: Int, salt: Int): Float {
    var h = i * 374761393 + salt * 668265263 + 1013904223
    h = (h xor (h ushr 13)) * 1274126177
    h = h xor (h ushr 16)
    return (h and 0x7fffffff) / 2147483647f
}

private fun fract(v: Float): Float = v - floor(v)

/** Capa animada. Ponla como último hijo de un Box y con `matchParentSize()`. */
@Composable
internal fun ShelfFxOverlay(kind: String, modifier: Modifier = Modifier) {
    if (kind.isBlank() || kind == "NONE") return
    val tr = rememberInfiniteTransition(label = "shelfFx")
    val phase by tr.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(FX_CYCLE_MS, easing = LinearEasing), RepeatMode.Restart),
        label = "shelfFxPhase"
    )
    Canvas(modifier) { drawFx(kind, phase) }
}

/** [t] va de 0 a 1 en cada ciclo; las velocidades son números enteros de vueltas, así el bucle no da saltos. */
private fun DrawScope.drawFx(kind: String, t: Float) {
    val w = size.width
    val h = size.height
    if (w <= 0f || h <= 0f) return
    val d = 1.dp.toPx()
    when (kind) {
        "RAIN" -> {
            drawRect(Color(0x143A5A8C), Offset.Zero, size)
            for (i in 0 until 70) {
                val k = 28 + (rnd(i, 1) * 14).toInt()
                val y = fract(t * k + rnd(i, 2))
                val len = (10f + rnd(i, 4) * 12f) * d
                val x = fract(rnd(i, 3) + y * 0.08f) * w
                val py = y * (h + len) - len
                drawLine(Color(0x77C4DCFF), Offset(x, py), Offset(x - len * 0.25f, py + len), 1.2f * d)
            }
        }
        "SNOW" -> {
            for (i in 0 until 60) {
                val k = 4 + (rnd(i, 1) * 4).toInt()
                val y = fract(t * k + rnd(i, 2))
                val sway = sin(TWO_PI * (t * (2 + (rnd(i, 5) * 3).toInt()) + rnd(i, 6))) * 12f * d
                val x = rnd(i, 3) * w + sway
                val r = (1.4f + rnd(i, 4) * 2.2f) * d
                val cy = y * (h + 2f * r) - r
                drawCircle(Color(0x26000000), r + 0.7f * d, Offset(x, cy))
                drawCircle(Color(0xEEFFFFFF), r, Offset(x, cy))
            }
        }
        "FIREFLIES" -> {
            for (i in 0 until 16) {
                val kx = 1 + (rnd(i, 1) * 3).toInt()
                val ky = 1 + (rnd(i, 2) * 3).toInt()
                val cx = rnd(i, 3) * w + sin(TWO_PI * (t * kx * 3 + rnd(i, 4))) * 26f * d
                val cy = rnd(i, 5) * h + cos(TWO_PI * (t * ky * 3 + rnd(i, 6))) * 22f * d
                val pulse = 0.5f + 0.5f * sin(TWO_PI * (t * (6 + (rnd(i, 7) * 10).toInt()) + rnd(i, 8)))
                drawCircle(Color(0xFFFFF08A).copy(alpha = 0.10f + 0.25f * pulse), 9f * d, Offset(cx, cy))
                drawCircle(Color(0xFFFFF4B0).copy(alpha = 0.35f + 0.6f * pulse), 2.2f * d, Offset(cx, cy))
            }
        }
        "DUST" -> {
            for (i in 0 until 34) {
                val y = 1f - fract(t * (1 + (rnd(i, 1) * 2).toInt()) + rnd(i, 2))
                val x = rnd(i, 3) * w + sin(TWO_PI * (t * (2 + (rnd(i, 4) * 3).toInt()) + rnd(i, 5))) * 14f * d
                val tw = 0.5f + 0.5f * sin(TWO_PI * (t * (5 + (rnd(i, 6) * 6).toInt()) + rnd(i, 7)))
                drawCircle(
                    Color(0xFFFFE9B0).copy(alpha = 0.15f + 0.45f * tw),
                    (1f + rnd(i, 8) * 1.6f) * d, Offset(x, y * h)
                )
            }
        }
        "STARS" -> {
            for (i in 0 until 26) {
                val x = rnd(i, 1) * w
                val y = rnd(i, 2) * h * 0.95f
                val tw = 0.5f + 0.5f * sin(TWO_PI * (t * (3 + (rnd(i, 3) * 8).toInt()) + rnd(i, 4)))
                val r = (1.5f + rnd(i, 5) * 2.5f) * d * (0.6f + 0.6f * tw)
                val c = Color(0xFFFFF3C4).copy(alpha = 0.25f + 0.7f * tw)
                drawLine(c, Offset(x - r, y), Offset(x + r, y), 1f * d)
                drawLine(c, Offset(x, y - r), Offset(x, y + r), 1f * d)
                drawCircle(c, 0.9f * d, Offset(x, y))
            }
            // estrella fugaz: una cada 10 s
            val s = fract(t * 3f)
            if (s < 0.12f) {
                val p = s / 0.12f
                val idx = (t * 3f).toInt()
                val sx = w * (0.15f + 0.5f * rnd(idx, 9)) + p * w * 0.35f
                val sy = h * (0.05f + 0.25f * rnd(idx, 10)) + p * h * 0.12f
                drawLine(
                    Color.White.copy(alpha = 1f - p),
                    Offset(sx - w * 0.08f, sy - h * 0.025f), Offset(sx, sy), 1.6f * d
                )
            }
        }
        "LEAVES" -> {
            val cols = listOf(Color(0xCCC0622B), Color(0xCCD99A2B), Color(0xCC8E3B1F), Color(0xCCB5742A))
            for (i in 0 until 16) {
                val k = 2 + (rnd(i, 1) * 2).toInt()
                val y = fract(t * k + rnd(i, 2))
                val x = rnd(i, 3) * w + sin(TWO_PI * (t * (2 + (rnd(i, 4) * 2).toInt()) + rnd(i, 5))) * 30f * d
                val ang = 360f * fract(t * (2 + (rnd(i, 6) * 3).toInt()) + rnd(i, 7))
                val lw = (7f + rnd(i, 8) * 5f) * d
                val cy = y * (h + 2f * lw) - lw
                rotate(ang, Offset(x, cy)) {
                    drawOval(cols[i % cols.size], Offset(x - lw / 2f, cy - lw / 4f), Size(lw, lw / 2f))
                }
            }
        }
        "PETALS" -> {
            val cols = listOf(Color(0xCCF6B8CC), Color(0xCCF9D0DC), Color(0xCCEFA3BE))
            for (i in 0 until 22) {
                val k = 2 + (rnd(i, 1) * 3).toInt()
                val y = fract(t * k + rnd(i, 2))
                val x = rnd(i, 3) * w + sin(TWO_PI * (t * (2 + (rnd(i, 4) * 3).toInt()) + rnd(i, 5))) * 24f * d
                val ang = 360f * fract(t * (3 + (rnd(i, 6) * 3).toInt()) + rnd(i, 7))
                val pw = (5f + rnd(i, 8) * 4f) * d
                val cy = y * (h + 2f * pw) - pw
                rotate(ang, Offset(x, cy)) {
                    drawOval(cols[i % cols.size], Offset(x - pw / 2f, cy - pw / 3f), Size(pw, pw * 0.66f))
                }
            }
        }
        "BUBBLES" -> {
            for (i in 0 until 18) {
                val k = 2 + (rnd(i, 1) * 3).toInt()
                val y = 1f - fract(t * k + rnd(i, 2))
                val x = rnd(i, 3) * w + sin(TWO_PI * (t * (3 + (rnd(i, 4) * 3).toInt()) + rnd(i, 5))) * 10f * d
                val r = (3f + rnd(i, 6) * 7f) * d
                val cy = y * (h + 2f * r) - r
                drawCircle(Color(0x22BFE6FF), r, Offset(x, cy))
                drawCircle(Color(0x99DDF2FF), r, Offset(x, cy), style = Stroke(1f * d))
                drawCircle(Color(0xAAFFFFFF), r * 0.22f, Offset(x - r * 0.38f, cy - r * 0.38f))
            }
        }
        "EMBERS" -> {
            for (i in 0 until 30) {
                val k = 3 + (rnd(i, 1) * 4).toInt()
                val f = fract(t * k + rnd(i, 2))
                val y = 1f - f
                val x = rnd(i, 3) * w + sin(TWO_PI * (t * (2 + (rnd(i, 4) * 3).toInt()) + rnd(i, 5))) * 16f * d
                val a = sin(PI_F * f)
                val flick = 0.6f + 0.4f * sin(TWO_PI * (t * (10 + (rnd(i, 6) * 10).toInt()) + rnd(i, 7)))
                val c = if (i % 3 == 0) Color(0xFFFFB347) else Color(0xFFFF7A33)
                drawCircle(c.copy(alpha = 0.18f * a * flick), 6f * d, Offset(x, y * h))
                drawCircle(c.copy(alpha = 0.9f * a * flick), (1.2f + rnd(i, 8) * 1.4f) * d, Offset(x, y * h))
            }
        }
        else -> Unit
    }
}
