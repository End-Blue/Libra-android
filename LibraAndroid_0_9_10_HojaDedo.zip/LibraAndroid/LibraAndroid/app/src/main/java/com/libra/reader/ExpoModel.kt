package com.libra.reader

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

// ══════════════════════════════════════════════════════════════════════════════
// VITRINA (expositor libre): modelo de datos, geometría y «física» de apoyo.
// Todo se guarda en SharedPreferences («libra_prefs», clave xp_board), sin tocar Room.
// Las unidades son dp y las posiciones son el CENTRO de cada objeto.
// ══════════════════════════════════════════════════════════════════════════════

internal const val X_SIDE = 9f            // grosor de los laterales de madera
internal const val X_FACE_SPINE = 0       // lomo
internal const val X_FACE_COVER = 1       // portada
internal const val X_FACE_EDGE = 2        // canto (páginas)
internal const val X_MAX_UNDO = 40

/** Un libro expuesto. [rot] en grados (sentido horario), [scale] 1 = tamaño normal. */
internal data class XBook(
    val id: String,
    val cx: Float,
    val cy: Float,
    val scale: Float = 1f,
    val rot: Float = 0f,
    val face: Int = X_FACE_COVER,
    val locked: Boolean = false,
    val z: Int = 0
)

/** Un objeto decorativo. */
internal data class XDeco(
    val id: String,
    val key: String,
    val cx: Float,
    val cy: Float,
    val scale: Float = 1f,
    val rot: Float = 0f,
    val locked: Boolean = false,
    val z: Int = 0
)

internal data class XBoard(
    val shelves: Int = 4,
    val bandH: Float = 200f,
    val plank: Float = 11f,
    val books: List<XBook> = emptyList(),
    val decos: List<XDeco> = emptyList()
)

internal data class XRef(val deco: Boolean, val id: String, val z: Int)

/** Caja que ocupa un objeto (ya girado y escalado): centro y medias-extensiones. */
internal data class XBox(
    val id: String,
    val deco: Boolean,
    val cx: Float,
    val cy: Float,
    val hw: Float,
    val hh: Float,
    val flat: Boolean
) {
    val left: Float get() = cx - hw
    val right: Float get() = cx + hw
    val top: Float get() = cy - hh
    val bottom: Float get() = cy + hh
}

/** Medidas de la vitrina: alto de cada balda, grosor de la madera y ancho disponible. */
internal class XGeo(val areaW: Float, val bandH: Float, val shelves: Int, val plankH: Float) {
    val totalH: Float get() = shelves * bandH
    val usableH: Float get() = bandH - plankH - 4f
    fun floorY(band: Int): Float = (band + 1) * bandH - plankH
    fun ceilY(band: Int): Float = band * bandH
    fun bandOf(cy: Float): Int = (cy / bandH).toInt().coerceIn(0, shelves - 1)
}

// ── Medidas ──────────────────────────────────────────────────────────────────

/** Tamaño base (ancho, alto) de un libro según la cara que se ve. */
internal fun xBookDims(b: LibraryItem, face: Int): Pair<Float, Float> {
    val hScale = 0.88f + (abs(b.title.hashCode()) % 28) / 100f
    val wScale = 0.85f + (abs((b.title + b.author).hashCode()) % 35) / 100f
    val baseH = if (b.spineHeightDp > 0) b.spineHeightDp.toFloat()
    else (114 * hScale).toInt().coerceIn(88, 150).toFloat()
    val baseW = if (b.spineWidthDp > 0) b.spineWidthDp.toFloat()
    else (30 * wScale).toInt().coerceIn(22, 42).toFloat()
    return if (face == X_FACE_COVER) (baseH * 0.68f).coerceIn(58f, 104f) to baseH else baseW to baseH
}

/** Medias-extensiones de la caja que envuelve a un rectángulo girado. */
internal fun xHalf(w: Float, h: Float, scale: Float, rot: Float): Pair<Float, Float> {
    val r = Math.toRadians(rot.toDouble())
    val c = abs(cos(r)).toFloat()
    val s = abs(sin(r)).toFloat()
    val ww = w * scale
    val hh = h * scale
    return ((c * ww + s * hh) / 2f) to ((s * ww + c * hh) / 2f)
}

/** Reduce la escala si el objeto no cabe en el alto de una balda. */
internal fun xFitScale(w: Float, h: Float, scale: Float, rot: Float, geo: XGeo): Float {
    val hh = xHalf(w, h, scale, rot).second
    return if (2f * hh > geo.usableH) scale * geo.usableH / (2f * hh) else scale
}

/** ¿El punto (px, py) cae dentro del rectángulo girado y escalado? */
internal fun xInside(
    px: Float, py: Float, cx: Float, cy: Float,
    w: Float, h: Float, scale: Float, rot: Float, slop: Float = 4f
): Boolean {
    val r = Math.toRadians(-rot.toDouble())
    val dx = px - cx
    val dy = py - cy
    val lx = (dx * cos(r) - dy * sin(r)).toFloat()
    val ly = (dx * sin(r) + dy * cos(r)).toFloat()
    return abs(lx) <= w * scale / 2f + slop && abs(ly) <= h * scale / 2f + slop
}

internal fun xBookBox(b: XBook, lib: LibraryItem): XBox {
    val dims = xBookDims(lib, b.face)
    val half = xHalf(dims.first, dims.second, b.scale, b.rot)
    val q = ((b.rot % 90f) + 90f) % 90f
    val axis = q <= 8f || q >= 82f
    return XBox(b.id, false, b.cx, b.cy, half.first, half.second, axis && half.first > half.second * 1.05f)
}

internal fun xDecoBox(d: XDeco): XBox {
    val def = xDecoDef(d.key)
    val w = (def?.w ?: 36).toFloat()
    val h = (def?.h ?: 48).toFloat()
    val half = xHalf(w, h, d.scale, d.rot)
    return XBox(d.id, true, d.cx, d.cy, half.first, half.second, false)
}

internal fun xBoxes(board: XBoard, lib: Map<String, LibraryItem>): List<XBox> {
    val out = ArrayList<XBox>()
    board.books.forEach { b ->
        val l = lib[b.id]
        if (l != null) out.add(xBookBox(b, l))
    }
    board.decos.forEach { out.add(xDecoBox(it)) }
    return out
}

internal fun xNextZ(b: XBoard): Int {
    val zb = b.books.maxOfOrNull { it.z } ?: 0
    val zd = b.decos.maxOfOrNull { it.z } ?: 0
    return maxOf(zb, zd) + 1
}

// ── Gravedad ─────────────────────────────────────────────────────────────────

/**
 * Baja un objeto desde su posición hasta apoyarse y devuelve el nuevo centro Y.
 * - Un libro se apoya en la madera de su balda o encima de un libro «tumbado» (plano).
 * - Un adorno se apoya en la madera o en cualquier libro.
 * - Si se suelta con el centro por encima de algo plano, sube a su superficie (se «sube» a la pila).
 */
internal fun xRestCy(
    cx: Float, cy: Float, hw: Float, hh: Float,
    band: Int, geo: XGeo, others: List<XBox>, selfId: String, selfDeco: Boolean
): Float {
    val floor = geo.floorY(band)
    val bandTop = geo.ceilY(band)
    val sups = ArrayList<XBox>()
    for (o in others) {
        if (o.id == selfId && o.deco == selfDeco) continue
        if (o.deco) continue
        if (!selfDeco && !o.flat) continue
        if (o.top < bandTop - 1f || o.top > floor + 1f) continue
        val ox = minOf(cx + hw, o.right) - maxOf(cx - hw, o.left)
        if (ox < maxOf(4f, 0.3f * minOf(2f * hw, 2f * o.hw))) continue
        sups.add(o)
    }
    var bottom = minOf(cy + hh, floor)
    for (iter in 0 until 8) {
        var lifted = false
        for (o in sups) {
            if (bottom > o.top + 1f && bottom - 2f * hh < o.bottom - 1f && (bottom - hh) < o.top) {
                bottom = o.top
                lifted = true
            }
        }
        if (!lifted) break
    }
    var rest = floor
    for (o in sups) {
        if (o.top >= bottom - 0.5f && o.top < rest) rest = o.top
    }
    return rest - hh
}

/**
 * Coloca un objeto soltado en (cx0, cy0): lo mete dentro de los laterales, lo apoya y,
 * si un libro se queda encima de otro, busca el hueco libre más cercano de esa balda.
 * Nunca falla: si no hay hueco, se queda donde cayó.
 */
internal fun xSettle(
    cx0: Float, cy0: Float, hw: Float, hh: Float,
    geo: XGeo, others: List<XBox>, selfId: String, selfDeco: Boolean
): Pair<Float, Float> {
    val minX = X_SIDE + hw
    val maxX = geo.areaW - X_SIDE - hw
    val cxc = if (maxX >= minX) cx0.coerceIn(minX, maxX) else geo.areaW / 2f
    val band = geo.bandOf(cy0)
    fun restAt(x: Float): Float = xRestCy(x, cy0, hw, hh, band, geo, others, selfId, selfDeco)
    val y0 = restAt(cxc)
    if (selfDeco) return cxc to y0

    fun fits(x: Float, y: Float): Boolean {
        if (y - hh < geo.ceilY(band) - 0.5f) return false
        for (o in others) {
            if (o.deco || o.id == selfId) continue
            val ox = minOf(x + hw, o.right) - maxOf(x - hw, o.left)
            val oy = minOf(y + hh, o.bottom) - maxOf(y - hh, o.top)
            if (ox > 3f && oy > 3f) return false
        }
        return true
    }
    if (fits(cxc, y0)) return cxc to y0
    var d = 3f
    while (d <= geo.areaW) {
        for (sign in intArrayOf(1, -1)) {
            val x = cxc + sign * d
            if (x < minX || x > maxX) continue
            val y = restAt(x)
            if (fits(x, y)) return x to y
        }
        d += 3f
    }
    return cxc to y0
}

/** Lo que flota cae (los de abajo primero). No sube ni mueve nada hacia los lados. */
internal fun xGravity(board: XBoard, lib: Map<String, LibraryItem>, geo: XGeo): XBoard {
    val bookList = board.books.toMutableList()
    val decoList = board.decos.toMutableList()
    fun allBoxes(): List<XBox> {
        val out = ArrayList<XBox>()
        bookList.forEach { b ->
            val l = lib[b.id]
            if (l != null) out.add(xBookBox(b, l))
        }
        decoList.forEach { out.add(xDecoBox(it)) }
        return out
    }
    val order = bookList.indices.sortedByDescending { i ->
        val l = lib[bookList[i].id]
        bookList[i].cy + (if (l != null) xBookBox(bookList[i], l).hh else 0f)
    }
    for (i in order) {
        val b = bookList[i]
        val l = lib[b.id] ?: continue
        val bx = xBookBox(b, l)
        val ny = xRestCy(b.cx, b.cy, bx.hw, bx.hh, geo.bandOf(b.cy), geo, allBoxes(), b.id, false)
        if (ny > b.cy + 0.5f) bookList[i] = b.copy(cy = ny)
    }
    for (i in decoList.indices) {
        val d = decoList[i]
        val bx = xDecoBox(d)
        val ny = xRestCy(d.cx, d.cy, bx.hw, bx.hh, geo.bandOf(d.cy), geo, allBoxes(), d.id, true)
        if (ny > d.cy + 0.5f) decoList[i] = d.copy(cy = ny)
    }
    return board.copy(books = bookList, decos = decoList)
}

/** Si cambia el grosor de la madera, todo se desplaza para seguir apoyado en la balda. */
internal fun xReseatPlank(board: XBoard, newPlank: Float): XBoard {
    val dy = board.plank - newPlank
    if (abs(dy) < 0.01f) return board
    return board.copy(
        plank = newPlank,
        books = board.books.map { it.copy(cy = it.cy + dy) },
        decos = board.decos.map { it.copy(cy = it.cy + dy) }
    )
}

/** Si cambia el alto de las baldas, cada objeto conserva su distancia a la madera de su balda. */
internal fun xRescaleBands(board: XBoard, newBandH: Float): XBoard {
    val old = board.bandH
    if (abs(old - newBandH) < 0.01f) return board
    fun move(cy: Float): Float {
        val band = (cy / old).toInt().coerceIn(0, board.shelves - 1)
        val oldFloor = (band + 1) * old - board.plank
        val newFloor = (band + 1) * newBandH - board.plank
        return newFloor - (oldFloor - cy)
    }
    return board.copy(
        bandH = newBandH,
        books = board.books.map { it.copy(cy = move(it.cy)) },
        decos = board.decos.map { it.copy(cy = move(it.cy)) }
    )
}

// ── Colocación automática (asistente / organización) ─────────────────────────

/** Reparte libros por filas, balda a balda, apoyados en la madera. */
private class XPacker(val areaW: Float, val bandH: Float, val plankH: Float) {
    var band = 0
    var cursor = X_SIDE + 8f
    val right = areaW - X_SIDE - 6f
    val books = ArrayList<XBook>()
    val decos = ArrayList<XDeco>()
    val bandEnd = HashMap<Int, Float>()
    var z = 1

    private val geo get() = XGeo(areaW, bandH, 1000, plankH)
    private fun floor(b: Int): Float = (b + 1) * bandH - plankH

    private fun need(width: Float) {
        if (cursor + width > right && cursor > X_SIDE + 9f) {
            bandEnd[band] = cursor
            band++
            cursor = X_SIDE + 8f
        }
    }

    fun addUpright(l: LibraryItem, face: Int, scale: Float, rot: Float, locked: Boolean = false) {
        val dims = xBookDims(l, face)
        val sc = xFitScale(dims.first, dims.second, scale, rot, geo)
        val half = xHalf(dims.first, dims.second, sc, rot)
        need(2f * half.first)
        books.add(
            XBook(l.id, cursor + half.first, floor(band) - half.second, sc, rot, face, locked, z++)
        )
        cursor += 2f * half.first + 2f
    }

    /** Hasta 3 libros tumbados uno encima de otro (torre baja). */
    fun addLyingGroup(group: List<LibraryItem>) {
        val items = ArrayList<Triple<LibraryItem, Float, Float>>()
        var total = 0f
        var maxW = 0f
        for (l in group) {
            val dims = xBookDims(l, X_FACE_SPINE)
            val sc = xFitScale(dims.first, dims.second, 1f, -90f, geo)
            val half = xHalf(dims.first, dims.second, sc, -90f)
            if (items.isNotEmpty() && total + 2f * half.second > geo.usableH) break
            items.add(Triple(l, half.first, half.second))
            total += 2f * half.second
            maxW = maxOf(maxW, 2f * half.first)
        }
        need(maxW)
        var bottom = floor(band)
        val cx = cursor + maxW / 2f
        for (t in items) {
            books.add(XBook(t.first.id, cx, bottom - t.third, 1f, -90f, X_FACE_SPINE, false, z++))
            bottom -= 2f * t.third
        }
        cursor += maxW + 2f
    }

    /** Cierra la última balda y devuelve cuántas se han usado. */
    fun finish(): Int {
        bandEnd[band] = cursor
        return band + 1
    }

    /** Pone los adornos al final (a la derecha) de cada balda con hueco libre. */
    fun seatDecos(source: List<XDeco>, shelves: Int): Int {
        var shelvesNow = shelves
        val rightFree = HashMap<Int, Float>()
        for (b in 0 until shelvesNow) rightFree[b] = right
        for (d in source) {
            val def = xDecoDef(d.key) ?: continue
            val w = def.w * d.scale
            val h = def.h * d.scale
            var b = 0
            while (true) {
                val leftBound = (bandEnd[b] ?: (X_SIDE + 8f))
                val rf = rightFree[b] ?: right
                if (rf - w >= leftBound + 4f) {
                    decos.add(d.copy(cx = rf - w / 2f, cy = floor(b) - h / 2f, rot = 0f))
                    rightFree[b] = rf - w - 4f
                    break
                }
                b++
                if (b >= shelvesNow) {
                    shelvesNow = b + 1
                    rightFree[b] = right
                }
            }
        }
        return shelvesNow
    }
}

private fun xKind(b: LibraryItem): Int = abs(b.id.hashCode()) % 10

/**
 * Asistente: llena el expositor con [items].
 * [mode] 0 = portadas, 1 = lomos, 2 = mezcla realista (lomos, portadas, inclinados y torres tumbadas).
 * [decoLevel] 0 = sin adornos, 1 = pocos, 2 = muchos. Si [keepDecos] no es nulo se recolocan esos adornos.
 */
internal fun xAssist(
    items: List<LibraryItem>, mode: Int, decoLevel: Int,
    areaW: Float, bandH: Float, plankH: Float, keepDecos: List<XDeco>? = null
): XBoard {
    val p = XPacker(areaW, bandH, plankH)
    var i = 0
    while (i < items.size) {
        val b = items[i]
        when (mode) {
            0 -> { p.addUpright(b, X_FACE_COVER, 1f, 0f); i++ }
            1 -> { p.addUpright(b, X_FACE_SPINE, 1f, 0f); i++ }
            else -> {
                val k = xKind(b)
                if (k >= 8) {
                    val group = ArrayList<LibraryItem>()
                    group.add(b)
                    var j = i + 1
                    while (j < items.size && group.size < 3 && xKind(items[j]) >= 8) {
                        group.add(items[j])
                        j++
                    }
                    p.addLyingGroup(group)
                    i = j
                } else if (k == 7) {
                    p.addUpright(b, X_FACE_SPINE, 1f, if (i % 2 == 0) 9f else -9f)
                    i++
                } else if (k <= 3) {
                    p.addUpright(b, X_FACE_SPINE, 1f, 0f)
                    i++
                } else {
                    p.addUpright(b, X_FACE_COVER, 1f, 0f)
                    i++
                }
            }
        }
    }
    var shelves = maxOf(3, p.finish())

    val decoSource: List<XDeco> = keepDecos ?: run {
        val pool = listOf(
            "monstera", "candle", "globe", "succulents", "owl", "fern", "coffee",
            "bonsai", "lamp", "stones", "cat", "orchid", "clock", "terrarium"
        )
        val out = ArrayList<XDeco>()
        if (decoLevel > 0) {
            var n = 0
            for (b in 0 until shelves) {
                val perBand = if (decoLevel >= 2) 2 else (if (b % 2 == 0) 1 else 0)
                for (k in 0 until perBand) {
                    val key = pool[(b * 3 + k * 5 + n) % pool.size]
                    out.add(XDeco("d" + java.util.UUID.randomUUID().toString(), key, 0f, 0f, 1.1f, 0f, false, 1000 + n))
                    n++
                }
            }
        }
        out
    }
    shelves = p.seatDecos(decoSource, shelves)
    // Los adornos van detrás de los libros
    val decos = p.decos.mapIndexed { idx, d -> d.copy(z = idx) }
    val books = p.books.map { it.copy(z = it.z + decos.size + 1) }
    return XBoard(shelves = shelves, bandH = bandH, plank = plankH, books = books, decos = decos)
}

/** Reordena los libros que ya están en la vitrina (conservan cara y tamaño; se enderezan). */
internal fun xRepack(
    board: XBoard, lib: Map<String, LibraryItem>, order: List<String>, areaW: Float
): XBoard {
    val p = XPacker(areaW, board.bandH, board.plank)
    val byId = board.books.associateBy { it.id }
    for (id in order) {
        val xb = byId[id] ?: continue
        val l = lib[id] ?: continue
        p.addUpright(l, xb.face, xb.scale, 0f, xb.locked)
    }
    var shelves = maxOf(board.shelves, p.finish())
    shelves = p.seatDecos(board.decos.sortedBy { it.z }, shelves)
    val decos = p.decos.mapIndexed { idx, d -> d.copy(z = idx) }
    val books = p.books.map { it.copy(z = it.z + decos.size + 1) }
    return board.copy(shelves = shelves, books = books, decos = decos)
}

// ── Guardado ─────────────────────────────────────────────────────────────────

/** Una estantería del usuario (cada una tiene su propio tablero). */
internal data class XShelfInfo(val id: String, val name: String)

/**
 * Guarda VARIAS estanterías. Índice en `xp_shelves` ({"active": id, "list": [{"id","n"}]}) y un tablero por
 * estantería en `xp_board_<id>`. La estantería que ya tenías (clave antigua `xp_board`) pasa a ser la primera.
 */
internal object ExpoStore {
    private const val PREFS = "libra_prefs"
    private const val LEGACY = "xp_board"
    private const val INDEX = "xp_shelves"
    const val MAX_SHELVES = 30

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, 0)
    private fun key(id: String) = "xp_board_$id"

    private fun readIndex(ctx: Context): Pair<String, List<XShelfInfo>> {
        val raw = prefs(ctx).getString(INDEX, null)
        if (raw != null) {
            try {
                val o = JSONObject(raw)
                val arr = o.optJSONArray("list") ?: JSONArray()
                val list = ArrayList<XShelfInfo>()
                for (i in 0 until arr.length()) {
                    val e = arr.getJSONObject(i)
                    val id = e.optString("id")
                    if (id.isNotBlank()) list.add(XShelfInfo(id, e.optString("n").ifBlank { "Estantería" }))
                }
                if (list.isNotEmpty()) {
                    val act = o.optString("active")
                    return (if (list.any { it.id == act }) act else list[0].id) to list
                }
            } catch (_: Exception) {
            }
        }
        // Primera vez con varias estanterías: la de siempre pasa a ser «Mi estantería»
        val first = XShelfInfo("s1", "Mi estantería")
        val legacy = prefs(ctx).getString(LEGACY, null)
        val ed = prefs(ctx).edit()
        if (legacy != null) ed.putString(key(first.id), legacy)
        ed.apply()
        writeIndex(ctx, first.id, listOf(first))
        return first.id to listOf(first)
    }

    private fun writeIndex(ctx: Context, active: String, list: List<XShelfInfo>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("n", it.name)) }
        prefs(ctx).edit().putString(INDEX, JSONObject().put("active", active).put("list", arr).toString()).apply()
    }

    fun shelves(ctx: Context): List<XShelfInfo> = readIndex(ctx).second

    fun activeId(ctx: Context): String = readIndex(ctx).first

    fun setActive(ctx: Context, id: String) {
        val (_, list) = readIndex(ctx)
        if (list.any { it.id == id }) writeIndex(ctx, id, list)
    }

    /** Crea una estantería vacía y la deja como activa. Devuelve su id. */
    fun create(ctx: Context, name: String): String {
        val (_, list) = readIndex(ctx)
        val id = "s" + java.lang.Long.toString(System.currentTimeMillis(), 36) + list.size
        val clean = name.trim().ifBlank { "Estantería ${list.size + 1}" }.take(32)
        save(ctx, id, XBoard())
        writeIndex(ctx, id, list + XShelfInfo(id, clean))
        return id
    }

    fun rename(ctx: Context, id: String, name: String) {
        val (act, list) = readIndex(ctx)
        val clean = name.trim().take(32)
        if (clean.isBlank()) return
        writeIndex(ctx, act, list.map { if (it.id == id) it.copy(name = clean) else it })
    }

    /** Elimina una estantería (siempre queda al menos una). Devuelve el id que pasa a estar activo. */
    fun delete(ctx: Context, id: String): String {
        val (act, list) = readIndex(ctx)
        if (list.size <= 1) return act
        val rest = list.filter { it.id != id }
        prefs(ctx).edit().remove(key(id)).apply()
        val next = if (act == id) rest[0].id else act
        writeIndex(ctx, next, rest)
        return next
    }

    /** Cuántos libros y objetos tiene una estantería (para mostrarlo en la lista). */
    fun counts(ctx: Context, id: String): Pair<Int, Int> {
        val b = load(ctx, id) ?: return 0 to 0
        return b.books.size to b.decos.size
    }

    fun load(ctx: Context, id: String): XBoard? {
        val raw = prefs(ctx).getString(key(id), null) ?: return null
        return try {
            val o = JSONObject(raw)
            val books = ArrayList<XBook>()
            val ba = o.optJSONArray("books") ?: JSONArray()
            for (i in 0 until ba.length()) {
                val b = ba.getJSONObject(i)
                books.add(
                    XBook(
                        id = b.getString("id"),
                        cx = b.optDouble("x", 0.0).toFloat(),
                        cy = b.optDouble("y", 0.0).toFloat(),
                        scale = b.optDouble("s", 1.0).toFloat(),
                        rot = b.optDouble("r", 0.0).toFloat(),
                        face = b.optInt("f", X_FACE_COVER),
                        locked = b.optInt("l", 0) == 1,
                        z = b.optInt("z", 0)
                    )
                )
            }
            val decos = ArrayList<XDeco>()
            val da = o.optJSONArray("decos") ?: JSONArray()
            for (i in 0 until da.length()) {
                val d = da.getJSONObject(i)
                val k = d.optString("k")
                if (xDecoDef(k) == null) continue
                decos.add(
                    XDeco(
                        id = d.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
                        key = k,
                        cx = d.optDouble("x", 0.0).toFloat(),
                        cy = d.optDouble("y", 0.0).toFloat(),
                        scale = d.optDouble("s", 1.0).toFloat(),
                        rot = d.optDouble("r", 0.0).toFloat(),
                        locked = d.optInt("l", 0) == 1,
                        z = d.optInt("z", 0)
                    )
                )
            }
            XBoard(
                shelves = o.optInt("shelves", 4).coerceIn(1, 40),
                bandH = o.optDouble("bandH", 200.0).toFloat().coerceIn(120.0f, 320.0f),
                plank = o.optDouble("plank", 11.0).toFloat(),
                books = books,
                decos = decos
            )
        } catch (_: Exception) {
            null
        }
    }

    fun save(ctx: Context, id: String, b: XBoard) {
        val o = JSONObject()
        o.put("shelves", b.shelves)
        o.put("bandH", b.bandH.toDouble())
        o.put("plank", b.plank.toDouble())
        val ba = JSONArray()
        b.books.forEach { x ->
            ba.put(
                JSONObject().put("id", x.id).put("x", x.cx.toDouble()).put("y", x.cy.toDouble())
                    .put("s", x.scale.toDouble()).put("r", x.rot.toDouble()).put("f", x.face)
                    .put("l", if (x.locked) 1 else 0).put("z", x.z)
            )
        }
        o.put("books", ba)
        val da = JSONArray()
        b.decos.forEach { x ->
            da.put(
                JSONObject().put("id", x.id).put("k", x.key).put("x", x.cx.toDouble()).put("y", x.cy.toDouble())
                    .put("s", x.scale.toDouble()).put("r", x.rot.toDouble())
                    .put("l", if (x.locked) 1 else 0).put("z", x.z)
            )
        }
        o.put("decos", da)
        prefs(ctx).edit().putString(key(id), o.toString()).apply()
    }
}
