package com.libra.reader

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AColor
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.webkit.WebView
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas as ComposeCanvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

// ══════════════════════════════════════════════════════════════════════════════
// Hoja de libro que se pliega (única animación de paso de hoja de Libellum)
//
// Cómo funciona: antes de cambiar de hoja se fotografía el WebView; se cambia de hoja
// al instante, se fotografía la hoja nueva y se anima una hoja de papel que se despega
// por el borde, se curva sobre un cilindro, muestra su reverso y proyecta sombra.
// Hacia delante: la hoja actual se levanta por el borde derecho y se va hacia el lomo.
// Hacia atrás: la hoja anterior vuelve desde el lomo y se posa sobre la actual.
// Si algo falla (no se puede fotografiar), el cambio de hoja es instantáneo y correcto.
// ══════════════════════════════════════════════════════════════════════════════

private const val CURL_MS = 560

/** Hoja pendiente de abrir al llegar a un capítulo: texto exacto de un subrayado. */
class PendingTextJump(val chapter: Int, val text: String, val k: Int) {
    var tries: Int = 0
}

@Stable
class PageCurlState {
    var old by mutableStateOf<Bitmap?>(null)
    var fresh by mutableStateOf<Bitmap?>(null)
    var forward by mutableStateOf(true)
    var t by mutableFloatStateOf(0f)
    var active by mutableStateOf(false)

    private var job: Job? = null
    private var gate: CompletableDeferred<Unit>? = null

    // ── arrastre con el dedo ──
    private var dragging = false                 // el dedo sigue en la pantalla
    private var undoPending = false              // se está devolviendo la hoja a su sitio
    private var dragFinish: Boolean? = null      // qué decidió el dedo al soltar (null = aún arrastra)
    private var dragScope: CoroutineScope? = null
    private var dragView: View? = null
    private var dragCommit: (() -> Unit)? = null
    private var dragUndo: (() -> Unit)? = null

    /** El WebView avisa de que un capítulo nuevo ya está paginado. */
    fun pagesReady() {
        gate?.complete(Unit)
    }

    fun clear() {
        job?.cancel()
        job = null
        gate = null
        dragging = false
        undoPending = false
        dragFinish = null
        dragScope = null
        dragView = null
        dragCommit = null
        dragUndo = null
        active = false
        old = null
        fresh = null
        t = 0f
    }

    /**
     * Cambia de hoja con la animación.
     * [waitForPages] = true cuando [change] carga otro capítulo (hay que esperar a que se pagine).
     */
    fun turn(
        scope: CoroutineScope,
        view: View?,
        forward: Boolean,
        waitForPages: Boolean = false,
        change: () -> Unit
    ) {
        if (dragging || undoPending) {
            // un arrastre sin terminar: se descarta y el cambio pedido se hace directo
            clear()
            change()
            return
        }
        val shot = captureView(view)
        job?.cancel()
        if (shot == null) {
            clear()
            change()
            return
        }
        this.forward = forward
        old = shot
        fresh = null
        t = 0f
        active = true
        val g = if (waitForPages) CompletableDeferred<Unit>() else null
        gate = g
        change()
        job = scope.launch {
            try {
                if (g != null) withTimeoutOrNull(1600L) { g.await() }
                if (view is WebView) withTimeoutOrNull(400L) { awaitVisual(view) }
                delay(if (g != null) 90L else 30L)
                val nb = captureView(view)
                if (nb == null) {
                    clear()
                    return@launch
                }
                fresh = nb
                val a = Animatable(0f)
                a.animateTo(1f, tween(CURL_MS, easing = FastOutSlowInEasing)) { t = value }
                clear()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                clear()
            }
        }
    }

    /**
     * Empieza a arrastrar la hoja con el dedo. Devuelve false si no se puede (entonces el
     * gesto sigue su camino normal). [change] lleva el WebView a la hoja de destino,
     * [undo] lo devuelve a la de origen y [commit] anota en el lector que se cambió de hoja.
     */
    fun beginDrag(
        scope: CoroutineScope,
        view: View?,
        forward: Boolean,
        change: () -> Unit,
        undo: () -> Unit,
        commit: () -> Unit
    ): Boolean {
        if (dragging || undoPending) return false
        val shot = captureView(view) ?: return false
        job?.cancel()
        this.forward = forward
        old = shot
        fresh = null
        t = 0f
        active = true
        dragging = true
        dragFinish = null
        dragScope = scope
        dragView = view
        dragCommit = commit
        dragUndo = undo
        change()
        job = scope.launch {
            try {
                if (view is WebView) withTimeoutOrNull(400L) { awaitVisual(view) }
                delay(30L)
                val nb = captureView(view)
                if (nb == null) {
                    // no se puede seguir al dedo: el giro se da por hecho, sin animación
                    val done = dragCommit
                    clear()
                    done?.invoke()
                    return@launch
                }
                fresh = nb
                val f = dragFinish
                if (f != null) runFinish(f)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                val done = dragCommit
                clear()
                done?.invoke()
            }
        }
        return true
    }

    /** Progreso del arrastre: 0 = hoja plana, 1 = hoja totalmente pasada. */
    fun dragTo(progress: Float) {
        if (dragging && dragFinish == null) t = progress.coerceIn(0f, 1f)
    }

    /** El dedo se levantó: [complete] = true termina el giro; false devuelve la hoja a su sitio. */
    fun endDrag(complete: Boolean) {
        if (!dragging || dragFinish != null) return
        dragFinish = complete
        if (fresh != null) {
            val sc = dragScope ?: return
            job?.cancel()
            job = sc.launch {
                try {
                    runFinish(complete)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    clear()
                }
            }
        }
        // si la hoja nueva aún se está fotografiando, la tarea de beginDrag termina el giro al acabar
    }

    private suspend fun runFinish(complete: Boolean) {
        dragging = false
        val from = t
        if (complete) {
            dragCommit?.invoke()
            val a = Animatable(from)
            a.animateTo(1f, tween((140 + 360 * (1f - from)).toInt(), easing = FastOutSlowInEasing)) { t = value }
            clear()
        } else {
            undoPending = true
            val a = Animatable(from)
            a.animateTo(0f, tween((140 + 300 * from).toInt(), easing = FastOutSlowInEasing)) { t = value }
            dragUndo?.invoke()
            val v = dragView
            if (v is WebView) withTimeoutOrNull(400L) { awaitVisual(v) }
            delay(30L)
            clear()
        }
    }
}

/** Fotografía lo que está pintando una vista (null si no se puede o sale en blanco). */
fun captureView(v: View?): Bitmap? {
    if (v == null || v.width <= 0 || v.height <= 0) return null
    return try {
        val bmp = Bitmap.createBitmap(v.width, v.height, Bitmap.Config.ARGB_8888)
        v.draw(Canvas(bmp))
        if (AColor.alpha(bmp.getPixel(bmp.width / 2, bmp.height / 2)) == 0) null else bmp
    } catch (e: Throwable) {
        null
    }
}

/** Espera a que el WebView haya pintado lo último que se le pidió. */
private suspend fun awaitVisual(wv: WebView) = suspendCancellableCoroutine<Unit> { c ->
    try {
        wv.postVisualStateCallback(System.nanoTime(), object : WebView.VisualStateCallback() {
            override fun onComplete(requestId: Long) {
                if (c.isActive) c.resume(Unit)
            }
        })
    } catch (e: Throwable) {
        if (c.isActive) c.resume(Unit)
    }
}

/** Capa que se dibuja encima del lector mientras dura el giro de hoja. */
@Composable
fun PageCurlOverlay(state: PageCurlState, modifier: Modifier = Modifier) {
    if (!state.active) return
    ComposeCanvas(modifier) {
        val o = state.old
        if (o != null) {
            drawIntoCanvas { cv ->
                CurlPainter.draw(cv.nativeCanvas, size.width, size.height, o, state.fresh, state.forward, state.t)
            }
        }
    }
}

private object CurlPainter {
    private const val N = 200                       // columnas de la malla (curva suave)
    private val PI_F = Math.PI.toFloat()
    private val verts = FloatArray((N + 1) * 4)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dst = RectF()

    fun draw(c: Canvas, w: Float, h: Float, old: Bitmap, fresh: Bitmap?, forward: Boolean, t: Float) {
        dst.set(0f, 0f, w, h)
        if (fresh == null) {
            c.drawBitmap(old, null, dst, paint)
            return
        }
        // Hacia delante se levanta la hoja actual; hacia atrás vuelve la anterior (el giro al revés)
        if (forward) turn(c, w, h, old, fresh, t) else turn(c, w, h, fresh, old, 1f - t)
    }

    private fun alpha(a: Float, rgb: Int = 0): Int =
        ((a.coerceIn(0f, 1f) * 255f).toInt() shl 24) or (rgb and 0xFFFFFF)

    private fun paperColor(b: Bitmap): Int = try {
        b.getPixel(minOf(3, b.width - 1), b.height / 2) or (0xFF shl 24)
    } catch (e: Throwable) {
        0xFFF4EEE0.toInt()
    }

    /** p = 0: la hoja está plana sobre la página · p = 1: la hoja ya salió por el lomo. */
    private fun turn(c: Canvas, w: Float, h: Float, leaf: Bitmap, under: Bitmap, p: Float) {
        c.drawBitmap(under, null, dst, paint)

        val s = sin(PI_F * p).coerceAtLeast(0f)
        val r = w * (0.035f + 0.055f * s)           // radio del rizo: crece a mitad del giro
        val xf = w + (-0.04f * w - w) * p           // línea de pliegue: del borde derecho al lomo

        // 1) Sombra que la hoja proyecta sobre la página de debajo
        val sa = s.pow(0.6f)
        if (sa > 0.01f) {
            val left = xf + r * 0.5f
            val sw = w * (0.05f + 0.13f * s)
            fill.shader = LinearGradient(
                left, 0f, left + sw, 0f, alpha(0.42f * sa), 0, Shader.TileMode.CLAMP
            )
            c.drawRect(left, 0f, left + sw, h, fill)
            fill.shader = null
        }

        // 2) La hoja: malla de bitmap enrollada sobre un cilindro en la línea de pliegue
        var k = 0
        for (row in 0..1) {
            val y = if (row == 0) 0f else h
            for (i in 0..N) {
                val x = w * i / N
                val d = x - xf
                val px: Float
                val z: Float
                if (d <= 0f) {
                    px = x; z = 0f
                } else if (d < PI_F * r) {
                    val th = d / r
                    px = xf + r * sin(th); z = r * (1f - cos(th))
                } else {
                    px = xf - (d - PI_F * r); z = 2f * r
                }
                val sc = 1f + 0.045f * (z / (2f * r))   // el papel levantado se ve un poco mayor
                verts[k++] = px
                verts[k++] = h / 2f + (y - h / 2f) * sc
            }
        }
        c.drawBitmapMesh(leaf, N, 1, verts, 0, null, 0, paint)

        // 3) Reverso del papel (se transparenta un poco el texto de la cara delantera)
        val dMax = w - xf
        if (dMax > PI_F * r / 2f) {
            val xEnd = if (dMax < PI_F * r) xf + r * sin(dMax / r) else xf - (dMax - PI_F * r)
            val crest = xf + r

            // sombra del borde libre de la hoja sobre la página que queda
            if (xEnd > 0f && sa > 0.01f) {
                val sw2 = w * 0.05f
                fill.shader = LinearGradient(
                    xEnd - sw2, 0f, xEnd, 0f, 0, alpha(0.30f * sa), Shader.TileMode.CLAMP
                )
                c.drawRect(xEnd - sw2, 0f, xEnd, h, fill)
                fill.shader = null
            }

            val paper = paperColor(leaf)
            fill.color = (paper and 0xFFFFFF) or (0xD0 shl 24)
            c.drawRect(xEnd, 0f, crest, h, fill)

            // brillo suave del papel: más oscuro hacia el borde libre
            if (xf > xEnd) {
                fill.shader = LinearGradient(
                    xEnd, 0f, xf, 0f, alpha(0.16f), 0, Shader.TileMode.CLAMP
                )
                c.drawRect(xEnd, 0f, xf, h, fill)
                fill.shader = null
            }

            // el rizo: sombra al arrancar, luz en la cresta y borde oscuro donde se dobla
            fill.shader = LinearGradient(
                xf, 0f, crest, 0f,
                intArrayOf(0, alpha(0.12f), alpha(0.34f, 0xFFFFFF), alpha(0.30f)),
                floatArrayOf(0f, 0.40f, 0.78f, 1f),
                Shader.TileMode.CLAMP
            )
            c.drawRect(xf, 0f, crest, h, fill)
            fill.shader = null
        }
    }
}
