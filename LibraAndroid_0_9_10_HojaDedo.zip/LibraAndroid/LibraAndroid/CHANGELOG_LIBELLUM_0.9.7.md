# Libellum 0.9.7 — Lector: marcadores con listón, posición exacta, animación de hoja

## Panel
- **X y marcas intercambiadas:** la X para cerrar el libro queda arriba a la izquierda; el botón de marcas/anotaciones, arriba a la derecha (la tarjeta se abre desde ahí).
- **Marcadores + Capítulos:** la pestaña de marcadores ahora trae debajo la lista de capítulos (el actual resaltado en dorado); tocar uno te lleva a él.

## Marcador funcional con listón rojo
- Botón de la pestaña Marcadores: **pone / quita** el marcador en la hoja que estás leyendo (se vuelve rojo si ya está marcada).
- En esa hoja aparece un **listón rojo** pegado al lateral izquierdo (tela con brillo, pespunte, muesca en V y sombra), que cae con un pequeño rebote. Mantén pulsado el listón para quitarlo.
- El marcador guarda el **texto exacto** de la hoja (no solo el capítulo): al tocarlo en la lista, vuelves a esa hoja aunque cambies tamaño o fuente.
- Ajustes › Página › icono de marcador = mostrar/ocultar el listón (clave `bookmarkStyle` = "NONE" lo oculta).

## Reabrir en la hoja exacta
- Se guarda el texto de la hoja actual (`pg_<idLibro>` = capítulo|desplazamiento en SharedPreferences, con 650 ms de retardo para no escribir en cada gesto).
- Al abrir, el lector coloca esa hoja desde el primer fotograma y la mantiene durante el remedido inicial (imágenes/fuentes).

## Paso de hoja animado (EPUB) — por defecto «Cambio»
Antes EPUB cambiaba de hoja al instante (las animaciones solo existían en otros formatos). Ahora, dentro de la página:
- **Cambio:** desliza (240 ms, salida suave).  **Retirada:** desliza + sombra del canto de la hoja que se retira (380 ms).
- **Superposición:** fundido por encima de la hoja (110 + 170 ms).  **Voluta:** desplazamiento largo y continuo (460 ms).  **Sin animación:** instantáneo.
- Cada animación termina SIEMPRE en la hoja exacta (seguro por tiempo), se puede interrumpir con otro paso y no toca el resto del maquetado.
- El capítulo nuevo aparece con un fundido suave de 160 ms.

## Tipografía
- «Serif» y «Clásica» eran la misma (Georgia no existe en Android). **Clásica ahora es Lora** (OFL), incluida en `assets/fonts/` y servida al lector EPUB; también se usa en el lector de texto y en la vista previa del panel.

## Subrayar
- El subrayado se pinta **al instante y en el sitio exacto** de la selección (antes se pintaba la primera aparición del texto en el capítulo, que a veces estaba en otra hoja). Se guarda qué aparición era para repintarla igual al reabrir.
- Al subrayar **una palabra**, el cuadro muestra su **traducción/definición** del diccionario en cuanto llega, con opción «Guardar la traducción en la nota» (aparece luego en Notas y Resaltados). Requiere internet, como el diccionario.

## Archivos
`Reader.kt` · `ReaderPanels.kt` · `ReaderIcons.kt` · `Highlights.kt` · `assets/fonts/{lora,lora-italic}.ttf` · `app/build.gradle.kts` (0.9.7 / 19)
