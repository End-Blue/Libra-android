# Libellum 0.9.6 — Panel del lector rediseñado

## Qué cambia
- **Ajustes de lectura → botón flotante abajo a la derecha.** Abre una tarjeta compacta con 4 pestañas de icono:
  Texto (tamaño · fuente · interlineado), Página (márgenes · justificado · sangría · cinta),
  Pasar hoja y pantalla (5 animaciones · auto/vertical/horizontal · mano izquierda · botones ◀ ▶),
  Tema y brillo. Una sola línea de texto muestra nombre y valor de lo último que tocaste; ↺ restablece.
- **Anotaciones → botón flotante arriba a la izquierda** (sustituye a «Volver» y a los iconos de notas y de ajustes de la barra superior;
  el libro se cierra con ✕ o con el gesto atrás). Tarjeta con 3 pestañas: **Marcadores · Notas · Resaltados**.
- **Resaltados expandibles:** al abrir la pestaña la tarjeta crece (ancho y alto) y cada resaltado muestra la
  **oración completa** (serif, con la barra y el fondo del color elegido). Si es muy larga, «Ver toda la oración» la despliega;
  ⌃/⌄ contrae o expande la tarjeta. Desde cada resaltado: ir al texto (EPUB), editar nota/color, eliminar.
- **Marcadores nuevos (EPUB):** «+» guarda la hoja actual; tocarlo te lleva a ese capítulo. Se guardan en SharedPreferences
  (clave `bm_<idLibro>`), la base de datos Room no cambia (no hace falta migración).
- Tocar fuera de una tarjeta la cierra. Los dos botones aparecen con las opciones del lector (toque central) y se
  convierten en ✕ cuando su tarjeta está abierta. Si activas «Botones ◀ ▶», el botón de ajustes sube para no taparlos.

## Archivos
- NUEVO `ReaderPanels.kt` — botones, tarjeta de ajustes, tarjeta de anotaciones, marcadores.
- NUEVO `ReaderIcons.kt` — 23 iconos dibujados con Canvas (mismo estilo que Icons.kt).
- `Reader.kt` — `ReaderScreen` usa `ReaderFloatingPanels`; se eliminan `ReaderSettingsPanel`, `Adj`, `ReaderChipRow`, `MiniChip`
  y la hoja inferior de notas; `EpubReader` recibe `jumpChapter` / `onJumpConsumed`.
- `app/build.gradle.kts` — versionCode 18 · versionName 0.9.6.

## Colores
Los paneles usan azul noche + dorado (constantes `Rp*` al inicio de `ReaderPanels.kt`).
Para igualarlos al tema «papel» de la app, cambia esas 7 constantes por `Panel`, `Ink`, `Line`, `Gold`, `Cream`, `Muted`.
