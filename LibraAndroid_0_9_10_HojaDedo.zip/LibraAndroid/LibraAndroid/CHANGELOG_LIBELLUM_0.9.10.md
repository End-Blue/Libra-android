# Libellum 0.9.10

## Pasar de hoja: una sola animación, la de la hoja de libro
- Se eliminan Cambio, Retirada, Superposición, Voluta y Sin animación (y su selector en Ajustes de lectura).
- Nueva animación `PageCurl.kt`: la hoja se despega por el borde, se curva sobre un cilindro, muestra su reverso de papel (con el texto transparentándose) y proyecta sombra sobre la página de debajo.
  - Hacia delante: la hoja actual se levanta por el borde derecho y se va hacia el lomo.
  - Hacia atrás: la hoja anterior vuelve desde el lomo y se posa sobre la actual.
  - También se usa al cambiar de capítulo.
- Si el dispositivo no permite fotografiar la página, el cambio de hoja es instantáneo (nunca se queda a medias).
- Los lectores de PDF/TXT/otros cambian de página directamente, sin animación.

## Subrayados que llevan a la hoja exacta
- En la pestaña Notas (biblioteca): tocar cualquier subrayado (o «Ir al texto») abre el libro en la hoja donde está subrayado.
- En el lector (panel de notas/resaltados): tocar cualquier nota o resaltado salta a esa hoja exacta; el lápiz edita.
- Usa el texto subrayado y su aparición exacta (si la palabra se repite, va a la que subrayaste).

## La hoja sigue al dedo
- Arrastra horizontalmente y la hoja se despega y se curva siguiendo el dedo (derecha→izquierda = adelante, izquierda→derecha = atrás).
- Al soltar: si pasaste de ~1/3 de la pantalla (o fue un gesto rápido) termina de pasar; si no, la hoja vuelve a su sitio.
- Mantener pulsado sigue seleccionando texto; los toques en los bordes siguen pasando hoja con la animación por tiempo.
- En la primera/última hoja de un capítulo el gesto usa el giro normal (cambio de capítulo).

## Corrección del salto a subrayados
- Probado en Chromium: el salto cae en la hoja exacta, también con palabras repetidas.
- Corregido: si el maquetado cambiaba justo después de abrir el capítulo (fuentes/imágenes), el texto se desplazaba a otra hoja. Ahora el salto queda anclado al texto.
