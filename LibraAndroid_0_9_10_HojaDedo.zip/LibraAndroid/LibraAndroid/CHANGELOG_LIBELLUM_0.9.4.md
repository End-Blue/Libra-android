# Libellum 0.9.4 — Panel de inicio

- Rediseño del panel con cabecera editorial ilustrada, paleta pergamino/sepia y tarjetas de lectura.
- Racha semanal más compacta; el día se registra al acumular al menos 30 segundos en el lector.
- Tarjeta «Leyendo ahora» con portada, progreso, tiempo total acumulado y última sesión.
- Gráfico semanal interactivo por día, alimentado con minutos reales de lectura.
- Carrusel de libros añadidos recientemente y accesos funcionales a Ajustes y Biblioteca.
- Importar libros y escanear documentos dejan de mostrarse en el panel y pasan a Ajustes > Gestión de biblioteca.
- Se desactiva el escaneo automático al iniciar por primera vez.
- Se actualiza la paleta a sepia cálido y se usa la familia serif del sistema como sustituto tipográfico local.

Nota: el proyecto recibido no incluía Fraunces.ttf y el entorno de trabajo no permitió descargar el archivo binario. Por eso esta versión usa la serif nativa de Android en los encabezados; la incorporación exacta de Fraunces queda pendiente de añadir el archivo TTF/OTF licenciado en `res/font`.

Las estadísticas nuevas empiezan a acumularse desde esta versión; no se reconstruyen sesiones históricas que la app anterior no guardaba.
