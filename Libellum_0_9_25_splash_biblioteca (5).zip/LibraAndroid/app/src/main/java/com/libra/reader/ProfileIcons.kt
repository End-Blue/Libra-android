package com.libra.reader

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Iconos de trazo fino (rejilla 24×24) que usa la pantalla «Mi Perfil Lector». */
internal enum class PIcon {
    HEADPHONES, CLOUD_UP, CLOUD_CHECK, DATABASE, SHARE_UP, DOWNLOAD, SCAN, SHIELD, INFO,
    DOTS_CIRCLE, GRAD_CAP, RESTORE, SHARE_NODES, PENCIL, MASK, QUILL, PLAY
}

@Composable
internal fun PIconView(kind: PIcon, modifier: Modifier = Modifier, tint: Color = LbBrown, size: Dp = 24.dp) {
    Canvas(modifier.size(size)) { drawPIcon(kind, tint) }
}

private fun DrawScope.drawPIcon(kind: PIcon, c: Color) {
    val u = size.minDimension / 24f
    val line = Stroke(width = 1.7f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
    val thin = Stroke(width = 1.3f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
    fun o(x: Float, y: Float) = Offset(x * u, y * u)
    fun seg(x1: Float, y1: Float, x2: Float, y2: Float, w: Stroke = line) =
        drawLine(c, o(x1, y1), o(x2, y2), w.width, StrokeCap.Round)
    fun path(block: Path.() -> Unit) = Path().apply(block)
    fun Path.m(x: Float, y: Float) = moveTo(x * u, y * u)
    fun Path.l(x: Float, y: Float) = lineTo(x * u, y * u)
    fun Path.cu(a: Float, b: Float, cc: Float, d: Float, e: Float, f: Float) =
        cubicTo(a * u, b * u, cc * u, d * u, e * u, f * u)

    val cloud = path {
        m(7f, 18f)
        cu(4.5f, 18f, 3f, 16.2f, 3f, 14.3f)
        cu(3f, 12.5f, 4.4f, 11f, 6.3f, 10.8f)
        cu(6.8f, 8f, 9f, 6f, 11.8f, 6f)
        cu(14.6f, 6f, 16.8f, 7.8f, 17.4f, 10.3f)
        cu(19.6f, 10.5f, 21f, 12.2f, 21f, 14.2f)
        cu(21f, 16.3f, 19.4f, 18f, 17.2f, 18f)
        close()
    }

    when (kind) {
        PIcon.HEADPHONES -> {
            drawArc(c, 180f, 180f, false, Offset(4f * u, 3f * u), Size(16f * u, 16f * u), style = line)
            drawRoundRect(c, o(3.2f, 12.6f), Size(3.8f * u, 7f * u), CornerRadius(1.6f * u))
            drawRoundRect(c, o(17f, 12.6f), Size(3.8f * u, 7f * u), CornerRadius(1.6f * u))
        }
        PIcon.CLOUD_UP -> {
            drawPath(cloud, c, style = line)
            seg(12f, 16.2f, 12f, 9.8f)
            drawPath(path { m(9.3f, 12.4f); l(12f, 9.6f); l(14.7f, 12.4f) }, c, style = line)
        }
        PIcon.CLOUD_CHECK -> {
            drawPath(cloud, c.copy(alpha = 0.22f))
            drawPath(cloud, c, style = line)
            val g = Color(0xFF2E9E4F)
            drawCircle(g, 5f * u, o(18f, 18f))
            drawPath(path { m(15.6f, 18.2f); l(17.4f, 20f); l(20.6f, 16.4f) }, Color.White, style = line)
        }
        PIcon.DATABASE -> {
            drawOval(c, o(5f, 3.5f), Size(14f * u, 5f * u), style = line)
            seg(5f, 6f, 5f, 18f); seg(19f, 6f, 19f, 18f)
            drawArc(c, 0f, 180f, false, o(5f, 15.5f), Size(14f * u, 5f * u), style = line)
            drawArc(c, 0f, 180f, false, o(5f, 9.5f), Size(14f * u, 5f * u), style = thin)
        }
        PIcon.SHARE_UP -> {
            drawPath(path { m(5f, 11.5f); l(5f, 19.5f); l(19f, 19.5f); l(19f, 11.5f) }, c, style = line)
            seg(12f, 15f, 12f, 4f)
            drawPath(path { m(8.3f, 7.6f); l(12f, 3.9f); l(15.7f, 7.6f) }, c, style = line)
        }
        PIcon.DOWNLOAD -> {
            drawPath(path { m(5f, 14f); l(5f, 19.5f); l(19f, 19.5f); l(19f, 14f) }, c, style = line)
            seg(12f, 4f, 12f, 14.5f)
            drawPath(path { m(8.3f, 10.8f); l(12f, 14.5f); l(15.7f, 10.8f) }, c, style = line)
        }
        PIcon.SCAN -> {
            val k = 5f
            for ((sx, sy) in listOf(4f to 4f, 20f to 4f, 4f to 20f, 20f to 20f)) {
                val dx = if (sx < 12f) 1f else -1f
                val dy = if (sy < 12f) 1f else -1f
                drawPath(path { m(sx, sy + dy * k); l(sx, sy); l(sx + dx * k, sy) }, c, style = line)
            }
            seg(7.5f, 12f, 16.5f, 12f, thin)
        }
        PIcon.SHIELD -> {
            drawPath(path {
                m(12f, 3f); l(19.5f, 6f); l(19.5f, 12f)
                cu(19.5f, 16.5f, 16.5f, 19.8f, 12f, 21f)
                cu(7.5f, 19.8f, 4.5f, 16.5f, 4.5f, 12f)
                l(4.5f, 6f); close()
            }, c, style = line)
            drawPath(path { m(8.6f, 12f); l(11f, 14.4f); l(15.6f, 9.6f) }, c, style = line)
        }
        PIcon.INFO -> {
            drawCircle(c, 9f * u, o(12f, 12f), style = line)
            drawCircle(c, 1.1f * u, o(12f, 7.9f))
            seg(12f, 11f, 12f, 16.6f)
        }
        PIcon.DOTS_CIRCLE -> {
            drawCircle(
                Brush.verticalGradient(listOf(Color(0xFFD9A441), Color(0xFFA3610B))),
                11f * u, o(12f, 12f)
            )
            for (x in listOf(7.6f, 12f, 16.4f)) drawCircle(Color(0xFFFFF6E4), 1.5f * u, o(x, 12f))
        }
        PIcon.GRAD_CAP -> {
            drawPath(path { m(2f, 9f); l(12f, 4f); l(22f, 9f); l(12f, 14f); close() }, c, style = line)
            drawPath(path { m(6f, 11.6f); l(6f, 16f); cu(6f, 17.6f, 9f, 19f, 12f, 19f); cu(15f, 19f, 18f, 17.6f, 18f, 16f); l(18f, 11.6f) }, c, style = line)
            seg(22f, 9f, 22f, 15f)
        }
        PIcon.RESTORE -> {
            drawArc(c, 125f, 290f, false, o(4f, 4f), Size(16f * u, 16f * u), style = line)
            drawPath(path { m(3f, 4.5f); l(5.2f, 9.4f); l(9.8f, 6.6f) }, c, style = line)
            drawPath(path { m(12f, 8f); l(12f, 12f); l(15f, 14f) }, c, style = line)
        }
        PIcon.SHARE_NODES -> {
            seg(7.6f, 11f, 15.4f, 7f); seg(7.6f, 13f, 15.4f, 17f)
            drawCircle(c, 2.6f * u, o(6f, 12f), style = line)
            drawCircle(c, 2.6f * u, o(17f, 6f), style = line)
            drawCircle(c, 2.6f * u, o(17f, 18f), style = line)
        }
        PIcon.PENCIL -> {
            drawPath(path { m(4f, 20f); l(5f, 15.4f); l(16f, 4.4f); l(19.6f, 8f); l(8.6f, 19f); close() }, c, style = line)
            seg(13.6f, 6.8f, 17.2f, 10.4f, thin)
        }
        PIcon.MASK -> {
            drawPath(path {
                m(4f, 6f); cu(4f, 6f, 8f, 5f, 12f, 5f); cu(16f, 5f, 20f, 6f, 20f, 6f)
                cu(20f, 13f, 16.5f, 18.5f, 12f, 19f); cu(7.5f, 18.5f, 4f, 13f, 4f, 6f); close()
            }, c, style = line)
            drawArc(c, 200f, 140f, false, o(6.4f, 9f), Size(4f * u, 3f * u), style = thin)
            drawArc(c, 200f, 140f, false, o(13.6f, 9f), Size(4f * u, 3f * u), style = thin)
            drawArc(c, 20f, 140f, false, o(8.6f, 12.2f), Size(6.8f * u, 4f * u), style = thin)
        }
        PIcon.QUILL -> {
            drawPath(path { m(20f, 3f); cu(10f, 4f, 6f, 11f, 5f, 20f); cu(12f, 17f, 18f, 12f, 20f, 3f); close() }, c, style = line)
            seg(5f, 20f, 16f, 8.4f, thin)
            seg(9.4f, 13.4f, 12.6f, 14.6f, thin); seg(11.6f, 10.8f, 15f, 11.8f, thin)
        }
        PIcon.PLAY -> drawPath(path { m(8f, 5.5f); l(19f, 12f); l(8f, 18.5f); close() }, c)
    }
}
