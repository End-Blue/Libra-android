package com.libra.reader

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Preferencias del perfil del lector (nombre, foto, «miembro desde» y estado de la última copia). */
internal object ProfilePrefs {
    private const val FILE = "libra_profile"
    private fun sp(ctx: Context) = ctx.getSharedPreferences(FILE, 0)

    fun name(ctx: Context): String = sp(ctx).getString("name", null)?.takeIf { it.isNotBlank() } ?: "Carlos Andrés"
    fun setName(ctx: Context, v: String) { sp(ctx).edit().putString("name", v.trim()).apply() }

    fun photoFile(ctx: Context): File? = File(ctx.filesDir, "profile_photo.jpg").takeIf { it.exists() }
    fun removePhoto(ctx: Context) { File(ctx.filesDir, "profile_photo.jpg").delete() }

    /** Guarda la foto elegida recortada en cuadrado a 512 px. Devuelve false si no se pudo leer. */
    fun savePhoto(ctx: Context, uri: Uri): Boolean = try {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        var sample = 1
        while (opts.outWidth / (sample * 2) >= 1024 && opts.outHeight / (sample * 2) >= 1024) sample *= 2
        val bmp = ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        }
        if (bmp == null) false else {
            val side = minOf(bmp.width, bmp.height)
            val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
            val out = Bitmap.createScaledBitmap(square, 512, 512, true)
            File(ctx.filesDir, "profile_photo.jpg").outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            true
        }
    } catch (_: Throwable) {
        false
    }

    /** Fecha de alta: se fija la primera vez (el libro más antiguo de la biblioteca o hoy). */
    fun memberSince(ctx: Context, books: List<LibraryItem>): Long {
        val saved = sp(ctx).getLong("member_since", 0L)
        if (saved > 0L) return saved
        val first = books.minOfOrNull { it.addedAt } ?: return System.currentTimeMillis()
        sp(ctx).edit().putLong("member_since", first).apply()
        return first
    }

    fun markBackup(ctx: Context, ok: Boolean) {
        sp(ctx).edit().putLong("backup_at", System.currentTimeMillis()).putBoolean("backup_ok", ok).apply()
    }
    fun lastBackupAt(ctx: Context): Long = sp(ctx).getLong("backup_at", 0L)
    fun lastBackupOk(ctx: Context): Boolean = sp(ctx).getBoolean("backup_ok", false)
}

/** Título del lector según el tamaño de su biblioteca. */
internal fun readerRank(bookCount: Int): String = when {
    bookCount >= 250 -> "Maestro de la Biblioteca"
    bookCount >= 100 -> "Gran Lector"
    bookCount >= 50 -> "Bibliófilo"
    bookCount >= 15 -> "Explorador Literario"
    bookCount >= 5 -> "Lector Curioso"
    else -> "Lector Novel"
}

/** Autor y género favoritos: los mismos criterios que la pantalla «Tu resumen». */
internal fun favoriteAuthorAndGenre(books: List<LibraryItem>): Pair<String, String> {
    val readBooks = books.filter { it.statusKey() != "TBR" || it.progress > 0 }
    val author = (readBooks.ifEmpty { books })
        .filter { it.author.isNotBlank() && it.author != "Autor no identificado" }
        .groupBy { it.author }
        .maxWithOrNull(
            compareBy<Map.Entry<String, List<LibraryItem>>>({ it.value.size })
                .thenBy { e -> e.value.count { it.statusKey() == "FINISHED" } }
        )?.key ?: "—"
    val genre = readBooks.filter { it.genre.isNotBlank() }
        .ifEmpty { books.filter { it.genre.isNotBlank() } }
        .groupingBy { it.genre }.eachCount().entries.maxByOrNull { it.value }?.key ?: "—"
    return author to genre
}

/** Libros terminados este año (los que no tienen fecha cuentan igualmente), como en la pantalla del reto. */
internal fun finishedThisYear(books: List<LibraryItem>): Int {
    val year = Calendar.getInstance().get(Calendar.YEAR)
    return books.count { b ->
        b.statusKey() == "FINISHED" && (b.finishedAt == 0L ||
            Calendar.getInstance().apply { timeInMillis = b.finishedAt }.get(Calendar.YEAR) == year)
    }
}

/** Milisegundos leídos desde el inicio del periodo (TODAY / WEEK / MONTH / YEAR) hasta hoy. */
internal fun readMsInPeriod(ctx: Context, period: String): Long {
    val c = Calendar.getInstance()
    when (period) {
        "WEEK" -> c.add(Calendar.DAY_OF_YEAR, -((c.get(Calendar.DAY_OF_WEEK) + 5) % 7))
        "MONTH" -> c.set(Calendar.DAY_OF_MONTH, 1)
        "YEAR" -> c.set(c.get(Calendar.YEAR), Calendar.JANUARY, 1)
        else -> {}
    }
    val startKey = Streak.key(c)
    val todayKey = Streak.key()
    return ReadStats.all(ctx).filterKeys { it in startKey..todayKey }.values.sum()
}

/** «2 h 35 min», «45 min», «3 h». */
internal fun formatDuration(ms: Long): String {
    val totalMin = (ms / 60_000L).toInt()
    val h = totalMin / 60
    val m = totalMin % 60
    return when {
        h == 0 -> "$m min"
        m == 0 -> "$h h"
        else -> "$h h $m min"
    }
}

/** Libro en curso con su capítulo y una estimación del tiempo que falta (según tu ritmo real en ese libro). */
internal class ContinueInfo(val book: LibraryItem, val chapter: String, val remaining: String)

internal fun continueInfo(ctx: Context, books: List<LibraryItem>): ContinueInfo? {
    val stats = ctx.getSharedPreferences("libra_reading_stats", 0)
    val book = ReadingNow.current(books, stats) ?: return null
    val pos = ctx.getSharedPreferences("libra_reading_prefs", 0).getString("pg2_${book.id}", null)
    val chapter = pos?.substringBefore('|')?.toIntOrNull()?.let { "Capítulo ${it + 1}" } ?: ""
    val total = stats.getLong("book_total_${book.id}", 0L)
    val pct = book.progressPct()
    val remaining = if (pct in 3..99 && total > 60_000L) "≈ ${formatDuration(total * (100 - pct) / pct)} restantes" else ""
    return ContinueInfo(book, chapter, remaining)
}

// ── Exportaciones ──────────────────────────────────────────────────────────────

/** Todos los datos de la biblioteca en un JSON legible (sin los archivos de los libros). */
internal suspend fun exportFullJson(
    ctx: Context, dao: LibraryDao, highlightDao: HighlightDao, uri: Uri
): String = withContext(Dispatchers.IO) {
    try {
        val items = dao.getAll()
        val highlights = highlightDao.getAll()
        val root = JSONObject()
        root.put("app", "Libellum")
        root.put("exportado", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()))
        root.put("perfil", JSONObject().put("nombre", ProfilePrefs.name(ctx)))
        val days = Streak.days(ctx).sorted()
        root.put("racha", JSONObject()
            .put("actual", Streak.current(days.toSet()))
            .put("mejor", Streak.best(days.toSet()))
            .put("objetivoAnual", Streak.goal(ctx))
            .put("dias", JSONArray(days)))
        val ms = JSONObject()
        ReadStats.all(ctx).toSortedMap().forEach { (k, v) -> ms.put(k, v) }
        root.put("milisegundosLeidosPorDia", ms)
        val books = JSONArray()
        items.forEach { b ->
            books.put(JSONObject()
                .put("id", b.id).put("titulo", b.title).put("autor", b.author)
                .put("formato", b.format).put("tipo", b.mediaType)
                .put("progresoPct", b.progressPct()).put("estado", b.statusKey())
                .put("valoracion", b.rating).put("genero", b.genre).put("resena", b.review)
                .put("favorito", b.isFavorite == 1)
                .put("anadido", b.addedAt).put("empezado", b.startedAt).put("terminado", b.finishedAt))
        }
        root.put("libros", books)
        val notes = JSONArray()
        highlights.forEach { h ->
            notes.put(JSONObject()
                .put("libroId", h.bookId).put("libro", h.bookTitle).put("capitulo", h.chapterTitle)
                .put("texto", h.selectedText).put("nota", h.note)
                .put("color", h.colorArgb).put("fecha", h.createdAt))
        }
        root.put("notasYCitas", notes)
        ctx.contentResolver.openOutputStream(uri, "w")?.use { it.write(root.toString(2).toByteArray(Charsets.UTF_8)) }
            ?: return@withContext "No se pudo crear el archivo."
        "Datos exportados: ${items.size} elementos y ${highlights.size} notas."
    } catch (e: Throwable) {
        "No se pudo exportar: ${e.message ?: "error desconocido"}"
    }
}

/** Notas y subrayados en texto plano, agrupados por libro. */
internal suspend fun exportNotesTxt(
    ctx: Context, highlightDao: HighlightDao, uri: Uri
): String = withContext(Dispatchers.IO) {
    try {
        val all = highlightDao.getAll()
        if (all.isEmpty()) return@withContext "Todavía no tienes notas ni subrayados."
        val sb = StringBuilder("NOTAS Y CITAS — Libellum\n\n")
        all.groupBy { it.bookTitle }.forEach { (title, list) ->
            sb.append(title).append('\n').append("=".repeat(title.length.coerceAtLeast(3))).append("\n\n")
            list.sortedBy { it.createdAt }.forEach { h ->
                sb.append('“').append(h.selectedText.trim()).append('”')
                if (h.chapterTitle.isNotBlank()) sb.append("  (").append(h.chapterTitle).append(')')
                sb.append('\n')
                if (h.note.isNotBlank()) sb.append("   Nota: ").append(h.note.trim()).append('\n')
                sb.append('\n')
            }
        }
        ctx.contentResolver.openOutputStream(uri, "w")?.use { it.write(sb.toString().toByteArray(Charsets.UTF_8)) }
            ?: return@withContext "No se pudo crear el archivo."
        "Notas exportadas: ${all.size}."
    } catch (e: Throwable) {
        "No se pudo exportar: ${e.message ?: "error desconocido"}"
    }
}
