package com.libra.reader

import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ══════════════════════════════════════════════════════════════════════════════
// «Mi Perfil Lector» — pantalla de Ajustes
// Cabecera con ilustración · perfil · continuar leyendo · progreso · copia de seguridad ·
// datos y exportación · ajustes y gestión · más opciones. Todo está conectado a funciones reales.
// ══════════════════════════════════════════════════════════════════════════════

private val GoldFill = Brush.verticalGradient(listOf(Color(0xFFBF8A36), Color(0xFF8A5714)))
private val ButtonText = Color(0xFFFFF3DC)
private val Green = Color(0xFF2E9E4F)

@Composable
internal fun ProfileScreen(
    books: List<LibraryItem>,
    audioCount: Int,
    notesCount: Int,
    days: Set<String>,
    goal: Int,
    statsVersion: Int,
    backupVersion: Int,
    busy: Boolean,
    status: String,
    onOpen: (LibraryItem) -> Unit,
    onShelf: () -> Unit,
    onReto: () -> Unit,
    onStreak: () -> Unit,
    onImportBooks: () -> Unit,
    onScanBooks: () -> Unit,
    onExportBackup: () -> Unit,
    onRestore: () -> Unit,
    onExportCsv: () -> Unit,
    onExportFull: () -> Unit,
    onExportNotes: () -> Unit,
    onTutorial: () -> Unit
) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(ProfilePrefs.name(ctx)) }
    var photoVersion by remember { mutableIntStateOf(0) }
    var dialog by remember { mutableStateOf<String?>(null) }       // edit · privacy · about · info
    var moreData by remember { mutableStateOf(false) }
    var moreSettings by remember { mutableStateOf(false) }
    var period by remember { mutableStateOf("MONTH") }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && ProfilePrefs.savePhoto(ctx, uri)) photoVersion++
    }

    val (favAuthor, favGenre) = remember(books) { favoriteAuthorAndGenre(books) }
    val since = remember(books.size) { ProfilePrefs.memberSince(ctx, books) }
    val sinceText = remember(since) {
        SimpleDateFormat("MMMM yyyy", Locale("es")).format(Date(since))
    }
    val info = remember(books, statsVersion) { continueInfo(ctx, books) }
    val readMs = remember(period, statsVersion, days) { readMsInPeriod(ctx, period) }
    val doneBooks = remember(books) { finishedThisYear(books) }
    val backupAt = remember(backupVersion) { ProfilePrefs.lastBackupAt(ctx) }
    val backupOk = remember(backupVersion) { ProfilePrefs.lastBackupOk(ctx) }
    val recent = backupAt > 0L && System.currentTimeMillis() - backupAt < 30L * 86_400_000L

    LazyColumn(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // ── Cabecera ──
        item {
            HeroHeader(
                art = R.drawable.hero_profile,
                title = "Mi Perfil Lector",
                sub = "Tu historia entre páginas",
                quote = "Un lector vive mil vidas\nantes de morir.",
                titleSize = 26,
                subSize = 14
            )
        }
        // El mensaje inicial («Libellum guarda tu biblioteca…») no se muestra; sí los avisos de las operaciones
        if (busy || (status.isNotBlank() && !status.startsWith("Libellum guarda"))) {
            item {
                LbCard(Modifier.padding(horizontal = 14.dp), padding = 12.dp) {
                    Text(
                        if (busy && status.isBlank()) "Trabajando…" else status,
                        color = LbText, fontSize = 13.sp, fontFamily = LibellumSerif
                    )
                }
            }
        }

        // ── Perfil ──
        item {
            LbCard(Modifier.padding(horizontal = 14.dp).offset(y = (-8).dp), padding = 14.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(80.dp).clickable { dialog = "edit" }) {
                        val photo = remember(photoVersion) {
                            ProfilePrefs.photoFile(ctx)?.let { f ->
                                runCatching { BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap() }.getOrNull()
                            }
                        }
                        Box(
                            Modifier.fillMaxSize().clip(CircleShape)
                                .border(3.dp, Brush.verticalGradient(listOf(Color(0xFFE3B65C), Color(0xFF9A6A1E))), CircleShape)
                                .padding(3.dp).clip(CircleShape)
                        ) {
                            if (photo != null) Image(photo, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            else Image(painterResource(R.drawable.profile_avatar), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        }
                        Box(
                            Modifier.align(Alignment.BottomEnd).size(26.dp).clip(CircleShape).background(GoldFill),
                            contentAlignment = Alignment.Center
                        ) { PIconView(PIcon.PENCIL, tint = ButtonText, size = 14.dp) }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            name, color = LbTitle, fontSize = 24.sp, fontFamily = LibellumSerif,
                            fontStyle = FontStyle.Italic, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.clickable { dialog = "edit" }
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            LibIcon(LibIconKind.STAR, tint = Color(0xFFE0A52A), size = 18.dp, filled = true)
                            Spacer(Modifier.width(5.dp))
                            Text(
                                readerRank(books.size), color = LbBrown, fontSize = 14.sp,
                                fontFamily = LibellumSerif, maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    Spacer(Modifier.width(8.dp))
                    Row(
                        Modifier.clip(RoundedCornerShape(50)).background(Color(0xFFF2DDB8))
                            .padding(horizontal = 10.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        LbIcon(LbIconKind.CALENDAR, tint = LbBrown, size = 22.dp)
                        Spacer(Modifier.width(6.dp))
                        Column {
                            Text("Miembro desde", color = LbText, fontSize = 10.sp, fontFamily = LibellumSerif)
                            Text(sinceText, color = LbText, fontSize = 10.sp, fontFamily = LibellumSerif, maxLines = 1)
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    PfStat(Modifier.weight(1f), { LbIcon(LbIconKind.BOOK_OPEN, tint = LbBrown, size = 26.dp) }, "${books.size}", "Libros")
                    PfDivider()
                    PfStat(Modifier.weight(1f), { LbIcon(LbIconKind.HEART, tint = LbBrownLight, size = 26.dp, filled = true) }, "${books.count { it.isFavorite == 1 }}", "Favoritos")
                    PfDivider()
                    PfStat(Modifier.weight(1f), { PIconView(PIcon.HEADPHONES, tint = LbBrownLight, size = 26.dp) }, "$audioCount", "Audiolibros")
                    PfDivider()
                    PfStat(Modifier.weight(1f), { LbIcon(LbIconKind.DOC, tint = LbBrown, size = 26.dp) }, "$notesCount", "Notas y citas")
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Laurel(Modifier.size(width = 34.dp, height = 38.dp), flip = false)
                    PfFav(Modifier.weight(1f), { PIconView(PIcon.QUILL, tint = LbBrown, size = 24.dp) }, "Autor favorito", favAuthor)
                    PfFav(Modifier.weight(1f), { PIconView(PIcon.MASK, tint = LbBrown, size = 24.dp) }, "Género favorito", favGenre)
                    Laurel(Modifier.size(width = 34.dp, height = 38.dp), flip = true)
                }
            }
        }

        // ── Continuar leyendo ──
        item {
            LbSectionHeader(
                "Continuar leyendo",
                icon = { LbIcon(LbIconKind.BOOK_OPEN, tint = LbBrown, size = 28.dp) },
                modifier = Modifier.padding(horizontal = 14.dp),
                trailing = { LbLink("Ver en estantería", onShelf) }
            )
        }
        item {
            if (info == null) {
                LbCard(Modifier.padding(horizontal = 14.dp)) {
                    Text(
                        "Aún no has empezado ningún libro. Abre uno desde la estantería y aparecerá aquí.",
                        color = LbText, fontSize = 14.sp, fontFamily = LibellumSerif
                    )
                }
            } else {
                LbCard(Modifier.padding(horizontal = 14.dp), padding = 12.dp, onClick = { onOpen(info.book) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        BookCover(info.book, Modifier.size(width = 62.dp, height = 90.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                info.book.title, color = LbTitle, fontSize = 17.sp, fontFamily = LibellumSerif,
                                fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                info.book.author, color = LbText, fontSize = 13.sp, fontFamily = LibellumSerif,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            Spacer(Modifier.height(6.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(50)).background(LbTrack)) {
                                    Box(
                                        Modifier.fillMaxHeight().fillMaxWidth(info.book.progressFraction().coerceIn(0.02f, 1f))
                                            .clip(RoundedCornerShape(50)).background(Brush.horizontalGradient(listOf(LbBarSel, LbBar)))
                                    )
                                }
                                Spacer(Modifier.width(8.dp))
                                Text(info.book.progressText(), color = LbTitle, fontSize = 13.sp, fontFamily = LibellumSerif)
                            }
                            Spacer(Modifier.height(6.dp))
                            if (info.chapter.isNotEmpty()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    PIconView(PIcon.HEADPHONES, tint = LbBrown, size = 16.dp)
                                    Spacer(Modifier.width(5.dp))
                                    Text(info.chapter, color = LbText, fontSize = 11.sp, fontFamily = LibellumSerif, maxLines = 1)
                                }
                            }
                            if (info.remaining.isNotEmpty()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    LbIcon(LbIconKind.CLOCK, tint = LbBrown, size = 16.dp)
                                    Spacer(Modifier.width(5.dp))
                                    Text(info.remaining, color = LbText, fontSize = 11.sp, fontFamily = LibellumSerif, maxLines = 1)
                                }
                            }
                        }
                        Spacer(Modifier.width(8.dp))
                        PfGoldButton(Modifier.width(96.dp), onClick = { onOpen(info.book) }) {
                            PIconView(PIcon.PLAY, tint = ButtonText, size = 18.dp)
                            Spacer(Modifier.width(4.dp))
                            Text("Continuar\nleyendo", color = ButtonText, fontSize = 12.sp, fontFamily = LibellumSerif, lineHeight = 14.sp)
                        }
                    }
                }
            }
        }

        // ── Tu progreso ──
        item {
            var open by remember { mutableStateOf(false) }
            val options = listOf("TODAY" to "Hoy", "WEEK" to "Esta semana", "MONTH" to "Este mes", "YEAR" to "Este año")
            LbSectionHeader(
                "Tu progreso",
                icon = { LbIcon(LbIconKind.CHART, tint = LbBrown, size = 28.dp) },
                modifier = Modifier.padding(horizontal = 14.dp),
                trailing = {
                    Box {
                        Row(
                            Modifier.clip(RoundedCornerShape(8.dp)).clickable { open = true }.padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                options.first { it.first == period }.second, color = LbBrownLight, fontSize = 14.sp,
                                fontFamily = LibellumSerif, fontStyle = FontStyle.Italic, maxLines = 1, softWrap = false
                            )
                            Spacer(Modifier.width(2.dp))
                            LbIcon(LbIconKind.CHEVRON_DOWN, tint = LbBrownLight, size = 16.dp)
                        }
                        DropdownMenu(open, { open = false }, modifier = Modifier.background(Color(0xFFFFF8EA))) {
                            options.forEach { (k, label) ->
                                DropdownMenuItem(
                                    text = { Text(label, color = LbTitle, fontFamily = LibellumSerif) },
                                    onClick = { period = k; open = false }
                                )
                            }
                        }
                    }
                }
            )
        }
        item {
            LbCard(Modifier.padding(horizontal = 14.dp), padding = 12.dp) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    PfProgress(
                        Modifier.weight(1f).clickable(onClick = onStreak),
                        { LbIcon(LbIconKind.FLAME, tint = Color(0xFFE8751A), size = 34.dp, filled = true) },
                        "${Streak.current(days)}", if (Streak.current(days) == 1) "día de racha" else "días de racha"
                    )
                    PfDivider()
                    PfProgress(
                        Modifier.weight(1f).clickable(onClick = onReto),
                        { LbIcon(LbIconKind.TARGET, tint = LbBrownLight, size = 34.dp) },
                        "$doneBooks / $goal", "Libros del reto"
                    )
                    PfDivider()
                    PfProgress(
                        Modifier.weight(1f),
                        { LbIcon(LbIconKind.CLOCK, tint = LbBrownLight, size = 34.dp) },
                        formatDuration(readMs), "Tiempo leído"
                    )
                }
            }
        }

        // ── Copia de seguridad ──
        item {
            LbSectionHeader(
                "Copia de seguridad",
                icon = { PIconView(PIcon.CLOUD_UP, tint = LbBrown, size = 28.dp) },
                modifier = Modifier.padding(horizontal = 14.dp),
                trailing = { LbLink(if (recent) "Todo seguro" else "Hacer copia", onExportBackup) }
            )
        }
        item {
            LbCard(Modifier.padding(horizontal = 14.dp), padding = 12.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    PIconView(PIcon.CLOUD_CHECK, tint = Color(0xFFA89A84), size = 56.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (recent) "Tu biblioteca está protegida" else if (backupAt == 0L) "Aún no tienes copias" else "Tu última copia es antigua",
                            color = LbTitle, fontSize = 16.sp, fontFamily = LibellumSerif, fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            if (backupAt == 0L) "Haz una copia para no perder nada."
                            else "Última copia: " + SimpleDateFormat("d 'de' MMMM 'de' yyyy", Locale("es")).format(Date(backupAt)),
                            color = LbText, fontSize = 12.sp, fontFamily = LibellumSerif
                        )
                        if (backupAt > 0L) {
                            Text(
                                if (backupOk) "✔ Copia correcta" else "✖ La última copia falló",
                                color = if (backupOk) Green else Color(0xFFB3261E), fontSize = 12.sp, fontFamily = LibellumSerif
                            )
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PfGoldButton(Modifier.weight(1.15f), enabled = !busy, onClick = onExportBackup) {
                        PIconView(PIcon.CLOUD_UP, tint = ButtonText, size = 22.dp)
                        Spacer(Modifier.width(6.dp))
                        Text("Exportar\ncopia de seguridad", color = ButtonText, fontSize = 12.sp, fontFamily = LibellumSerif, lineHeight = 14.sp)
                    }
                    PfOutlineButton(Modifier.weight(1f), enabled = !busy, onClick = onRestore) {
                        PIconView(PIcon.RESTORE, tint = LbBrown, size = 22.dp)
                        Spacer(Modifier.width(6.dp))
                        Text("Restaurar\ndesde copia", color = LbTitle, fontSize = 12.sp, fontFamily = LibellumSerif, lineHeight = 14.sp)
                    }
                }
            }
        }

        // ── Datos y exportación ──
        item {
            LbSectionHeader(
                "Datos y exportación",
                icon = { PIconView(PIcon.DATABASE, tint = LbBrown, size = 28.dp) },
                modifier = Modifier.padding(horizontal = 14.dp),
                trailing = {
                    Row(
                        Modifier.clip(RoundedCornerShape(8.dp)).clickable { moreData = !moreData }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            if (moreData) "Ver menos" else "Ver más", color = LbBrownLight, fontSize = 14.sp,
                            fontFamily = LibellumSerif, fontStyle = FontStyle.Italic, maxLines = 1, softWrap = false
                        )
                        Spacer(Modifier.width(4.dp))
                        PfDiamond()
                    }
                }
            )
        }
        item {
            Column(Modifier.padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PfTile(Modifier.weight(1f), enabled = !busy, onClick = onExportCsv, horizontal = true,
                        icon = { PfCsvIcon() }, label = "Exportar lista de libros (CSV)")
                    PfTile(Modifier.weight(1f), enabled = !busy, onClick = onExportFull, horizontal = true,
                        icon = { PIconView(PIcon.SHARE_UP, tint = LbBrown, size = 32.dp) },
                        label = "Exportar datos completos de tu biblioteca")
                }
                if (moreData) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        PfTile(Modifier.weight(1f), enabled = !busy, onClick = onExportNotes, horizontal = true,
                            icon = { LbIcon(LbIconKind.DOC, tint = LbBrown, size = 32.dp) },
                            label = "Exportar notas y citas (TXT)")
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
        }

        // ── Ajustes y Gestión ──
        item {
            LbSectionHeader(
                "Ajustes y Gestión",
                icon = { LbIcon(LbIconKind.GEAR, tint = LbBrown, size = 28.dp) },
                modifier = Modifier.padding(horizontal = 14.dp),
                trailing = { LbLink(if (moreSettings) "Ver menos" else "Ver todos") { moreSettings = !moreSettings } }
            )
        }
        item {
            Row(Modifier.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painterResource(R.drawable.profile_lantern), null,
                    Modifier.width(84.dp), contentScale = ContentScale.FillWidth
                )
                Spacer(Modifier.width(6.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PfPill(Modifier.weight(1f), enabled = !busy, onClick = onImportBooks,
                            icon = { PIconView(PIcon.DOWNLOAD, tint = LbBrown, size = 22.dp) }, label = "Importar libros")
                        PfPill(Modifier.weight(1f), onClick = { dialog = "privacy" },
                            icon = { PIconView(PIcon.SHIELD, tint = LbBrown, size = 22.dp) }, label = "Privacidad y seguridad")
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PfPill(Modifier.weight(1f), enabled = !busy, onClick = onScanBooks,
                            icon = { PIconView(PIcon.SCAN, tint = LbBrown, size = 22.dp) }, label = "Escanear")
                        PfPill(Modifier.weight(1f), onClick = { dialog = "about" },
                            icon = { PIconView(PIcon.INFO, tint = LbBrown, size = 22.dp) },
                            label = "Acerca de Libellum", sub = "Versión ${appVersionName(ctx)}")
                    }
                    if (moreSettings) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PfPill(Modifier.weight(1f), onClick = { openAllFilesSettings(ctx) },
                                icon = { LbIcon(LbIconKind.LOCK, tint = LbBrown, size = 22.dp) }, label = "Permiso de archivos")
                            PfPill(Modifier.weight(1f), onClick = {
                                ctx.getSharedPreferences("libra_prefs", 0).edit().putBoolean("tutorial_done", false).apply()
                                onTutorial()
                            }, icon = { LibIcon(LibIconKind.HELP, tint = LbBrown, size = 22.dp) }, label = "Repetir tutorial")
                        }
                    }
                }
            }
        }

        // ── Más opciones ──
        item {
            Row(Modifier.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                PIconView(PIcon.DOTS_CIRCLE, size = 28.dp)
                Spacer(Modifier.width(8.dp))
                Text(
                    "Más opciones", color = LbTitle, fontSize = 22.sp, fontFamily = LibellumSerif,
                    fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic
                )
            }
        }
        item {
            Row(Modifier.padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PfTile(Modifier.weight(1f), onClick = onTutorial, horizontal = false,
                    icon = { PIconView(PIcon.GRAD_CAP, tint = LbBrown, size = 28.dp) }, label = "Tutorial\nde la app")
                PfTile(Modifier.weight(1f), enabled = !busy, onClick = onRestore, horizontal = false,
                    icon = { PIconView(PIcon.CLOUD_UP, tint = LbBrown, size = 28.dp) }, label = "Restaurar\ndesde una copia")
                PfTile(Modifier.weight(1f), onClick = { dialog = "info" }, horizontal = false,
                    icon = { PIconView(PIcon.INFO, tint = LbBrownLight, size = 28.dp) }, label = "Más información")
                PfTile(Modifier.weight(1f), onClick = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, "Estoy usando Libellum para leer y organizar mis libros: tu historia entre páginas.")
                    }
                    runCatching { ctx.startActivity(Intent.createChooser(send, null)) }
                }, horizontal = false,
                    icon = { PIconView(PIcon.SHARE_NODES, tint = LbBrown, size = 28.dp) }, label = "Compartir app")
            }
        }

        // ── Frase final ──
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Laurel(Modifier.size(width = 34.dp, height = 38.dp), flip = false)
                Text(
                    "“Tus historias siempre estarán a salvo.”", color = LbText, fontSize = 14.sp,
                    fontFamily = LibellumSerif, fontStyle = FontStyle.Italic, textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
                Laurel(Modifier.size(width = 34.dp, height = 38.dp), flip = true)
            }
            Spacer(Modifier.height(8.dp))
        }
    }

    // ── Diálogos ──
    when (dialog) {
        "edit" -> {
            var text by remember { mutableStateOf(name) }
            val hasPhoto = ProfilePrefs.photoFile(ctx) != null
            AlertDialog(
                onDismissRequest = { dialog = null },
                title = { Text("Tu perfil", fontFamily = LibellumSerif) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = text, onValueChange = { text = it.take(40) },
                            label = { Text("Nombre") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                        TextButton(onClick = { photoPicker.launch("image/*") }) { Text("Cambiar foto", color = LbBrown) }
                        if (hasPhoto) {
                            TextButton(onClick = { ProfilePrefs.removePhoto(ctx); photoVersion++ }) {
                                Text("Quitar foto", color = LbBrown)
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (text.isNotBlank()) { ProfilePrefs.setName(ctx, text); name = ProfilePrefs.name(ctx) }
                        dialog = null
                    }) { Text("Guardar", color = LbBrown) }
                },
                dismissButton = { TextButton(onClick = { dialog = null }) { Text("Cancelar", color = LbMuted) } }
            )
        }
        "privacy" -> {
            val granted = remember(dialog) { hasAllFilesAccess() }
            AlertDialog(
                onDismissRequest = { dialog = null },
                title = { Text("Privacidad y seguridad", fontFamily = LibellumSerif) },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        PfInfoBlock("En tu teléfono", "Tus libros, notas, subrayados y progreso se guardan en este dispositivo, en el almacenamiento privado de Libellum.")
                        PfInfoBlock("Internet", "Solo se usa para el diccionario: al consultar una palabra, esa palabra se envía a los servicios de definiciones y traducción.")
                        PfInfoBlock(
                            "Acceso a archivos",
                            (if (granted) "Concedido. " else "No concedido. ") +
                                "Solo lo usa el escáner para buscar libros en tu almacenamiento; no lee nada más."
                        )
                        PfInfoBlock("Copias de seguridad", "El archivo .zip lo guardas tú donde quieras. Contiene tus libros y notas: guárdalo en un lugar de confianza.")
                    }
                },
                confirmButton = { TextButton(onClick = { dialog = null }) { Text("Cerrar", color = LbBrown) } },
                dismissButton = { TextButton(onClick = { openAllFilesSettings(ctx) }) { Text("Permiso de archivos", color = LbMuted) } }
            )
        }
        "about" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Libellum", fontFamily = LibellumSerif) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Versión ${appVersionName(ctx)}", color = LbTitle, fontFamily = LibellumSerif)
                    Text("Tu historia entre páginas.", color = LbText, fontFamily = LibellumSerif, fontStyle = FontStyle.Italic)
                    Text("Lee libros electrónicos, escucha audiolibros, guarda notas y sigue tu racha de lectura.", color = LbText, fontSize = 13.sp)
                }
            },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text("Cerrar", color = LbBrown) } }
        )
        "info" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Más información", fontFamily = LibellumSerif) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    PfInfoBlock("Formatos", "EPUB, PDF, TXT, FB2 y CBZ para leer; archivos de audio para los audiolibros.")
                    PfInfoBlock("Añadir libros", "«Importar libros» abre el selector de archivos; «Escanear» busca libros en todo el teléfono y deja marcados solo los que parecen libros.")
                    PfInfoBlock("Copias de seguridad", "La copia incluye libros, audiolibros, portadas, progreso, notas y el orden de la estantería. Puedes restaurarla en otro teléfono.")
                    PfInfoBlock("Exportar", "El CSV es la lista de libros; «datos completos» incluye también progreso, notas y racha; las notas también se pueden sacar en texto.")
                }
            },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text("Cerrar", color = LbBrown) } }
        )
    }
}

// ── Piezas de la pantalla ─────────────────────────────────────────────────────

@Composable
private fun PfDivider() {
    Box(Modifier.width(1.dp).height(38.dp).background(LbLine.copy(alpha = 0.8f)))
}

@Composable
private fun PfStat(modifier: Modifier, icon: @Composable () -> Unit, value: String, label: String) {
    Row(modifier.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        icon()
        Spacer(Modifier.width(5.dp))
        Column {
            Text(value, color = LbTitle, fontSize = 18.sp, fontFamily = LibellumSerif, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(label, color = LbText, fontSize = 10.sp, fontFamily = LibellumSerif, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun PfFav(modifier: Modifier, icon: @Composable () -> Unit, label: String, value: String) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        icon()
        Spacer(Modifier.width(6.dp))
        Column {
            Text(label, color = LbText, fontSize = 10.sp, fontFamily = LibellumSerif, maxLines = 1)
            Text(
                value, color = LbTitle, fontSize = 13.sp, fontFamily = LibellumSerif, fontStyle = FontStyle.Italic,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun PfProgress(modifier: Modifier, icon: @Composable () -> Unit, value: String, label: String) {
    Row(modifier.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        icon()
        Spacer(Modifier.width(6.dp))
        Column {
            Text(value, color = LbTitle, fontSize = 17.sp, fontFamily = LibellumSerif, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(label, color = LbText, fontSize = 11.sp, fontFamily = LibellumSerif, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun PfGoldButton(
    modifier: Modifier, enabled: Boolean = true, onClick: () -> Unit, content: @Composable RowScope.() -> Unit
) {
    Row(
        modifier.clip(RoundedCornerShape(50)).background(GoldFill)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, content = content
    )
}

@Composable
private fun PfOutlineButton(
    modifier: Modifier, enabled: Boolean = true, onClick: () -> Unit, content: @Composable RowScope.() -> Unit
) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier.clip(shape).background(Color(0xFFFFF8EA)).border(1.5.dp, LbBrown.copy(alpha = 0.6f), shape)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, content = content
    )
}

@Composable
private fun PfPill(
    modifier: Modifier, onClick: () -> Unit, icon: @Composable () -> Unit, label: String,
    sub: String? = null, enabled: Boolean = true
) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier.clip(shape).background(Brush.verticalGradient(listOf(LbCardTop, LbCardBottom)))
            .border(1.dp, LbCardEdge, shape).clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        icon()
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = LbTitle, fontSize = 12.sp, fontFamily = LibellumSerif, maxLines = 2, lineHeight = 14.sp)
            if (sub != null) Text(sub, color = LbText, fontSize = 10.sp, fontFamily = LibellumSerif, maxLines = 1)
        }
    }
}

@Composable
private fun PfTile(
    modifier: Modifier, onClick: () -> Unit, horizontal: Boolean, icon: @Composable () -> Unit, label: String,
    enabled: Boolean = true
) {
    LbCard(modifier.clickable(enabled = enabled, onClick = onClick), padding = 12.dp) {
        if (horizontal) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                icon()
                Spacer(Modifier.width(10.dp))
                Text(label, color = LbTitle, fontSize = 13.sp, fontFamily = LibellumSerif, lineHeight = 16.sp, modifier = Modifier.weight(1f))
            }
        } else {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                icon()
                Spacer(Modifier.height(6.dp))
                Text(label, color = LbTitle, fontSize = 11.sp, fontFamily = LibellumSerif, lineHeight = 13.sp, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun PfCsvIcon() {
    Box(Modifier.size(34.dp), contentAlignment = Alignment.Center) {
        LbIcon(LbIconKind.DOC, tint = LbBrown, size = 34.dp)
        Text("CSV", color = LbBrown, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.offset(y = 5.dp))
    }
}

@Composable
private fun PfDiamond() {
    Canvas(Modifier.size(14.dp)) {
        val c = size.width / 2f
        val p = Path().apply {
            moveTo(c, 1f); lineTo(size.width - 1f, c); lineTo(c, size.height - 1f); lineTo(1f, c); close()
        }
        drawPath(p, LbBrownLight, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.6f))
    }
}

@Composable
private fun PfInfoBlock(title: String, body: String) {
    Column {
        Text(title, color = LbBrown, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = LibellumSerif)
        Text(body, color = LbText, fontSize = 13.sp, lineHeight = 18.sp)
    }
}

// ── Utilidades ────────────────────────────────────────────────────────────────

private fun appVersionName(ctx: android.content.Context): String =
    runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "—"

private fun hasAllFilesAccess(): Boolean =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) Environment.isExternalStorageManager() else true

private fun openAllFilesSettings(ctx: android.content.Context) {
    val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
    else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
    runCatching { ctx.startActivity(intent) }.onFailure {
        runCatching { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))) }
    }
}
