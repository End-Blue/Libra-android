# Selección y resaltado de texto a nivel de carácter

## Qué cambia
- **Signos sueltos:** mantener pulsado sobre un «.», «,», «;», símbolo o espacio selecciona ESE carácter
  (antes solo se podían seleccionar palabras). Sobre una letra o dígito se sigue seleccionando la palabra.
- **Arrastre tras la pulsación larga:** lento → carácter a carácter (incluye espacios y puntuación);
  rápido → por palabras. Nunca encoge por debajo de la unidad inicial.
- **Manejadores:** el ajuste ya era carácter/palabra según la velocidad; ahora el extremo contrario puede estar en otra hoja.
  En selecciones cortas de una línea los manejadores se separan hacia fuera para que sus zonas táctiles no se pisen.
- **Auto-giro (equivale al auto-scroll):** arrastrar el manejador final por debajo de la última línea (o el inicial por encima
  de la primera) ~0,45 s gira la hoja sin perder la selección; se repite cada ~1,2 s dentro del capítulo.
  Se desactiva con `SELECTION_AUTO_TURN = false` en `TextSelection.kt`.
- **Barra de acciones inferior** (`SelectionActionBar.kt`): solo los 6 colores (un toque resalta) y un botón de tres puntos
  horizontales con el resto: Copiar, Añadir nota, Buscar, Compartir, Definir, Expandir a frase, Quitar resaltado (solo si la
  selección toca un resaltado) y Limpiar selección. Pasa arriba si la selección queda abajo.
- **Barra de navegación:** la 4.ª pestaña es ahora «Biblioteca» (antes «Racha»); Racha pasa al menú «Más» en el lugar de Biblioteca.
- **Resaltados cortos:** un signo suelto se pinta con un ancho mínimo (rectángulo redondeado) para que se vea claro;
  los extremos de espacio se recortan al resaltar; resaltar de nuevo el mismo rango solo cambia el color.
- **Toque sobre un resaltado** usa el carácter BAJO el dedo (`glyphAt`), también para signos sueltos.

## Archivos
Nuevo: `SelectionActionBar.kt` · Modificados: `PageLayout.kt`, `TextSelection.kt`, `NativeReader.kt`
Sin cambios en base de datos ni en el formato de los resaltados guardados.

# Escáner de libros: solo libros reales

- **Dos fases:** (1) recorrido rápido por extensión y tamaño; (2) validación del contenido de cada candidato, en paralelo (de 4 en 4) y con progreso «Revisando archivos… n/total».
- **EPUB** (ZIP con META-INF/container.xml), **FB2** (contiene `<FictionBook`) y **CBZ** (≥ 5 imágenes y ≥ 80 % del contenido): se descarta lo que sea otra cosa con esa extensión.
- **PDF:** se puntúa por páginas (≥ 80 suma, < 10 descarta), nombre de archivo (factura, recibo, CV, boleto, manual de usuario, scan/IMG…), carpeta (Libros/Books/Calibre suman; WhatsApp/Facturas/Scans restan) y metadatos (título + autor no genérico).
  ≥ 2 → **Libro** (marcado) · de −1 a 1 → **Dudoso** (aparte y sin marcar, con el motivo) · ≤ −2 → se descarta. PDF dañados o con contraseña también se descartan.
- **TXT:** solo si pesa ≥ 100 KB y siempre como dudoso.
- **Carpetas ignoradas** además de las de antes: DCIM, Screenshots/Capturas, Ringtones, Alarms, Notifications, Recordings.
- **Duplicados:** mismo nombre y tamaño en dos carpetas = un solo libro.
- **Diálogo:** chips «Libros n» / «Dudosos n», filtro por tipo dentro de cada grupo, páginas y tamaño legible en cada fila.
- Permisos: sin cambios (sigue «Acceso a todos los archivos» en Android 11+ y lectura en Android 10 o menos).

# Ajustes → «Mi Perfil Lector»

Pantalla nueva (`ProfileScreen.kt`) con el diseño de la imagen de referencia; reutiliza el sistema de diseño de la app
(`HeroHeader`, `LbCard`, `LbSectionHeader`, `LbLink`, `Laurel`). Se abre desde «Más → Ajustes» y desde el engranaje del Panel.

| Elemento | Función |
|---|---|
| Cabecera | Ilustración recortada de la imagen (`hero_profile.webp`) |
| Foto y nombre (lápiz) | Editables: nombre y foto de la galería (recortada a 512 px, se guarda en la app) |
| Título («Explorador Literario») | Según el nº de libros: 0-4 Lector Novel · 5-14 Lector Curioso · 15-49 Explorador Literario · 50-99 Bibliófilo · 100-249 Gran Lector · 250+ Maestro de la Biblioteca |
| Miembro desde | Fecha del libro más antiguo (o primer uso); se fija una vez |
| Libros / Favoritos / Audiolibros / Notas y citas | Contadores reales |
| Autor y género favorito | Mismo criterio que «Tu resumen» |
| Continuar leyendo | Libro en curso (mismo criterio que «Leyendo ahora»), progreso, capítulo y tiempo restante estimado con tu ritmo real; abre el lector |
| Tu progreso | Racha actual, libros del reto y tiempo leído con selector Hoy / Semana / Mes / Año; tocar racha o reto abre su pantalla |
| Copia de seguridad | Estado real: fecha y resultado de la última copia (se guarda al exportar); Exportar y Restaurar |
| Datos y exportación | CSV (existente); NUEVO: datos completos en JSON; «Ver más» → NUEVO: notas y citas en TXT |
| Ajustes y Gestión | Importar, Escanear, Privacidad y seguridad (NUEVO: diálogo con estado del permiso de archivos y acceso a su ajuste), Acerca de (versión real); «Ver todos» → Permiso de archivos y Repetir tutorial |
| Más opciones | Tutorial, Restaurar, Más información (NUEVO: diálogo), Compartir app (texto, sin enlace) |

Notas: la barra inferior conserva «Biblioteca» (antes «Racha»), como se pidió; el SettingsScreen anterior queda sin uso.
Recursos nuevos: hero_profile, profile_avatar, profile_lantern (WebP, recortados de la imagen).
